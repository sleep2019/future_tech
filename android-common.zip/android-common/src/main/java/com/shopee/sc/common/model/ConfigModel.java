package com.shopee.sc.common.model;

import android.content.Context;

import androidx.annotation.IntDef;
import androidx.annotation.Nullable;

import com.google.gson.reflect.TypeToken;
import com.shopee.sc.common.bean.Result;
import com.shopee.sc.common.cache.ACache;
import com.shopee.sc.common.util.AppUtils;
import com.shopee.sc.common.util.GsonUtils;
import com.shopee.sc.logger.api.Logger;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by honggang.xiong on 2019-09-02.
 */
public abstract class ConfigModel<T> extends TypeToken<T> {

    private static final String TAG = "ConfigModel";

    /**
     * Config 获取模式
     */
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({FETCH_MODE_MEMORY, FETCH_MODE_MEMORY_CACHE, FETCH_MODE_MEMORY_CACHE_NETWORK, FETCH_MODE_CACHE,
            FETCH_MODE_CACHE_NETWORK, FETCH_MODE_NETWORK, FETCH_MODE_NETWORK_CACHE})
    public @interface FetchMode {
    }

    /**
     * 当内存中的 config 不为空时，直接返回内存中的 config，
     * 当不需要返回 Single<Result<T>> 形式时，可直接使用 {@link #getConfigDirectly()}
     */
    public static final int FETCH_MODE_MEMORY = 1;
    /**
     * 当 1 失败时，尝试读取缓存 config，成功后更新 内存config
     */
    public static final int FETCH_MODE_MEMORY_CACHE = 2;
    /**
     * 当 1、2 都失败时，尝试拉取后台 config，成功后更新 缓存config、内存config
     */
    public static final int FETCH_MODE_MEMORY_CACHE_NETWORK = 3;
    /**
     * 尝试读取缓存config，成功后更新 内存config
     */
    public static final int FETCH_MODE_CACHE = 4;
    /**
     * 当 4 失败时，尝试拉取后台config，成功后更新 缓存config、内存config
     */
    public static final int FETCH_MODE_CACHE_NETWORK = 5;
    /**
     * 尝试拉取后台config，成功后更新 缓存config、内存config
     */
    public static final int FETCH_MODE_NETWORK = 6;
    /**
     * 当 6 失败时，尝试读取缓存 config，成功后更新 内存config
     */
    public static final int FETCH_MODE_NETWORK_CACHE = 7;

    protected final Result<T> memoryResult = new Result<>((T) null);

    protected ConfigModel() {
        super();
    }

    /**
     * 直接返回config，适用于 需要快速获取Config 或者 对Config实时性要求不高 的场景
     */
    @Nullable
    public T getConfigDirectly() {
        return memoryResult.data;
    }

    /**
     * 拉取后台最新 Config，失败后拉取缓存 Config，适用于 对Config实时性要求较高 的场景
     */
    public Single<Result<T>> getConfigFromNetworkOrCache() {
        return getConfig(ConfigModel.FETCH_MODE_NETWORK_CACHE)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Single<Result<T>> getConfig(@FetchMode int fetchMode) {
        switch (fetchMode) {
            case FETCH_MODE_MEMORY_CACHE:
                return getFromMemoryInternal()
                        .onErrorResumeNext(getFromCacheInternal());
            case FETCH_MODE_MEMORY_CACHE_NETWORK:
                return getFromMemoryInternal()
                        .onErrorResumeNext(getFromCacheInternal())
                        .onErrorResumeNext(getFromNetworkInternal());
            case FETCH_MODE_CACHE:
                return getFromCacheInternal();
            case FETCH_MODE_CACHE_NETWORK:
                return getFromCacheInternal()
                        .onErrorResumeNext(getFromNetworkInternal());
            case FETCH_MODE_NETWORK:
                return getFromNetworkInternal();
            case FETCH_MODE_NETWORK_CACHE:
                return getFromNetworkInternal()
                        .onErrorResumeNext(getFromCacheInternal());
            case FETCH_MODE_MEMORY:
            default:
                return getFromMemoryInternal();
        }
    }

    protected abstract String getCacheKey();

    protected abstract Single<Result<T>> getFromNetwork();

    /**
     * 默认 getFromCache() 及 saveToCache(T) 使用 ACache 缓存，如需修改，可同时重写这两个方法
     */
    protected T getFromCache() {
        Context context = AppUtils.getContext();
        if (context == null) {
            return null;
        }

        String jsonValue = ACache.get(context, true).getString(getCacheKey());
        T config = GsonUtils.fromJson(jsonValue, getType());
        if (Logger.isDebug()) {
            Logger.d(TAG, "getFromCache key=" + getCacheKey() + ", jsonValue=" + jsonValue + ",\n config=" + config);
        }
        return config;
    }

    protected void saveToCache(T config) {
        Context context = AppUtils.getContext();
        if (context == null) {
            return;
        }

        String jsonValue = GsonUtils.toJson(config);
        if (Logger.isDebug()) {
            Logger.d(TAG, "saveToCache key=" + getCacheKey() + ", jsonValue=" + jsonValue + ",\n config=" + config);
        }
        ACache.get(context, true).putString(getCacheKey(), jsonValue);
    }

    private Single<Result<T>> getFromMemoryInternal() {
        if (memoryResult.data == null) {
            return Single.error(new Exception("Config in not initialized!"));
        } else {
            return Single.just(new Result.Builder<>(memoryResult).build());
        }
    }

    private Single<Result<T>> getFromCacheInternal() {
        return Single.defer(() -> {
            T config = getFromCache();
            if (config == null) {
                // cache 中无缓存，清除 内存config
                memoryResult.data = null;
                return Single.error(new Exception("Can't find config in cache!"));
            } else {
                memoryResult.data = config;
                memoryResult.isCache = true;
                return Single.just(new Result.Builder<>(memoryResult).build());
            }
        });
    }

    private Single<Result<T>> getFromNetworkInternal() {
        return getFromNetwork().map(netResult -> {
            if (netResult.isStrictSuccess()) {
                saveToCache(netResult.data);
                memoryResult.data = netResult.data;
                memoryResult.isCache = false;
            }
            return netResult;
        }).doOnError(throwable -> Logger.w(TAG, "getFromNetworkInternal error: " + throwable));
    }

}
