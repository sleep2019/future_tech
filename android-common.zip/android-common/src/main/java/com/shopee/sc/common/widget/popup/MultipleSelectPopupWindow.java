package com.shopee.sc.common.widget.popup;

import android.content.Context;
import android.util.SparseArray;

import com.chad.library.adapter.base.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: MultipleSelectPopupWindow
 * @Description: 可多选的popupwindow
 * @Author: lanjingzeng
 * @CreateDate: 2020-05-09 15:48
 * @Version: 1.0
 */
public abstract class MultipleSelectPopupWindow<T> extends ListPopupWindow<T> {
    private SparseArray<T> mSparseArray;

    public MultipleSelectPopupWindow(Context context, int layoutResID, int recyclerViewId, int itemlayoutResId) {
        super(context, layoutResID, recyclerViewId, itemlayoutResId);
        mSparseArray = new SparseArray<>();
    }

    public void setDefaultSelectedPos(int[] defaultSelectedPosArray) {
        int length = defaultSelectedPosArray == null ? 0 : defaultSelectedPosArray.length;
        if (length == 0) {
            return;
        }
        for (int i = 0; i < length; i++) {
            int position = defaultSelectedPosArray[i];
            if (!(position >= 0 && position < getListSize())) {
                continue;
            }
            mSparseArray.put(position, getAdapter().getItem(position));
            getAdapter().notifyItemChanged(position + getAdapter().getHeaderLayoutCount());
        }
    }

    public void toggleSelect(int position) {
        if (!(position >= 0 && position < getListSize())) {
            return;
        }
        if (mSparseArray.indexOfKey(position) < 0) {
            //小于0说明之前没有选中，此时点击需要选中
            mSparseArray.put(position, getAdapter().getItem(position));
        } else {
            //大于等于0说明之前有选中，此时点击应该不选中
            mSparseArray.delete(position);
        }
        getAdapter().notifyItemChanged(position + getAdapter().getHeaderLayoutCount());
    }

    public List<T> getSelectedList() {
        int size = mSparseArray.size();
        if (size == 0) {
            return null;
        }
        ArrayList<T> arrayList = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            T t = mSparseArray.valueAt(i);
            if (t == null) {
                continue;
            }
            arrayList.add(t);
        }
        return arrayList;
    }

    public Integer[] getSelectedPos() {
        ArrayList<Integer> arrayList = new ArrayList<>();
        int size = mSparseArray.size();
        if (size == 0) {
            return null;
        }
        for (int i = 0; i < size; i++) {
            int key = mSparseArray.keyAt(i);
            if (!(key >= 0 && key < getListSize())) {
                continue;
            }
            arrayList.add(key);
        }
        return (Integer[]) arrayList.toArray();
    }

    @Override
    public void showItem(BaseViewHolder helper, T itemData) {
        int position = getData() == null ? -1 : getData().indexOf(itemData);
        int index = mSparseArray.indexOfKey(position);
        if (index < 0) {
            showItem(helper, itemData, position, false);
        } else {
            showItem(helper, itemData, position, true);
        }
    }

    public abstract void showItem(BaseViewHolder helper, T itemData, int position, boolean isSelected);

}
