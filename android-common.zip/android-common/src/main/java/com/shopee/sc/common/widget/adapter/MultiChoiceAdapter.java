package com.shopee.sc.common.widget.adapter;

import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.sc.common.bean.CheckedItem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-12-06.
 */
public abstract class MultiChoiceAdapter<T> extends BaseQuickAdapter<CheckedItem<T>, BaseViewHolder> {

    private OnMultiCheckedChangeListener<T> mOnMultiCheckedChangeListener;
    private int mCheckedCount;

    public MultiChoiceAdapter(@LayoutRes int layoutResId, List<T> originList, boolean defaultChecked) {
        super(layoutResId, CheckedItem.generateMultiCheckedList(originList, defaultChecked));
        mCheckedCount = defaultChecked ? getData().size() : 0;
    }

    public MultiChoiceAdapter(@LayoutRes int layoutResId, @Nullable List<CheckedItem<T>> data) {
        super(layoutResId, data);
        refreshCheckedCount();
    }

    @Override
    protected BaseViewHolder onCreateDefViewHolder(ViewGroup parent, int viewType) {
        BaseViewHolder viewHolder = super.onCreateDefViewHolder(parent, viewType);
        CompoundButton checkableView = getCheckableView(viewHolder);
        if (checkableView != null) {
            checkableView.setOnClickListener(v -> {
                int position = viewHolder.getLayoutPosition();
                boolean isChecked = checkableView.isChecked();
                if (canToggleItem(position, isChecked)) {
                    toggleCheckedStatus(position, isChecked);
                } else {
                    checkableView.setChecked(!isChecked); // 不可改变时，回退选中状态
                }
            });
        }
        return viewHolder;
    }

    // 是否可以改变子项的选中状态，默认 true；子类可在超过最大数量等场景时返回 false
    protected boolean canToggleItem(int position, boolean targetChecked) {
        return true;
    }

    public void setOnMultiCheckedChangeListener(OnMultiCheckedChangeListener<T> onMultiCheckedChangeListener) {
        mOnMultiCheckedChangeListener = onMultiCheckedChangeListener;
    }

    private void notifyMultiCheckChanged(int position) {
        if (mOnMultiCheckedChangeListener != null) {
            CheckedItem<T> checkedItem = getItem(position);
            mOnMultiCheckedChangeListener.onMultiCheckedChanged(checkedItem != null ? checkedItem.getModel() : null,
                    position, checkedItem != null && checkedItem.isCurrentChecked(), mCheckedCount, getData().size());
        }
    }

    @NonNull
    public List<T> getCheckedItemList() {
        List<T> result = new ArrayList<>();
        for (CheckedItem<T> checkedItem : getData()) {
            if (checkedItem.isCurrentChecked()) {
                result.add(checkedItem.getModel());
            }
        }
        return result;
    }

    @NonNull
    public List<T> getUnCheckedItemList() {
        List<T> result = new ArrayList<>();
        for (CheckedItem<T> checkedItem : getData()) {
            if (!checkedItem.isCurrentChecked()) {
                result.add(checkedItem.getModel());
            }
        }
        return result;
    }

    @NonNull
    public List<T> getItemList() {
        List<T> result = new ArrayList<>();
        for (CheckedItem<T> checkedItem : getData()) {
            result.add(checkedItem.getModel());
        }
        return result;
    }

    public boolean removeCheckedItems() {
        int preCheck = mCheckedCount;
        List<CheckedItem<T>> dataList = getData();
        int size = dataList.size();
        for (int i = size - 1; i >= 0; i--) {
            if (dataList.get(i).isCurrentChecked()) {
                dataList.remove(i);
                mCheckedCount--;
            }
        }
        if (preCheck != mCheckedCount) {
            notifyDataSetChanged();
            notifyMultiCheckChanged(-1);
            return true;
        }
        return false;
    }

    /**
     * @return 返回可选中的列表项总数
     */
    public int getCheckableTotal() {
        int checkableTotal = 0;
        for (CheckedItem<T> data : getData()) {
            if (data.isCheckable()) {
                checkableTotal++;
            }
        }
        return checkableTotal;
    }

    public int getCheckedCount() {
        return mCheckedCount;
    }

    public void toggleCheckedStatus(int position, boolean checked) {
        CheckedItem<T> checkedItem = getItem(position);
        if (checkedItem == null) {
            return;
        }
        if (changeCheckStatusInternal(position, checked)) {
            notifyDataSetChanged();
            mCheckedCount += checked ? 1 : -1;
            notifyMultiCheckChanged(position);
        }
    }

    public void setAllToDefault() {
        boolean changed = false;
        for (CheckedItem<T> checkedItem : mData) {
            if (checkedItem.changeToDefault()) {
                handleItemCheckedStatusChanged(checkedItem);
                changed = true;
            }
        }
        if (changed) {
            notifyDataSetChanged();
            refreshCheckedCount();
            notifyMultiCheckChanged(-1);
        }
    }

    public void checkAll() {
        setAllToStatus(true, true);
    }

    public void checkAll(boolean changeUncheckable) {
        setAllToStatus(true, changeUncheckable);
    }

    public void clearCheck() {
        setAllToStatus(false, true);
    }

    public void clearCheck(boolean changeUncheckable) {
        setAllToStatus(false, changeUncheckable);
    }

    private void setAllToStatus(boolean checked, boolean changeUncheckable) {
        boolean changed = false;
        boolean canChange;
        for (CheckedItem<T> checkedItem : mData) {
            canChange = changeUncheckable || checkedItem.isCheckable();
            if (canChange && checkedItem.changeCurrentChecked(checked)) {
                handleItemCheckedStatusChanged(checkedItem);
                changed = true;
            }
        }
        if (changed) {
            refreshCheckedCount();
            notifyDataSetChanged();
            notifyMultiCheckChanged(-1);
        }
    }

    private void refreshCheckedCount() {
        mCheckedCount = 0;
        for (CheckedItem<T> item : getData()) {
            if (item.isCurrentChecked()) {
                mCheckedCount++;
            }
        }
    }

    @Override
    public void setNewData(@Nullable List<CheckedItem<T>> data) {
        super.setNewData(data);
        refreshCheckedCount();
        notifyMultiCheckChanged(-1);
    }

    @Override
    public void addData(int position, @NonNull CheckedItem<T> data) {
        super.addData(position, data);
        if (data.isCurrentChecked()) {
            mCheckedCount++;
        }
        notifyMultiCheckChanged(position);
    }

    @Override
    public void addData(@NonNull CheckedItem<T> data) {
        super.addData(data);
        if (data.isCurrentChecked()) {
            mCheckedCount++;
        }
        notifyMultiCheckChanged(getData().size() - 1);
    }

    @Override
    public void remove(int position) {
        super.remove(position);
        refreshCheckedCount();
        notifyMultiCheckChanged(-1);
    }

    @Override
    public void setData(int index, @NonNull CheckedItem<T> data) {
        super.setData(index, data);
        refreshCheckedCount();
        notifyMultiCheckChanged(index);
    }

    @Override
    public void addData(int position, @NonNull Collection<? extends CheckedItem<T>> newData) {
        super.addData(position, newData);
        refreshCheckedCount();
        notifyMultiCheckChanged(-1);
    }

    @Override
    public void addData(@NonNull Collection<? extends CheckedItem<T>> newData) {
        super.addData(newData);
        refreshCheckedCount();
        notifyMultiCheckChanged(-1);
    }

    @Override
    public void replaceData(@NonNull Collection<? extends CheckedItem<T>> data) {
        super.replaceData(data);
        refreshCheckedCount();
        notifyMultiCheckChanged(-1);
    }

    private boolean changeCheckStatusInternal(int position, boolean checked) {
        CheckedItem<T> item = getItem(position);
        if (item != null) {
            if (item.changeCurrentChecked(checked)) {
                handleItemCheckedStatusChanged(item);
                return true;
            }
        }
        return false;
    }

    // item checked 状态变化回调，子类可据此做更新数据类的操作
    protected void handleItemCheckedStatusChanged(@NonNull CheckedItem<T> checkedItem) {

    }


    /**
     * 可取消选中时，使用 {@link android.widget.CheckBox}
     * 不可取消选中时，使用 {@link android.widget.RadioButton}
     */
    protected abstract CompoundButton getCheckableView(BaseViewHolder viewHolder);


    public interface OnMultiCheckedChangeListener<T> {
        /**
         * 当选项列表中的单个或多个选择发生变化时，回调该方法。
         *
         * @param data         发生变化的单个选项实体，批量变化时为 null
         * @param position     发生变化的单个选项的 index，批量变化时为 -1
         * @param checked      发生变化的单个选项的当前选中状态，批量变化时为 false
         * @param checkedCount 当前已选中的选项数量
         * @param total        总选项数量
         */
        void onMultiCheckedChanged(T data, int position, boolean checked, int checkedCount, int total);
    }
}
