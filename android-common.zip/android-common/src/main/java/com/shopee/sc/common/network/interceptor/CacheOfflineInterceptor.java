package com.shopee.sc.common.network.interceptor;

import android.content.Context;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.CacheControl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

import static com.shopee.sc.common.network.NetConstant.DEFAULT_CACHE_TIME;
import static com.shopee.sc.common.network.NetConstant.HEADER_CACHE_CONTROL;
import static com.shopee.sc.common.network.NetConstant.HEADER_CACHE_PRAGMA;
import static com.shopee.sc.common.util.NetworkUtils.isConnected;

public class CacheOfflineInterceptor implements Interceptor {

    private Context mContext;
    private long mCacheTime;

    public CacheOfflineInterceptor(Context context) {
        this(context, DEFAULT_CACHE_TIME);
    }

    public CacheOfflineInterceptor(Context context, long cacheTime) {
        mContext = context;
        mCacheTime = cacheTime;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();

        if (!isConnected(mContext)) {
            /**
             * 离线缓存设置有效期限，不使用{@link CacheControl#FORCE_CACHE}，因为它有个很大的默认超时时间{@link Integer.MAX_VALUE}
             * 新建一个{@link CacheControl}
             */
            CacheControl cacheControl = new CacheControl.Builder().onlyIfCached().maxStale((int) mCacheTime, TimeUnit.SECONDS).build();
            request = request.newBuilder().cacheControl(cacheControl).build();
            Response response = chain.proceed(request);
            /**
             * 离线缓存，重新设置请求
             * max-stale设置缓存策略，及超时策略
             */
            return response.newBuilder().removeHeader(HEADER_CACHE_PRAGMA).removeHeader(HEADER_CACHE_CONTROL).header(HEADER_CACHE_CONTROL, "public, only-if-cached, max-stale=" + mCacheTime).build();
        }
        return chain.proceed(request);
    }
}
