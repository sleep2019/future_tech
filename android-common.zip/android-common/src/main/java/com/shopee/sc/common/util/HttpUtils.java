package com.shopee.sc.common.util;

import okhttp3.HttpUrl;

public class HttpUtils {
    public static String parseUrl(String ip, String port) {
        String res = "https://" + ip + ":" + port;
        try {
            HttpUrl.get(res);
        } catch (IllegalArgumentException e) {
            // url 不合规，即 ip 和 port 有问题
            return "";
        }
        return res;
    }
}
