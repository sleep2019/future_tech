package com.shopee.sc.common.helper.paging;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;

import com.shopee.sc.common.bean.PagingBean;

/**
 * 基本的分页回调
 * <p>
 * Created by honggang.xiong on 2021/11/15.
 */
public interface PagingCallback<T> {

    /**
     * 分页数据加载成功回调
     *
     * @param type       分页类型
     * @param pagingBean 分页数据
     */
    @MainThread
    void handleDataList(@NonNull PagingType type, @NonNull PagingBean<T> pagingBean);

    /**
     * 分页数据加载失败回调
     *
     * @param type 分页类型
     */
    @MainThread
    void handleLoadFailed(@NonNull PagingType type);

    /**
     * 分页数据加载取消回调
     *
     * @param type 分页类型
     */
    @MainThread
    default void handleLoadCancelled(@NonNull PagingType type) {
    }

}
