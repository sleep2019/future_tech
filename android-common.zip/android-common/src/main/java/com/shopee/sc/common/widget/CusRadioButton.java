package com.shopee.sc.common.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.RadioButton;

import com.shopee.sc.common.widget.helper.TextViewCompatHelper;

@SuppressLint("AppCompatCustomView")
public class CusRadioButton extends RadioButton {

    private final TextViewCompatHelper mHelper = new TextViewCompatHelper();

    public CusRadioButton(Context context) {
        super(context);
    }

    public CusRadioButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CusRadioButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        mHelper.tryDetectInconsistentDrawableStateOnMeasure(this);
    }

}
