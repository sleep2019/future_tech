package com.shopee.sc.common.util;

import java.util.Collection;
import java.util.List;

public class CollectionUtils {
    /**
     * 把字符串列表转成带自定义有分隔符的字符串
     *
     * @param list      字符串列表
     * @param delimiter 分隔符
     * @return 带自定义有分隔符的字符串
     */
    public static String joining(List<String> list, String delimiter) {
        if (list == null || list.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            sb.append(list.get(i));
            if (i < list.size() - 1) {
                sb.append(delimiter);
            }
        }
        return sb.toString();
    }

    public static boolean equalsSize(Collection<?> collection1, Collection<?> collection2) {
        int size1 = collection1 == null ? 0 : collection1.size();
        int size2 = collection2 == null ? 0 : collection2.size();

        return size1 == size2;
    }
}
