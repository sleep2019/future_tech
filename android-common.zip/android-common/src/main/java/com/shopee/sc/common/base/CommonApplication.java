package com.shopee.sc.common.base;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;

import com.shopee.sc.logger.api.Logger;

/**
 * CommonApplication
 */
public class CommonApplication extends Application {

    public final static String TAG = "App";

    @SuppressLint("StaticFieldLeak")
    private static Context sContext;

    private static boolean sAppColdStart = true;

    @Override
    public void onCreate() {
        super.onCreate();
        sContext = getApplicationContext();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        Logger.d(TAG, "onTerminate");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Logger.d(TAG, "onTrimMemory:" + level);
    }

    public static boolean isAppColdStart() {
        return sAppColdStart;
    }

    public static void setAppColdStart(boolean appColdStart) {
        sAppColdStart = appColdStart;
    }

    public static Context getContext() {
        return sContext;
    }

    protected static void setContext(Context context) {
        sContext = context;
    }
}
