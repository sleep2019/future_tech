package com.shopee.sc.common.util;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.sc.common.R;
import com.shopee.sc.common.bean.Result;
import com.shopee.sc.common.functions.IExecutor;
import com.shopee.sc.common.plugins.CommonPlugins;
import com.shopee.sc.logger.api.Logger;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import io.reactivex.Scheduler;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BiConsumer;

/**
 * Created by honggang.xiong on 2019-08-26.
 */
public class RxUtils {

    static final BiConsumer<Object, Throwable> EMPTY_BI_CONSUMER = new BiConsumer<Object, Throwable>() {
        @Override
        public void accept(Object o, Throwable throwable) throws Exception {
            if (throwable != null) {
                Logger.w("EMPTY_BI_CONSUMER get error: " + throwable);
            }
        }
    };

    private RxUtils() {
    }

    public static void dispose(Disposable disposable) {
        if (disposable != null && !disposable.isDisposed()) {
            disposable.dispose();
        }
    }

    @SuppressWarnings("unchecked")
    public static <T> BiConsumer<T, Throwable> emptyBiConsumer() {
        return (BiConsumer<T, Throwable>) EMPTY_BI_CONSUMER;
    }

    public static IExecutor wrapScheduler(@NonNull Scheduler scheduler) {
        Objects.requireNonNull(scheduler, "scheduler cannot be null!");
        return new IExecutor() {
            @Override
            public void execute(@NonNull Runnable command, long delay, TimeUnit unit) {
                scheduler.scheduleDirect(command, delay, unit);
            }

            @Override
            public void execute(@NonNull Runnable command) {
                scheduler.scheduleDirect(command);
            }
        };
    }

    public static <T> BiConsumer<Result<T>, Throwable> successConsumer(@NonNull SuccessConsumer<T> consumer) {
        return successConsumer(consumer, null);
    }

    /**
     * 包装 {@link SuccessConsumer}, 返回通用 {@link BiConsumer}，retcode == 0 即回调 SuccessConsumer
     */
    public static <T> BiConsumer<Result<T>, Throwable> successConsumer(@NonNull SuccessConsumer<T> consumer,
                                                                       @Nullable String tag) {
        return new BiConsumer<Result<T>, Throwable>() {
            @Override
            public void accept(Result<T> result, Throwable throwable) throws Exception {
                if (result != null) {
                    if (result.isSuccess()) {
                        consumer.onSuccess(result.data);
                    } else {
                        CommonPlugins.getToaster().toast(result);
                    }
                } else {
                    if (tag != null) {
                        Logger.w(tag + " failed: " + throwable);
                    }
                    CommonPlugins.getToaster().toast(throwable);
                }
            }
        };
    }

    public static <T> BiConsumer<Result<T>, Throwable> strictSuccessConsumer(@NonNull StrictSuccessConsumer<T> consumer) {
        return strictSuccessConsumer(consumer, null);
    }

    /**
     * 包装 {@link StrictSuccessConsumer}, 返回通用 {@link BiConsumer}，retcode == 0 且结果非空才回调 StrictSuccessConsumer
     */
    public static <T> BiConsumer<Result<T>, Throwable> strictSuccessConsumer(@NonNull StrictSuccessConsumer<T> consumer,
                                                                             @Nullable String tag) {
        return new BiConsumer<Result<T>, Throwable>() {
            @Override
            public void accept(Result<T> result, Throwable throwable) throws Exception {
                if (result != null) {
                    if (result.isSuccess()) {
                        if (result.data != null) {
                            consumer.onStrictSuccess(result.data);
                        } else {
                            // 需要结果对象但后台未返回
                            CommonPlugins.getToaster().showShort(R.string.common_system_error);
                        }
                    } else {
                        CommonPlugins.getToaster().toast(result);
                    }
                } else {
                    if (tag != null) {
                        Logger.w(tag + " failed: " + throwable);
                    }
                    CommonPlugins.getToaster().toast(throwable);
                }
            }
        };
    }

    public static <T> BiConsumer<Result<T>, Throwable> commonConsumer(@NonNull CommonConsumer<T> consumer) {
        return commonConsumer(consumer, null);
    }

    public static <T> BiConsumer<Result<T>, Throwable> commonConsumer(@NonNull CommonConsumer<T> consumer,
                                                                      @Nullable String tag) {
        return new BiConsumer<Result<T>, Throwable>() {
            @Override
            public void accept(Result<T> result, Throwable throwable) throws Exception {
                if (result != null) {
                    if (result.isSuccess()) {
                        consumer.onSuccess(result.data);
                    } else {
                        consumer.onFail();
                        CommonPlugins.getToaster().toast(result);
                    }
                } else {
                    if (tag != null) {
                        Logger.w(tag + " failed: " + throwable);
                    }
                    consumer.onFail();
                    CommonPlugins.getToaster().toast(throwable);
                }
            }
        };
    }


    public interface SuccessConsumer<T> {
        void onSuccess(@Nullable T successData);
    }

    public interface StrictSuccessConsumer<T> {
        void onStrictSuccess(@NonNull T successData);
    }

    public interface CommonConsumer<T> extends SuccessConsumer<T> {
        void onFail();
    }

}
