package com.shopee.sc.common.widget.dropdown;

import android.view.View;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Objects;

/**
 * 封装 CheckBox 的 DropDownTrigger，CheckBox 的 OnClickListener 已被替换，如需设置可使用本类的
 * {@link #setOuterOnClickListener(View.OnClickListener)}。
 * <p>
 * Created by honggang.xiong on 2021/4/7.
 */
public class CheckBoxDropDownTrigger implements IDropDownTrigger, View.OnClickListener {

    private final CheckBox mCheckBox;
    private final View mBgCheckBox;
    private View.OnClickListener mOuterOnClickListener;
    private OnTriggerClickListener mOnTriggerClickListener;

    public CheckBoxDropDownTrigger(@NonNull CheckBox checkBox) {
        this(checkBox, null);
    }

    /**
     * 自动协调 CheckBox 及其外层背景 View
     */
    public CheckBoxDropDownTrigger(@NonNull CheckBox checkBox, @Nullable View bgCheckBox) {
        mCheckBox = Objects.requireNonNull(checkBox);
        mBgCheckBox = bgCheckBox;
        if (mBgCheckBox != null) {
            mCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> mBgCheckBox.setSelected(isChecked));
            mBgCheckBox.setOnClickListener(v -> mCheckBox.performClick());
        }
    }

    @Override
    public boolean isChecked() {
        return mCheckBox.isChecked();
    }

    @Override
    public void setChecked(boolean isChecked) {
        mCheckBox.setChecked(isChecked);
    }

    @Override
    public void setOnTriggerClickListener(@Nullable OnTriggerClickListener listener) {
        mOnTriggerClickListener = listener;
        checkListenerInternal();
    }

    public void setOuterOnClickListener(@Nullable View.OnClickListener outerOnClickListener) {
        mOuterOnClickListener = outerOnClickListener;
        checkListenerInternal();
    }

    @Override
    public void onClick(View v) {
        if (mOuterOnClickListener != null) {
            mOuterOnClickListener.onClick(v);
        }
        if (mOnTriggerClickListener != null) {
            mOnTriggerClickListener.onTriggerClick(this, mCheckBox.isChecked());
        }
    }

    private void checkListenerInternal() {
        if (mOuterOnClickListener != null || mOnTriggerClickListener != null) {
            mCheckBox.setOnClickListener(this);
        } else {
            mCheckBox.setOnClickListener(null);
        }
    }

}
