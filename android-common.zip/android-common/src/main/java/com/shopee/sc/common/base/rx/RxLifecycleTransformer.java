package com.shopee.sc.common.base.rx;

import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;

import com.trello.lifecycle2.android.lifecycle.AndroidLifecycle;
import com.trello.rxlifecycle3.LifecycleProvider;

import io.reactivex.ObservableTransformer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class RxLifecycleTransformer {

    @SuppressWarnings("unchecked")
    public static <T> ObservableTransformer<T, T> ioToMain(@NonNull LifecycleOwner lifecycleOwner) {
        return upstream -> upstream
                .compose(getIoMainTransformer())
                .compose(getLifecycleProvider(lifecycleOwner).bindUntilEvent(Lifecycle.Event.ON_DESTROY));
    }

    @SuppressWarnings("rawtypes")
    private static ObservableTransformer getIoMainTransformer() {
        return upstream -> upstream
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @NonNull
    private static LifecycleProvider<Lifecycle.Event> getLifecycleProvider(@NonNull LifecycleOwner lifecycleOwner) {
        return AndroidLifecycle.createLifecycleProvider(lifecycleOwner);
    }
}
