package com.shopee.sc.common.misc;

import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;

import com.shopee.sc.common.R;
import com.shopee.sc.common.plugins.CommonPlugins;
import com.shopee.sc.common.util.AppUtils;
import com.shopee.sc.common.util.NumberUtils;

/**
 * Created by chris on 2019/1/28.
 */
public class NumRangeInputFilter implements InputFilter {

    private static final String TAG = "NumRangeInputFilter";
    // 只允许输入数字和小数点
    private static final String REGEX = "([0-9]|\\.)*";

    private static final String POINTER = ".";

    private static final String ZERO_ZERO = "00";
    // 输入的最大数
    private float mMaxValue;
    // 输入的最小数
    private float mMinValue = Integer.MIN_VALUE;
    // 小数点后的位数
    private int mMaxPointerLength = 1;

    private OnNumRangInputListener mOnNumRangInputListener;

    public NumRangeInputFilter() {
    }

    public NumRangeInputFilter(int maxValue) {
        this.mMaxValue = maxValue;
    }

    public NumRangeInputFilter(int maxValue, int maxPointerLength) {
        this.mMaxValue = maxValue;
        this.mMaxPointerLength = maxPointerLength;
    }

    public NumRangeInputFilter(int maxValue, int minValue, int maxPointerLength) {
        this.mMaxValue = maxValue;
        this.mMinValue = minValue;
        this.mMaxPointerLength = maxPointerLength;
    }

    public NumRangeInputFilter(float maxValue, float minValue, int maxPointerLength,
                               OnNumRangInputListener onNumRangInputListener) {
        mMaxValue = maxValue;
        mMinValue = minValue;
        mMaxPointerLength = maxPointerLength;
        mOnNumRangInputListener = onNumRangInputListener;
    }

    /**
     * @param source 新输入的字符串
     * @param start  新输入的字符串起始下标，一般为0
     * @param end    新输入的字符串终点下标，一般为source长度-1
     * @param dest   输入之前文本框内容
     * @param dstart 原内容起始坐标，一般为0
     * @param dend   原内容终点坐标，一般为dest长度-1
     * @return 输入内容
     */
    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        String sourceText = source.toString();
        String destText = dest.toString();

        // 新输入的字符串为空（删除剪切等）
        if (TextUtils.isEmpty(sourceText)) {
            return "";
        }

        // 拼成字符串
        String temp = destText.substring(0, dstart)
                + sourceText.substring(start, end)
                + destText.substring(dend, dest.length());
//        LogUtils.v(TAG, "-" + temp);

        // 纯数字加小数点
        if (!temp.matches(REGEX)) {
            return dest.subSequence(dstart, dend);
        }

        // 小数点的情况
        if (temp.contains(POINTER)) {
            // 第一位就是小数点
            if (temp.startsWith(POINTER)) {
                return dest.subSequence(dstart, dend);
            }
            // 不止一个小数点
            if (temp.indexOf(POINTER) != temp.lastIndexOf(POINTER)) {
                return dest.subSequence(dstart, dend);
            }
        }

        double sumText = Double.parseDouble(temp);
        if (mMaxValue != Integer.MAX_VALUE) {
            // 超出最大值
            if (sumText > mMaxValue) {
                if (mOnNumRangInputListener != null) {
                    mOnNumRangInputListener.onExceededMaxInput();
                } else {
                    String msg = AppUtils.string(R.string.common_input_num_no_over_x,
                            NumberUtils.subLastZeroAndDot(String.valueOf(mMaxValue)));
                    CommonPlugins.getToaster().showShort(msg);
                }
                return dest.subSequence(dstart, dend);
            }
        }

        if (mMinValue != Integer.MIN_VALUE) {
            // 低于最小值
            if (sumText < mMinValue) {
                if (mOnNumRangInputListener != null) {
                    mOnNumRangInputListener.onBelowMinInput();
                } else {
                    String msg = AppUtils.string(R.string.common_input_num_not_less_than_x,
                            NumberUtils.subLastZeroAndDot(String.valueOf(mMinValue)));
                    CommonPlugins.getToaster().showShort(msg);
                }
                return dest.subSequence(dstart, dend);
            }
        }
        // 有小数点的情况下
        if (temp.contains(POINTER)) {
            //验证小数点精度，保证小数点后只能输入两位
            if (!temp.endsWith(POINTER) && temp.split("\\.")[1].length() > mMaxPointerLength) {
                return dest.subSequence(dstart, dend);
            }
        } else if (temp.startsWith(POINTER) || temp.startsWith(ZERO_ZERO)) {
            // 首位只能有一个0
            return dest.subSequence(dstart, dend);
        }

        return source;
    }

    public void setMaxValue(int maxValue) {
        mMaxValue = maxValue;
    }

    public void setMinValue(int minValue) {
        mMinValue = minValue;
    }

    public void setMaxPointerLength(int maxPointerLength) {
        mMaxPointerLength = maxPointerLength;
    }

    public void setOnNumRangInputListener(OnNumRangInputListener onNumRangInputListener) {
        mOnNumRangInputListener = onNumRangInputListener;
    }

    public interface OnNumRangInputListener {
        void onExceededMaxInput();

        default void onBelowMinInput() {

        }
    }
}
