package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Switch;

public class CusSwitch extends Switch {
    public CusSwitch(Context context) {
        super(context);
    }

    public CusSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CusSwitch(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
