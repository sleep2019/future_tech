package com.shopee.sc.common.manager;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

/**
 * @ClassName: AppFBInspectorManager
 * @Description: 监控app当前是前台还是后台
 * @Author: Lanjing Zeng
 * @CreateDate: 2021/12/11 7:54 PM
 * @Version: 1.0
 */
public final class AppFBInspectorManager {
    private static final String TAG = "AppFBInspectorManager";
    private static volatile AppFBInspectorManager mInstance;
    /**
     * Splash页面的全限定类名
     */
    private String mSplashName;
    private int mCurrentProcessRunningActivityCount;
    private RunningPageListener mRunningPageListener;
    private ArrayList<AppInspectorListener> mAppInspectorListeners;
    /**
     * 如果是从点击桌面icon重新启动应用，此时最先启动的是SplashActivity，由于此页面只是一个闪屏页，很快会被finish掉，
     * 因此有时(例如申请悬浮窗权限，且需要监听授权成功的回调并添加业务逻辑)需要延后将逻辑放在下一个页面去处理(登录页或者首页)
     */
    private ArrayList<AppInspectorListener> mPendingInspectorListeners;
    private int mOtherProcessRunningPageCount;
    /**
     * 应用页面是否位于多个进程中
     */
    private boolean mMultipleProcessHasRunningPage;

    private AppFBInspectorManager() {
        mAppInspectorListeners = new ArrayList<>();
        mPendingInspectorListeners = new ArrayList<>();
    }

    public static AppFBInspectorManager getInstance() {
        if (mInstance == null) {
            synchronized (AppFBInspectorManager.class) {
                if (mInstance == null) {
                    mInstance = new AppFBInspectorManager();
                }
            }
        }
        return mInstance;
    }

    public void setRunningPageListener(RunningPageListener runningPageListener) {
        this.mRunningPageListener = runningPageListener;
    }

    /**
     * 设置闪屏页的全限定类名，如果需要跳过闪屏页，则使用此api设置闪屏页类名
     * <p>
     * 外部类:packageName+className   内部类:packageName+classNameOuter$className
     *
     * @param splashName 例如：com.shopee.servicepoint.SplashActivity
     */
    public void setSplashName(String splashName) {
        this.mSplashName = splashName;
    }

    public void addAppInspectorListener(AppInspectorListener appInspectorListener) {
        if (appInspectorListener == null) {
            return;
        }
        if (appInspectorListener.needSkipSplash() && TextUtils.isEmpty(mSplashName)) {
            throw new IllegalArgumentException("AppFBInspectorManager:Need to skip splash page,but not set SplashName.....");
        }
        this.mAppInspectorListeners.add(appInspectorListener);
    }

    public void removeAppInspectorListener(AppInspectorListener appInspectorListener) {
        if (appInspectorListener == null) {
            return;
        }
        this.mAppInspectorListeners.remove(appInspectorListener);
    }

    public void onForegroundFirst(Activity activity, boolean isSplashPage) {
//        Logger.i(TAG, "onForegroundFirst() activity:" + activity);
        mPendingInspectorListeners.clear();
        int size = mAppInspectorListeners.size();
        for (int index = 0; index < size; index++) {
            AppInspectorListener listener = mAppInspectorListeners.get(index);
            if (listener == null) {
                continue;
            }
            if (listener.needSkipSplash() && isSplashPage) {
                mPendingInspectorListeners.add(listener);
                continue;
            }
            listener.onForeground(activity);
        }
    }

    public void onForegroundSecond(Activity activity, boolean isSplashPage) {
        if (isSplashPage) {
            return;
        }
        int size = mPendingInspectorListeners.size();
//        Logger.i(TAG, "onForegroundSecond() mPendingInspectorListeners size:" + size);
        for (int index = 0; index < size; index++) {
            AppInspectorListener listener = mPendingInspectorListeners.get(index);
            if (listener == null) {
                continue;
            }
            if (listener.needSkipSplash()) {
                listener.onForeground(activity);
            }
        }
        mPendingInspectorListeners.clear();
    }

    public void onBackground(Activity activity) {
        int size = mAppInspectorListeners.size();
        for (int index = 0; index < size; index++) {
            AppInspectorListener listener = mAppInspectorListeners.get(index);
            if (listener == null) {
                continue;
            }
            listener.onBackground(activity);
        }
    }

    public void init(Application application) {
        init(false, application);
    }

    public void init(boolean multipleProcessHasRunningPage, Application application) {
        mMultipleProcessHasRunningPage = multipleProcessHasRunningPage;
        if (mMultipleProcessHasRunningPage) {
            if (mRunningPageListener == null) {
                throw new IllegalArgumentException("AppFBInspectorManager:There are running pages in multiple process,but not set RunningPageListener...");
            }
        }
        application.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
            }

            @Override
            public void onActivityStarted(@NonNull Activity activity) {
                if (mCurrentProcessRunningActivityCount == 0) {
                    mOtherProcessRunningPageCount = mMultipleProcessHasRunningPage ?
                            getOtherProcessRunningPageNumber(mRunningPageListener) : 0;
                    if (mOtherProcessRunningPageCount == 0) {
                        onForegroundFirst(activity, isSplash(activity));
                    }
                }
                int pendingSize = mPendingInspectorListeners.size();
//                Logger.i(TAG, "onForeground() mPendingInspectorListeners size:" + pendingSize);
                if (pendingSize > 0 && mCurrentProcessRunningActivityCount == 1) {
                    onForegroundSecond(activity, isSplash(activity));
                }
                mCurrentProcessRunningActivityCount++;
            }

            @Override
            public void onActivityResumed(@NonNull Activity activity) {

            }

            @Override
            public void onActivityPaused(@NonNull Activity activity) {

            }

            @Override
            public void onActivityStopped(@NonNull Activity activity) {
                mCurrentProcessRunningActivityCount--;
                if (mCurrentProcessRunningActivityCount > 0) {
                    return;
                }
                mOtherProcessRunningPageCount = mMultipleProcessHasRunningPage ?
                        getOtherProcessRunningPageNumber(mRunningPageListener) : 0;
                if (mOtherProcessRunningPageCount > 0) {
                    return;
                }
                onBackground(activity);
            }

            @Override
            public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(@NonNull Activity activity) {

            }
        });
    }

    private boolean needInspect() {
        if (mAppInspectorListeners == null || mAppInspectorListeners.size() == 0) {
            return false;
        }
        return true;
    }

    private int getOtherProcessRunningPageNumber(RunningPageListener runningPageListener) {
        if (runningPageListener == null) {
            return 0;
        }
        return runningPageListener.getOtherProcessRunningPageNumber();
    }

    private boolean isSplash(Activity activity) {
        return activity.getClass().getName().equals(mSplashName);
    }

    public int getRunningPageCount() {
        return mCurrentProcessRunningActivityCount;
    }

    public interface AppInspectorListener {
        /**
         * 是否需要跳过闪屏页
         *
         * @return
         */
        default boolean needSkipSplash() {
            return false;
        }

        /**
         * 应用在前台时的回调方法
         *
         * @param activity
         */
        default void onForeground(Activity activity) {
        }

        /**
         * 应用在后台时的回调方法
         *
         * @param activity
         */
        default void onBackground(Activity activity) {
        }
    }

    public interface RunningPageListener {
        int getOtherProcessRunningPageNumber();
    }
}
