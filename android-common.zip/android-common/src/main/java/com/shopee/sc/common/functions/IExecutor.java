package com.shopee.sc.common.functions;

import androidx.annotation.NonNull;

import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/**
 * Created by honggang.xiong on 2020/8/7.
 */
public interface IExecutor extends Executor {

    void execute(@NonNull Runnable command, long delay, TimeUnit unit);

}
