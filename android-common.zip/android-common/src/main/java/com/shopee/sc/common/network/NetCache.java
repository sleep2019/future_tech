package com.shopee.sc.common.network;

import android.text.TextUtils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;

import io.reactivex.disposables.Disposable;
import retrofit2.Call;

public class NetCache {
    /**
     * 网络请求队列
     */
    private final Map<String, Object> CALL_MAP = new HashMap<>();
    private Object mLock = new Object();

    private NetCache() {
    }

    private static class NetCacheHoldInner {
        private static NetCache mInstance = new NetCache();
    }

    public static NetCache getInstance() {
        return NetCacheHoldInner.mInstance;
    }

    /**
     * 判断请求队列是否存在，以 tag 作为标识
     *
     * @param tag
     * @return
     */
    public boolean containsRequest(Object tag) {
        return containsRequest(tag, null);
    }

    /**
     * 判断请求队列是否存在，以 tag + key 作为标识
     *
     * @param tag
     * @param key
     * @return
     */
    public boolean containsRequest(Object tag, String key) {
        if (tag == null) {
            return false;
        }
        String cacheKey = getReqCacheKey(tag, key);
        synchronized (mLock) {
            return CALL_MAP.containsKey(cacheKey);
        }
    }

    /**
     * 添加网络请求队列，以 tag + key 作为标识
     *
     * @param tag     标签
     * @param key     该字段用于需要取消单个请求的情况，表示单个请求的标记符 注：优先使用外部调用者传入的key作为网络请求tag标记的一部分，若外部没有传，默认取请求的完整url
     * @param request 网络请求
     */
    public void addSingleRequest(Object tag, String key, Object request) {
        if (tag == null) {
            return;
        }
        if (TextUtils.isEmpty(key)) {
            if (request instanceof Call) {
                key = getUrlFromCall((Call) request);
            }
        }
        String reqKey = getReqCacheKey(tag, key);
        synchronized (mLock) {
            CALL_MAP.put(reqKey, request);
        }
    }

    private String getUrlFromCall(Call call) {
        String url = "";
        if (call == null) {
            return url;
        }
        if (call != null && call.request() != null) {
            url = call.request().url().url().toString();
        }
        return url;
    }

    /**
     * 根据tag + key 标识删除队列里的完成、错误的某个网络请求
     *
     * @param tag     标签
     * @param key     该字段用于需要取消单个请求的情况，表示单个请求的标记符 注：优先使用外部调用者传入的key作为网络请求tag标记的一部分，若外部没有传，默认取请求的完整url
     * @param request 网络请求
     */
    public void removeRequest(Object tag, String key, Object request) {
        if (tag == null) {
            return;
        }
        if (TextUtils.isEmpty(key)) {
            if (request instanceof Call) {
                key = getUrlFromCall((Call) request);
            }
        }
        String reqKey = getReqCacheKey(tag, key);
        synchronized (mLock) {
            if (CALL_MAP.containsKey(reqKey)) {
                CALL_MAP.remove(reqKey);
            }
        }
    }

    private String getReqCacheKey(Object tag, String key) {
        String cacheKey = "";
        if (tag == null) {
            return cacheKey;
        }
        if (TextUtils.isEmpty(key)) {
            key = "";
        }
        cacheKey = tag.toString() + key;
        return cacheKey;
    }

    /**
     * 取消单个界面的所有请求，或取消某个tag的所有请求
     * 如果想取消单个请求，请传入 标识：tag.toString() + url
     * <p>
     * 遍历删除，使用迭代
     *
     * @param tag 标签
     */
    public void cancel(Object tag) {
        if (tag == null) {
            return;
        }
        synchronized (mLock) {
            for (Iterator<String> iterator = CALL_MAP.keySet().iterator(); iterator.hasNext(); ) {
                String key = iterator.next();
                if (key.startsWith(tag.toString())) {
                    cancel(key);
                    iterator.remove();
                }
            }
        }
    }

    public void cancel(Object tag, String key) {
        if (tag == null) {
            return;
        }
        String cacheKey = getReqCacheKey(tag, key);
        synchronized (mLock) {
            for (Iterator<String> iterator = CALL_MAP.keySet().iterator(); iterator.hasNext(); ) {
                String itemKey = iterator.next();
                if (itemKey.equals(cacheKey)) {
                    cancel(key);
                    iterator.remove();
                }
            }
        }
    }

    /**
     * 通过正则表达式取消请求
     *
     * @param pattern
     */
    public void cancel(Pattern pattern) {
        if (pattern == null) {
            return;
        }
        synchronized (mLock) {
            for (Iterator<String> iterator = CALL_MAP.keySet().iterator(); iterator.hasNext(); ) {
                String key = iterator.next();
                if (pattern.matcher(key).matches()) {
                    cancel(key);
                    iterator.remove();
                }
            }
        }
    }

    /**
     * 取消所有网络请求
     */
    public void cancelAll() {
        synchronized (mLock) {
            for (String key : CALL_MAP.keySet()) {
                cancel(key);
            }
            CALL_MAP.clear();
        }
    }

    /**
     * 取消单个网络请求
     *
     * @param key 请求标识：tag.toString() + url
     */
    private void cancel(String key) {
        Object request = CALL_MAP.get(key);
        if (request instanceof Call) {
            if (!((Call) request).isCanceled()) {
                ((Call) request).cancel();
            }
        } else if (request instanceof Disposable) {
            if (!((Disposable) request).isDisposed()) {
                ((Disposable) request).dispose();
            }
        }
    }
}
