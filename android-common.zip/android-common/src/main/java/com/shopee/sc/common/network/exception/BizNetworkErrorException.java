package com.shopee.sc.common.network.exception;

/**
 * 业务网络错误异常
 *
 * @author jianwei.luo
 * @date 2021/6/1
 */
public class BizNetworkErrorException extends Exception {
    public BizNetworkErrorException() {
    }

    public BizNetworkErrorException(String message) {
        super(message);
    }
}
