package com.shopee.sc.common.network;

import android.text.Html;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.shopee.sc.common.bean.Result;
import com.shopee.sc.common.network.callback.ILoadingCallback;
import com.shopee.sc.common.network.callback.IResponseCallback;
import com.shopee.sc.common.util.AppUtils;

import java.io.IOException;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by chris on 06/05/2020.
 * <p>
 * eg.
 * <p>
 * new NetAgent.Builder<ManualInputControl>()
 * .setResponseCallback(callback)
 * .setLoadingCallback(listener)
 * .tag(this)
 * .url(WmsApi.MANUAL_INPUT_CODE_CONTROL_CONFIG)
 * .build()
 * .callRequest(getRetrofit().create(ConfigRequest.class).getManualInputControlConfig());
 */
public final class NetAgent<T> {

    /**
     * 请求被取消后，是否把错误信息回调给界面，默认回调 true
     */
    public static boolean sCancelCallback = true;
    /**
     * 请求后Result为空时，是否要保证回调界面时不为空，默认回调 true
     */
    public static boolean sKeepResultNonNull = true;

    private IResponseCallback<T> mResponseCallback;
    private ILoadingCallback mLoadingCallback;
    private Object mTag;
    private String mKey;
    private boolean mIsRefresh;
    private Object[] mParams;

    private NetAgent() {

    }

    NetAgent(IResponseCallback<T> callback,
             ILoadingCallback loadingCallback,
             Object tag, String key, boolean refresh, Object... params) {
        this.mResponseCallback = callback;
        this.mLoadingCallback = loadingCallback;
        this.mTag = tag;
        this.mKey = key;
        this.mIsRefresh = refresh;
        this.mParams = params;
    }

    public void callRequest(@NonNull Call<Result<T>> call) {
        AppUtils.checkNotNull(call);
        addSingleRequest(call);
        showLoading();
        call.enqueue(new Callback<Result<T>>() {
            @Override
            public void onResponse(Call<Result<T>> call, Response<Result<T>> response) {
                hideLoading();
                //如果遇到网络失败(eg:404)等错误时response的body是空，errorBody是非空，将errorBody的内容取出来
                Result<T> result = response == null ? null : response.body();
                ResponseBody erroBody = response == null ? null : response.errorBody();
                if (result != null) {
                    dealWithResult(result, null);
                } else {
                    String error = "";
                    try {
                        error = erroBody == null ? "" : erroBody.string();
                        error = Html.fromHtml(error).toString();
                    } catch (IOException e) {
                        error = e.getMessage();
                    }
                    dealWithResult(null, new Throwable(error));
                }
                removeSingleRequest(call);
            }

            @Override
            public void onFailure(Call<Result<T>> call, Throwable t) {
                hideLoading();
                if (sCancelCallback || !call.isCanceled()) {
                    dealWithResult(null, t);
                }
                removeSingleRequest(call);
            }
        });
    }

    private void dealWithResult(Result<T> result, Throwable t) {
        if (mResponseCallback == null) {
            return;
        }
        if (result == null) {
            if (sKeepResultNonNull) {
                // 保证 result 不为空，减少业务遗漏判空导致空指针异常
                result = new Result<>(null);
                result.retcode = -1;
                result.message = t == null ? "" : t.getMessage();
            }
            mResponseCallback.showResult(result, mKey, false,
                    t == null ? "" : t.getMessage(), mIsRefresh, mParams);
        } else {
            mResponseCallback.showResult(result, mKey, result.isSuccess(), result.message, mIsRefresh, mParams);
        }
    }

    public void obRequest(@NonNull Observable<Result<T>> observable) {
        AppUtils.checkNotNull(observable);
        showLoading();
        observable = observable
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
        Disposable disposable = observable.subscribe(result -> {
            hideLoading();
            dealWithResult(result, null);
            removeSingleDisposable();
        }, throwable -> {
            hideLoading();
            dealWithResult(null, throwable);
            removeSingleDisposable();
        });
        addSingleDisposable(disposable);
    }

    //使用retrofit+rxjava必须由外部指定tag和key才将请求加入队列
    private void addSingleDisposable(Disposable disposable) {
        if (mTag == null || TextUtils.isEmpty(mKey)) {
            return;
        }
        if (disposable == null) {
            return;
        }
        NetCache.getInstance().addSingleRequest(mTag, mKey, disposable);
    }

    private void removeSingleDisposable() {
        if (mTag == null || TextUtils.isEmpty(mKey)) {
            return;
        }
        NetCache.getInstance().removeRequest(mTag, mKey, null);
    }

    //单独使用retrofit，必须由外部指定了tag(key若没传默认使用请求的完整url)才将请求加入队列
    private void addSingleRequest(Call request) {
        if (mTag == null) {
            return;
        }
        if (request == null) {
            return;
        }
        NetCache.getInstance().addSingleRequest(mTag, mKey, request);
    }

    private void removeSingleRequest(Call request) {
        if (mTag == null) {
            return;
        }
        if (request == null) {
            return;
        }
        NetCache.getInstance().removeRequest(mTag, mKey, request);
    }

    private void showLoading() {
        if (mLoadingCallback != null) {
            mLoadingCallback.onStartLoading();
        }
    }

    private void hideLoading() {
        if (mLoadingCallback != null) {
            mLoadingCallback.onFinishLoading();
        }
    }

    public static final class Builder<T> {

        private IResponseCallback<T> mResponseCallback;
        private ILoadingCallback mLoadingCallback;
        private Object mTag;
        private String mKey;
        private boolean mIsRefresh;
        private Object[] mParams;
        private boolean mResultNullable;

        public Builder() {
        }

        /**
         * 服务端数据展示
         */
        public Builder<T> setResponseCallback(IResponseCallback<T> callback) {
            this.mResponseCallback = callback;
            return this;
        }

        /**
         * 加载框展示
         */
        public Builder<T> setLoadingCallback(ILoadingCallback callback) {
            this.mLoadingCallback = callback;
            return this;
        }

        /**
         * 设置网络请求标识，用于取消请求
         * <p>
         * 根据tag 取消单个界面的所有请求，或取消某个tag的所有请求
         */
        public Builder<T> tag(Object tag) {
            this.mTag = tag;
            return this;
        }

        /**
         * 设置Result 是否可空
         * 非空,则在dealWithResult()方法中处理为空情况
         * 可空，则在showResult()实现方法中自己判断
         * 迁移时可根据判断业务result是否可空来决定
         */
        public Builder<T> setResultNullable(boolean nullable) {
            this.mResultNullable = nullable;
            return this;
        }

        /**
         * 该字段作用：
         * 1.设置单个网络请求标识，用于取消请求单个请求
         * 2.网络请求回来后，通过key就传给上层区分不用的请求（例如同一个页面都多个请求的情况可用这个字段区分）
         * <p>
         * 如果只想取消单个请求，请传入标识：tag.toString() + url
         */
        public Builder<T> key(String key) {
            this.mKey = key;
            return this;
        }

        /**
         * 分页刷新
         */
        public Builder<T> refresh(boolean refresh) {
            this.mIsRefresh = refresh;
            return this;
        }

        /**
         * 更多参数
         */
        public Builder<T> params(Object... params) {
            this.mParams = params;
            return this;
        }

        public NetAgent<T> build() {
            return new NetAgent<>(mResponseCallback, mLoadingCallback, mTag, mKey, mIsRefresh, mParams);
        }
    }

}
