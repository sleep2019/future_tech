package com.shopee.sc.common.network.callback;

/**
 * 加载框回调
 */
public interface ILoadingCallback {
    /**
     * 显示加载框
     */
    void onStartLoading();

    /**
     * 隐藏加载框
     */
    void onFinishLoading();
}
