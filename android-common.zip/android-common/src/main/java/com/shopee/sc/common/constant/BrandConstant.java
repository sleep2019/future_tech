package com.shopee.sc.common.constant;

/**
 * Created by chris on 2019-09-19.
 */
public class BrandConstant {

    public static final String BRAND_ZEBRA = "Zebra";
    public static final String BRAND_SEUIC = "Seuic";
    public static final String BRAND_IWRIST = "Iwrist";
    public static final String BRAND_NEWLAND = "Newland";
}
