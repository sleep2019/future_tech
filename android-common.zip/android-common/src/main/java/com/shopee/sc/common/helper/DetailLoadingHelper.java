package com.shopee.sc.common.helper;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.shopee.sc.common.R;
import com.shopee.sc.common.bean.Result;
import com.shopee.sc.common.plugins.CommonPlugins;
import com.shopee.sc.common.util.RxUtils;
import com.shopee.sc.logger.api.Logger;

import java.util.Objects;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Detail Loading Helper，适用于详情页需要加载详细数据的场景，抽离出此类方便集成至 Activity、Fragment 中。
 *
 * 实现以下功能：
 * 1、自动处理 loading、loading fail、empty 等状态，回调只需实现加载数据接口及提供替换锚点；
 * 2、可自定义 loading，loading fail、empty 文案及图标；
 * 3、自动处理数据更新请求；
 * 4、支持集成 SwipeRefreshLayout；
 * - 不能替换 SwipeRefreshLayout 的一级子 View，这里 anchor 至少需为 SwipeRefreshLayout 的二级子 View
 *
 * Created by honggang.xiong on 2020/7/14.
 */
public class DetailLoadingHelper<T> {

    private static final String TAG = "DetailLoadingHelper";

    public static final int LOAD_STATUS_INITIAL = 0;
    public static final int LOAD_STATUS_PENDING = 1;
    public static final int LOAD_STATUS_LOADING = 2;
    public static final int LOAD_STATUS_SUCCESS = 3;
    public static final int LOAD_STATUS_SUCCESS_NO_DATA = 4;
    public static final int LOAD_STATUS_FAILED = 5;

    private static final int LOADING_STYLE_SWIPE_REFRESH = 10;
    private static final int LOADING_STYLE_CUSTOM = 11;
    private static final int LOADING_STYLE_INNER = 12;

    private View mReplaceAnchor;                    // 替换锚点
    private ViewGroup mContainerParent;             // 锚点父 View
    private SwipeRefreshLayout mSwipeRefreshLayout; // 集成 SwipeRefreshLayout

    private LoadingCallback<T> mCallback;
    private T mInitialData; // 初始化数据
    private CustomLoading mCustomLoading;
    private final LifecycleOwner mLifecycleOwner;

    private View mReplaceView;
    private TextView mTvEmpty;
    private ImageView mIvEmpty;
    private ProgressBar mPbInner;

    private int mEmptyDrawableRes;
    private int mErrorDrawableRes;
    private String mEmptyStr;
    private String mErrorStr;

    private int mLoadStatus = LOAD_STATUS_INITIAL;
    private boolean mIsResumed = false;
    private Disposable mLoadDataDisposable;

    /**
     * Suggest to be invoked in android.app.Activity#onCreate(Bundle) or
     * {@link androidx.fragment.app.Fragment#onViewCreated(View, Bundle)}
     *
     * @param replaceAnchor 锚点 View，替换时将从此 View 的父 View 中移除此 View
     * @param callback      回调
     */
    public static <T> Builder<T> newBuilder(@NonNull View replaceAnchor, @NonNull LoadingCallback<T> callback) {
        return new Builder<>(replaceAnchor, callback);
    }

    private DetailLoadingHelper(Builder<T> builder) {
        mReplaceAnchor = builder.mReplaceAnchor;
        mCallback = builder.mCallback;
        mSwipeRefreshLayout = builder.mSwipeRefreshLayout;
        mInitialData = builder.mInitialData;
        mCustomLoading = builder.mCustomLoading;
        mLifecycleOwner = builder.mLifecycleOwner;
        mEmptyDrawableRes = builder.mEmptyDrawableRes;
        mErrorDrawableRes = builder.mErrorDrawableRes;
        mEmptyStr = builder.mEmptyStr;
        mErrorStr = builder.mErrorStr;

        mContainerParent = (ViewGroup) mReplaceAnchor.getParent();
        // init SwipeRefreshLayout
        if (mSwipeRefreshLayout != null) {
            mSwipeRefreshLayout.setOnRefreshListener(this::loadData);
            mSwipeRefreshLayout.setColorSchemeResources(R.color.commonColorPrimary,
                    R.color.commonColorAccent, R.color.commonColorPrimaryDark);
        }
        if (mLifecycleOwner != null) {
            mLifecycleOwner.getLifecycle().addObserver(new LifecycleEventObserver() {
                @Override
                public void onStateChanged(@NonNull LifecycleOwner source, @NonNull Lifecycle.Event event) {
                    switch (event) {
                        case ON_CREATE:
                            onCreate();
                            break;
                        case ON_RESUME:
                            onResume();
                            break;
                        case ON_PAUSE:
                            onPause();
                            break;
                        case ON_DESTROY:
                            onDestroy();
                            break;
                    }
                }
            });
        }
    }

    public void performCreate() {
        if (mLifecycleOwner == null) {
            onCreate();
        }
    }

    public void performResume() {
        if (mLifecycleOwner == null) {
            onResume();
        }
    }

    public void performPause() {
        if (mLifecycleOwner == null) {
            onPause();
        }
    }

    public void performDestroy() {
        if (mLifecycleOwner == null) {
            onDestroy();
        }
    }

    void onCreate() {
    }

    void onResume() {
        mIsResumed = true;
        if (mLoadStatus == LOAD_STATUS_INITIAL) {
            if (mInitialData != null) { // 有初始化数据，直接返回
                mCallback.showDetailView(mInitialData);
                mLoadStatus = LOAD_STATUS_SUCCESS;
                return;
            }
            mLoadStatus = LOAD_STATUS_PENDING;
        }

        if (mLoadStatus == LOAD_STATUS_PENDING) {
            forceRefresh();
        }
    }

    void onPause() {
        mIsResumed = false;
    }

    void onDestroy() {
        RxUtils.dispose(mLoadDataDisposable);
        restoreSource();
    }

    public int getLoadStatus() {
        return mLoadStatus;
    }

    public boolean isPendingUpdate() {
        return mLoadStatus == LOAD_STATUS_PENDING;
    }

    @MainThread
    public void setPendingUpdate() {
        mLoadStatus = LOAD_STATUS_PENDING;
        if (mIsResumed) {
            forceRefresh();
        } else {
            RxUtils.dispose(mLoadDataDisposable);
        }
    }

    protected void forceRefresh() {
        loadData();
    }

    private void loadData() {
        RxUtils.dispose(mLoadDataDisposable);
        mLoadStatus = LOAD_STATUS_LOADING;

        int loadingStyle;
        if (mSwipeRefreshLayout != null) {
            mSwipeRefreshLayout.setRefreshing(true);
            loadingStyle = LOADING_STYLE_SWIPE_REFRESH;
        } else if (mCustomLoading != null) {
            mCustomLoading.showDetailLoading(true);
            loadingStyle = LOADING_STYLE_CUSTOM;
        } else {
            showInnerLoading(true);
            loadingStyle = LOADING_STYLE_INNER;
        }

        mCallback.onRefreshStart();
        mLoadDataDisposable = mCallback.getDetailData()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doFinally(() -> {
                    switch (loadingStyle) {
                        case LOADING_STYLE_SWIPE_REFRESH:
                            mSwipeRefreshLayout.setRefreshing(false);
                            break;
                        case LOADING_STYLE_CUSTOM:
                            mCustomLoading.showDetailLoading(false);
                            break;
                        case LOADING_STYLE_INNER:
                        default:
                            showInnerLoading(false);
                            break;
                    }
                    mCallback.onRefreshEnd();
                })
                .subscribe(result -> {
                    if (result.isSuccess()) {
                        if (result.data != null) {
                            Logger.i(TAG, "load detail data success:" + result.data);
                            mLoadStatus = LOAD_STATUS_SUCCESS;
                            restoreSource();
                            mCallback.showDetailView(result.data);
                        } else {
                            mLoadStatus = LOAD_STATUS_SUCCESS_NO_DATA;
                            showEmptyView();
                        }
                    } else {
                        CommonPlugins.getToaster().toast(result);
                        mLoadStatus = LOAD_STATUS_FAILED;
                        showLoadFailedView();
                    }
                }, throwable -> {
                    Logger.w(TAG, "load data error:" + throwable);
                    CommonPlugins.getToaster().toast(throwable);
                    mLoadStatus = LOAD_STATUS_FAILED;
                    showLoadFailedView();
                });
    }

    private void showInnerLoading(boolean isLoading) {
        if (isLoading) {
            replacedSource();
        }
        if (mReplaceView != null) {
            mPbInner.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        }
    }

    private void showEmptyView() {
        replacedSource();
        if (mReplaceView != null) {
            mIvEmpty.setImageResource(mEmptyDrawableRes);
            mTvEmpty.setText(mEmptyStr);
        }
        mCallback.onEmptyViewShowed();
    }

    private void showLoadFailedView() {
        replacedSource();
        if (mReplaceView != null) {
            mIvEmpty.setImageResource(mErrorDrawableRes);
            mTvEmpty.setText(mErrorStr);
        }
        mCallback.onErrorViewShowed();
    }

    private void replacedSource() {
        if (mContainerParent == null) {
            Logger.i("replacedSource container is null!");
            return;
        }

        if (mReplaceAnchor.getParent() == null) {
            Logger.i("replacedSource already replaced");
            return;
        }

        int index = mContainerParent.indexOfChild(mReplaceAnchor);
        if (index >= 0) {
            ViewGroup.LayoutParams params = mReplaceAnchor.getLayoutParams();
            mContainerParent.removeViewAt(index);
            mContainerParent.addView(getReplaceView(mContainerParent.getContext()), index, params);
        } else {
            // 异常情况，无法替换，如外部改变了 mReplaceAnchor 的布局层级
            Logger.w("replacedSource invalid status, mReplaceAnchor=" + mReplaceAnchor
                    + ", parent=" + mReplaceAnchor.getParent() + ", mContainerParent=" + mContainerParent);
        }
    }

    private void restoreSource() {
        if (mContainerParent == null) {
            Logger.i("restoreSource container is null!");
            return;
        }

        if (mReplaceAnchor.getParent() == mContainerParent || mReplaceView == null) {
            Logger.i("restoreSource not replaced yet");
            return;
        }

        int index = mContainerParent.indexOfChild(mReplaceView);
        if (index >= 0) {
            ViewGroup.LayoutParams params = mReplaceView.getLayoutParams();
            mContainerParent.removeViewAt(index);
            mContainerParent.addView(mReplaceAnchor, index, params);
        } else {
            // 异常情况，无法恢复，如外部改变了 mReplaceView 的布局层级
            Logger.w("restoreSource invalid status, mReplaceView=" + mReplaceAnchor
                    + ", parent=" + mReplaceView.getParent() + ", mContainerParent=" + mContainerParent);
        }
    }

    private View getReplaceView(Context context) {
        if (mReplaceView == null) {
            RelativeLayout relativeLayout = (RelativeLayout) LayoutInflater.from(context)
                    .inflate(R.layout.common_layout_empty_view, null);
            mPbInner = relativeLayout.findViewById(R.id.progress_bar);
            mTvEmpty = relativeLayout.findViewById(R.id.tv_empty);
            mIvEmpty = relativeLayout.findViewById(R.id.iv_empty);
            relativeLayout.setOnClickListener(v -> {
                if (mLoadStatus != LOAD_STATUS_LOADING) {
                    loadData();
                }
            });
            mReplaceView = relativeLayout;
        }
        return mReplaceView;
    }


    public interface LoadingCallback<T> {
        /**
         * Invoked when refresh start
         */
        default void onRefreshStart() {
            // default no-op
        }

        /**
         * Get detail data from DB or net
         */
        Single<Result<T>> getDetailData();

        /**
         * Set Views when detail data is present
         */
        void showDetailView(@NonNull T data);

        /**
         * Invoked when empty view is showed
         */
        default void onEmptyViewShowed() {
            // default no-op
        }

        /**
         * Invoked error empty view is showed
         */
        default void onErrorViewShowed() {
            // default no-op
        }

        /**
         * Invoked when refresh end
         */
        default void onRefreshEnd() {
            // default no-op
        }
    }

    public interface CustomLoading {
        void showDetailLoading(boolean isLoading);
    }


    public static class Builder<T> {

        private View mReplaceAnchor;
        private LoadingCallback<T> mCallback;

        private T mInitialData;
        private SwipeRefreshLayout mSwipeRefreshLayout;

        private CustomLoading mCustomLoading;
        private LifecycleOwner mLifecycleOwner;

        private int mEmptyDrawableRes = R.drawable.common_ic_empty_normal;
        private int mErrorDrawableRes = R.drawable.common_ic_error_normal;
        private String mEmptyStr;
        private String mErrorStr;

        Builder(@NonNull View replaceAnchor, @NonNull LoadingCallback<T> callback) {
            mReplaceAnchor = Objects.requireNonNull(replaceAnchor, "anchor cannot be null");
            mCallback = Objects.requireNonNull(callback, "callback cannot be null");
            mEmptyStr = replaceAnchor.getContext().getString(R.string.common_no_data);
            mErrorStr = replaceAnchor.getContext().getString(R.string.common_please_try_again);
        }

        /**
         * 设置初始化数据
         *
         * @param initialData 初始化数据，如非空初次加载时直接返回该数据
         */
        public Builder<T> setInitialData(@Nullable T initialData) {
            mInitialData = initialData;
            return this;
        }

        /**
         * 集成 SwipeRefreshLayout
         *
         * @param swipeRefreshLayout 非空代表集成 SwipeRefreshLayout，不能为 replaceAnchor 及其子 View，
         *                           否则集成将失效
         */
        public Builder<T> setSwipeRefreshLayout(@Nullable SwipeRefreshLayout swipeRefreshLayout) {
            mSwipeRefreshLayout = swipeRefreshLayout;
            return this;
        }

        /**
         * 设置自定义 loading，将不使用内部 loading
         *
         * @param customLoading 自定义 loading
         */
        public Builder<T> setCustomLoading(@Nullable CustomLoading customLoading) {
            mCustomLoading = customLoading;
            return this;
        }

        /**
         * 设置 LifecycleOwner
         *
         * @param lifecycleOwner 非空时将通过 owner 自动处理生命周期事件并屏蔽外部调用
         */
        public Builder<T> setLifecycleOwner(@Nullable LifecycleOwner lifecycleOwner) {
            mLifecycleOwner = lifecycleOwner;
            return this;
        }

        public Builder<T> setEmptyDrawableRes(@DrawableRes int emptyDrawableRes) {
            mEmptyDrawableRes = emptyDrawableRes;
            return this;
        }

        public Builder<T> setErrorDrawableRes(@DrawableRes int errorDrawableRes) {
            mErrorDrawableRes = errorDrawableRes;
            return this;
        }

        public Builder<T> setEmptyStr(@Nullable String emptyStr) {
            mEmptyStr = emptyStr;
            return this;
        }

        public Builder<T> setErrorStr(@Nullable String errorStr) {
            mErrorStr = errorStr;
            return this;
        }

        public DetailLoadingHelper<T> build() {
            return new DetailLoadingHelper<>(this);
        }
    }

}
