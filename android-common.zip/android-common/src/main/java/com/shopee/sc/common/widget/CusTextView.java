package com.shopee.sc.common.widget;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.sc.common.plugins.CommonPlugins;

/**
 * Created by chris on 2019-12-04.
 */
@SuppressLint("AppCompatCustomView")
public class CusTextView extends TextView {

    private static final int LAYOUT_HIERARCHIES = 5;
    private long mLastActionDownTime = 0L;

    public CusTextView(Context context) {
        super(context);
        init();
    }

    public CusTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CusTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOnLongClickAction();
    }

    private void setOnLongClickAction() {
        this.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {
                if (v instanceof TextView) {
                    Context context = v.getContext();
                    final String textInfo = ((TextView) v).getText().toString();
                    if (!TextUtils.isEmpty(textInfo)) {
                        ClipboardManager cManager =
                                (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData cData = ClipData.newPlainText("text", textInfo);
                        if (cManager != null) {
                            cManager.setPrimaryClip(cData);
                        }
                        CommonPlugins.getToaster().showShort(context.getString(android.R.string.copy) + " " + "\"" + textInfo + "\"");
                    }
                }
                return true;
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean b = super.onTouchEvent(event);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mLastActionDownTime = System.currentTimeMillis();
                break;
            case MotionEvent.ACTION_UP:
                final long actionUpTime = System.currentTimeMillis();
                if (actionUpTime - mLastActionDownTime < ViewConfiguration.getLongPressTimeout()) {
                    ViewGroup viewGroup = getClickableView(this);
                    // Longclickable 会影响 Clickable，消费点击事件
                    // 本身非Clickable，parent是clickable，向上执行
                    if (viewGroup != null && !isClickable()) {
                        return viewGroup.performClick();
                    }
                }
                break;
            default:
                break;
        }
        return b;
    }

    private ViewGroup getClickableView(@NonNull View v) {
        ViewParent parent = v.getParent();
        for (int i = 0; i < LAYOUT_HIERARCHIES; i++) {
            if (parent instanceof ViewGroup) {
                if (((ViewGroup) parent).isClickable()) {
                    return ((ViewGroup) parent);
                }
                parent = parent.getParent();
            }
        }
        return null;
    }

    @Override
    public void setOnClickListener(@Nullable OnClickListener listener) {
        super.setOnClickListener(new ViewClickProxy(listener));
    }
}
