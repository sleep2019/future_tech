package com.shopee.sc.common.widget;

import android.app.Activity;
import android.view.View;
import android.view.Window;

import androidx.appcompat.app.AlertDialog;

import com.shopee.sc.common.R;

/**
 * @ClassName: LoadingDialog
 * @Description: 等待加载框
 * @Author: lanjingzeng
 * @CreateDate: 2021/5/12 8:04 PM
 * @Version: 1.0
 */
public class LoadingDialog {
    private Activity mActivity;
    private AlertDialog mAlertDialog;

    public LoadingDialog(Activity activity) {
        this.mActivity = activity;
        initDialog();
    }

    private void initDialog() {
        View contentView = mActivity.getLayoutInflater().inflate(R.layout.common_layout_loading, null);
        //导包用"androidx.appcompat.app.AlertDialog"，不要用"android.app.AlertDialog"，后者idata型号的PDA会报错:requestFeature() must be called before adding content
        mAlertDialog = new AlertDialog.Builder(mActivity)
                .setView(contentView)
                .create();

        Window window = mAlertDialog.getWindow();
        //去掉对话框外边默认的margin
        window.getDecorView().setPadding(0, 0, 0, 0);
        window.getDecorView().setBackgroundColor(mActivity.getResources().getColor(android.R.color.transparent));
    }

    public void show() {
        if (mAlertDialog.isShowing()) {
            return;
        }
        mAlertDialog.show();
    }

    public boolean isShowing() {
        return mAlertDialog.isShowing();
    }

    public void dismiss() {
        if (mAlertDialog.isShowing()) {
            mAlertDialog.dismiss();
        }
    }
}
