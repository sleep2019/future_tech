package com.shopee.sc.common.network;

import androidx.annotation.NonNull;

import com.shopee.sc.common.bean.Result;
import com.shopee.sc.common.network.callback.ILoadingCallback;
import com.shopee.sc.common.network.callback.IResponseCallback;

import retrofit2.Call;

/**
 * Created by javy on 10/09/2020.
 */
public final class NetHelper {

    private NetHelper() {

    }

    @Deprecated
    public static <T> void callRequest(Object tag,
                                       IResponseCallback<T> responseCallback,
                                       @NonNull Call<Result<T>> call,
                                       Object... params) {
        callRequest(tag, null, responseCallback, "", false, call, params);
    }

    @Deprecated
    public static <T> void callRequest(Object tag,
                                       ILoadingCallback loadingCallback,
                                       IResponseCallback<T> responseCallback,
                                       @NonNull Call<Result<T>> call,
                                       Object... params) {
        callRequest(tag, loadingCallback, responseCallback, "", false, call, params);
    }

    public static <T> void callRequest(Object tag,
                                       IResponseCallback<T> responseCallback,
                                       String key,
                                       @NonNull Call<Result<T>> call,
                                       Object... params) {
        callRequest(tag, null, responseCallback, key, false, call, params);
    }

    public static <T> void callRequest(Object tag,
                                       ILoadingCallback loadingCallback,
                                       IResponseCallback<T> responseCallback,
                                       String key,
                                       @NonNull Call<Result<T>> call,
                                       Object... params) {
        callRequest(tag, loadingCallback, responseCallback, key, false, call, params);
    }

    public static <T> void callRequest(Object tag,
                                       IResponseCallback<T> responseCallback,
                                       String key,
                                       boolean refresh,
                                       @NonNull Call<Result<T>> call,
                                       Object... params) {
        callRequest(tag, null, responseCallback, key, refresh, call, params);
    }

    /**
     * 网络请求
     *
     * @param tag              取消单个界面的所有请求，或取消某个tag的所有请求
     * @param loadingCallback  Loading加载框
     * @param responseCallback 返回的服务端数据
     * @param key              单个请求的标志
     * @param refresh          是否分页
     * @param call             Call
     * @param params           可变参数
     */
    public static <T> void callRequest(Object tag,
                                       ILoadingCallback loadingCallback,
                                       IResponseCallback<T> responseCallback,
                                       String key,
                                       boolean refresh,
                                       @NonNull Call<Result<T>> call,
                                       Object... params) {
        new NetAgent.Builder<T>()
                .setResponseCallback(responseCallback)
                .setLoadingCallback(loadingCallback)
                .tag(tag)
                .key(key)
                .refresh(refresh)
                .params(params)
                .build()
                .callRequest(call);
    }

    public static void cancel(Object tag, String key) {
        NetCache.getInstance().cancel(tag, key);
    }

    public static void cancel(Object tag) {
        NetCache.getInstance().cancel(tag);
    }

    public static void cancelAll() {
        NetCache.getInstance().cancelAll();
    }
}
