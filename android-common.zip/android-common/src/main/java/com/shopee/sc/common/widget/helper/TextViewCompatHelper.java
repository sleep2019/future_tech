package com.shopee.sc.common.widget.helper;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.shopee.sc.logger.api.Logger;

import java.util.Arrays;

/**
 * 修复 TextView 及其子类在 6.0 及以下使用 drawableStart、drawableEnd 时 drawable 首帧绘制状态和控件实际状态不一致的问题。
 * 一般来说，需同时满足以下条件才会有问题：
 * 1、使用 drawStart、drawEnd 有问题，使用 left、top、right、bottom 没有问题
 * 2、使用有状态的 drawable
 * 3、在 xml 布局中设置 drawable，或者代码中在设置控件状态前设置 drawable
 * 4、控件用于 RecyclerView 中有问题，用于普通页面中没有问题（可以通过 View.dispatchAttachedToWindow 刷新状态）
 *
 * 综上，一般只有 {@link android.widget.CheckBox}、{@link android.widget.RadioButton} 需要进行修复
 *
 * Created by honggang.xiong on 2022/6/16.
 */
public class TextViewCompatHelper {

    private static final String TAG = "TextViewCompatHelper";

    private boolean mHasDetectDrawableState = false;

    /**
     * 7.0 及以上会在 onResolveDrawables 中对 mShowing[Drawables.LEFT] 及 mShowing[Drawables.RIGHT]
     * 进行 state 双重检测，6.0 及以下不会，所以这里在 onMeasure 中进行一次检测
     * 相关调用：
     * -> View.measure
     * -> View.resolveRtlPropertiesIfNeeded
     * -> View.resolveDrawables
     * -> TextView.onResolveDrawables
     * -> TextView.prepareDrawableForDisplay (7.0 新增)
     */
    public void tryDetectInconsistentDrawableStateOnMeasure(@NonNull TextView textView) {
        // FlexboxLayoutManager 会在 isLayoutDirectionResolved() 返回 true 之前调用 onMeasure，
        // 此时 drawableStart、drawableEnd 还没有赋值给 drawableLeft、drawableRight
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.M && !mHasDetectDrawableState
                && textView.isLayoutDirectionResolved()) {
            int[] currentState = textView.getDrawableState();
            Drawable[] drawables = textView.getCompoundDrawables();
            Drawable left = drawables[0];
            Drawable right = drawables[2];
            boolean leftAbnormal = left != null && left.isStateful() && !Arrays.equals(currentState, left.getState());
            boolean rightAbnormal = right != null && right.isStateful() && !Arrays.equals(currentState, right.getState());
            if (leftAbnormal || rightAbnormal) {
                Logger.i(TAG, "Detect inconsistent drawable state, trigger refreshDrawableState once");
                textView.refreshDrawableState();
            }
            // 目前仅需检测一次，后续暂未发现不一致问题
            mHasDetectDrawableState = true;
        }
    }

}
