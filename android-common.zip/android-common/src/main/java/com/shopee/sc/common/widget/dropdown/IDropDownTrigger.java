package com.shopee.sc.common.widget.dropdown;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * 下拉菜单触发器
 *
 * Created by honggang.xiong on 2021/4/7.
 */
public interface IDropDownTrigger {

    boolean isChecked();

    void setChecked(boolean isChecked);

    void setOnTriggerClickListener(@Nullable OnTriggerClickListener listener);


    interface OnTriggerClickListener {
        void onTriggerClick(@NonNull IDropDownTrigger trigger, boolean isChecked);
    }

}
