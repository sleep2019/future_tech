package com.shopee.sc.common.widget.dropdown;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.util.Pair;
import android.view.View;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.sc.logger.api.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 下拉菜单协调器
 *
 * Created by honggang.xiong on 2021/4/7.
 */
public class DropDownCoordinator implements IDropDownDisplay.OnViewDismissListener {

    public static final int ANIM_IN_MILLIS = 200;
    public static final int ANIM_OUT_MILLIS = 100;

    private final View mMaskView;
    private boolean mMaskPendingHide = false;

    private IDropDownTrigger mCurrentTrigger;
    private IDropDownDisplay mCurrentDisplay;

    private DropDownCoordinator(@Nullable View maskView, @NonNull List<Pair<IDropDownTrigger, IDropDownDisplay>> pairList) {
        mMaskView = maskView;

        if (maskView != null) {
            maskView.setOnClickListener(v -> hideDropDown(true));
            maskView.setVisibility(View.GONE); // reset to default state
        }

        for (Pair<IDropDownTrigger, IDropDownDisplay> pair : pairList) {
            IDropDownTrigger trigger = pair.first;
            IDropDownDisplay view = pair.second;
            // reset to default state
            trigger.setChecked(false);
            if (view.isShowing()) {
                view.hide();
            }

            trigger.setOnTriggerClickListener((trigger1, isChecked) -> {
                if (isChecked) {
                    showDropDown(trigger, view);
                } else {
                    hideDropDown(true);
                }
            });
            view.setOnViewDismissListener(this);
        }
    }

    @Override
    public void onViewDismiss(@NonNull IDropDownDisplay display) {
        if (display == mCurrentDisplay) {
            hideDropDown(true);
        }
    }

    void showDropDown(@NonNull IDropDownTrigger trigger, @NonNull IDropDownDisplay display) {
        hideDropDown(!display.needMask());
        if (mMaskView != null && display.needMask()) {
            mMaskView.animate().cancel();
            mMaskView.setVisibility(View.VISIBLE);
        }
        mCurrentTrigger = trigger;
        mCurrentDisplay = display;
        mCurrentTrigger.setChecked(true);
        mCurrentDisplay.show();
    }

    @MainThread
    public void hideDropDown(boolean hideMaskView) {
        IDropDownTrigger currentTrigger = mCurrentTrigger;
        IDropDownDisplay currentDisplay = mCurrentDisplay;
        mCurrentTrigger = null;
        mCurrentDisplay = null;

        if (currentTrigger != null && currentTrigger.isChecked()) {
            currentTrigger.setChecked(false);
        }
        if (currentDisplay != null && currentDisplay.isShowing()) {
            currentDisplay.hide();
        }
        if (hideMaskView && mMaskView != null && !mMaskPendingHide) {
            mMaskView.animate().cancel();
            mMaskView.setAlpha(1);
            mMaskPendingHide = true;
            Logger.v("mMaskView hide anim start");
            mMaskView.animate().alpha(0)
                    .setDuration(ANIM_OUT_MILLIS)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            Logger.v("mMaskView hide anim end");
                            mMaskPendingHide = false;
                            mMaskView.setAlpha(1);
                            mMaskView.setVisibility(View.GONE);
                        }
                    })
                    .start();
        }
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static class Builder {

        private View mMaskView;
        private final List<Pair<IDropDownTrigger, IDropDownDisplay>> mPairList = new ArrayList<>();

        public Builder() {
        }

        public Builder setMaskView(@Nullable View maskView) {
            mMaskView = maskView;
            return this;
        }

        public Builder addPair(@NonNull IDropDownTrigger trigger, @NonNull IDropDownDisplay view) {
            mPairList.add(Pair.create(Objects.requireNonNull(trigger), Objects.requireNonNull(view)));
            return this;
        }

        public DropDownCoordinator build() {
            return new DropDownCoordinator(mMaskView, mPairList);
        }
    }

}
