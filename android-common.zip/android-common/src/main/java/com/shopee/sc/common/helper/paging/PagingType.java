package com.shopee.sc.common.helper.paging;

/**
 * 分页类型
 * <p>
 * Created by honggang.xiong on 2021/11/15.
 */
public enum PagingType {
    SWIPE_REFRESH(true),
    LOAD_MORE(false),
    EMPTY_REFRESH(true),
    EVENT_REFRESH(true),
    SILENCE_REFRESH(true),
    ;

    private final boolean mIsForceFetch;

    PagingType(boolean isForceFetch) {
        mIsForceFetch = isForceFetch;
    }

    public boolean isForceFetch() {
        return mIsForceFetch;
    }
}
