package com.shopee.sc.common.sound;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;

import androidx.annotation.RawRes;

import java.util.HashMap;

/**
 * Created by chris on 2018/7/16.
 */
public class SoundHelper {
    private static final int MAX_STREAM = 5;
    private static volatile SoundHelper sInstance;
    private SoundPool mSoundPool;
    private HashMap<Integer, Integer> mSoundIdList;

    public static SoundHelper getInstance() {
        if (sInstance == null) {
            synchronized (SoundHelper.class) {
                if (sInstance == null) {
                    sInstance = new SoundHelper();
                }
            }
        }
        return sInstance;
    }

    private SoundHelper() {
        mSoundPool = new SoundPool.Builder()
                .setMaxStreams(MAX_STREAM)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setLegacyStreamType(AudioManager.STREAM_MUSIC)
                        .build())
                .build();
    }

    /**
     * 初始化加载音频文件
     */
    public synchronized void load(Context context, Integer... soundRawIdLists) {
        if (mSoundIdList == null) {
            mSoundIdList = new HashMap<>();
        }
        int size = soundRawIdLists == null ? 0 : soundRawIdLists.length;
        for (int i = 0; i < size; i++) {
            int soundRawId = soundRawIdLists[i];
            int soundId = mSoundPool.load(context, soundRawId, 1);
            mSoundIdList.put(soundRawId, soundId);
        }
    }

    /**
     * 播放加载的音频文件
     *
     * @param soundRawId
     */
    public synchronized void play(@RawRes int soundRawId) {
        if (mSoundIdList == null) {
            return;
        }
        Integer soundId = mSoundIdList.get(soundRawId);
        if (soundId == null) {
            return;
        }
        mSoundPool.play(soundId, 1, 1, 1, 0, 1);
    }

}
