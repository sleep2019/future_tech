package com.shopee.sc.common.widget;

import android.view.View;

public class ViewClickProxy implements View.OnClickListener {

    private final static long INTERVAL_TIME = 500;
    private long mClickTime;
    private View.OnClickListener mOrigin;

    public ViewClickProxy(View.OnClickListener origin) {
        this.mOrigin = origin;
    }

    @Override
    public void onClick(View v) {
        if (isFastClick()) {
            return;
        }
        if (mOrigin != null) {
            mOrigin.onClick(v);
        }
    }

    private boolean isFastClick() {
        if (System.currentTimeMillis() - mClickTime < INTERVAL_TIME) {
            return true;
        }
        mClickTime = System.currentTimeMillis();
        return false;
    }
}
