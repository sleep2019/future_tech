package com.shopee.sc.common.util;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;

import androidx.annotation.NonNull;

import com.shopee.sc.common.bean.Result;
import com.shopee.sc.logger.api.Logger;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by honggang.xiong on 2019-07-24.
 */
public class NetworkUtils {

    private NetworkUtils() {
    }

    public static boolean isConnected() {
        Context context = AppUtils.getContext();
        if (context != null) {
            return isConnected(context);
        }
        return false;
    }

    /**
     * 检查当前网络是否连接
     */
    public static boolean isConnected(@NonNull Context context) {
        ConnectivityManager manager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (null != manager) {
            NetworkInfo info = manager.getActiveNetworkInfo();
            return info != null && info.isConnected();
        }
        return false;
    }

    /**
     * 检查当前WIFI是否连接
     */
    public static boolean isWifiConnected(@NonNull Context context) {
        ConnectivityManager manager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (null != manager) {
            NetworkInfo info = manager.getActiveNetworkInfo();
            return info != null && info.isConnected() && info.getType() == ConnectivityManager.TYPE_WIFI;
        }
        return false;
    }

    public static boolean isWifiOpened(@NonNull Context context) {
        WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        return wifiManager.isWifiEnabled();
    }

    public static boolean isBluetoothOpen() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter != null) {
            return bluetoothAdapter.enable();
        }
        return false;
    }

    /**
     * Get the current network state
     *
     * No network-NO
     * 4G network-4G
     * 3G network-3G
     * 2G network-2G
     * WIFI network-WIFI
     * Unknown network-Unknown
     *
     * @param context
     * @return
     */
    public static String getAPNType(@NonNull Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) {
            return "NO";
        }
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo == null) {
            return "NO";
        }

        int nType = networkInfo.getType();
        if (nType == ConnectivityManager.TYPE_WIFI) {
            return "WIFI";
        } else if (nType == ConnectivityManager.TYPE_MOBILE) {
            int nSubType = networkInfo.getSubtype();
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (telephonyManager == null) {
                return "Unknown";
            }
            if (nSubType == TelephonyManager.NETWORK_TYPE_LTE
                    && !telephonyManager.isNetworkRoaming()) {
                return "4G";
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_UMTS
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_0
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_A
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSDPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSUPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_B
                    || nSubType == TelephonyManager.NETWORK_TYPE_EHRPD
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSPAP
                    && !telephonyManager.isNetworkRoaming()) {
                return "3G";
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_GPRS
                    || nSubType == TelephonyManager.NETWORK_TYPE_EDGE
                    || nSubType == TelephonyManager.NETWORK_TYPE_CDMA
                    || nSubType == TelephonyManager.NETWORK_TYPE_1xRTT
                    || nSubType == TelephonyManager.NETWORK_TYPE_IDEN
                    && !telephonyManager.isNetworkRoaming()) {
                return "2G";
            } else {
                return "Unknown";
            }
        }
        return "Unknown";
    }

    /**
     * Open the network setting interface
     */
    public static void openNetworkSetting(@NonNull Activity activity) {
        Intent intent = new Intent("/");
        ComponentName cm = new ComponentName("com.android.settings",
                "com.android.settings.WirelessSettings");
        intent.setComponent(cm);
        intent.setAction("android.intent.action.VIEW");
        activity.startActivityForResult(intent, 0);
    }

    public static <T> Result<T> syncGetResult(@NonNull Call<Result<T>> call) throws IOException {
        Response<Result<T>> response = call.execute();
        if (response == null || response.body() == null) {
            throw new IOException("Empty response!");
        }
        return response.body();
    }

    public static byte[] parseIPv4(String ip) {
        if (RegexUtils.isValidIPv4(ip)) {
            try {
                String[] ips = ip.split("\\.");
                if (ips.length == 4) {
                    byte[] addr = new byte[4];
                    for (int i = 0; i < 4; i++) {
                        addr[i] = (byte) Integer.parseInt(ips[i]);
                    }
                    return addr;
                }
            } catch (Throwable e) {
                Logger.w("parseIp error: " + e);
            }
        }
        return null;
    }

}
