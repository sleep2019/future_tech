package com.shopee.sc.common.network.client;

import android.content.Context;

import androidx.annotation.NonNull;

import com.ihsanbal.logging.Level;
import com.ihsanbal.logging.LoggingInterceptor;
import com.shopee.sc.common.network.interceptor.CacheOfflineInterceptor;
import com.shopee.sc.common.network.interceptor.CacheOnlineInterceptor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.internal.platform.Platform;
import retrofit2.CallAdapter;
import retrofit2.Converter;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import static com.shopee.sc.common.network.NetConstant.DEFAULT_CACHE_SIZE;
import static com.shopee.sc.common.network.NetConstant.DEFAULT_CACHE_TIME;
import static com.shopee.sc.common.network.NetConstant.DEFAULT_NET_TIMEOUT;
import static com.shopee.sc.common.util.AppUtils.checkHttpURL;
import static com.shopee.sc.common.util.AppUtils.checkNotNull;
import static com.shopee.sc.common.util.AppUtils.getContext;

public class RetrofitWrapper {

    private Retrofit mRetrofit;
    private Retrofit mPrinterRetrofit;//打印机网络请求时不需要校验主机

    private RetrofitWrapper(Builder builder) {
        mRetrofit = builder.mRetrofit;
        mPrinterRetrofit = builder.mRetrofit.newBuilder().client(builder.mOkHttpClient.newBuilder().hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        }).build()).build();
    }

    public Retrofit getRetrofit() {
        checkNotNull(mRetrofit);
        return mRetrofit;
    }

    public Retrofit getPrinterRetrofit() {
        checkNotNull(mPrinterRetrofit);
        return mPrinterRetrofit;
    }


    public static class Builder {

        private Context mContext;

        private Retrofit.Builder mRetrofitBuilder;
        private Retrofit mRetrofit = null;

        private OkHttpClient mOkHttpClient = null;
        private OkHttpClient.Builder mOkHttpClientBuilder;

        private boolean mCacheEnable = false;
        private Cache mCache = null;
        private long mCacheTime = DEFAULT_CACHE_TIME;
        private long mCacheOnlineTime = 0;

        private boolean mIsDefaultConvertFactory = false;
        private boolean mIsDefaultCallFactory = false;

        private List<Converter.Factory> mConverterFactories = new ArrayList<>();
        private List<CallAdapter.Factory> mCallAdapterFactories = new ArrayList<>();

        public Builder() {
            mContext = getContext();
            mRetrofitBuilder = new Retrofit.Builder();
            mOkHttpClientBuilder = new OkHttpClient.Builder();
        }

        public OkHttpClient.Builder getOkHttpClientBuilder() {
            return mOkHttpClientBuilder;
        }

        /**
         * 设置baseUrl
         *
         * @param baseUrl
         * @return
         */
        public Builder baseUrl(@NonNull String baseUrl) {
            checkHttpURL(baseUrl);
            if (!baseUrl.endsWith("/")) {
                baseUrl += "/";
            }
            mRetrofitBuilder.baseUrl(baseUrl);
            return this;
        }

        /**
         * 是否开启缓存
         * <p>
         * 默认缓存
         * 位置: /sdcard/Android/data/YourPackageName/cache/
         * /data/data/package/cache
         *
         * @param cacheEnable
         * @return
         */
        public Builder cacheEnable(boolean cacheEnable) {
            this.mCacheEnable = cacheEnable;
            return this;
        }

        /**
         * 自定义缓存
         *
         * @param cache
         * @return
         */
        public Builder cache(Cache cache) {
            mCache = cache;
            if (mCache != null) {
                cacheEnable(true);
            }
            return this;
        }

        /**
         * 设置离线缓存有效期限，默认1天
         *
         * @param cacheTime 单位：s
         * @return
         * @see CacheOfflineInterceptor
         */
        public Builder cacheTime(long cacheTime) {
            mCacheTime = cacheTime;
            cacheEnable(true);
            return this;
        }

        /**
         * 设置在线缓存有效期限，默认0s：每次都重新请求
         *
         * @param cacheOnlineTime 单位：s
         * @return
         * @see CacheOnlineInterceptor
         */
        public Builder cacheOnlineTime(long cacheOnlineTime) {
            mCacheOnlineTime = cacheOnlineTime;
            cacheEnable(true);
            return this;
        }

        /**
         * 是否自动重连
         *
         * @param retryOnConnectionFailure
         * @return
         */
        public Builder retryOnConnectionFailure(boolean retryOnConnectionFailure) {
            mOkHttpClientBuilder.retryOnConnectionFailure(retryOnConnectionFailure);
            return this;
        }

        /**
         * 添加拦截器
         *
         * @param interceptor
         * @return
         */
        public Builder addInterceptor(@NonNull Interceptor interceptor) {
            mOkHttpClientBuilder.addInterceptor(interceptor);
            return this;
        }

        /**
         * 添加网络拦截器
         *
         * @param interceptor
         * @return
         */
        public Builder addNetworkInterceptor(@NonNull Interceptor interceptor) {
            mOkHttpClientBuilder.addNetworkInterceptor(interceptor);
            return this;
        }

        /**
         * 设置转换工厂
         *
         * @param factory
         * @return
         */
        public Builder addConverterFactory(@NonNull Converter.Factory factory) {
            if (factory instanceof ScalarsConverterFactory) {
                mIsDefaultConvertFactory = false;
            }
            mConverterFactories.add(factory);
            return this;
        }

        /**
         * 设置回调工厂
         *
         * @param factory
         * @return
         */
        public Builder addCallAdapterFactory(@NonNull CallAdapter.Factory factory) {
            if (factory instanceof RxJava2CallAdapterFactory) {
                mIsDefaultCallFactory = false;
            }
            mCallAdapterFactories.add(factory);
            return this;
        }

        /**
         * 设置连接超时
         *
         * @param timeout
         * @param timeUnit
         * @return
         */
        public Builder connectTimeout(long timeout, TimeUnit timeUnit) {
            if (timeout < 0) {
                mOkHttpClientBuilder.connectTimeout(DEFAULT_NET_TIMEOUT, TimeUnit.SECONDS);
            } else {
                mOkHttpClientBuilder.connectTimeout(timeout, timeUnit);
            }
            return this;
        }

        /**
         * 设置连接超时，单位为s
         *
         * @param timeout
         * @return
         */
        public Builder connectTimeout(long timeout) {
            return connectTimeout(timeout, TimeUnit.SECONDS);
        }

        /**
         * 设置读超时
         *
         * @param timeout
         * @param timeUnit
         * @return
         */
        public Builder readTimeout(long timeout, TimeUnit timeUnit) {
            if (timeout < 0) {
                mOkHttpClientBuilder.readTimeout(DEFAULT_NET_TIMEOUT, TimeUnit.SECONDS);
            } else {
                mOkHttpClientBuilder.readTimeout(timeout, timeUnit);
            }
            return this;
        }

        /**
         * 设置读超时
         *
         * @param timeout
         * @return
         */
        public Builder readTimeout(long timeout) {
            return readTimeout(timeout, TimeUnit.SECONDS);
        }

        /**
         * 设置写超时
         *
         * @param timeout
         * @param timeUnit
         * @return
         */
        public Builder writeTimeout(long timeout, TimeUnit timeUnit) {
            if (timeout < 0) {
                mOkHttpClientBuilder.writeTimeout(DEFAULT_NET_TIMEOUT, TimeUnit.SECONDS);
            } else {
                mOkHttpClientBuilder.writeTimeout(timeout, timeUnit);
            }
            return this;
        }

        /**
         * 设置写超时
         *
         * @param timeout
         * @return
         */
        public Builder writeTimeout(long timeout) {
            return writeTimeout(timeout, TimeUnit.SECONDS);
        }

        /**
         * 统一设置超时
         *
         * @param timeout
         * @return
         */
        public Builder setTimeout(long timeout) {
            mOkHttpClientBuilder.connectTimeout(timeout, TimeUnit.SECONDS);
            mOkHttpClientBuilder.readTimeout(timeout, TimeUnit.SECONDS);
            mOkHttpClientBuilder.writeTimeout(timeout, TimeUnit.SECONDS);
            return this;
        }

        /**
         * 添加Log打印
         *
         * @param isEnable
         * @return
         */
        public Builder addLog(boolean isEnable) {
            if (isEnable) {
                //打印网络请求日志
                final LoggingInterceptor httpLoggingInterceptor = new LoggingInterceptor.Builder()
                        .loggable(true)
                        .setLevel(Level.BODY)
                        .log(Platform.INFO)
                        .request("Request")
                        .response("Response")
                        .build();
                mOkHttpClientBuilder.addInterceptor(httpLoggingInterceptor);
            }
            return this;
        }

        /**
         * 配置此客户端以跟踪重定向。默认true，自动重定向；如果false，会拦截到状态码30X
         *
         * @param followRedirects
         * @return
         */
        public Builder followRedirects(boolean followRedirects) {
            mOkHttpClientBuilder.followRedirects(followRedirects);
            return this;
        }

        /**
         * 配置此客户端以跟踪从HTTPS到HTTP以及从HTTP到HTTPS的重定向。默认true
         * 如果未设置，将遵循协议重定向。
         *
         * @param followProtocolRedirects
         * @return
         */
        public Builder followSslRedirects(boolean followProtocolRedirects) {
            mOkHttpClientBuilder.followSslRedirects(followProtocolRedirects);
            return this;
        }

        /**
         * HTTPS不做SSL校验
         *
         * @return
         */
        public Builder avoidSslVerification() {
            // Avoid ssl verification, this is not safe
            mOkHttpClientBuilder.hostnameVerifier((HostnameVerifier) (hostname, session) -> true);
            return this;
        }

        /**
         * 自定义{@link OkHttpClient}，其他自定义设置会被覆盖，如{@link #followRedirects(boolean)}
         *
         * @param okHttpClient
         * @return
         */
        public Builder okHttpClient(OkHttpClient okHttpClient) {
            mOkHttpClient = okHttpClient;
            return this;
        }

        public RetrofitWrapper build() {
            mOkHttpClient = mOkHttpClientBuilder.build();
            if (mCacheEnable) {
                /**
                 * 默认不开启的缓存
                 */
                if (mCache == null) {
                    File cacheFile = mContext.getExternalCacheDir();
                    if (cacheFile == null) {
                        cacheFile = mContext.getCacheDir();
                    }
                    cache(new Cache(cacheFile, DEFAULT_CACHE_SIZE));
                }
                //这里重新获取OkHttpClient.Builder对象是为了避免build()方法被多次执行时多次添加cache相关的拦截器
                OkHttpClient.Builder okHttpClientBuilder = mOkHttpClient.newBuilder();
                okHttpClientBuilder.cache(mCache);
                final CacheOfflineInterceptor cacheOfflineInterceptor = new CacheOfflineInterceptor(mContext, mCacheTime);
                final CacheOnlineInterceptor cacheOnlineInterceptor = new CacheOnlineInterceptor(mCacheOnlineTime);
                okHttpClientBuilder.addInterceptor(cacheOfflineInterceptor);
                okHttpClientBuilder.addNetworkInterceptor(cacheOfflineInterceptor);
                okHttpClientBuilder.addNetworkInterceptor(cacheOnlineInterceptor);
                mRetrofitBuilder.client(okHttpClientBuilder.build());
            } else {
                mRetrofitBuilder.client(mOkHttpClient);
            }

            if (mIsDefaultConvertFactory) {
                // 默认不支持字符串数据转换
                mRetrofitBuilder.addConverterFactory(ScalarsConverterFactory.create());
            }
            for (Converter.Factory converterFactory : mConverterFactories) {
                mRetrofitBuilder.addConverterFactory(converterFactory);
            }

            if (mIsDefaultCallFactory) {
                // 默认不支持RxJava回调
                mRetrofitBuilder.addCallAdapterFactory(RxJava2CallAdapterFactory.create());
            }
            for (CallAdapter.Factory callAdapterFactory : mCallAdapterFactories) {
                mRetrofitBuilder.addCallAdapterFactory(callAdapterFactory);
            }

            mRetrofit = mRetrofitBuilder.build();
            return new RetrofitWrapper(this);
        }
    }
}
