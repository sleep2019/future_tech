package com.shopee.sc.common.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;

import androidx.annotation.DrawableRes;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;

import com.shopee.sc.common.R;

public class CommonDividerItemDecoration extends DividerItemDecoration {

    public CommonDividerItemDecoration(Context context, int orientation) {
        super(context, orientation);
        Drawable drawable = ContextCompat.getDrawable(context, R.drawable.common_divider_gray_horizontal);
        if (drawable != null) {
            setDrawable(drawable);
        }
    }

    public CommonDividerItemDecoration(Context context, int orientation, @DrawableRes int dividerDrawable) {
        super(context, orientation);
        Drawable drawable = ContextCompat.getDrawable(context,
                dividerDrawable == 0 ? R.drawable.common_divider_gray_horizontal : dividerDrawable);
        if (drawable != null) {
            setDrawable(drawable);
        }
    }
}

