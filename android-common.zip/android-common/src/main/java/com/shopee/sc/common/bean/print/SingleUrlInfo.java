package com.shopee.sc.common.bean.print;

import com.google.gson.annotations.SerializedName;

/**
 * Created by honggang.xiong on 2020/8/13.
 */
public class SingleUrlInfo {

    @SerializedName("url")
    private String url;

    public SingleUrlInfo() {
    }

    public SingleUrlInfo(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}
