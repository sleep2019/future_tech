package com.shopee.sc.common.widget.dropdown;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.Objects;

/**
 * Created by honggang.xiong on 2021/4/7.
 */
public class CommonViewDropDownDisplay implements IDropDownDisplay {

    private final View mView;
    private boolean mPendingHide = false;

    public CommonViewDropDownDisplay(@NonNull View view) {
        mView = Objects.requireNonNull(view);
        mView.setPivotY(0);
    }

    @Override
    public boolean isShowing() {
        return mView.getVisibility() == View.VISIBLE && !mPendingHide;
    }

    @Override
    public void show() {
        mPendingHide = false;
        mView.animate().cancel();
        mView.setVisibility(View.VISIBLE);
        mView.setScaleY(0);
        mView.animate().scaleY(1)
                .setDuration(DropDownCoordinator.ANIM_IN_MILLIS)
                .setListener(null) // 需手动置为空，否则将复用 hide 动画的 listener
                .start();
    }

    @Override
    public void hide() {
        mPendingHide = true;
        mView.animate().cancel();
        mView.setScaleY(1);
        mView.animate().scaleY(0)
                .setDuration(DropDownCoordinator.ANIM_OUT_MILLIS)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        mPendingHide = false;
                        mView.setVisibility(View.GONE);
                    }
                })
                .start();
    }

}
