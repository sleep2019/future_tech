package com.shopee.sc.common.base;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.android.scanner.adapter.ScannerManager;
import com.shopee.android.scanner.base.IScannerCallback;
import com.shopee.android.scanner.base.IScannerTool;
import com.shopee.android.scanner.base.bean.ScanError;
import com.shopee.android.scanner.base.bean.ScanResult;
import com.shopee.android.scanner.base.bean.ScanState;
import com.shopee.android.scanner.base.constant.ScannerMode;
import com.shopee.sc.logger.api.Logger;

/**
 * Created by honggang.xiong on 2021/11/24.
 */
public abstract class CommonScanFragment extends CommonFragment implements IScannerCallback {

    private static final String TAG = "CommonScanFragment";

    public IScannerTool mScannerTool; // 具体的扫描对象

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (enableScan()) {
            mScannerTool = ScannerManager.getInstance().getScanner(objectToString(), true, true);
            if (mScannerTool != null) {
                mScannerTool.onCreate(getContext());
            }
        }
    }

    @CallSuper
    protected void onVisible() {
        super.onVisible();
        if (enableScan() && mScannerTool != null) {
            mScannerTool.setScannerCallback(this);
            mScannerTool.onResume();
        }
    }

    @CallSuper
    protected void onInvisible() {
        super.onInvisible();
        if (enableScan() && mScannerTool != null) {
            mScannerTool.onPause();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (enableScan() && mScannerTool != null) {
            mScannerTool.onDestroy();
            ScannerManager.getInstance().releaseScanner(objectToString());
        }
    }

    /**
     * 生命周期内返回固定值
     */
    protected boolean enableScan() {
        return false;
    }

    /**
     * 转接方法，scanResult 已判断为非空，不同项目可继续增加判断，比如是否在 loading
     */
    protected void tryHandleScanResult(@NonNull String scanResult) {
        // default no-op
    }

    @Override
    public void onScanStatus(ScanState scanState) {
        Logger.d(TAG, "onScanStatus - " + scanState);
    }

    @Override
    public void onScanSuccess(ScanResult scanResult) {
        String result = scanResult == null ? null : scanResult.getScanData();
        Logger.i(TAG, "onScanSuccess - " + result);
        if (!TextUtils.isEmpty(result)) {
            tryHandleScanResult(result);
        }
    }

    @Override
    public void onScanError(ScanError scanError) {
        Logger.w(TAG, "onScanError - " + scanError);
    }

    protected void triggerSoftOnceScan() {
        switchTriggerType(ScannerMode.SOFT_ONCE_TYPE);
    }

    /**
     * 切换状态(这个方法是扫描的入口)
     *
     * @param triggerType
     */
    protected void switchTriggerType(int triggerType) {
        if (enableScan() && mScannerTool != null) {
            mScannerTool.switchScanMode(triggerType);
        }
    }

    protected int getCurrentScanMode() {
        if (mScannerTool == null) {
            return ScannerMode.STOP;
        }
        return mScannerTool.getCurrentScanMode();
    }

    public String objectToString() {
        return getClass().getName() + "@" + Integer.toHexString(hashCode());
    }

}
