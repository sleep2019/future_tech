package com.shopee.sc.common.widget.popup;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.PopupWindow;

import com.shopee.sc.logger.api.Logger;

/**
 * @ClassName: BasePopupWindow
 * @Description: PopupWindow的基类
 * @Author: lanjingzeng
 * @CreateDate: 2020/12/25 10:39 AM
 * @Version: 1.0
 */
public class BasePopupWindow implements PopupWindow.OnDismissListener {
    private static final String TAG = "BasePopupWindow";
    protected Context mContext;
    protected PopupWindow mPopupWindow;
    //显示时其他空白区域的透明度
    private float mDisplayAlpha;
    private PopupWindow.OnDismissListener mOnDismissListener;

    public BasePopupWindow(Context context) {
        mContext = context;
        mDisplayAlpha = (float) 0.4954;//默认的空白区域alpha
        mPopupWindow = new PopupWindow(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mPopupWindow.setOnDismissListener(this);
    }

    public PopupWindow getPopupwindow() {
        return mPopupWindow;
    }

    public View getContentView() {
        if (mPopupWindow == null) {
            return null;
        }
        return mPopupWindow.getContentView();
    }

    /**
     * 设置显示时其他空白区域的透明度
     */
    public void setDisplayAlpha(float alpha) {
        mDisplayAlpha = alpha;
    }

    private void setAlpha(float alpha) {
        Activity activity = (Activity) mContext;
        Window window = activity.getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        params.alpha = alpha;
        window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        window.setAttributes(params);
    }

    public void setLayoutParams(int width, int height) {
        mPopupWindow.setWidth(width);
        mPopupWindow.setHeight(height);
    }

    public int getWidth() {
        return mPopupWindow.getWidth();
    }

    public int getHeight() {
        return mPopupWindow.getHeight();
    }

    public void setOnDismissListener(PopupWindow.OnDismissListener onDismissListener) {
        mOnDismissListener = onDismissListener;
    }

    public void showAsDropDown(View anchorView, int xoff, int yoff, int gravity) {
        if (mPopupWindow == null) {
            return;
        }
        if (mPopupWindow.isShowing()) {
            return;
        }
        setAlpha(mDisplayAlpha);
        mPopupWindow.showAsDropDown(anchorView, xoff, yoff, gravity);
    }

    public void showAtLocation(View anchorView, int gravity, int xoff, int yoff) {
        if (mPopupWindow == null) {
            return;
        }
        if (mPopupWindow.isShowing()) {
            return;
        }
        setAlpha(mDisplayAlpha);
        mPopupWindow.showAtLocation(anchorView, gravity, xoff, yoff);
    }

    public boolean isShowing() {
        if (mPopupWindow == null) {
            return false;
        }
        return mPopupWindow.isShowing();
    }

    public void dismissPopupWindow() {
        if (mPopupWindow == null) {
            return;
        }
        if (!mPopupWindow.isShowing()) {
            return;
        }
        mPopupWindow.dismiss();
    }

    @Override
    public void onDismiss() {
        setAlpha(1.0f);
        if (mOnDismissListener != null) {
            mOnDismissListener.onDismiss();
        }
    }

    public void setOutsideTouchable(boolean touchable) {
        mPopupWindow.setOutsideTouchable(touchable);
    }

    public void setMaxHeight(int maxHeight) {
        View contentView = getContentView();
        contentView.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                int height = contentView.getHeight();
                Logger.i(TAG, "height:" + height + "   maxHeight:" + maxHeight);
                if (height <= maxHeight) {
                    contentView.getViewTreeObserver().removeOnPreDrawListener(this);
                    return true;
                }
                height = maxHeight;
                ViewGroup.LayoutParams lp = contentView.getLayoutParams();
                lp.height = height;
                contentView.setLayoutParams(lp);
                mPopupWindow.setHeight(height);
                contentView.getViewTreeObserver().removeOnPreDrawListener(this);
                return true;
            }
        });
    }

}
