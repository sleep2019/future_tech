package com.shopee.sc.common.viewbinding;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;

import com.shopee.sc.common.util.ViewBindingUtil;

/**
 * View Binding Creator，默认方法已实现默认逻辑（反射调用 VB 的 inflate 方法），如无特殊逻辑 implements 即可。
 * 一般用于 Activity、Fragment、Adapter。
 *
 * 注意：如子类未指定 VB 具体生成类，则必须实现 {@link #createCustomViewBinding(LayoutInflater, ViewGroup, boolean)}
 * 方法并返回非空结果，否则反射将报错。
 *
 * Created by honggang.xiong on 2021/3/23.
 */
public interface ViewBindingCreator<VB extends ViewBinding> {

    @Nullable
    default VB createCustomViewBinding(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
        return null;
    }

    @NonNull
    default VB createViewBinding(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
        VB viewBinding = createCustomViewBinding(inflater, parent, attachToParent);
        if (viewBinding != null) {
            return viewBinding;
        }
        return ViewBindingUtil.inflate(this, inflater, parent, attachToParent);
    }

}
