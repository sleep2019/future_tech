package com.shopee.sc.common.plugins;

import androidx.annotation.NonNull;

import com.shopee.sc.common.functions.CommonFunctions;
import com.shopee.sc.common.functions.IExecutor;
import com.shopee.sc.common.functions.ILog;
import com.shopee.sc.common.functions.IToast;
import com.shopee.sc.common.util.RxUtils;
import com.shopee.sc.logger.api.LogPrinter;
import com.shopee.sc.logger.api.Logger;

import java.util.Objects;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by honggang.xiong on 2019-07-26.
 * <p>
 * common 模块下的 log、toast 等操作，统一通过本类代理，以适配不同 App 的个性化需求
 */
public class CommonPlugins {

    @NonNull
    private static final ILog sLogger = new LogPrintWrapper() {
        @NonNull
        @Override
        protected LogPrinter getPrinter() {
            return Logger.getPrinter();
        }
    };

    @NonNull
    private static final ILog sNetLogger = new LogPrintWrapper() {
        @NonNull
        @Override
        protected LogPrinter getPrinter() {
            return Logger.getReportPrinter();
        }
    };

    @NonNull
    private static IToast sToaster = CommonFunctions.NO_OP_TOAST;

    @NonNull
    private static IExecutor sMainExecutor = RxUtils.wrapScheduler(AndroidSchedulers.mainThread());
    @NonNull
    private static IExecutor sIoExecutor = RxUtils.wrapScheduler(Schedulers.io());
    @NonNull
    private static IExecutor sComputeExecutor = RxUtils.wrapScheduler(Schedulers.computation());
    @NonNull
    private static IExecutor sSingleExecutor = RxUtils.wrapScheduler(Schedulers.single());

    /**
     * 直接使用 {@link Logger} 或者 {@link Logger#getPrinter()}
     */
    @NonNull
    @Deprecated
    public static ILog getLogger() {
        return sLogger;
    }

    /**
     * 直接使用 {@link Logger} 或者 {@link Logger#getReportPrinter()}
     */
    @NonNull
    @Deprecated
    public static ILog getNetLogger() {
        return sNetLogger;
    }

    @NonNull
    public static IToast getToaster() {
        return sToaster;
    }

    public static void setToaster(@NonNull IToast toaster) {
        Objects.requireNonNull(toaster, "toaster can not be null");
        sToaster = toaster;
    }

    @NonNull
    public static IExecutor getMainExecutor() {
        return sMainExecutor;
    }

    public static void setMainExecutor(@NonNull IExecutor mainExecutor) {
        Objects.requireNonNull(mainExecutor, "mainExecutor can not be null");
        sMainExecutor = mainExecutor;
    }

    @NonNull
    public static IExecutor getIoExecutor() {
        return sIoExecutor;
    }

    public static void setIoExecutor(@NonNull IExecutor ioExecutor) {
        Objects.requireNonNull(ioExecutor, "ioExecutor can not be null");
        sIoExecutor = ioExecutor;
    }

    @NonNull
    public static IExecutor getComputeExecutor() {
        return sComputeExecutor;
    }

    public static void setComputeExecutor(@NonNull IExecutor computeExecutor) {
        Objects.requireNonNull(computeExecutor, "computeExecutor can not be null");
        sComputeExecutor = computeExecutor;
    }

    @NonNull
    public static IExecutor getSingleExecutor() {
        return sSingleExecutor;
    }

    public static void setSingleExecutor(@NonNull IExecutor singleExecutor) {
        Objects.requireNonNull(singleExecutor, "singleExecutor can not be null");
        sSingleExecutor = singleExecutor;
    }
}
