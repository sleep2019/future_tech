package com.shopee.sc.common.widget.adapter.viewbinding;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.sc.common.viewbinding.ViewBindingCreator;
import com.shopee.sc.logger.api.Logger;

import java.util.List;

/**
 * Created by honggang.xiong on 2021/3/29.
 */
public abstract class BaseViewBindingAdapter<T, VB extends ViewBinding> extends BaseQuickAdapter<T, ViewBindingViewHolder<VB>>
        implements ViewBindingCreator<VB> {

    public BaseViewBindingAdapter() {
        super(null);
    }

    public BaseViewBindingAdapter(@Nullable List<T> data) {
        super(data);
    }

    // 子类不用传 id，指定 VB 具体类即可
    public BaseViewBindingAdapter(int layoutResId) {
        super(0);
    }

    public BaseViewBindingAdapter(int layoutResId, @Nullable List<T> data) {
        super(0, data);
    }

    /**
     * convert with non null ViewBinding instance
     */
    protected abstract void convertWithVB(@NonNull BaseViewHolder helper, @NonNull VB viewBinding, T item);

    @Override
    protected final void convert(@NonNull ViewBindingViewHolder<VB> helper, T item) {
        VB viewBinding = helper.getViewBinding();
        if (viewBinding != null) {
            convertWithVB(helper, viewBinding, item);
        } else {
            Logger.w("convert find null viewBinding!", new Exception());
        }
    }

    @Override
    protected final ViewBindingViewHolder<VB> createBaseViewHolder(ViewGroup parent, int layoutResId) {
        if (layoutResId == 0) {
            VB viewBinding = createViewBinding(mLayoutInflater, parent, false);
            return new ViewBindingViewHolder<>(viewBinding.getRoot(), viewBinding);
        }
        return super.createBaseViewHolder(parent, layoutResId);
    }

    @Override
    protected final ViewBindingViewHolder<VB> createBaseViewHolder(View view) {
        return new ViewBindingViewHolder<>(view, null);
    }

}
