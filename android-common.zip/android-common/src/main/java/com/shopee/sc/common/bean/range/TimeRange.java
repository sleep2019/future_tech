package com.shopee.sc.common.bean.range;

/**
 * Created by honggang.xiong on 2021/4/8.
 */
public class TimeRange {

    private final long startSecond;
    private final long endSecond;
    private final boolean isWholeMonth;

    public TimeRange(long startSecond, long endSecond, boolean isWholeMonth) {
        this.startSecond = startSecond;
        this.endSecond = endSecond;
        this.isWholeMonth = isWholeMonth;
    }

    public long getStartSecond() {
        return startSecond;
    }

    public long getEndSecond() {
        return endSecond;
    }

    public boolean isWholeMonth() {
        return isWholeMonth;
    }
}
