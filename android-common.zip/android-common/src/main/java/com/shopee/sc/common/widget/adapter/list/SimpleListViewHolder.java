package com.shopee.sc.common.widget.adapter.list;

import android.util.SparseArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;

/**
 * Simple ListView ViewHolder.
 * <p>
 * Created by honggang.xiong on 2019-11-15.
 */
public class SimpleListViewHolder {

    @NonNull
    public final View itemView;

    /**
     * Views indexed with their IDs
     */
    private final SparseArray<View> mViews = new SparseArray<>();

    public SimpleListViewHolder(@NonNull View itemView) {
        if (itemView == null) {
            throw new IllegalArgumentException("itemView may not be null");
        }
        this.itemView = itemView;
    }

    @SuppressWarnings("unchecked")
    public <T extends View> T getView(@IdRes int viewId) {
        View view = mViews.get(viewId);
        if (view == null) {
            view = itemView.findViewById(viewId);
            mViews.put(viewId, view);
        }
        return (T) view;
    }

    public TextView getTextView(@IdRes int viewId) {
        return getView(viewId);
    }

    public ImageView getImageView(@IdRes int viewId) {
        return getView(viewId);
    }
}
