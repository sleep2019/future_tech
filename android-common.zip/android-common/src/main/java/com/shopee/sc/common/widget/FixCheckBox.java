package com.shopee.sc.common.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.sc.common.widget.helper.TextViewCompatHelper;

/**
 * 修复 CheckBox 在 6.0 及以下使用 drawStart/drawLeft、drawEnd/drawRight 时 drawable 首帧绘制状态和
 * 控件实际状态不一致的问题
 *
 * Created by honggang.xiong on 2021/3/15.
 */
@SuppressLint("AppCompatCustomView")
public class FixCheckBox extends CheckBox {

    private final TextViewCompatHelper mHelper = new TextViewCompatHelper();

    public FixCheckBox(@NonNull Context context) {
        super(context);
    }

    public FixCheckBox(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public FixCheckBox(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        mHelper.tryDetectInconsistentDrawableStateOnMeasure(this);
    }

}
