package com.shopee.sc.common.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

/**
 * Created by javy on 29/07/2020.
 */
public class GlideUtils {

    private GlideUtils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    /**
     * 默认加载
     */
    public static void loadImageView(String path, ImageView mImageView) {
        Glide.with(mImageView.getContext()).load(path).into(mImageView);
    }

    public static void loadImageWithError(String path, int errorRes, ImageView mImageView) {
        Glide.with(mImageView.getContext())
                .load(path)
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                .error(errorRes)
                .into(mImageView);
    }

    /**
     * 设置加载中以及加载失败图片
     */
    public static void loadImageWithLoading(String path, ImageView mImageView, int loadingImage, int errorRes) {
        Glide.with(mImageView.getContext())
                .load(path)
                .placeholder(loadingImage)
                .error(errorRes)
                .into(mImageView);
    }

    /**
     * 清理磁盘缓存需要在子线程中执行
     */
    public static void clearDiskCache(Context mContext) {
        Glide.get(mContext).clearDiskCache();
    }

    /**
     * 清理内存缓存可以在UI主线程中进行
     */
    public static void clearMemory(Context mContext) {
        Glide.get(mContext).clearMemory();
    }

}