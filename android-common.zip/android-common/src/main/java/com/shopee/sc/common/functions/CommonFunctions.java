package com.shopee.sc.common.functions;

import androidx.annotation.NonNull;

import com.shopee.sc.common.bean.Result;

/**
 * Created by honggang.xiong on 2019-07-26.
 */
public class CommonFunctions {

    public static final Consumer NO_OP_CONSUMER = new SimpleConsumer<>();
    public static final BiConsumer NO_OP_BI_CONSUMER = new SimpleBiConsumer<>();
    public static final IToast NO_OP_TOAST = new EmptyToast();

    @SuppressWarnings("unchecked")
    public static <T> Consumer<T> noOpConsumer() {
        return (Consumer<T>) NO_OP_CONSUMER;
    }

    @SuppressWarnings("unchecked")
    public static <T1, T2> BiConsumer<T1, T2> noOpBiConsumer() {
        return (BiConsumer<T1, T2>) NO_OP_BI_CONSUMER;
    }


    private static class SimpleConsumer<E> implements Consumer<E> {
        @Override
        public void accept(E e) {

        }
    }

    private static class SimpleBiConsumer<E1, E2> implements BiConsumer<E1, E2> {
        @Override
        public void accept(E1 e1, E2 e2) {

        }
    }

    public static class EmptyToast implements IToast {
        @Override
        public void showShort(CharSequence text) {

        }

        @Override
        public void showShort(int resId) {

        }

        @Override
        public void showLong(CharSequence text) {

        }

        @Override
        public void showLong(int resId) {

        }

        @Override
        public void toast(@NonNull Result<?> result, boolean longToast) {

        }

        @Override
        public void toast(@NonNull Throwable throwable, boolean longToast) {

        }
    }

}
