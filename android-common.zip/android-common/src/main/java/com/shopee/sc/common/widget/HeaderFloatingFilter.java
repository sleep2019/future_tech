package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;
import com.shopee.sc.common.R;
import com.shopee.sc.common.widget.adapter.SingleChoiceAdapter;
import com.shopee.sc.common.widget.dropdown.CheckBoxDropDownTrigger;
import com.shopee.sc.common.widget.dropdown.CommonViewDropDownDisplay;
import com.shopee.sc.common.widget.dropdown.DropDownCoordinator;
import com.shopee.sc.logger.api.Logger;

import java.util.List;

/**
 * 自定义筛选器，支持单选筛选项
 *
 * @author zhangkaiwen
 * @date 2022/6/14
 */
public class HeaderFloatingFilter extends ConstraintLayout {

    private TabLayout mTlHeaderFilter;
    private CheckBox mCbHeaderFilter;
    private RecyclerView mRvFloatingFilter;

    private boolean mPreventMultiFetch = false;
    private SingleChoiceAdapter<IFilterData> mFloatingAdapter;
    private IFilterData mCurrentData = null;

    private OnTabSelectedListener mOnTabSelectedListener;
    private OnTabResetListener mOnTabResetListener;

    public HeaderFloatingFilter(@NonNull Context context) {
        this(context, null);
    }

    public HeaderFloatingFilter(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public HeaderFloatingFilter(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        inflate(context, R.layout.common_layout_header_floating_filter, this);
        initView();
        initHeaderFilterListeners();
    }

    private void initView() {
        mTlHeaderFilter = findViewById(R.id.tlHeaderFilter);
        mCbHeaderFilter = findViewById(R.id.cbHeaderFilter);
        mRvFloatingFilter = findViewById(R.id.rvFloatingFilter);

        View viewMask = findViewById(R.id.view_mask);
        ConstraintLayout containerFloatingFilter = findViewById(R.id.containerFloatingFilter);
        CheckBoxDropDownTrigger trigger = new CheckBoxDropDownTrigger(mCbHeaderFilter);
        new DropDownCoordinator.Builder()
                .setMaskView(viewMask)
                .addPair(trigger, new CommonViewDropDownDisplay(containerFloatingFilter))
                .build();
    }

    public void initFilter(@NonNull RecyclerView.LayoutManager layoutManager,
                           @NonNull SingleChoiceAdapter<IFilterData> floatingAdapter,
                           @NonNull OnTabSelectedListener onTabSelectedListener,
                           @Nullable OnTabResetListener onTabResetListener) {
        initFloatingAdapter(layoutManager, floatingAdapter);
        setOnTabSelectedListener(onTabSelectedListener);
        setOnTabResetListener(onTabResetListener);
    }

    /**
     * 获取当前选中的 tab
     */
    @Nullable
    public IFilterData getCurrentFilterData() {
        return mCurrentData;
    }

    /**
     * 如需刷新并重置 filter，先调此方法，再调 {@link #updateAndResetFloatingFilterView}
     */
    public void setPendingResetFilter() {
        mCurrentData = null;
    }

    /**
     * 刷新并重置 filter
     * 需先调 {@link #setPendingResetFilter}
     */
    @MainThread
    public void updateAndResetFloatingFilterView(@NonNull List<IFilterData> filterList) {
        boolean needReset = mCurrentData == null;
        if (needReset) {
            mFloatingAdapter.replaceOriginData(filterList, 0);
            mPreventMultiFetch = true;
            resetFilterTabs(filterList);
            changeHeaderFilterCheckedPosition(0);
            mPreventMultiFetch = false;
        }
    }

    private void initFloatingAdapter(RecyclerView.LayoutManager layoutManager,
                                     SingleChoiceAdapter<IFilterData> floatingAdapter) {
        mFloatingAdapter = floatingAdapter;
        mRvFloatingFilter.setLayoutManager(layoutManager);
        mRvFloatingFilter.setAdapter(mFloatingAdapter);
        mFloatingAdapter.setOnCheckedChangeListener((checkedData, checkedPosition)
                -> changeHeaderFilterCheckedPosition(checkedPosition));
    }

    private void initHeaderFilterListeners() {
        mTlHeaderFilter.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mFloatingAdapter.check(tab.getPosition());
                mCurrentData = mFloatingAdapter.getCheckedData();
                if (!mPreventMultiFetch && mOnTabSelectedListener != null) {
                    mOnTabSelectedListener.onTabSelected(tab);
                }
                if (mCbHeaderFilter.isChecked()) {
                    // 隐藏悬浮筛选框
                    mCbHeaderFilter.performClick();
                }

                changeHeaderFilterCheckedPosition(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        mTlHeaderFilter.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            boolean canScrollHorizontally = v.canScrollHorizontally(1) || v.canScrollHorizontally(-1);
            Logger.d("onLayoutChange canScrollHorizontally=" + canScrollHorizontally);
            v.post(() -> {
                mCbHeaderFilter.setVisibility(canScrollHorizontally ? View.VISIBLE : View.GONE);
            });
        });
    }

    private void changeHeaderFilterCheckedPosition(int pos) {
        mTlHeaderFilter.selectTab(mTlHeaderFilter.getTabAt(pos));
        if (mCbHeaderFilter.isChecked()) {
            // 隐藏悬浮筛选框
            mCbHeaderFilter.performClick();
        }
    }

    private void resetFilterTabs(List<IFilterData> currentFilterList) {
        mTlHeaderFilter.removeAllTabs();
        Context context = getContext();
        for (int i = 0; i < currentFilterList.size(); i++) {
            IFilterData tabData = currentFilterList.get(i);
            View view = LayoutInflater.from(context)
                    .inflate(R.layout.common_item_floating_filter_tab, new LinearLayout(context), false);
            String content = tabData.getTitle();
            if (mOnTabResetListener != null) {
                content = mOnTabResetListener.onTabReset(currentFilterList.size(), i,
                        content, view.findViewById(android.R.id.text1));
            }
            mTlHeaderFilter.addTab(mTlHeaderFilter.newTab()
                    .setCustomView(view)
                    .setText(content));
        }
    }

    /**
     * 设置点击 tab 时的回调
     */
    public void setOnTabSelectedListener(OnTabSelectedListener onTabSelectedListener) {
        mOnTabSelectedListener = onTabSelectedListener;
    }

    public void setOnTabResetListener(OnTabResetListener onTabResetListener) {
        this.mOnTabResetListener = onTabResetListener;
    }

    public interface IFilterData {

        default int getIntId() {
            return -1;
        };

        default String getStringId() {
            return "";
        };

        String getTitle();

    }

    public interface OnTabSelectedListener {
        /**
         * called when a tab is selected.
         *
         * @param tab the selected tab
         */
        void onTabSelected(TabLayout.Tab tab);
    }

    public interface OnTabResetListener {
        /**
         * called when each tab {@link IFilterData} is getting added into tab layout {@link #mTlHeaderFilter}
         * @param size total size of tabs
         * @param index index of the current tab that is getting added
         * @param title title of the current tab
         * @param textView the current tab displays in this textView
         * @return the displayed content of the current tab
         */
        String onTabReset(int size, int index, String title, TextView textView);
    }

}
