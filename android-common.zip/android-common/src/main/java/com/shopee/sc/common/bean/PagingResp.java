package com.shopee.sc.common.bean;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-08-28.
 */
public class PagingResp<T> implements Serializable {

    @SerializedName("count")
    private int count;
    @SerializedName("total")
    private int total;
    @SerializedName("pageno")
    private int pageNumber;
    @SerializedName("list")
    private List<T> list;

    public PagingResp() {
    }

    public PagingResp(int count, int total, int pageNumber, List<T> list) {
        this.count = count;
        this.total = total;
        this.pageNumber = pageNumber;
        this.list = list;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    @NonNull
    public List<T> getList() {
        return list != null ? list : Collections.emptyList();
    }

    public int getListCount() {
        return getList().size();
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public void setListAndCount(List<T> list) {
        this.list = list;
        this.count = getList().size();
    }
}
