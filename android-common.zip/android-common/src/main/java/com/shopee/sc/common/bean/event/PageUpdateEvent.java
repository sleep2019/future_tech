package com.shopee.sc.common.bean.event;

/**
 * Created by honggang.xiong on 2020/8/14.
 */
public class PageUpdateEvent extends BaseEvent {

    private int pageType;
    private int extraInfo;

    public PageUpdateEvent(int pageType, int extraInfo) {
        this.pageType = pageType;
        this.extraInfo = extraInfo;
    }

    public int getPageType() {
        return pageType;
    }

    public int getExtraInfo() {
        return extraInfo;
    }

    @Override
    public String toString() {
        return "PageUpdateEvent{" +
                "pageType=" + pageType +
                ", extraInfo=" + extraInfo +
                '}';
    }
}
