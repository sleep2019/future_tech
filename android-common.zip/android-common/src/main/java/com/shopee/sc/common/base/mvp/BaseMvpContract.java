package com.shopee.sc.common.base.mvp;

import com.shopee.sc.common.network.callback.ILoadingCallback;

public interface BaseMvpContract {
    interface Presenter {

    }

    interface View {
        ILoadingCallback getLoadingCallback();
    }
}
