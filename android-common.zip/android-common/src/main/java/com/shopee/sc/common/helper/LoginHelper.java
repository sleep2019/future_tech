package com.shopee.sc.common.helper;


/**
 * 登陆帮助类
 *
 * @author jianwei.luo
 * @date 2021-5-31
 */
public class LoginHelper {

    private LoginHelper() {
    }

    private static LoginCallback sLoginCallback;

    public static void setLoginCallback(LoginCallback loginCallback) {
        sLoginCallback = loginCallback;
    }

    public static LoginCallback getLoginCallback() {
        return sLoginCallback;
    }

    /**
     * 登陆页面回调
     *
     * @author jianwei.luo
     * @date 2021-5-31
     */
    public interface LoginCallback {
        /**
         * 登出
         */
        void logout();

        /**
         * 弹出登出确认弹窗，确认后登出
         */
        void showLogoutDialog(String message);
    }
}
