package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RadioGroup;

public class CusRadioGroup extends RadioGroup {
    public CusRadioGroup(Context context) {
        super(context);
    }

    public CusRadioGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
