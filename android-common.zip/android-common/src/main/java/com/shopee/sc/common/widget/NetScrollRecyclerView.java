package com.shopee.sc.common.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.shopee.sc.common.R;

public class NetScrollRecyclerView extends CusRecyclerView {
    private int mMaxHeight;
    private float mLastY;
    private boolean mIsSupportNestScroll;

    public NetScrollRecyclerView(Context context) {
        super(context);
    }

    public NetScrollRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context, attrs);
    }

    public NetScrollRecyclerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize(context, attrs);
    }

    private void initialize(Context context, AttributeSet attrs) {
        TypedArray arr = context.obtainStyledAttributes(attrs, R.styleable.NetScrollRecyclerView);
        mMaxHeight = arr.getLayoutDimension(R.styleable.NetScrollRecyclerView_maxHeight, mMaxHeight);
        arr.recycle();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mMaxHeight > 0) {
            heightMeasureSpec = MeasureSpec.makeMeasureSpec(mMaxHeight, MeasureSpec.AT_MOST);
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (mIsSupportNestScroll) {
            handleNestScroll(event);
        }
        return super.onTouchEvent(event);
    }

    public void setSupportNestScroll(boolean supportNestScroll) {
        mIsSupportNestScroll = supportNestScroll;
    }

    private void handleNestScroll(MotionEvent event) {
        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                mLastY = event.getY();
                //不允许父View拦截事件
                getParent().requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_MOVE:
                float nowY = event.getY();
                boolean up = nowY < mLastY;
                boolean down = nowY > mLastY;
                if ((down && isCanScrollDown()) || (up && isCanScrollUp())) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                mLastY = nowY;
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                getParent().requestDisallowInterceptTouchEvent(false);
                break;
        }
    }

    private boolean isCanScrollUp() {
        return canScrollVertically(1);
    }

    private boolean isCanScrollDown() {
        return canScrollVertically(-1);
    }
}
