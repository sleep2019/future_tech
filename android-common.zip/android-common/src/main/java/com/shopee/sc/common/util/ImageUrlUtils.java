package com.shopee.sc.common.util;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chris on 2019/5/24.
 */
public class ImageUrlUtils {

    private final static String URL_SLD_ORI = "://f";
    private final static String URL_SLD_NEW = "://cf";

    /**
     * 图片地址，由原来的 https://f.shopee*** 变成 https://cf.shopee***，即把二级域名由 f 变成 cf
     *
     * 源于后端 修改 成本偏高，由客户端来转换
     */
    public static String alter2LD(String url) {
        String targetUrl = "";
        if (!TextUtils.isEmpty(url)) {
            targetUrl = url.contains(URL_SLD_ORI) ? url.replace(URL_SLD_ORI, URL_SLD_NEW) : url;
        }
        return targetUrl;
    }

    /**
     * 将用逗号隔开的图片url，解析成url的list
     *
     * @param images
     * @return
     */
    public static List<String> parseImageUrlList(String images) {
        List<String> urls = new ArrayList<>();
        if (images != null) {
            String[] imageArr = images.split(",");
            for (String img : imageArr) {
                urls.add(img.trim());
            }
        }
        return urls;
    }
}
