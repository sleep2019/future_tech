package com.shopee.sc.common.util;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Looper;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.AnyRes;
import androidx.annotation.ColorRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.shopee.sc.common.R;
import com.shopee.sc.common.plugins.CommonPlugins;
import com.shopee.sc.logger.api.Logger;

import java.io.File;
import java.util.List;
import java.util.Objects;

public class AppUtils {

    private static final String TAG = "AppUtils";

    public static final int CALL_PHONE_REQUEST_CODE = 0x1002;
    public static final int CALL_MSG_REQUEST_CODE = 0x1003;
    public static final int REQUEST_CODE_READ_CALL = 0x1004;
    public static final int REQUEST_CODE_READ_MSG = 0x1005;
    public static final int REQUEST_CODE_READ_PHONE_STATE = 0x1006;

    private static Context sAppContext;
    private static boolean sIsDebug;

    /**
     * App 启动后需先进行初始化
     */
    public static void init(@NonNull Context context, boolean isDebug) {
        sAppContext = context.getApplicationContext();
        sIsDebug = isDebug;
    }

    /**
     * 获取 ApplicationContext
     */
    public static Context getContext() {
        return sAppContext;
    }

    public static boolean isDebug() {
        return sIsDebug;
    }

    public static String string(@StringRes int resId) {
        if (sAppContext == null) {
            return "";
        }
        return sAppContext.getResources().getString(resId);
    }

    public static String string(@StringRes int resId, Object... args) {
        if (sAppContext == null) {
            return "";
        }
        return sAppContext.getResources().getString(resId, args);
    }

    public static <T> T checkNotNull(@Nullable T obj) {
        return Objects.requireNonNull(obj);
    }

    public static <T> T checkNotNull(@Nullable T object, String message) {
        return Objects.requireNonNull(object, message);
    }

    public static String checkHttpURL(String url) {
        if (isURLEmpty(url)) {
            throw new NullPointerException("url can not be null");
        } else if (!isHttp(url)) {
            throw new NullPointerException("invalid url");
        }
        return url;
    }

    /**
     * 判断链接是否为空
     *
     * @param url 链接
     * @return {@code true}：空<br>{@code false}：不为空
     */
    public static boolean isURLEmpty(String url) {
        return TextUtils.isEmpty(url) || url.equalsIgnoreCase("null");
    }

    /**
     * 判断链接是否是Http
     *
     * @param url 链接
     * @return {@code true}：是<br>{@code false}：不是
     */
    public static boolean isHttp(String url) {
        checkNotNull(url);
        return url.startsWith("http://") || url.startsWith("https://");
    }

    /**
     * View获取Activity的工具
     *
     * @param view view
     * @return Activity
     */
    @NonNull
    public static Activity getActivity(@NonNull View view) throws IllegalStateException {
        Activity activity = UiUtils.getActivityFromView(view);
        if (activity != null) {
            return activity;
        }
        throw new IllegalStateException("View " + view + " is not attached to an Activity");
    }

    /**
     * 全局获取Color的方法
     *
     * @param resId 资源Id
     * @return String
     */
    public static int getColor(@ColorRes int resId) {
        return ContextCompat.getColor(getContext(), resId);
    }

    /**
     * 全局获取String的方法
     *
     * @param id 资源Id
     * @return String
     */
    public static String getString(@StringRes int id) {
        return string(id);
    }

    /**
     * 判断App是否是Debug版本
     *
     * @return {@code true}: 是<br>{@code false}: 否
     */
    public static boolean isAppDebug() {
        if (StringUtils.isSpace(getContext().getPackageName())) return false;
        try {
            PackageManager pm = getContext().getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(getContext().getPackageName(), 0);
            return ai != null && (ai.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 当有焦点的时候强制隐藏软键盘
     */
    public static void hideSystemInputWhenHasFocus(Activity activity) {
        if (null != activity.getCurrentFocus()) {
            ((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow
                    (activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    /**
     * 判断intent是否有String参数
     *
     * @param activity Context
     * @param extra    参数
     * @return 若有则返回该参数的值，否则返回空字符串
     */
    public static String getExtraString(Activity activity, String extra) {
        if (activity.getIntent().hasExtra(extra) && null != activity.getIntent().getStringExtra(extra)) {
            return activity.getIntent().getStringExtra(extra);
        } else {
            return "";
        }
    }

    /**
     * The {@code fragment} is added to the container view with id {@code frameId}. The operation is
     * performed by the {@code fragmentManager}.
     */
    public static void addFragmentToActivity(@NonNull FragmentManager fragmentManager,
                                             @NonNull Fragment fragment, int frameId) {
        checkNotNull(fragmentManager);
        checkNotNull(fragment);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.add(frameId, fragment);
        transaction.commit();
    }

    /**
     * Check external storage mounted or not
     */
    public static boolean isExternalStorageMounted() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    public static String getVersionName(Context context) {
        PackageInfo packageInfo = getPackageInfo(context);
        return packageInfo != null ? packageInfo.versionName : "";
    }

    public static int getVersionCode(Context context) {
        PackageInfo packageInfo = getPackageInfo(context);
        return packageInfo != null ? packageInfo.versionCode : 0;
    }

    public static PackageInfo getPackageInfo(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean isMainThread() {
        return Looper.myLooper() == Looper.getMainLooper();
    }

    public static String getProcessName(Context context) {
        if (context == null) {
            return null;
        }
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> list = manager.getRunningAppProcesses();
        if (list != null) {
            for (ActivityManager.RunningAppProcessInfo processInfo : list) {
                if (processInfo.pid == android.os.Process.myPid()) {
                    return processInfo.processName;
                }
            }
        }

        return null;
    }

    public static boolean isMainProcess(Context context) {
        if (context == null) {
            return false;
        }
        String currentProcessName = getProcessName(context);
        return context.getPackageName().equals(currentProcessName);
    }


    /**
     * 检查权限，当某权限未授权时，申请权限或者弹出申请原因
     */
    public static void checkOrRequestPermission(@NonNull Activity activity, @NonNull String permission,
                                                int requestCode, boolean showRationale) {
        if (ActivityCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
            if (showRationale) {
                requestPermissionOrShowRationale(activity, permission, requestCode);
            } else {
                ActivityCompat.requestPermissions(activity, new String[]{permission}, requestCode);
            }
        }
    }

    /**
     * 当某权限未授权时，申请权限或者弹出申请原因
     */
    public static void requestPermissionOrShowRationale(@NonNull Activity activity, @NonNull String permission, int requestCode) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
            new AlertDialog.Builder(activity)
                    .setMessage(R.string.common_hint_permission)
                    .setPositiveButton(R.string.common_setting, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            intent.setData(Uri.parse("package:" + activity.getPackageName()));
                            activity.startActivity(intent);
                        }
                    })
                    .setNegativeButton(R.string.common_cancel, null)
                    .create()
                    .show();
        } else {
            // Apply for this permission
            ActivityCompat.requestPermissions(activity, new String[]{permission}, requestCode);
        }
    }

    /**
     * 需在提示用户具体的请求权限原因后再调用该方法，避免直接跳转设置页
     */
    public static void requestPermissionOrGoSetting(@NonNull Activity activity, @NonNull String permission, int requestCode) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
            goSettingForApp(activity);
        } else {
            // Apply for this permission
            ActivityCompat.requestPermissions(activity, new String[]{permission}, requestCode);
        }
    }

    public static void goSettingForApp(Context context) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + context.getPackageName()));
        if (!(context instanceof Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(intent);
    }

    public static void callBrowser(Context context, String url) {
        if (context == null || TextUtils.isEmpty(url)) {
            return;
        }
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            Logger.w("no app can handle: " + url + ", error: " + e);
        }
    }

    /**
     * 不用权限也可以，建议直接调用 {@link #realCallMsg(Context, String)}
     */
    @Deprecated
    public static void callMsg(Activity activity, String phone) {
        if (activity == null) {
            return;
        }
        // Check call phone permissions
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionOrShowRationale(activity, Manifest.permission.CALL_PHONE, CALL_MSG_REQUEST_CODE);
        } else {
            realCallMsg(activity, phone);
        }
    }

    /**
     * 如需唤起 WhatsApp，可使用 ShareHelper#callMsg(Context, String, String)
     */
    public static void realCallMsg(@NonNull Context context, String phone) {
        phone = AdjustUtils.adjustPhoneNumber(phone);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setType("vnd.android-dir/mms-sms");
        intent.putExtra("address", /*code +*/ phone);
        try {
            context.startActivity(intent);
        } catch (RuntimeException e) {
            intent.setAction(Intent.ACTION_SEND);
            intent.setType("text/plain");
            context.startActivity(intent);
        }
    }

    /**
     * 不用权限也可以，建议直接调用 {@link #realCallPhone(Context, String)}
     */
    @Deprecated
    public static void callPhone(Activity activity, String phone) {
        if (activity == null) {
            return;
        }
        // Check call phone permissions
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionOrShowRationale(activity, Manifest.permission.CALL_PHONE, CALL_PHONE_REQUEST_CODE);
        } else {
            realCallPhone(activity, phone);
        }
    }

    public static void realCallPhone(@NonNull Context context, String phone) {
        realCallPhone(context, phone, false);
    }

    /**
     * 如需唤起 WhatsApp，可使用 ShareHelper#callPhone(Context, String)
     */
    public static void realCallPhone(@NonNull Context context, String phone, boolean checkSim) {
        if (checkSim && !hasSimCard(context)) {
            CommonPlugins.getToaster().showShort(R.string.common_msg_no_sim_detected);
            return;
        }

        phone = AdjustUtils.adjustPhoneNumber(phone);
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + /*code +*/ phone));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            CommonPlugins.getToaster().showShort(R.string.common_not_install_app);
        }
    }

    public static boolean hasSimCard(@NonNull Context context) {
        TelephonyManager manager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (manager == null) {
            return false;
        }
        int state = manager.getSimState();
        switch (state) {
            case TelephonyManager.SIM_STATE_ABSENT:
            case TelephonyManager.SIM_STATE_UNKNOWN:
            case TelephonyManager.SIM_STATE_PERM_DISABLED:
                return false;
        }
        return true;
    }

    public static void vibrate() {
        vibrate(getContext());
    }

    public static void vibrate(Context context) {
        if (context == null) {
            return;
        }
        try {
            Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null) {
                vibrator.vibrate(200);
            }
        } catch (Exception e) {
            Logger.e(TAG, "vibrate : " + e.toString());
        }
    }

    /**
     * 二维码扫描请求相机权限
     */
    public static void requestQrCodePermissions(Activity activity, int requestCode) {
        if (activity == null) {
            return;
        }
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.CAMERA},
                    requestCode);
        }
    }

    public static void captureImage(@NonNull Activity activity, @NonNull File targetFile, int requestCode) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Uri uri = FileUtils.getFileUri(activity, targetFile);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        }
        try {
            activity.startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            Logger.w("captureImage error: ", e);
        }
    }

    /**
     * 检查通知渠道，不存在则创建
     */
    public static void createNotificationChannelIfNeeded(@NonNull Context context, String channelId,
                                                         String channelName, int channelImportance,
                                                         @Nullable Uri soundUri) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = nm.getNotificationChannel(channelId);
        if (channel == null) {
            channel = new NotificationChannel(channelId, channelName, channelImportance);
            if (soundUri != null) {
                AudioAttributes audioAttributes = new AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .build();
                channel.setSound(soundUri, audioAttributes);
            }
            nm.createNotificationChannel(channel);
        }
    }

    /**
     * 返回资源 Uri，eg: "android.resource://{pkgName}/raw/sound1"
     *
     * 如果返回的 Uri 被外部保存，如 {@linkplain NotificationChannel#setSound}，App 升级时只需替换同名资源，
     * 即可起到铃声替换的效果。相比 {@link #getUriForResourceTemporary(Context, int)}，
     * 可以避免资源无法找到或者资源错乱的问题
     */
    public static Uri getUriForResource(@NonNull Context context, @AnyRes int resId) {
        Resources resources = context.getResources();
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE
                + "://" + resources.getResourcePackageName(resId)
                + "/" + resources.getResourceTypeName(resId)
                + "/" + resources.getResourceEntryName(resId));
    }

    /**
     * 该方法返回固定 id uri，eg: "android.resource://{pkgName}/2131689472" (0x7f0f0000)
     *
     * 当返回的 uri 可能被保存时，建议使用 {@link #getUriForResource(Context, int)}
     */
    public static Uri getUriForResourceTemporary(@NonNull Context context, @AnyRes int resId) {
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + context.getPackageName() + "/" + resId);
    }

}
