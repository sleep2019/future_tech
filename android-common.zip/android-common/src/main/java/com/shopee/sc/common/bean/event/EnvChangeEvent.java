package com.shopee.sc.common.bean.event;

/**
 * Created by honggang.xiong on 2020/8/17.
 */
public class EnvChangeEvent extends BaseEvent {

    private int newEnv;

    public EnvChangeEvent(int newEnv) {
        this.newEnv = newEnv;
    }

    public int getNewEnv() {
        return newEnv;
    }

    @Override
    public String toString() {
        return "EnvChangeEvent{" +
                "newEnv=" + newEnv +
                '}';
    }
}
