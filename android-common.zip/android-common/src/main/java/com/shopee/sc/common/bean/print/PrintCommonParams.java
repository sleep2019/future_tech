package com.shopee.sc.common.bean.print;

import com.google.gson.annotations.SerializedName;

/**
 * Created by honggang.xiong on 2020/8/20.
 */
public class PrintCommonParams {

    @SerializedName("file_path")
    String filePath; // 保存 PDF 文件的URL
    @SerializedName("device")
    String device;   // optional
    @SerializedName("scale")
    Integer scale;   // optional
    @SerializedName("height")
    Integer height;
    @SerializedName("width")
    Integer width;
    @SerializedName("repeat_times")
    Integer repeatTimes; // optional, default 1

    public PrintCommonParams(String filePath) {
        this.filePath = filePath;
    }

    public PrintCommonParams(String filePath, int height, int width) {
        this.filePath = filePath;
        this.height = height;
        this.width = width;
    }
}
