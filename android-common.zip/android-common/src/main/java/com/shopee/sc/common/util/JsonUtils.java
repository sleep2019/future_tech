package com.shopee.sc.common.util;

import java.lang.reflect.Type;

public class JsonUtils {

    private JsonUtils() {
    }

    /**
     * convert object to json string
     */
    public static String toJson(Object object) {
        return GsonUtils.toJson(object);
    }

    /**
     * convert json string to object
     */
    public static <T> T fromJson(String json, Type typeOfT) {
        return GsonUtils.fromJson(json, typeOfT);
    }

}

