package com.shopee.sc.common.router;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;

import com.alibaba.android.arouter.facade.Postcard;
import com.alibaba.android.arouter.facade.callback.NavCallback;
import com.alibaba.android.arouter.facade.callback.NavigationCallback;
import com.alibaba.android.arouter.launcher.ARouter;

import java.util.Map;

/**
 * Created by javy on 29/07/2020.
 */
public class RouterHelper {

    private RouterHelper() {
    }

    private static class InstanceHolder {
        private final static RouterHelper INSTANCE = new RouterHelper();
    }

    public static RouterHelper getInstance() {
        return InstanceHolder.INSTANCE;
    }

    public static void init(Application application, boolean isDebug) {
        if (isDebug) {
            ARouter.openDebug();
            ARouter.openLog();
            ARouter.printStackTrace();
        }
        ARouter.init(application);
    }

    public static void inject(Object thiz) {
        ARouter.getInstance().inject(thiz);
    }

    /**
     * 默认跳转动画
     */
    public static PostcardWrapper buildWithThemeAnim(String path) {
        return new PostcardWrapper(path);
    }

    /**
     * 无动画转换
     */
    public static PostcardWrapper buildWithoutAnim(String path) {
        return new PostcardWrapper(path).withTransition(0, 0);
    }

    public static PostcardWrapper build(Uri uri) {
        return new PostcardWrapper(uri);
    }

    public static <T> T navigation(Class<? extends T> service) {
        return ARouter.getInstance().navigation(service);
    }

    public static Object navigation(Context context, PostcardWrapper postcard, int requestCode, NavigationCallback callback) {
        return ARouter.getInstance().navigation(context, postcard.getPostcard(), requestCode, callback);
    }

    public static Object navigation(String path) {
        return ARouter.getInstance().build(path).navigation();
    }

    public static Object navigation(String path, Context context) {
        return ARouter.getInstance().build(path).navigation(context);
    }

    public static void navigation(String path, Activity activity, int requestCode) {
        ARouter.getInstance().build(path).navigation(activity, requestCode);
    }

    public static void navigation(String path, String key, String value) {
        ARouter.getInstance().build(path).withString(key, value).navigation();
    }

    public static void navigation(String path, Map<String, Object> extra) {
        Postcard postcard = ARouter.getInstance().build(path);
        if (extra != null && !extra.isEmpty()) {
            for (String key : extra.keySet()) {
                Object value = extra.get(key);
                if (value instanceof String) {
                    postcard.withString(key, (String) value);
                } else if (value instanceof Integer) {
                    postcard.withInt(key, (Integer) value);
                } else if (value instanceof Parcelable) {
                    postcard.withParcelable(key, (Parcelable) value);
                } else if (value instanceof Long) {
                    postcard.withLong(key, (Long) value);
                } else if (value instanceof Boolean) {
                    postcard.withBoolean(key, (Boolean) value);
                }
                // todo 根据需要增加类型
            }
        }
        postcard.navigation();
    }

    public static Object navigation(String path, Bundle bundle) {
        if (bundle == null) {
            return navigation(path);
        }
        return ARouter.getInstance().build(path).with(bundle).navigation();
    }

    public static Object navigation(String path, Bundle bundle, Context context) {
        return navigation(path, bundle, context, null);
    }

    public static Object navigation(String path, Bundle bundle, Context context, NavCallback navCallback) {
        Postcard postcard = ARouter.getInstance().build(path);
        if (bundle != null) {
            postcard.with(bundle);
        }
        return postcard.navigation(context, navCallback);
    }
}