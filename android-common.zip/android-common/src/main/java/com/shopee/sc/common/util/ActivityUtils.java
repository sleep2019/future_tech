package com.shopee.sc.common.util;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.shopee.sc.common.R;
import com.shopee.sc.common.plugins.CommonPlugins;
import com.shopee.sc.logger.api.Logger;

public class ActivityUtils {

    private ActivityUtils() {
    }

    /**
     * The {@code fragment} is added to the container view with id {@code frameId}. The operation is
     * performed by the {@code fragmentManager}.
     */
    public static void addFragmentToActivity(@NonNull FragmentManager fragmentManager,
                                             @NonNull Fragment fragment, int frameId) {
        if (fragmentManager == null || fragment == null) {
            return;
        }
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.add(frameId, fragment);
        transaction.commit();
    }


    public static void finish(Activity activity) {
        if (activity == null) {
            return;
        }
        if (activity.isFinishing()) {
            return;
        }
        activity.finish();
    }

    /**
     * 通过Context跳转页面
     */
    public static void startActivity(Context context, Intent intent) {
        startActivity(context, intent, false);
    }

    /**
     * 通过Context跳转页面
     */
    public static void startActivity(Context context, Intent intent, boolean finish) {
        startActivity(context, intent, -1, finish);
    }

    /**
     * 通过Context跳转页面
     */
    public static void startActivity(Context context, Intent intent, int reqCode) {
        startActivity(context, intent, reqCode, false);
    }

    /**
     * 通过Context跳转页面
     */
    private static void startActivity(Context context, Intent intent, int reqCode, boolean finish) {
        if (context == null || intent == null) {
            Logger.e("startActivity() : context and intent must not be null.");
            return;
        }
        //android 9.0增加的限制：如果是非Activity启动新页面，需要增加flag:FLAG_ACTIVITY_NEW_TASK
        if (!(context instanceof Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        try {
            if (reqCode == -1) {
                context.startActivity(intent);
                if (finish) {
                    if (!(context instanceof Activity)) {
                        return;
                    }
                    ((Activity) context).finish();
                }
            } else {
                if (context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, reqCode);
                }
            }
        } catch (ActivityNotFoundException e) {
            handleActivityNotFoundException();
        }
    }

    /**
     * 通过fragment跳转页面
     */
    public static void startActivity(Fragment fragment, Intent intent, int reqCode) {
        startActivity(fragment, intent, reqCode, false);
    }

    /**
     * 通过fragment跳转页面
     */
    public static void startActivity(Fragment fragment, Intent intent, int reqCode, boolean finish) {
        if (fragment == null || intent == null) {
            return;
        }
        Activity activity = fragment.getActivity();
        //android 9.0增加的限制：如果是非Activity启动新页面，需要增加flag:FLAG_ACTIVITY_NEW_TASK
        if (activity == null) {
            return;
        }

        try {
            if (reqCode == -1) {
                activity.startActivity(intent);
                if (finish) {
                    activity.finish();
                }
            } else {
                fragment.startActivityForResult(intent, reqCode);
            }
        } catch (ActivityNotFoundException e) {
            handleActivityNotFoundException();
        }
    }

    /**
     * 跳转到权限设置界面
     *
     * @param context
     */
    public static void toPermissionSetting(Context context) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setData(Uri.fromParts("package", context.getPackageName(), null));
        if (intent.resolveActivity(context.getPackageManager()) != null) {
            startActivity(context, intent);
        }
    }

    public static boolean checkPermission(Activity activity, String permission) {
        if (activity == null) {
            throw new NullPointerException("activity is null");
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        return ActivityCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean startActivityForResult(Activity activity, Intent intent, int requestCode) {
        if (activity == null || intent == null) {
            Logger.e("startActivityForResult() : activity and intent must not be null.");
            return false;
        }

        try {
            activity.startActivityForResult(intent, requestCode);
            return true;
        } catch (ActivityNotFoundException e) {
            handleActivityNotFoundException();
            return false;
        }
    }

    public static void startActivityForResult(Fragment fragment, Intent intent, int requestCode) {
        if (fragment == null || intent == null) {
            Logger.e("startActivityForResult() : fragment, intent must not be null.");
            return;
        }

        try {
            fragment.startActivityForResult(intent, requestCode);
        } catch (ActivityNotFoundException e) {
            handleActivityNotFoundException();
        }
    }

    private static void handleActivityNotFoundException() {
        CommonPlugins.getToaster().showShort(R.string.common_please_update_new_version);
    }
}
