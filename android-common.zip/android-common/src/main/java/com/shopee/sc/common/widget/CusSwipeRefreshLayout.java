package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class CusSwipeRefreshLayout extends SwipeRefreshLayout {
    public CusSwipeRefreshLayout(@NonNull Context context) {
        super(context);
    }

    public CusSwipeRefreshLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
}
