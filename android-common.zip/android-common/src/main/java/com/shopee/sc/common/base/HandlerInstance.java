package com.shopee.sc.common.base;

import android.os.Handler;
import android.os.Looper;

/**
 * Created by heroxiong on 2018/5/8.
 */

public class HandlerInstance {
    private Handler myHandler;

    private HandlerInstance() {
        myHandler = new Handler(Looper.getMainLooper());
    }

    public static HandlerInstance instance() {
        return InstanceHolder.instance;
    }

    private static class InstanceHolder {
        private static HandlerInstance instance = new HandlerInstance();
    }

    public void postDelay(Runnable runnable, long time) {
        myHandler.postDelayed(runnable, time);
    }

    /**
     * 调用 postDelay 的地方记得在销毁时，调用这个方法，防止内存泄漏
     *
     * @param runnable
     */
    public void removeCallBack(Runnable runnable) {
        myHandler.removeCallbacks(runnable);
    }
}
