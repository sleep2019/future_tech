package com.shopee.sc.common.base.paging;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class ListWrapper<T> implements Serializable {

    @SerializedName("list")
    private List<T> list;

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }
}
