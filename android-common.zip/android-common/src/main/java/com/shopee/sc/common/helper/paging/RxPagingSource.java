package com.shopee.sc.common.helper.paging;

import androidx.annotation.NonNull;

import com.shopee.sc.common.bean.PagingBean;
import com.shopee.sc.common.bean.Result;
import com.shopee.sc.common.plugins.CommonPlugins;
import com.shopee.sc.common.util.RxUtils;
import com.shopee.sc.logger.api.Logger;

import java.util.Objects;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by honggang.xiong on 2021/11/15.
 */
public class RxPagingSource<T> implements PagingSource<T> {

    private static final String TAG = "RxPagingSource";

    @NonNull
    private final SingleSource<T> mSingleSource;
    private Disposable mLoadDataDisposable = null;

    public RxPagingSource(@NonNull SingleSource<T> singleSource) {
        mSingleSource = Objects.requireNonNull(singleSource);
    }

    @Override
    public void load(@NonNull PagingParams params, @NonNull PagingType type, @NonNull PagingCallback<T> callback) {
        mLoadDataDisposable = mSingleSource.getPagingData(params, type)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnDispose(() -> callback.handleLoadCancelled(type))
                .subscribe(result -> {
                    if (result.isStrictSuccess()) {
                        callback.handleDataList(type, result.data);
                    } else {
                        CommonPlugins.getToaster().toast(result);
                        callback.handleLoadFailed(type);
                    }
                }, throwable -> {
                    Logger.w(TAG, "load data error:" + throwable);
                    CommonPlugins.getToaster().toast(throwable);
                    callback.handleLoadFailed(type);
                });
    }

    @Override
    public void stopCurrentLoad() {
        RxUtils.dispose(mLoadDataDisposable);
    }


    public interface SingleSource<T> {
        @NonNull
        Single<Result<PagingBean<T>>> getPagingData(@NonNull PagingParams params, @NonNull PagingType type);
    }

}
