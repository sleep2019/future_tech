package com.shopee.sc.common.contract;

import androidx.annotation.CallSuper;

import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

/**
 * Base Presenter.
 *
 * Created by honggang.xiong on 2020/6/19.
 */
public abstract class BasePresenter<V extends Contract.View> implements Contract.Presenter<V> {

    private CompositeDisposable mAutoCancelDisposables = new CompositeDisposable();
    protected V mView;

    @Override
    @CallSuper
    public void subscribe(V view) {
        mView = view;
    }

    @Override
    @CallSuper
    public void unsubscribe() {
        mAutoCancelDisposables.clear();
        mView = null;
    }

    protected void callShowLoading(boolean isShowLoading) {
        if (mView != null) {
            mView.showLoadingView(isShowLoading);
        }
    }

    protected void addAutoCancelDisposables(Disposable... disposables) {
        mAutoCancelDisposables.addAll(disposables);
    }

}
