package com.shopee.sc.common.util;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Base64;
import android.webkit.MimeTypeMap;

import androidx.annotation.Dimension;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.WorkerThread;
import androidx.core.content.FileProvider;

import com.shopee.sc.logger.api.Logger;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-07-24.
 */
public class FileUtils {

    private FileUtils() {
    }

    public static File getAppFileDir(Context context, String dirName) {
        File file = new File(context.getFilesDir(), dirName);
        return file;
    }

    public static File getAppCacheDir(@NonNull Context context) {
        // Fix bugly #75205 外置sd卡无法使用FileProvider问题
        //https://blog.csdn.net/fengyuzhengfan/article/details/52876586
        //https://jira.shopee.io/browse/SPXFM-2064
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N
                && (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())
                || !Environment.isExternalStorageRemovable())) {
            return context.getExternalCacheDir();
        } else {
            return context.getCacheDir();
        }
    }

    public static Uri getFileUri(Context context, File file) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return Uri.fromFile(file);
        } else {
            return FileProvider.getUriForFile(context, context.getPackageName(), file);
        }
    }

    public static void deleteFile(File file) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            for (File f : file.listFiles()) {
                deleteFile(f);
            }
        } else {
            file.delete();
        }
    }

    public static long getFileSize(File file) {
        if (file == null || !file.exists()) {
            return 0;
        }

        if (file.isDirectory()) {
            long size = 0;
            for (File subFile : file.listFiles()) {
                size += getFileSize(subFile);
            }
            return size;
        } else {
            return file.length();
        }
    }

    public static boolean isFileExist(String filePath) {
        if (!TextUtils.isEmpty(filePath)) {
            File file = new File(filePath);
            return file.exists();
        }
        return false;
    }

    public static boolean saveBitmapToPath(Bitmap bitmap, File target, int quality) throws IOException {
        if (bitmap == null || target == null) {
            return false;
        }
        if (quality < 0 || quality > 100) {
            quality = 100;
        }
        boolean result = false;
        FileOutputStream fileOutputStream = null;
        try {
            if (!createDirs(target.getParentFile())) {
                throw new IOException("Create file parent dir failed");
            }
            fileOutputStream = new FileOutputStream(target);
            result = bitmap.compress(Bitmap.CompressFormat.JPEG, quality, fileOutputStream);
        } catch (IOException e) {
            Logger.e("saveBitmapToPath error: " + e);
            throw e;
        } finally {
            close(fileOutputStream);
        }
        return result;
    }

    /**
     * @return true if dir exists or successfully created, otherwise return false
     */
    public static boolean createDirs(@NonNull File fileDir) {
        return (fileDir.exists() && fileDir.isDirectory()) || fileDir.mkdirs();
    }

    public static void close(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException ex) {
                Logger.e("close stream exception" + ex);
            }
        }
    }

    @NonNull
    @WorkerThread
    public static List<Bitmap> pdfToBitmapByFixedWidth(@Nullable File pdfFile, @Dimension int fixedWidth,
                                                       @IntRange(from = 0) int fromPage,
                                                       @IntRange(from = 1) int toPage) {
        try {
            return pdfToBitmapByFixedWidthMayException(pdfFile, fixedWidth, fromPage, toPage);
        } catch (Exception e) {
            Logger.w("pdfToBitmap error:" + e);
        }
        return new ArrayList<>();
    }

    @NonNull
    @WorkerThread
    public static List<Bitmap> pdfToBitmapByFixedWidthMayException(@Nullable File pdfFile, @Dimension int fixedWidth,
                                                                   @IntRange(from = 0) int fromPage,
                                                                   @IntRange(from = 1) int toPage) throws IOException {
        List<Bitmap> bitmapList = new ArrayList<>();
        if (pdfFile == null || !pdfFile.exists() || fixedWidth <= 0) {
            return bitmapList;
        }

        PdfRenderer renderer = new PdfRenderer(ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY));
        final int pageCount = renderer.getPageCount();
        int from = Math.max(fromPage, 0);
        int to = Math.min(pageCount, toPage);
        for (int i = from; i < to; i++) {
            PdfRenderer.Page page = renderer.openPage(i);
            if (page.getWidth() <= 0) {
                page.close();
                continue;
            }

            float ratio = fixedWidth * 1.0f / page.getWidth();
            int height = (int) (page.getHeight() * ratio);

            long start = SystemClock.elapsedRealtime();
            Bitmap bitmap = Bitmap.createBitmap(fixedWidth, height, Bitmap.Config.ARGB_8888);
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            bitmapList.add(bitmap);

            Logger.d("pdfToBitmap page=" + i + ", page.getWidth()=" + page.getWidth()
                    + ", page.getHeight()=" + page.getHeight()
                    + ", bitmap width=" + fixedWidth
                    + ", bitmap height=" + height
                    + ", cost " + (SystemClock.elapsedRealtime() - start) + "ms"
            );
            // close the page
            page.close();
        }
        // close the renderer
        renderer.close();
        return bitmapList;
    }

    public static String getStorageDirectory(@NonNull Context ctx) {
        String path = "";
        final String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            final File externalFilesDir = ctx.getExternalFilesDir(null);
            if (externalFilesDir == null) {
                path = ctx.getFilesDir().getAbsolutePath();
            } else {
                path = externalFilesDir.getAbsolutePath();
            }
        } else {
            path = ctx.getFilesDir().getAbsolutePath();
        }
        return path;
    }


    public static File getTargetDir(@NonNull Context ctx, @NonNull String child) {
        final File dir = new File(FileUtils.getStorageDirectory(ctx));
        final File folder = new File(dir, child);
        if (!folder.exists()) {
            folder.mkdir();
        }
        return folder;
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    public static long getSdFreeSize() {
        //取得SD卡文件路径
        File path = Environment.getExternalStorageDirectory();
        StatFs sf = new StatFs(path.getPath());
        //获取单个数据块的大小(Byte)
        long blockSize = sf.getBlockSizeLong();
        //空闲的数据块的数量
        long freeBlocks = sf.getAvailableBlocksLong();
        return (freeBlocks * blockSize) / 1024 / 1024; //单位MB
    }

    public static String getFileSuffix(File file) {
        if (file == null) {
            return null;
        }
        String filePath = file.getAbsolutePath();
        return getFileSuffix(filePath);
    }

    public static String getFileSuffix(String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }
        if (filePath.endsWith(".")) {
            return null;
        }
        int index = filePath.lastIndexOf(".");
        if (index == -1) {
            return null;
        }
        String suffix = filePath.substring(index + 1);
        return suffix;
    }


    /**
     * 文件转base64字符串
     *
     * @param file
     * @return
     */
    public static String fileToBase64(File file) throws IOException {
        if (file == null || !file.exists()) {
            return null;
        }
        String base64 = null;
        InputStream in = null;
        try {
            in = new FileInputStream(file);
            byte[] bytes = new byte[in.available()];
            int length = in.read(bytes);
            base64 = Base64.encodeToString(bytes, 0, length, Base64.DEFAULT);
        } finally {
            if (in != null) {
                in.close();
            }
        }
        return base64;
    }

    public static String getMimeType(Context context, Uri uri) {
        String mimeType = null;
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            ContentResolver cr = context.getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri.toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        return mimeType;
    }

    public static boolean copyFile(String oldPath, String newPath) throws IOException {
        FileInputStream fileInputStream = null;
        FileOutputStream fileOutputStream = null;
        try {
            File oldFile = new File(oldPath);
            if (!oldFile.exists() || !oldFile.isFile() || !oldFile.canRead()) {
                return false;
            }

            fileInputStream = new FileInputStream(oldPath);
            fileOutputStream = new FileOutputStream(newPath);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = fileInputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            fileOutputStream.flush();
            return true;
        } finally {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
        }
    }
}
