package com.shopee.sc.common.widget.adapter;

import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

public abstract class SingleSelectQuickAdapter<T, K extends BaseViewHolder> extends BaseSelectQuickAdapter<T, K> {

    public SingleSelectQuickAdapter(int layoutResId) {
        super(layoutResId);
        addItemClickListener();
    }

    public void addItemClickListener() {
        setOnItemClickListener((adapter, view, position) -> {
            List<SelectableEntity<T>> selectableEntityList = getData();
            for (int i = 0; i < selectableEntityList.size(); i++) {
                SelectableEntity<T> selectableEntity = selectableEntityList.get(i);
                if (i == position) {
                    if (!selectableEntity.isSelected()) {
                        selectableEntity.setSelected(true);
                        notifyItemChanged(getItemPosition(i));
                    }
                } else {
                    if (selectableEntity.isSelected()) {
                        selectableEntity.setSelected(false);
                        notifyItemChanged(getItemPosition(i));
                    }
                }
            }
        });
    }

    public int getSelectedPosition() {
        for (int i = 0; i < getDataSize(); i++) {
            SelectableEntity<T> selectableEntity = getItem(i);
            // 单选列表，只要找到选中item，直接返回
            if (selectableEntity != null && selectableEntity.isSelected()) {
                return i;
            }
        }
        return -1;
    }

    public T getSelectedData() {
        int selectedPosition = getSelectedPosition();
        if (selectedPosition < 0) {
            return null;
        }
        SelectableEntity<T> selectableEntity = getItem(selectedPosition);
        return selectableEntity != null ? selectableEntity.getItem() : null;
    }
}
