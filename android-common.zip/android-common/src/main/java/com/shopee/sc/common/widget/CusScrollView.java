package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ScrollView;

public class CusScrollView extends ScrollView {
    public CusScrollView(Context context) {
        super(context);
    }

    public CusScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CusScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
