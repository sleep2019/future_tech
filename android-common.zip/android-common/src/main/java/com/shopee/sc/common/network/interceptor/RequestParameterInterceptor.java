package com.shopee.sc.common.network.interceptor;

import androidx.annotation.NonNull;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class RequestParameterInterceptor implements Interceptor {

    public static final String KEY_APP_VERSION = "app_version";
    private final String mVersionName;

    public RequestParameterInterceptor(String versionName) {
        mVersionName = versionName;
    }

    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request originRequest = chain.request();
        Request.Builder builder = originRequest.newBuilder();
        builder.url(originRequest.url().newBuilder()
                .addQueryParameter(KEY_APP_VERSION, mVersionName)
                .build());
        return chain.proceed(builder.build());
    }

}
