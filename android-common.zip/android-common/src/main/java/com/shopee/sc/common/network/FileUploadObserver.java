package com.shopee.sc.common.network;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;

/**
 * Created by honggang.xiong on 2019-09-05.
 */
public abstract class FileUploadObserver<T> implements SingleObserver<T> {

    private int mLastProgress = -1;

    @Override
    public void onSubscribe(Disposable d) {

    }

    // 上传进度回调
    public abstract void onProgress(int progress);

    // 监听进度的改变
    public void onProgressChange(long bytesWritten, long contentLength) {
        // LogUtils.d("onProgressChange bytesWritten=" + bytesWritten + ", contentLength=" + contentLength);
        int progress = calculateProgress(bytesWritten, contentLength, 100);
        if (mLastProgress != progress) {
            mLastProgress = progress;
            onProgress(progress);
        }
    }

    protected int calculateProgress(long bytesWritten, long contentLength, int maxProgress) {
        if (contentLength <= 0) {
            contentLength = 1;
        }
        int progress = (int) (bytesWritten * maxProgress / contentLength);
        if (progress >= maxProgress) {
            progress = maxProgress;
        }
        return progress;
    }

}
