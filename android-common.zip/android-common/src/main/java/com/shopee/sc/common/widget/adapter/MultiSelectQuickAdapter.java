package com.shopee.sc.common.widget.adapter;

import com.chad.library.adapter.base.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

public abstract class MultiSelectQuickAdapter<T, K extends BaseViewHolder> extends BaseSelectQuickAdapter<T, K> {

    protected OnSelectedChangeListener mOnSelectedChangeListener;

    public MultiSelectQuickAdapter(int layoutResId) {
        super(layoutResId);
        addItemClickListener();
    }

    public void addItemClickListener() {
        setOnItemClickListener((adapter, view, position) -> {
            SelectableEntity<?> selectableEntity = getItem(position);
            if (selectableEntity == null) {
                return;
            }
            boolean isChecked = !selectableEntity.isSelected();
            selectableEntity.setSelected(isChecked);
            if (mOnSelectedChangeListener != null) {
                mOnSelectedChangeListener.onSelectedChange(position, isChecked);
            }
            notifyItemChanged(getItemPosition(position));
        });
    }

    public List<T> getSelectedDataList() {
        List<T> selectedDataList = new ArrayList<>();
        for (SelectableEntity<T> selectableEntity : getData()) {
            if (selectableEntity.isSelected()) {
                selectedDataList.add(selectableEntity.getItem());
            }
        }
        return selectedDataList;
    }

    public void setAllItemSelected() {
        setAllItemSelectState(true);
    }

    public void cancelAllSelectedItem() {
        setAllItemSelectState(false);
    }

    private void setAllItemSelectState(boolean isSelected) {
        if (getData() == null) {
            return;
        }
        for (SelectableEntity<T> entity : getData()) {
            entity.setSelected(isSelected);
        }
        notifyDataSetChanged();
    }

    public void setOnSelectedChangeListener(OnSelectedChangeListener onSelectedChangeListener) {
        mOnSelectedChangeListener = onSelectedChangeListener;
    }

    public interface OnSelectedChangeListener {
        void onSelectedChange(int position, boolean isSelected);
    }
}
