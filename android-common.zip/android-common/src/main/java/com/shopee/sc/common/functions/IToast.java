package com.shopee.sc.common.functions;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;

import com.shopee.sc.common.bean.Result;

/**
 * Created by honggang.xiong on 2019-07-26.
 */
public interface IToast {

    void showShort(CharSequence text);

    void showShort(@StringRes int resId);

    void showLong(CharSequence text);

    void showLong(@StringRes int resId);

    default void toast(@NonNull Result<?> result) {
        toast(result, false);
    }

    void toast(@NonNull Result<?> result, boolean longToast);

    default void toast(@NonNull Throwable throwable) {
        toast(throwable, false);
    }

    void toast(@NonNull Throwable throwable, boolean longToast);

}
