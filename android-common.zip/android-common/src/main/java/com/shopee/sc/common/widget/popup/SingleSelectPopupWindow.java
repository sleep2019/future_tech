package com.shopee.sc.common.widget.popup;

import android.content.Context;

import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

/**
 * @ClassName: SingleSelectPopupWindow
 * @Description: popupwidow中显示的列表只能选择一个item
 * @Author: lanjingzeng
 * @CreateDate: 2020-04-23 18:01
 * @Version: 1.0
 */
public abstract class SingleSelectPopupWindow<T> extends ListPopupWindow<T> {
    private static final String TAG = SingleSelectPopupWindow.class.getSimpleName();
    private static int DEFAULT_SELECTED_POS = 0;
    private int mLastSelectedPos = -1;
    private int mSelectedPos = -1;

    public SingleSelectPopupWindow(Context context, int layoutResID, int recyclerViewId, int itemlayoutResId) {
        super(context, layoutResID, recyclerViewId, itemlayoutResId);
    }

    /**
     * 默认选中list中的某一个item
     *
     * @param position 默认选中的item在list中的位置
     */
    public void setDefaultSelectedPos(int position) {
        if (!(position >= 0 && position < getListSize())) {
            position = DEFAULT_SELECTED_POS;
        }
        setSelectedPos(position);
    }

    /**
     * 选中list中的某一个item
     *
     * @param position 选中的item在list中的位置
     */
    public void setSelectedPos(int position) {
        if (!(position >= 0 && position < getListSize())) {
            return;
        }
        if (mSelectedPos != -1) {
            mLastSelectedPos = mSelectedPos;
        }
        mSelectedPos = position;
        getAdapter().notifyItemChanged(mSelectedPos + getAdapter().getHeaderLayoutCount());
        if (mLastSelectedPos != -1 && mLastSelectedPos != mSelectedPos) {//mLastSelectedPos和mSelectedPos相等(重复点击同一个item),此时该item状态为选中，只需通知选中更新状态即可
            getAdapter().notifyItemChanged(mLastSelectedPos + getAdapter().getHeaderLayoutCount());
        }
    }

    /**
     * 清空当前的选中状态
     */
    public void clearSelectPos() {
        if (mSelectedPos != -1) {
            mLastSelectedPos = mSelectedPos;
            mSelectedPos = -1;
            getAdapter().notifyItemChanged(mLastSelectedPos + getAdapter().getHeaderLayoutCount());
        }
    }

    /**
     * 返回选中的item在list中的位置
     *
     * @return
     */
    public int getSelectedPos() {
        return mSelectedPos;
    }

    /**
     * 返回选中的item
     *
     * @return
     */
    public T getSelectItem() {
        if (mSelectedPos < 0) {
            return null;
        }
        List<T> datas = getData();
        if (datas == null || mSelectedPos >= datas.size()) {
            return null;
        }
        return datas.get(mSelectedPos);
    }

    @Override
    public void showItem(BaseViewHolder helper, T itemData) {
        int position = getData() == null ? -1 : getData().indexOf(itemData);
        if (mSelectedPos != -1 && position == mSelectedPos) {
            showItem(helper, itemData, position, true);
        } else {
            showItem(helper, itemData, position, false);
        }
    }

    public abstract void showItem(BaseViewHolder helper, T itemData, int position, boolean isSelected);

}
