package com.shopee.sc.common.util;

import androidx.annotation.NonNull;

import com.shopee.sc.common.functions.Function;

/**
 * Created by honggang.xiong on 2021/9/2.
 */
public class AdjustUtils {

    private static Function<String, String> sPhoneNumberAdjuster = null;

    public static void setPhoneNumberAdjuster(Function<String, String> phoneNumberAdjuster) {
        sPhoneNumberAdjuster = phoneNumberAdjuster;
    }

    @NonNull
    public static String adjustPhoneNumber(String origin) {
        if (sPhoneNumberAdjuster == null) {
            return origin != null ? origin : "";
        }
        return sPhoneNumberAdjuster.apply(origin);
    }

}
