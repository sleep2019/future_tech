package com.shopee.sc.common.helper.paging;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.loadmore.LoadMoreView;
import com.shopee.sc.common.bean.PagingBean;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 详细的分页回调，供外部实现
 * <p>
 * Created by honggang.xiong on 2021/11/15.
 */
public interface RichPagingCallback<T> extends PagingCallback<T> {

    @MainThread
    default void onLoadStart(@NonNull PagingParams params, @NonNull PagingType type) {
        // default no-op
    }

    /**
     * 可对分页数据加载成功回调进行预处理
     *
     * @param type       分页类型
     * @param pagingBean 分页数据
     */
    @MainThread
    void preHandleDataList(@NonNull PagingType type, @NonNull PagingBean<T> pagingBean);

    /**
     * 调用 {@link BaseQuickAdapter} 的某个方法更新首页数据。
     * 一般使用 {@link BaseQuickAdapter#setNewData(List)} 比较通用，但无法做到局部更新；
     * 使用 {@link BaseQuickAdapter#replaceData(Collection)} 等方法并重写 ，可以做到局部更新，
     * 但需要结合 {@link BaseQuickAdapter#setLoadMoreView(LoadMoreView)} 处理 loadMore 的问题
     */
    @MainThread
    default void updateFirstPageDataList(@NonNull BaseQuickAdapter<T, ? extends BaseViewHolder> adapter,
                                         @NonNull PagingType type, @NonNull PagingBean<T> pagingBean) {
        adapter.setNewData(new ArrayList<>(pagingBean.finalList));
    }

}
