package com.shopee.sc.common.functions;

/**
 * Created by honggang.xiong on 2019-07-26.
 */
public interface ILog {

    boolean isLoggable();

    void d(String msg);

    void d(String tag, String msg);

    void d(String tag, String msg, Throwable tr);

    void i(String msg);

    void i(String tag, String msg);

    void i(String tag, String msg, Throwable tr);

    void w(String msg);

    void w(String tag, String msg);

    void w(String tag, String msg, Throwable tr);

    void e(String msg);

    void e(String tag, String msg);

    void e(String tag, String msg, Throwable tr);

}
