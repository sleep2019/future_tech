package com.shopee.sc.common.bean.event;

/**
 * Created by heroxiong on 2018/8/10.
 */

public class BaseEvent {

    public static final int UPDATE_MENU = 0x0010;

    public int event;
    public int arg;
    public boolean booleanArg;
    public Object obj;

    public BaseEvent() {
        this(0, 0, false, null);
    }

    public BaseEvent(int event, int arg) {
        this(event, arg, false, null);
    }

    public BaseEvent(int event, int arg, Object obj) {
        this(event, arg, false, obj);
    }

    public BaseEvent(int event, boolean booleanArg) {
        this(event, 0, booleanArg, null);
    }

    public BaseEvent(boolean booleanArg) {
        this(0, 0, booleanArg, null);
    }

    public BaseEvent(int event, int arg, boolean booleanArg, Object obj) {
        this.event = event;
        this.arg = arg;
        this.booleanArg = booleanArg;
        this.obj = obj;
    }

    public int getEvent() {
        return event;
    }

    public int getArg() {
        return arg;
    }

    public boolean getBooleanArg() {
        return booleanArg;
    }

    public Object getObj() {
        return obj;
    }

}
