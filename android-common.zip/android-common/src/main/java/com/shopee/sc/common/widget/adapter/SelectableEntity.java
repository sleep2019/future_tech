package com.shopee.sc.common.widget.adapter;

import java.io.Serializable;

public class SelectableEntity<T> implements Serializable {
    private T item;
    private boolean isSelected;


    public SelectableEntity(T item) {
        this.item = item;
    }

    public T getItem() {
        return item;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setItem(T item) {
        this.item = item;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
