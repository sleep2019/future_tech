package com.shopee.sc.common.helper.paging;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;

import com.shopee.sc.common.bean.PagingBean;

/**
 * 分页数据源
 * <p>
 * Created by honggang.xiong on 2021/11/15.
 */
public interface PagingSource<T> {

    PagingSource<?> EMPTY_SOURCE = new PagingSource<Object>() {
        @Override
        public void load(@NonNull PagingParams params, @NonNull PagingType type, @NonNull PagingCallback<Object> callback) {
            callback.handleDataList(type, PagingBean.fromList(null));
        }

        @Override
        public void stopCurrentLoad() {
            // np-op
        }
    };

    @SuppressWarnings("unchecked")
    static <T> PagingSource<T> emptySource() {
        return (PagingSource<T>) EMPTY_SOURCE;
    }

    /**
     * 加载数据，子类自行处理线程切换及将结果回调给 callback
     *
     * @param params   分页参数
     * @param type     分页类型
     * @param callback 分页回调
     */
    @MainThread
    void load(@NonNull PagingParams params, @NonNull PagingType type, @NonNull PagingCallback<T> callback);

    /**
     * 停止当前加载
     */
    @MainThread
    void stopCurrentLoad();

}
