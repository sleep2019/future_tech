package com.shopee.sc.common.widget;

import android.content.res.ColorStateList;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.IdRes;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;

/**
 * Created by honggang.xiong on 2020/9/23.
 */
@SuppressWarnings("rawtypes")
public interface ViewAttributeSetter<SubClass extends ViewAttributeSetter> {

    <T extends View> T findViewById(@IdRes int id);

    SubClass getSelf();


    default SubClass setText(@IdRes int viewId, @StringRes int resId) {
        ((TextView) findViewById(viewId)).setText(resId);
        return getSelf();
    }

    default SubClass setText(@IdRes int viewId, CharSequence text) {
        ((TextView) findViewById(viewId)).setText(text);
        return getSelf();
    }

    default SubClass setTextColor(@IdRes int viewId, @ColorRes int resId) {
        TextView textView = findViewById(viewId);
        textView.setTextColor(ContextCompat.getColor(textView.getContext(), resId));
        return getSelf();
    }

    default SubClass setTextColorInt(@IdRes int viewId, @ColorInt int color) {
        ((TextView) findViewById(viewId)).setTextColor(color);
        return getSelf();
    }

    default SubClass setTextGravity(@IdRes int viewId, int gravity) {
        ((TextView) findViewById(viewId)).setGravity(gravity);
        return getSelf();
    }

    default SubClass setImageResource(@IdRes int viewId, @DrawableRes int resId) {
        ((ImageView) findViewById(viewId)).setImageResource(resId);
        return getSelf();
    }

    default SubClass setBackgroundColor(@IdRes int viewId, @ColorInt int color) {
        findViewById(viewId).setBackgroundColor(color);
        return getSelf();
    }

    default SubClass setBackgroundRes(@IdRes int viewId, @DrawableRes int resId) {
        findViewById(viewId).setBackgroundResource(resId);
        return getSelf();
    }

    default SubClass setBackgroundTintColorInt(@IdRes int viewId, @ColorInt int color) {
        findViewById(viewId).setBackgroundTintList(ColorStateList.valueOf(color));
        return getSelf();
    }

    default SubClass setBackgroundTintColorRes(@IdRes int viewId, @ColorRes int colorRes) {
        View view = findViewById(viewId);
        int color = ContextCompat.getColor(view.getContext(), colorRes);
        view.setBackgroundTintList(ColorStateList.valueOf(color));
        return getSelf();
    }

    default SubClass setVisibility(@IdRes int viewId, int visibility) {
        findViewById(viewId).setVisibility(visibility);
        return getSelf();
    }

    default SubClass setOnClickListener(@IdRes int viewId, View.OnClickListener onClickListener) {
        findViewById(viewId).setOnClickListener(onClickListener);
        return getSelf();
    }

}
