package com.shopee.sc.common.contract;

/**
 * Top interface for View and Presenter.
 *
 * See {@link BasePresenter}.
 *
 * Created by honggang.xiong on 2020/6/19.
 */
public interface Contract {

    interface View {

        void showLoadingView(boolean isShowLoading);
    }

    interface Presenter<V extends View> {

        void subscribe(V view);

        void unsubscribe();
    }

}
