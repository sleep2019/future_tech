package com.shopee.sc.common.functions;

public interface IEventInterceptor {

    /**
     * 拦截back点击
     *
     * @return
     */
    boolean onInterceptBackEvent();
}
