package com.shopee.sc.common.base;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.IdRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.shopee.sc.common.network.NetCache;
import com.shopee.sc.logger.api.Logger;

public abstract class BaseDialogFragment extends DialogFragment {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setNoTitleStyle();
    }

    protected void setNoTitleStyle() {
        setStyle(STYLE_NO_TITLE, android.R.style.Theme_Dialog);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(contentViewId(), container, false);
    }

    /**
     * return fragment layout id
     */
    @LayoutRes
    protected abstract int contentViewId();

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Cancel all requests in dialog fragment
        NetCache.getInstance().cancel(this);
    }

    @SuppressWarnings("unchecked")
    protected <T extends View> T findViewById(@IdRes int id) {
        if (getView() == null) {
            return null;
        }
        return (T) (getView().findViewById(id));
    }

    /**
     * 宽度占满整个屏幕，高度自适应，贴在底部的对话框
     */
    protected void setAsBottomDialog() {
        if (getDialog() == null) {
            return;
        }
        Window window = getDialog().getWindow();
        if (window == null) {
            return;
        }
        // 去掉Dialog默认的padding, 宽度占满整个屏幕,底部贴边
        window.getDecorView().setPadding(0, 0, 0, 0);
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        // 设置Dialog的位置在底部
        lp.gravity = Gravity.BOTTOM;
        // 设置Dialog的动画
//        lp.windowAnimations = R.style.BottomDialogAnimation;
        window.setAttributes(lp);
    }

    @Override
    public void show(@NonNull FragmentManager manager, @Nullable String tag) {
        Fragment fragment = manager.findFragmentByTag(tag);
        if (fragment != null && fragment.isAdded()) {
            Logger.w("This fragment is already add!");
            return;
        }

        try {
            super.show(manager, tag);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int show(@NonNull FragmentTransaction transaction, @Nullable String tag) {
        try {
            return super.show(transaction, tag);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void showNow(@NonNull FragmentManager manager, @Nullable String tag) {
        try {
            super.showNow(manager, tag);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }
}
