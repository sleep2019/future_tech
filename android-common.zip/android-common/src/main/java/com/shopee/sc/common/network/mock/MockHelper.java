package com.shopee.sc.common.network.mock;

import android.app.Application;
import android.content.Context;

import java.lang.reflect.Method;

import okhttp3.OkHttpClient;

public class MockHelper {

    private final static String DEFAULT_BASE_MOCK_URL = "http://mock-admin.i.finance-apc.test.sz.shopee.io/mock/5fab9a212a6f6a36cf96069e/wms-pda";

    private static Application sApp;
    private static boolean sIsDebug;

    public static void init(Application application, boolean isDebug) {
        sIsDebug = isDebug;
        if (!isDebug()) {
            return;
        }
        sApp = application;
    }

    // 反射调用
    public static void initMock(OkHttpClient.Builder builder, String baseUrl) {
        if (!isDebug()) {
            return;
        }
        try {
            Class clazz = Class.forName("com.shopee.mocklib.MockDataManager");
            Method getInstance = clazz.getDeclaredMethod("getInstance");
            Object instance = getInstance.invoke(null);

            Method init = clazz.getDeclaredMethod("init", Application.class, OkHttpClient.Builder.class, String.class);
            init.invoke(instance, sApp, builder, baseUrl);

            Method baseServerUrl = clazz.getDeclaredMethod("setBaseServerUrl", String.class);
            baseServerUrl.invoke(instance, DEFAULT_BASE_MOCK_URL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 反射调用
    public static void startMockService(Context context) {
        if (!isDebug()) {
            return;
        }
        try {
            // 开启悬浮窗，默认开启全局Mock开关
            Class mockDataManagerClazz = Class.forName("com.shopee.mocklib.MockDataManager");
            Method getInstance = mockDataManagerClazz.getDeclaredMethod("getInstance");
            Object instance = getInstance.invoke(null);
            Method setOpenAllMock = mockDataManagerClazz.getDeclaredMethod("setOpenAllMock", boolean.class);
            setOpenAllMock.invoke(instance, true);

            Class clazz = Class.forName("com.shopee.mocklib.MockFloatWindowService");
            Method startSelf = clazz.getDeclaredMethod("startSelf", Context.class);
            startSelf.invoke(null, context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean isDebug() {
        return sIsDebug;
    }
}
