package com.shopee.sc.common.util;

import android.text.TextUtils;

/**
 * Created by chris on 2018/10/26.
 */
public class NumberUtils {

    /**
     * 把String转化为float
     */
    public static float convertToFloat(String number, float defaultValue) {
        if (TextUtils.isEmpty(number)) {
            return defaultValue;
        }
        try {
            return Float.parseFloat(number);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }

    }

    /**
     * 把String转化为double
     */
    public static double convertToDouble(String number, double defaultValue) {
        if (TextUtils.isEmpty(number)) {
            return defaultValue;
        }
        try {
            return Double.parseDouble(number);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }

    }

    /**
     * 把String转化为int
     */
    public static int convertToInt(String number, int defaultValue) {
        if (TextUtils.isEmpty(number)) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(number);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    /**
     * 把String转化为long
     */
    public static long convertToLong(String number, long defaultValue) {
        if (TextUtils.isEmpty(number)) {
            return defaultValue;
        }
        try {
            return Long.parseLong(number);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    /**
     * 把String小数转化为int
     */
    public static int convertDecimalToInt(String number, int defaultValue) {
        if (TextUtils.isEmpty(number)) {
            return defaultValue;
        }
        try {
            return Double.valueOf(number).intValue();
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    public static String subLastZeroAndDot(String value) {
        if (value.indexOf(".") > 0) {
            value = value.replaceAll("0+?$", ""); //去掉多余的0
            value = value.replaceAll("[.]$", ""); //如最后一位是.则去掉
        }
        return value;
    }
}
