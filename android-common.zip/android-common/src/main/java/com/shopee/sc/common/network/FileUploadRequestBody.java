package com.shopee.sc.common.network;

import androidx.annotation.NonNull;

import java.io.File;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.Buffer;
import okio.BufferedSink;
import okio.ForwardingSink;
import okio.Okio;
import okio.Sink;

/**
 * Created by honggang.xiong on 2019-09-05.
 */
public class FileUploadRequestBody<T> extends RequestBody {

    private final RequestBody mDelegate;
    private final FileUploadObserver<T> mFileUploadObserver;
    protected final String mFilePath;

    public FileUploadRequestBody(FileUploadObserver<T> fileUploadObserver, @NonNull String filePath) {
        this.mDelegate = RequestBody.create(MediaType.parse("application/octet-stream"), new File(filePath));
        this.mFileUploadObserver = fileUploadObserver;
        this.mFilePath = filePath;
    }

    @Override
    public long contentLength() throws IOException {
        return mDelegate.contentLength();
    }

    @Override
    public MediaType contentType() {
        return mDelegate.contentType();
    }

    @Override
    public void writeTo(@NonNull BufferedSink sink) throws IOException {
        BufferedSink bufferedSink = Okio.buffer(new CountingSink(sink));
        mDelegate.writeTo(bufferedSink);
        bufferedSink.flush();
    }

    public String getFilePath() {
        return mFilePath;
    }


    protected final class CountingSink extends ForwardingSink {

        private long bytesWritten = 0;

        protected CountingSink(Sink delegate) {
            super(delegate);
        }

        @Override
        public void write(@NonNull Buffer source, long byteCount) throws IOException {
            super.write(source, byteCount);

            bytesWritten += byteCount;
            if (mFileUploadObserver != null) {
                mFileUploadObserver.onProgressChange(bytesWritten, contentLength());
            }
        }
    }

}
