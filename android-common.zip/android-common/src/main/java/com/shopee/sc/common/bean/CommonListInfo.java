package com.shopee.sc.common.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * Created by honggang.xiong on 2020/7/8.
 */
public class CommonListInfo<T> implements Serializable {

    @SerializedName("list")
    private List<T> list;

    public CommonListInfo(List<T> list) {
        this.list = list;
    }

    public List<T> getList() {
        return list;
    }

}
