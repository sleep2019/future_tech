package com.shopee.sc.common.util;

import okio.ByteString;

/**
 * Created by honggang.xiong on 2019-07-24.
 */
public class DigestUtils {

    private DigestUtils() {
    }

    public static String md5(String content) {
        if (content == null) {
            return null;
        }
        return ByteString.encodeUtf8(content).md5().hex();
    }

    public static String md5(byte[] data) {
        if (data == null) {
            return null;
        }
        return ByteString.of(data).md5().hex();
    }

}
