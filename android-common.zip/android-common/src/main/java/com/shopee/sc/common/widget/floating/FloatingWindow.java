package com.shopee.sc.common.widget.floating;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.CallSuper;
import androidx.annotation.LayoutRes;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;

import com.shopee.sc.common.widget.ViewAttributeSetter;
import com.shopee.sc.logger.api.Logger;

import java.util.Objects;

/**
 * @ClassName: FloatingWindow
 * @Description: 悬浮窗基础类
 * @Author: Lanjing Zeng
 * @CreateDate: 2021/12/10 4:27 PM
 * @Version: 1.0
 */
public class FloatingWindow implements ViewAttributeSetter<FloatingWindow> {
    private static final String TAG = FloatingWindow.class.getSimpleName();
    private Context mContext;
    private WindowManager mWindowManager;
    private View mFloatView;
    private WindowManager.LayoutParams mLayoutParams;
    private boolean mNeedPerformClick;
    private UpdateCoordinateListener mUpdateCoordinateListener;

    private boolean mIsShowing;

    protected FloatingWindow(@NonNull Builder builder) {
        mContext = builder.mContext;
        mWindowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
        mFloatView = LayoutInflater.from(mContext).inflate(builder.mLayoutRes, null);

        if (builder.mMovable) {
            mFloatView.setOnTouchListener(mMovableOnTouchListener);
        }
        mNeedPerformClick = builder.mNeedPerformClick;

        mLayoutParams = new WindowManager.LayoutParams();
        mLayoutParams.format = PixelFormat.TRANSLUCENT;
        mLayoutParams.type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        mLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (builder.mLayoutInScreen) {
            mLayoutParams.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }
        mLayoutParams.gravity = builder.mGravity;
        mLayoutParams.width = builder.mWidth;
        mLayoutParams.height = builder.mHeight;
        mLayoutParams.x = builder.mOffsetX;
        mLayoutParams.y = builder.mOffsetY;
        mUpdateCoordinateListener = builder.mUpdateCoordinateListener;
    }

    public Context getContext() {
        return mContext;
    }

    @Override
    public <T extends View> T findViewById(int id) {
        return mFloatView.findViewById(id);
    }

    @Override
    public FloatingWindow getSelf() {
        return this;
    }

    public boolean isShowing() {
        return mIsShowing;
    }

    public void setChildViewMovableOnTouchListener(int id) {
        View view = findViewById(id);
        if (view == null) {
            return;
        }
        view.setOnTouchListener(mMovableOnTouchListener);
    }

    @MainThread
    @CallSuper
    public boolean show() {
        if (mIsShowing) {
            return true;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !(Settings.canDrawOverlays(mContext))) {
            return false;
        }
        try {
            mWindowManager.addView(mFloatView, mLayoutParams);
            mIsShowing = true;
            return mIsShowing;
        } catch (Exception e) {
            Logger.e(TAG, "addView error:", e);
        }
        return false;

    }

    @MainThread
    @CallSuper
    public void dismiss() {
        if (mIsShowing) {
            try {
                mWindowManager.removeView(mFloatView);
            } catch (Exception e) {
                Logger.e(TAG, "removeView error:", e);
            }
            mIsShowing = false;
        }
    }

    void offsetView(int deltaX, int deltaY) {
        int gravity = mLayoutParams.gravity;
        @SuppressLint("RtlHardcoded")
        int multiX = (gravity & Gravity.RIGHT) == Gravity.RIGHT ? -1 : 1;
        int multiY = (gravity & Gravity.BOTTOM) == Gravity.BOTTOM ? -1 : 1;
        mLayoutParams.x += multiX * deltaX;
        mLayoutParams.y += multiY * deltaY;
        mWindowManager.updateViewLayout(mFloatView, mLayoutParams);
        if (mUpdateCoordinateListener != null) {
            mUpdateCoordinateListener.updateCoordinate(mLayoutParams.x, mLayoutParams.y);
        }
    }

    boolean autoPerformClick(View view) {
        if (!mNeedPerformClick) {
            return false;
        }
        view.performClick();
        Logger.i(TAG, "ACTION_UP performClick()....");
        return true;
    }

    public static Builder newBuilder(@NonNull Context context, @LayoutRes int layoutRes) {
        return new Builder(context, layoutRes);
    }

    private View.OnTouchListener mMovableOnTouchListener = new View.OnTouchListener() {
        private int mLastX;
        private int mLastY;
        private int mFirstX;
        private int mFirstY;
        private boolean mTouchConsumedByMove;


        public final boolean onTouch(View view, MotionEvent event) {
            int curX = (int) event.getRawX();
            int curY = (int) event.getRawY();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    mFirstX = mLastX = curX;
                    mFirstY = mLastY = curY;
                    mTouchConsumedByMove = false;
                    break;
                case MotionEvent.ACTION_UP:
                    if (!mTouchConsumedByMove) {
                        mTouchConsumedByMove = autoPerformClick(view);
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    int deltaX = curX - mLastX;
                    int deltaY = curY - mLastY;
                    mLastX = curX;
                    mLastY = curY;
                    if (!mTouchConsumedByMove && Math.abs(mLastX - mFirstX) < 10
                            && Math.abs(mLastY - mFirstY) < 10) {
                        mTouchConsumedByMove = false;
                    } else {
                        if (event.getPointerCount() == 1) {
                            mTouchConsumedByMove = true;
                            offsetView(deltaX, deltaY);
                        } else {
                            mTouchConsumedByMove = false;
                        }
                    }
                    break;
                case MotionEvent.ACTION_OUTSIDE:
                    Logger.w(TAG, "outside touch:" + event);
                    break;
                default:
                    break;
            }
            return mTouchConsumedByMove;
        }
    };


    public static class Builder {
        final Context mContext;
        final int mLayoutRes;
        boolean mMovable = false;
        boolean mNeedPerformClick = true;//是否需要自动执行点击事件
        boolean mLayoutInScreen = false;
        int mGravity = Gravity.TOP | Gravity.START;
        int mWidth = WindowManager.LayoutParams.WRAP_CONTENT;
        int mHeight = WindowManager.LayoutParams.WRAP_CONTENT;
        int mOffsetX = 0;
        int mOffsetY = 0;
        UpdateCoordinateListener mUpdateCoordinateListener;

        public Builder(@NonNull Context context, @LayoutRes int layoutRes) {
            mContext = Objects.requireNonNull(context);
            mLayoutRes = layoutRes;
        }

        public Builder setMovable(boolean movable) {
            mMovable = movable;
            return this;
        }

        public Builder setLayoutInScreen(boolean layoutInScreen) {
            mLayoutInScreen = layoutInScreen;
            return this;
        }

        public Builder setGravity(int gravity) {
            mGravity = gravity;
            return this;
        }

        public Builder setWidth(int width) {
            mWidth = width;
            return this;
        }

        public Builder setHeight(int height) {
            mHeight = height;
            return this;
        }

        public Builder setOffsetX(int offsetX) {
            mOffsetX = offsetX;
            return this;
        }

        public Builder setOffsetY(int offsetY) {
            mOffsetY = offsetY;
            return this;
        }

        public Builder setNeedPerformClick(boolean needPerformClick) {
            mNeedPerformClick = needPerformClick;
            return this;
        }

        public Builder setUpdateCoordinateListener(UpdateCoordinateListener updateCoordinateListener) {
            this.mUpdateCoordinateListener = updateCoordinateListener;
            return this;
        }

        public FloatingWindow build() {
            return new FloatingWindow(this);
        }
    }

    public interface UpdateCoordinateListener {
        void updateCoordinate(int x, int y);
    }
}
