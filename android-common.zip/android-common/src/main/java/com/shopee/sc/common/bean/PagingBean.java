package com.shopee.sc.common.bean;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Collections;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-12-09.
 */
public class PagingBean<T> {

    public final int originCount;
    @NonNull
    public final List<T> finalList;
    public final int totalCount; // 如果未获取到或者不关注，则为 -1

    public static <T> PagingBean<T> fromList(@Nullable List<T> list) {
        List<T> finalList = list != null ? list : Collections.emptyList();
        return new PagingBean<>(finalList.size(), finalList);
    }

    public PagingBean(int originCount, @Nullable List<T> finalList) {
        this(originCount, finalList, -1);
    }

    public PagingBean(int originCount, @Nullable List<T> finalList, int totalCount) {
        this.originCount = originCount;
        this.finalList = finalList != null ? finalList : Collections.emptyList();
        this.totalCount = totalCount;
    }

}
