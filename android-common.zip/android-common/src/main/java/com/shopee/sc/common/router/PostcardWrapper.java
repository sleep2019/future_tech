package com.shopee.sc.common.router;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityOptionsCompat;

import com.alibaba.android.arouter.facade.Postcard;
import com.alibaba.android.arouter.facade.callback.NavigationCallback;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.alibaba.android.arouter.launcher.ARouter;
import com.shopee.sc.common.R;

import java.io.Serializable;
import java.util.ArrayList;

public class PostcardWrapper {

    private final Postcard mPostcard;

    public PostcardWrapper(Uri uri) {
        mPostcard = ARouter.getInstance().build(uri);
    }

    public Postcard getPostcard() {
        return mPostcard;
    }

    public Bundle getOptionsBundle() {
        return mPostcard.getOptionsBundle();
    }

    public int getEnterAnim() {
        return mPostcard.getEnterAnim();
    }

    public int getExitAnim() {
        return mPostcard.getExitAnim();
    }

    public IProvider getProvider() {
        return mPostcard.getProvider();
    }

    public PostcardWrapper setProvider(IProvider provider) {
        mPostcard.setProvider(provider);
        return this;
    }

    public PostcardWrapper(String path) {
        this.mPostcard = ARouter.getInstance().build(path);
    }

    public PostcardWrapper(String path, String group) {
        mPostcard = new Postcard(path, group);
    }

    public PostcardWrapper(String path, String group, Uri uri, Bundle bundle) {
        mPostcard = new Postcard(path, group, uri, bundle);
    }

    public boolean isGreenChannel() {
        return mPostcard.isGreenChannel();
    }

    public Object getTag() {
        return mPostcard.getTag();
    }

    public PostcardWrapper setTag(Object tag) {
        mPostcard.setTag(tag);
        return this;
    }

    public int getTimeout() {
        return mPostcard.getTimeout();
    }

    public PostcardWrapper setTimeout(int timeout) {
        mPostcard.setTimeout(timeout);
        return this;
    }

    public Uri getUri() {
        return mPostcard.getUri();
    }

    public PostcardWrapper setUri(Uri uri) {
        mPostcard.setUri(uri);
        return this;
    }

    public PostcardWrapper greenChannel() {
        mPostcard.greenChannel();
        return this;
    }

    public Object navigation() {
        return navigation(null);
    }


    public Object navigation(Context context) {
        return navigation(context, null);
    }

    public Object navigation(Context context, NavigationCallback callback) {
        return ARouter.getInstance().navigation(context, mPostcard, -1, callback);
    }


    public void navigation(Activity mContext, int requestCode) {
        navigation(mContext, requestCode, null);
    }

    public void navigation(Activity mContext, int requestCode, NavigationCallback callback) {
        ARouter.getInstance().navigation(mContext, mPostcard, requestCode, callback);
    }

    public PostcardWrapper with(Bundle bundle) {
        mPostcard.with(bundle);
        return this;
    }

    public PostcardWrapper withFlags(int flag) {
        mPostcard.withFlags(flag);
        return this;
    }

    public PostcardWrapper addFlags(int flags) {
        this.mPostcard.addFlags(flags);
        return this;
    }

    public int getFlags() {
        return mPostcard.getFlags();
    }


    public PostcardWrapper with(@Nullable String key, @Nullable Object value) {
        mPostcard.withObject(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable String value) {
        mPostcard.withString(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, boolean value) {
        mPostcard.withBoolean(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, short value) {
        mPostcard.withShort(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, int value) {
        mPostcard.withInt(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, long value) {
        mPostcard.withLong(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, double value) {
        mPostcard.withDouble(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, char value) {
        mPostcard.withChar(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, float value) {
        mPostcard.withFloat(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable CharSequence value) {
        mPostcard.withCharSequence(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable Parcelable value) {
        mPostcard.withParcelable(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable Parcelable[] value) {
        mPostcard.withParcelableArray(key, value);
        return this;
    }


    public PostcardWrapper with(@Nullable String key, @Nullable SparseArray<? extends Parcelable> value) {
        mPostcard.withSparseParcelableArray(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable Serializable value) {
        mPostcard.withSerializable(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable byte[] value) {
        mPostcard.withByteArray(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable short[] value) {
        mPostcard.withShortArray(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable char[] value) {
        mPostcard.withCharArray(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable float[] value) {
        mPostcard.withFloatArray(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable CharSequence[] value) {
        mPostcard.withCharSequenceArray(key, value);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable Bundle value) {
        mPostcard.withBundle(key, value);
        return this;
    }

    /**
     * 设置动画效果
     *
     * @param enterAnim 进入动画
     * @param exitAnim  退出动画
     * @return
     */
    public PostcardWrapper with(int enterAnim, int exitAnim) {
        mPostcard.withTransition(enterAnim, exitAnim);
        return this;
    }

    public PostcardWrapper withTransition(int enterAnim, int exitAnim) {
        mPostcard.withTransition(enterAnim, exitAnim);
        return this;
    }

    /**
     * 默认转换动画效果
     *
     * @return this
     */
    public PostcardWrapper withDefaultTrans() {
        mPostcard.withTransition(R.animator.common_in_righttoleft, R.animator.common_out_righttoleft);
        return this;
    }

    public PostcardWrapper withOptionsCompat(ActivityOptionsCompat compat) {
        mPostcard.withOptionsCompat(compat);
        return this;
    }

    /**
     * Set options compat
     *
     * @param compat compat
     * @return this
     */
    public PostcardWrapper with(ActivityOptionsCompat compat) {
        mPostcard.withOptionsCompat(compat);
        return this;
    }

    @Override
    public String toString() {
        return "PostcardWrapper ==> \n" + mPostcard.toString();
    }

    public String getAction() {
        return mPostcard.getAction();
    }

    public PostcardWrapper withAction(String action) {
        mPostcard.withAction(action);
        return this;
    }

    public PostcardWrapper with(String action) {
        mPostcard.withAction(action);
        return this;
    }

    public PostcardWrapper with(@Nullable String key, @Nullable ArrayList value) {
        if (value != null && value.size() > 0) {
            Object o = value.get(0);
            if (o instanceof String) {
                mPostcard.withStringArrayList(key, value);
            } else if (o instanceof CharSequence) {
                mPostcard.withCharSequenceArrayList(key, value);
            } else if (o instanceof Integer) {
                mPostcard.withIntegerArrayList(key, value);
            } else if (o instanceof Parcelable) {
                mPostcard.withParcelableArrayList(key, value);
            }
        }
        return this;
    }

}
