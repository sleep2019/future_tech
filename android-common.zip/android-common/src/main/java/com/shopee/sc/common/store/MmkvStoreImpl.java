package com.shopee.sc.common.store;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.shopee.sc.common.util.GsonUtils;
import com.shopee.sc.logger.api.Logger;
import com.shopee.sc.store.api.init.StoreInitParam;
import com.shopee.sc.store.core.StoreFrameworkCore;

import java.lang.reflect.Type;

/**
 * @ClassName: MmkvStoreImpl
 * @Description: 通过MMKV来存取数据。如果项目是多进程方式运行，则初始化时需要设置支持多进程。
 * @see{a href="https://confluence.shopee.io/pages/viewpage.action?pageId=564311816">存储框架</a>}
 * @Author: Lanjing Zeng
 * @CreateDate: 2021/7/22 5:20 PM
 * @Version: 1.0
 */
public final class MmkvStoreImpl implements IStore {
    private final String TAG = "MmkvStoreImpl";
    private final String DEFAULT_MMKV_ID = "mmkv_store_data";
    private String mDefaultId = DEFAULT_MMKV_ID;

    public MmkvStoreImpl() {
    }

    public MmkvStoreImpl(String defaultId) {
        if (!TextUtils.isEmpty(defaultId)) {
            this.mDefaultId = defaultId;
        }
    }

    public static void init(Context applicationContext, boolean multiProcess) {
        if (applicationContext == null) {
            throw new IllegalArgumentException("applicationContext is null...");
        }
        StoreInitParam.Builder storeInitParamBuilder = new StoreInitParam.Builder();
        storeInitParamBuilder.setMultiProcess(multiProcess);
        StoreFrameworkCore.init(applicationContext, storeInitParamBuilder.build());
    }

    @Override
    public void setName(String name) {
        if (TextUtils.isEmpty(name)) {
            throw new IllegalArgumentException("mmkvId is null...");
        }
        mDefaultId = name;
    }

    private String getName(String name) {
        if (TextUtils.isEmpty(name)) {
            return mDefaultId;
        }
        return name;
    }

    @Override
    public String getString(String key) {
        return getString(key, null);
    }

    @Override
    public String getString(String key, String defaultValue) {
        return getString(null, key, defaultValue);
    }

    private String getString(String name, String key, String defaultValue) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        return sp.getString(key, defaultValue);
    }

    @Override
    public boolean getBoolean(String key) {
        return getBoolean(key, false);
    }

    @Override
    public boolean getBoolean(String key, boolean defaultValue) {
        return getBoolean(null, key, defaultValue);
    }

    private boolean getBoolean(String name, String key, boolean defaultValue) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        return sp.getBoolean(key, defaultValue);
    }

    @Override
    public int getInt(String key) {
        return getInt(key, 0);
    }

    @Override
    public int getInt(String key, int defaultValue) {
        return getInt(null, key, defaultValue);
    }

    private int getInt(String name, String key, int defaultValue) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        return sp.getInt(key, defaultValue);
    }

    @Override
    public long getLong(String key) {
        return getLong(key, 0);
    }

    @Override
    public long getLong(String key, long defaultValue) {
        return getLong(null, key, defaultValue);
    }

    private long getLong(String name, String key, long defaultValue) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        return sp.getLong(key, defaultValue);
    }

    @Override
    public float getFloat(String key) {
        return getFloat(key, 0);
    }

    @Override
    public float getFloat(String key, float defaultValue) {
        return getFloat(null, key, defaultValue);
    }

    private float getFloat(String name, String key, float defaultValue) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        return sp.getFloat(key, defaultValue);
    }

    @Override
    public double getDouble(String key) {
        return getDouble(key, 0);
    }

    @Override
    public double getDouble(String key, double defaultValue) {
        return getDouble(null, key, defaultValue);
    }

    private double getDouble(String name, String key, double defaultValue) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        String valStr = sp.getString(key, null);
        if (valStr == null) {
            return defaultValue;
        }
        double value = defaultValue;
        try {
            value = Double.parseDouble(valStr);
        } catch (Exception e) {
            Logger.e(TAG, "getDouble() error" + e.getMessage(), e);
        }
        return value;
    }

    @Override
    public <T> T getObject(String key) {
        return getObject(null, key, null, null);
    }

    @Override
    public <T> T getObject(String key, Class<T> cls, T defaultValue) {
        return getObject(null, key, cls, defaultValue);
    }

    private <T> T getObject(String name, String key, Class<T> cls) {
        return getObject(name, key, cls, null);
    }

    private <T> T getObject(String name, String key, Class<T> cls, T defaultValue) {
        return getObject(name, key, (cls == null ? null : (Type) cls), defaultValue);
    }

    @Override
    public <T> T getObject(String key, Type type, T defaultValue) {
        return getObject(null, key, type, defaultValue);
    }

    private <T> T getObject(String name, String key, Type type, T defaultValue) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        String valStr = sp.getString(key, null);
        if (valStr == null) {
            return defaultValue;
        }
        T t = GsonUtils.fromJson(valStr, type);
        return t;
    }

    @Override
    public boolean putBoolean(String key, boolean value) {
        return putBoolean(null, key, value);
    }

    private boolean putBoolean(String name, String key, boolean value) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean(key, value);
        return editor.commit();
    }

    @Override
    public boolean putString(String key, String value) {
        return putString(null, key, value);
    }

    private boolean putString(String name, String key, String value) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key, value);
        return editor.commit();
    }

    @Override
    public boolean putInt(String key, int value) {
        return putInt(null, key, value);
    }

    private boolean putInt(String name, String key, int value) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(key, value);
        return editor.commit();
    }

    @Override
    public boolean putLong(String key, long value) {
        return putLong(null, key, value);
    }

    private boolean putLong(String name, String key, long value) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        SharedPreferences.Editor editor = sp.edit();
        editor.putLong(key, value);
        return editor.commit();
    }

    @Override
    public boolean putFloat(String key, float value) {
        return putFloat(null, key, value);
    }

    private boolean putFloat(String name, String key, float value) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        SharedPreferences.Editor editor = sp.edit();
        editor.putFloat(key, value);
        return editor.commit();
    }

    @Override
    public boolean putDouble(String key, double value) {
        return putDouble(null, key, value);
    }

    private boolean putDouble(String name, String key, double value) {
        return putString(name, key, String.valueOf(value));
    }

    @Override
    public boolean putObject(String key, Object value) {
        return putObject(null, key, value);
    }

    private boolean putObject(String name, String key, Object value) {
        String json = GsonUtils.toJson(value);
        return putString(name, key, json);
    }

    @Override
    public boolean remove(String key) {
        return remove(null, key);
    }

    private boolean remove(String name, String key) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        SharedPreferences.Editor editor = sp.edit();
        editor.remove(key);
        return editor.commit();
    }

    @Override
    public boolean clear() {
        return clear(null);
    }

    private boolean clear(String name) {
        SharedPreferences sp = StoreFrameworkCore.KV.getSharedPreferences(getName(name));
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        return editor.commit();
    }

}
