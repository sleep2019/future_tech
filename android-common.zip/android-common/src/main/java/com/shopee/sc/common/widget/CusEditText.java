package com.shopee.sc.common.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

/**
 * Created by chris on 2019-12-03.
 */
@SuppressLint("AppCompatCustomView")
public class CusEditText extends EditText {

    public CusEditText(Context context) {
        super(context);
        setCustomSelectionActionModeCallback(mCallback);
    }

    public CusEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setCustomSelectionActionModeCallback(mCallback);
    }

    public CusEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setCustomSelectionActionModeCallback(mCallback);
    }


    @Override
    public void setCustomSelectionActionModeCallback(ActionMode.Callback actionModeCallback) {
        //setTextIsSelectable(true);
        super.setCustomSelectionActionModeCallback(actionModeCallback);
    }

    public void requestDisallowInterceptTouchEvent() {
        setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // 解决scrollView中嵌套EditText导致不能上下滑动的问题
                v.getParent().requestDisallowInterceptTouchEvent(true);
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_UP:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });
    }

    final ActionMode.Callback mCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            int id = -1;
            for (int i = 0; i < menu.size(); i++) {
                try {
                    id = menu.getItem(i).getItemId();
                } catch (IndexOutOfBoundsException e) {
                }
                // 长按保留需要的菜单项
                if (id != android.R.id.cut
                        && id != android.R.id.copy
                        && id != android.R.id.selectAll
                        && id != android.R.id.paste
                        && id != -1) {

                    menu.removeItem(id);
                }
            }
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }
    };
}
