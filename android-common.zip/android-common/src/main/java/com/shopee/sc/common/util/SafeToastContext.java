package com.shopee.sc.common.util;

import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

/**
 * Created by honggang.xiong on 2019-06-13.
 */
public class SafeToastContext extends ContextWrapper {

    public SafeToastContext(Context base) {
        super(base);
    }

    @Override
    public Context getApplicationContext() {
        return new SafeToastContext(getBaseContext().getApplicationContext());
    }

    @Override
    public Object getSystemService(String name) {
        if (Context.WINDOW_SERVICE.equals(name)) {
            return new WindowManagerWrapper((WindowManager) getBaseContext().getSystemService(name));
        }
        return super.getSystemService(name);
    }


    private static class WindowManagerWrapper implements WindowManager {

        private final WindowManager base;

        WindowManagerWrapper(WindowManager base) {
            this.base = base;
        }

        @Override
        public Display getDefaultDisplay() {
            return base.getDefaultDisplay();
        }

        @Override
        public void removeViewImmediate(View view) {
            base.removeViewImmediate(view);
        }

        @Override
        public void addView(View view, ViewGroup.LayoutParams params) {
            try {
                base.addView(view, params);
            } catch (BadTokenException e) {
                // Android 7.1.1 发生 BadTokenException 后能正常移除view，但会抛出该异常造成crash
                // Android 8.0 及以上发生 BadTokenException 后不能正常移除view，但会在上层忽略该异常
                // 部分 7.1.1 机型的表现同8.0，这里 removeView 的逻辑扩大至 7.1.1
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    try {
                        removeViewImmediate(view);
                    } catch (Exception e1) {
                        // ignore
                    }
                }
                // 重置 ToastUtils，双重保证下一次 Toast 可用
//                ToastUtils.clearToast();
            } catch (IllegalStateException e) {
                // 重置 ToastUtils，双重保证下一次 Toast 可用
//                ToastUtils.clearToast();
            }
        }

        @Override
        public void updateViewLayout(View view, ViewGroup.LayoutParams params) {
            base.updateViewLayout(view, params);
        }

        @Override
        public void removeView(View view) {
            base.removeView(view);
        }
    }

}
