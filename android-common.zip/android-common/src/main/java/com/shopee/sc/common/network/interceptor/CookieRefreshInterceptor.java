package com.shopee.sc.common.network.interceptor;

import androidx.annotation.NonNull;

import com.shopee.sc.common.helper.LoginHelper;
import com.shopee.sc.logger.api.Logger;

import java.io.IOException;
import java.net.HttpURLConnection;

import okhttp3.Interceptor;
import okhttp3.Response;

/**
 * cookie refresh
 */
public class CookieRefreshInterceptor implements Interceptor {

    public static final int NET_COOKIE_TIMEOUT = HttpURLConnection.HTTP_UNAUTHORIZED; // 401

    private final int mTimeoutCode;

    public CookieRefreshInterceptor() {
        this(NET_COOKIE_TIMEOUT);
    }

    public CookieRefreshInterceptor(int timeoutCode) {
        mTimeoutCode = timeoutCode;
    }

    @NonNull
    @Override
    public Response intercept(Chain chain) throws IOException {
        final Response originalResponse = chain.proceed(chain.request());
        int httpCode = originalResponse.code();
        if (httpCode == mTimeoutCode) {
            Logger.d("---------Cookie 过期---------");
            // 登出，回到登录页面
            if (LoginHelper.getLoginCallback() != null) {
                LoginHelper.getLoginCallback().logout();
            }
        } else if (httpCode != HttpURLConnection.HTTP_OK) {
            Logger.w("unknown http code:" + httpCode);
        }
        return originalResponse;
    }
}