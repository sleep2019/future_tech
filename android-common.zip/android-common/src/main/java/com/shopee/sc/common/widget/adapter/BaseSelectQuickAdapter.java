package com.shopee.sc.common.widget.adapter;

import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseSelectQuickAdapter<T, K extends BaseViewHolder>
        extends BaseQuickAdapterExtra<SelectableEntity<T>, K> {

    public BaseSelectQuickAdapter(int layoutResId) {
        super(layoutResId);
    }

    @Override
    public void bindToRecyclerView(RecyclerView recyclerView) {
        super.bindToRecyclerView(recyclerView);
        recyclerView.setItemAnimator(null);
    }

    public void setSelectableNewData(List<T> data) {
        setSelectableNewData(data, null);
    }

    public void setSelectableNewData(List<T> data, SelectCompareCallback<T> selectCompareCallback) {
        setNewData(transferSelectableData(data, selectCompareCallback));
    }

    protected List<SelectableEntity<T>> transferSelectableData(List<T> dataList, List<T> selectedDataList) {
        if (dataList == null || dataList.isEmpty()) {
            return null;
        }
        List<SelectableEntity<T>> selectableEntityList = new ArrayList<>();
        for (T data : dataList) {
            SelectableEntity<T> selectableEntity = new SelectableEntity<>(data);
            if (selectedDataList != null && !selectedDataList.isEmpty()) {
                selectableEntity.setSelected(selectedDataList.contains(data));
            }
            selectableEntityList.add(selectableEntity);
        }
        return selectableEntityList;
    }

    public List<SelectableEntity<T>> transferSelectableData(List<T> dataList,
                                                            SelectCompareCallback<T> selectCompareCallback) {
        if (dataList == null || dataList.isEmpty()) {
            return null;
        }
        List<SelectableEntity<T>> selectableEntityList = new ArrayList<>();
        for (T data : dataList) {
            SelectableEntity<T> selectableEntity = new SelectableEntity<>(data);
            if (selectCompareCallback != null) {
                boolean isSelected = selectCompareCallback.isSelected(data);
                selectableEntity.setSelected(isSelected);
            }
            selectableEntityList.add(selectableEntity);
        }
        return selectableEntityList;
    }


    public interface SelectCompareCallback<T> {
        boolean isSelected(T data);
    }

}
