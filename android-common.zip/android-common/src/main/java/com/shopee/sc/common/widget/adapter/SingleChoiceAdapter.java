package com.shopee.sc.common.widget.adapter;

import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.sc.common.bean.CheckedItem;
import com.shopee.sc.logger.api.Logger;

import java.util.List;

/**
 * Created by honggang.xiong on 2019-05-28.
 */
public abstract class SingleChoiceAdapter<T> extends BaseQuickAdapter<CheckedItem<T>, BaseViewHolder> {

    private int mCheckedPosition = -1;
    private OnCheckedChangeListener<T> mOnCheckedChangeListener;

    /**
     * 上一次选中的position
     */
    private int mLastCheckedPosition = 0;

    public SingleChoiceAdapter(@LayoutRes int layoutResId, List<T> originList, int defaultCheckedPosition) {
        super(layoutResId, CheckedItem.generateSingleOrNoneCheckedList(originList, defaultCheckedPosition));
        if (-1 <= defaultCheckedPosition && defaultCheckedPosition < getData().size()) {
            mCheckedPosition = defaultCheckedPosition;
        }
    }

    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        BaseViewHolder viewHolder = super.onCreateViewHolder(parent, viewType);
        CompoundButton checkableView = getCheckableView(viewHolder);
        if (checkableView != null) {
            checkableView.setOnClickListener(v -> {
                int position = viewHolder.getLayoutPosition();
                if (checkableView.isChecked()) {
                    check(position);
                } else if (position == mCheckedPosition) {
                    clearCheck();
                }
            });
        }
        return viewHolder;
    }

    public int getCheckedPosition() {
        return mCheckedPosition;
    }

    @Nullable
    public T getCheckedData() {
        CheckedItem<T> checkedItem = getItem(mCheckedPosition);
        return checkedItem != null ? checkedItem.getModel() : null;
    }

    public void replaceOriginData(@Nullable List<T> originList, int defaultCheckedPosition) {
        super.setNewData(CheckedItem.generateSingleOrNoneCheckedList(originList, defaultCheckedPosition));
        if (-1 <= defaultCheckedPosition && defaultCheckedPosition < getData().size()) {
            mCheckedPosition = defaultCheckedPosition;
        }
    }

    public void addData(@Nullable List<T> originList) {
        super.addData(CheckedItem.generateMultiCheckedList(originList, false));
    }

    // 使用该方法时，需确保至多只有一个 item 处于选中态
    public void replaceCheckedData(@Nullable List<CheckedItem<T>> checkedItems) {
        if (checkedItems == null) {
            return;
        }

        int size = checkedItems.size();
        int newCheckedPos = -1;
        for (int i = 0; i < size; i++) {
            CheckedItem<T> checkedItem = checkedItems.get(i);
            if (checkedItem.isDefaultChecked()) {
                if (newCheckedPos == -1) {
                    newCheckedPos = i;
                } else {
                    Logger.w("Can't replaceCheckedData with more than 1 item checked! Error position is: " + i);
                    return;
                }
            }
        }

        replaceData(checkedItems);
        mCheckedPosition = newCheckedPos;
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener<T> onCheckedChangeListener) {
        mOnCheckedChangeListener = onCheckedChangeListener;
    }

    public void setAllToDefault() {
        boolean changed = false;
        for (CheckedItem<T> checkedItem : getData()) {
            if (checkedItem.changeToDefault()) {
                changed = true;
            }
        }
        if (changed) {
            notifyDataSetChanged();
        }
    }

    public void clearCheck() {
        check(-1);
    }

    public void check(int newPosition) {
        if (newPosition < -1 || newPosition >= getData().size()) {
            return;
        }
        if (newPosition == mCheckedPosition && !isAlwaysNotify()) {
            return;
        }

        boolean changed = changePositionCheckStatus(mCheckedPosition, false);
        changed |= changePositionCheckStatus(newPosition, true);
        if (changed) {
            notifyDataSetChanged();
        }
        setCheckedPosition(newPosition);
    }

    protected boolean isAlwaysNotify() {
        return false;
    }

    private boolean changePositionCheckStatus(int position, boolean checked) {
        CheckedItem<T> item = getItem(position);
        if (item != null) {
            return item.changeCurrentChecked(checked);
        }
        return false;
    }

    protected void setCheckedPosition(int position) {
        mLastCheckedPosition = mCheckedPosition;
        mCheckedPosition = position;
        CheckedItem<T> curItem = getItem(position);
        if (mOnCheckedChangeListener != null) {
            mOnCheckedChangeListener.onCheckedChanged(curItem != null ? curItem.getModel() : null, mCheckedPosition);
        }
    }

    /**
     * 是否为最后一项显示
     */
    protected boolean isLastChecked() {
        return mCheckedPosition >= 0 && mCheckedPosition == getLastPosition();
    }

    // 改用 getLastPosition 并纠正 position 关系
    // protected int getLastPos() {
    //     return getData().size();
    // }

    protected int getLastPosition() {
        return getData().size() - 1;
    }

    public CheckedItem<T> getLastItem() {
        return getItem(getLastPosition());
    }

    /**
     * 可取消选中时，使用 {@link android.widget.CheckBox}
     * 不可取消选中时，使用 {@link android.widget.RadioButton}
     */
    protected abstract CompoundButton getCheckableView(BaseViewHolder viewHolder);

    public int getLastCheckedPosition() {
        return mLastCheckedPosition;
    }

    public interface OnCheckedChangeListener<T> {
        void onCheckedChanged(T checkedData, int checkedPosition);
    }

}
