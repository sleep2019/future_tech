package com.shopee.sc.common.bean;

/**
 * Empty body Params For http POST.
 *
 * Created by honggang.xiong on 2020/11/13.
 */
public class EmptyParams {

}
