package com.shopee.sc.common.widget.listener;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * Created by honggang.xiong on 2019-08-16.
 *
 * Simple empty implementation for TextWatcher.
 */
public interface SimpleTextWatcher extends TextWatcher {
    @Override
    default void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    default void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    default void afterTextChanged(Editable s) {

    }
}
