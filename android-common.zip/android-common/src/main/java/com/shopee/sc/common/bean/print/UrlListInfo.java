package com.shopee.sc.common.bean.print;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.util.Collections;
import java.util.List;

/**
 * Created by honggang.xiong on 2020/8/21.
 */
public class UrlListInfo extends SingleUrlInfo {

    @SerializedName("url_list")
    private List<String> urlList;

    public UrlListInfo() {
    }

    @NonNull
    public List<String> getUrlList() {
        return urlList != null ? urlList : Collections.emptyList();
    }
}
