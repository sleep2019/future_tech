package com.shopee.sc.common.manager;

import android.content.Context;
import android.content.SharedPreferences;

import com.shopee.sc.common.cache.ObscuredSharedPreferences;
import com.shopee.sc.store.core.StoreFrameworkCore;
import com.shopee.sc.store.core.input.StoreType;

import static com.shopee.sc.common.util.AppUtils.checkNotNull;
import static com.shopee.sc.common.util.AppUtils.getContext;

/**
 * Created by javy on 21/08/2020.
 */
public class SecurePrefManager {

    private static final String SECURE_PREFERENCES = "secure_preferences";
    private static final String PREF_SECURE_USER_ID = "secure_user_id";
    private static final String PREF_SECURE_ENCRYPT = "secure_encrypt";
    private ObscuredSharedPreferences mSharedPref;

    private SecurePrefManager() {
        StoreFrameworkCore.of(StoreType.KV).importFromSharePreferences(SECURE_PREFERENCES,
                SECURE_PREFERENCES);
        SharedPreferences sharedPreferences = StoreFrameworkCore.of(StoreType.KV)
                .getSharedPreferences(SECURE_PREFERENCES);
        if (sharedPreferences == null) {
            sharedPreferences = getContext().getSharedPreferences(SECURE_PREFERENCES,
                    Context.MODE_PRIVATE);
        }
        mSharedPref = new ObscuredSharedPreferences(getContext(), sharedPreferences);
    }

    public static SecurePrefManager getInstance() {
        return Internal.INSTANCE;
    }

    private static class Internal {
        private static final SecurePrefManager INSTANCE = new SecurePrefManager();
    }

    public void storeStringValue(String key, String value) {
        ObscuredSharedPreferences.Editor editor = mSharedPref.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public void removeStringValue(String key) {
        ObscuredSharedPreferences.Editor editor = mSharedPref.edit();
        editor.remove(key);
        editor.commit();
    }

    public String getStringValue(String key) {
        return mSharedPref.getString(key, "");
    }

    public void clearAllSecurePrefs() {
        ObscuredSharedPreferences.Editor editor = mSharedPref.edit();
        editor.clear();
        editor.commit();
    }

    public static void storeLoginCredentials(String userId, String password) {
        checkNotNull(userId);
        checkNotNull(password);
        SecurePrefManager.getInstance().storeStringValue(PREF_SECURE_USER_ID, userId);
        SecurePrefManager.getInstance().storeStringValue(PREF_SECURE_ENCRYPT, password);
    }

    public static String getSharedUserId() {
        return SecurePrefManager.getInstance().getStringValue(PREF_SECURE_USER_ID);
    }

    public static String getSharedPassword() {
        return SecurePrefManager.getInstance().getStringValue(PREF_SECURE_ENCRYPT);
    }
}
