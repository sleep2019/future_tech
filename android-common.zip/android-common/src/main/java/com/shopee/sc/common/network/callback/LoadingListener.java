package com.shopee.sc.common.network.callback;

/**
 * 加载框监听
 */
public class LoadingListener implements ILoadingCallback {

    @Override
    public void onStartLoading() {

    }

    @Override
    public void onFinishLoading() {

    }
}
