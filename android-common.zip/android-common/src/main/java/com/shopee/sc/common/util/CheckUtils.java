package com.shopee.sc.common.util;

import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Collection;
import java.util.Map;

public class CheckUtils {
    public static final int VALUE_FALSE = 0;
    public static final int VALUE_TRUE = 1;

    public static final String DEFAULT_EMPTY = "/";

    public static boolean isNullOrEmpty(@Nullable Collection<?> value) {
        return value == null || value.isEmpty();
    }

    public static boolean isNullOrEmpty(@Nullable Map<?, ?> value) {
        return value == null || value.isEmpty();
    }

    private static <T> boolean isNullOrEmpty(@Nullable T[] value) {
        return value == null || value.length == 0;
    }

    public static int size(@Nullable Collection<?> value) {
        return value == null ? 0 : value.size();
    }

    public static boolean isEmpty(String value) {
        return TextUtils.isEmpty(value);
    }

    public static boolean isNotEmpty(String value) {
        return !isEmpty(value);
    }

    /**
     * @deprecated Use {@link CheckUtils#notNull(String)}
     */
    @NonNull
    public static String orEmpty(@Nullable String text) {
        return notNull(text);
    }

    @NonNull
    public static String notNull(@Nullable String text) {
        return orElse(text, "");
    }

    @NonNull
    public static String emptyUseDefault(@Nullable String text) {
        return !TextUtils.isEmpty(text) ? text : DEFAULT_EMPTY;
    }

    @NonNull
    public static String emptyUseOptionalDefault(@Nullable String text, String optionalDefault) {
        return !TextUtils.isEmpty(text) ? text : optionalDefault;
    }

    private static <T> T orElse(@Nullable T actualValue, T defaultValue) {
        return actualValue != null ? actualValue : defaultValue;
    }

    public static boolean isTrue(int value) {
        return value == VALUE_TRUE;
    }
}
