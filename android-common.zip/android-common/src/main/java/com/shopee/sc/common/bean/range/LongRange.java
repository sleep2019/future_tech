package com.shopee.sc.common.bean.range;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Objects;

/**
 * 不可变闭区间集合，eg：new LongRange(1,100) 代表 [1, 100]。
 * 提供基本的包含判断，交集，并集(非标准并集，返回包含两个集合的最小集合)操作。
 *
 * Created by honggang.xiong on 2020/7/1.
 */
public final class LongRange {

    private final long mLower;
    private final long mUpper;

    /**
     * Create a new immutable long range.
     *
     * @param lower The lower endpoint (inclusive)
     * @param upper The upper endpoint (inclusive)
     */
    public LongRange(final long lower, final long upper) {
        if (lower > upper) {
            throw new IllegalArgumentException("lower must be less than or equal to upper");
        }
        mLower = lower;
        mUpper = upper;
    }

    /**
     * Create a new immutable long range.
     *
     * @param lower The lower endpoint (inclusive)
     * @param upper The upper endpoint (inclusive)
     */
    public static LongRange create(final long lower, final long upper) {
        return new LongRange(lower, upper);
    }

    /**
     * Get the lower endpoint.
     */
    public long getLower() {
        return mLower;
    }

    /**
     * Get the upper endpoint.
     */
    public long getUpper() {
        return mUpper;
    }

    /**
     * Checks if the {@code value} is within the bounds of this range.
     *
     * @param value a long value
     * @return {@code true} if the value is within this inclusive range, {@code false} otherwise
     */
    public boolean contains(long value) {
        return mLower <= value && value <= mUpper;
    }

    /**
     * Checks if another {@code range} is within the bounds of this range.
     *
     * @param range a non-{@code null} {@code LongRange} reference
     * @return {@code true} if the range is within this inclusive range, {@code false} otherwise
     * @throws NullPointerException if {@code range} was {@code null}
     */
    public boolean contains(@NonNull LongRange range) {
        Objects.requireNonNull(range, "range must not be null");
        return mLower <= range.mLower && range.mUpper <= mUpper;
    }

    /**
     * Clamps {@code value} to this range.
     *
     * <p>If the value is within this range, it is returned.  Otherwise, if it is {@code <} than
     * the lower endpoint, the lower endpoint is returned, else the upper endpoint is returned.
     *
     * @param value a long value
     * @return {@code value} clamped to this range.
     */
    public long clamp(long value) {
        if (value < mLower) {
            return mLower;
        } else if (value > mUpper) {
            return mUpper;
        } else {
            return value;
        }
    }

    /**
     * Returns the intersection of this range and another {@code range}.
     *
     * E.g. if a < b < c < d, the intersection of [a, c] and [b, d] ranges is [b, c].
     *
     * @param range a non-{@code null} {@code LongRange} reference
     * @return the intersection of this range and the other range, or null if the ranges are disjoint.
     * @throws NullPointerException if {@code range} was {@code null}
     */
    @Nullable
    public LongRange intersect(@NonNull LongRange range) {
        Objects.requireNonNull(range, "range must not be null");
        int cmpLower = Long.compare(range.mLower, mLower);
        int cmpUpper = Long.compare(range.mUpper, mUpper);

        if (cmpLower <= 0 && cmpUpper >= 0) {
            // range includes this
            return this;
        } else if (cmpLower >= 0 && cmpUpper <= 0) {
            // this includes range
            return range;
        } else {
            long newLower = cmpLower <= 0 ? mLower : range.mLower;
            long newUpper = cmpUpper >= 0 ? mUpper : range.mUpper;
            if (newLower > newUpper) {
                return null;
            }
            return new LongRange(newLower, newUpper);
        }
    }

    /**
     * Returns the intersection of this range and the inclusive range specified by {@code [lower, upper]}.
     *
     * @param lower a long value
     * @param upper a long value
     * @return the intersection of this range and the other range, or null if the ranges are disjoint.
     */
    public LongRange intersect(long lower, long upper) {
        int cmpLower = Long.compare(lower, mLower);
        int cmpUpper = Long.compare(upper, mUpper);

        if (cmpLower <= 0 && cmpUpper >= 0) {
            // [lower, upper] includes this
            return this;
        } else {
            long newLower = cmpLower <= 0 ? mLower : lower;
            long newUpper = cmpUpper >= 0 ? mUpper : upper;
            if (newLower > newUpper) {
                return null;
            }
            return new LongRange(newLower, newUpper);
        }
    }

    /**
     * Returns the smallest range that includes this range and another {@code range}.
     *
     * E.g. if a < b < c < d, the extension of [a, c] and [b, d] ranges is [a, d].
     *
     * @param range a non-{@code null} {@code LongRange} reference
     * @return the extension of this range and the other range.
     * @throws NullPointerException if {@code range} was {@code null}
     */
    public LongRange extend(@NonNull LongRange range) {
        Objects.requireNonNull(range, "range must not be null");

        int cmpLower = Long.compare(range.mLower, mLower);
        int cmpUpper = Long.compare(range.mUpper, mUpper);

        if (cmpLower <= 0 && cmpUpper >= 0) {
            // other includes this
            return range;
        } else if (cmpLower >= 0 && cmpUpper <= 0) {
            // this includes other
            return this;
        } else {
            return LongRange.create(
                    cmpLower >= 0 ? mLower : range.mLower,
                    cmpUpper <= 0 ? mUpper : range.mUpper);
        }
    }

    /**
     * Returns the smallest range that includes this range and the inclusive range
     * specified by {@code [lower, upper]}.
     *
     * @param lower a long value
     * @param upper a long value
     * @return the extension of this range and the other range.
     */
    public LongRange extend(long lower, long upper) {
        int cmpLower = Long.compare(lower, mLower);
        int cmpUpper = Long.compare(upper, mUpper);

        if (cmpLower >= 0 && cmpUpper <= 0) {
            // this includes other
            return this;
        } else {
            return LongRange.create(
                    cmpLower >= 0 ? mLower : lower,
                    cmpUpper <= 0 ? mUpper : upper);
        }
    }

    /**
     * Returns the smallest range that includes this range and the {@code value}.
     *
     * @param value a long value
     * @return the extension of this range and the value.
     */
    public LongRange extend(long value) {
        return extend(value, value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(mLower, mUpper);
    }

    /**
     * Compare two ranges for equality.
     *
     * @return {@code true} if the ranges are equal, {@code false} otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        } else if (this == obj) {
            return true;
        } else if (obj instanceof LongRange) {
            LongRange other = (LongRange) obj;
            return mLower == other.mLower && mUpper == other.mUpper;
        }
        return false;
    }

    /**
     * Return the range as a string representation {@code "[lower, upper]"}.
     *
     * @return string representation of the range
     */
    @Override
    public String toString() {
        return "[" + mLower + ", " + mUpper + "]";
    }

}
