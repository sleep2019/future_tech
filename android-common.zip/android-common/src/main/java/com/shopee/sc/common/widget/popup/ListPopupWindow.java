package com.shopee.sc.common.widget.popup;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Px;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

/**
 * @ClassName: ListPopupWindow
 * @Description: 显示列表数据的PopupWindow，内部布局由调用者传入
 * @Author: lanjingzeng
 * @CreateDate: 2020-01-06 16:42
 * @Version: 1.0
 */
public abstract class ListPopupWindow<T> extends BasePopupWindow {
    private RecyclerView mRv;
    private ListAdapter mListAdapter;

    public ListPopupWindow(Context context, int layoutResID, int recyclerViewId, int itemlayoutResId) {
        super(context);
        init(layoutResID, recyclerViewId, itemlayoutResId);
    }

    public void init(int layoutResID, int recyclerViewId, int itemlayoutResId) {
        View popupWindowView = LayoutInflater.from(mContext).inflate(layoutResID, null);
        mRv = popupWindowView.findViewById(recyclerViewId);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        mRv.setLayoutManager(layoutManager);

        mListAdapter = new ListAdapter(itemlayoutResId);
        mRv.setAdapter(mListAdapter);

        mPopupWindow.setContentView(popupWindowView);
        mPopupWindow.setOutsideTouchable(false);
    }

    public void smoothScrollToPosition(int position) {
        if (position < 0 || position >= getListSize()) {
            return;
        }
        mRv.smoothScrollToPosition(position);
    }

    public void smoothScrollBy(@Px int dx, @Px int dy) {
        mRv.smoothScrollBy(dx, dy);
    }

    public void showAsDropDown(List<T> data, View anchorView) {
        showAsDropDown(data, anchorView, 0, 0);
    }

    public void showAsDropDown(List<T> data, View anchorView, int xoff, int yoff) {
        showAsDropDown(data, anchorView, 0, 0, Gravity.TOP | Gravity.START);
    }

    public void showAsDropDown(List<T> datas, View anchorView, int xoff, int yoff, int gravity) {
        mListAdapter.setNewData(datas);
        if (datas == null || datas.isEmpty()) {
            dismissPopupWindow();
            return;
        }

        showAsDropDown(anchorView, xoff, yoff, gravity);
    }

    public void showAtLocation(List<T> datas, View anchorView, int gravity, int xoff, int yoff) {
        mListAdapter.setNewData(datas);
        if (datas == null || datas.isEmpty()) {
            dismissPopupWindow();
            return;
        }

        showAtLocation(anchorView, gravity, xoff, yoff);
    }

    public void setOnItemClickListener(BaseQuickAdapter.OnItemClickListener onItemClickListener) {
        if (mListAdapter == null) {
            return;
        }
        mListAdapter.setOnItemClickListener(onItemClickListener);
    }

    public abstract void showItem(BaseViewHolder holder, T itemData);

    public void setData(List<T> datas) {
        mListAdapter.setNewData(datas);
    }

    public List<T> getData() {
        return mListAdapter.getData();
    }

    public T getItem(int postion) {
        if (postion < 0 || postion >= getListSize()) {
            return null;
        }
        return mListAdapter.getItem(postion);
    }

    public int getListSize() {
        return mListAdapter.getData().size();
    }

    public BaseQuickAdapter<T, BaseViewHolder> getAdapter() {
        return mListAdapter;
    }

    public class ListAdapter extends BaseQuickAdapter<T, BaseViewHolder> {

        public ListAdapter(int itemlayoutResId) {
            super(itemlayoutResId);
        }

        @Override
        public void onBindViewHolder(BaseViewHolder holder, int position) {
            super.onBindViewHolder(holder, position);
            onBindViewHolderAfter(holder, position);
        }

        @Override
        protected void convert(@NonNull BaseViewHolder holder, T itemData) {
            showItem(holder, itemData);
        }
    }

    protected void onBindViewHolderAfter(BaseViewHolder holder, int position) {
    }

}
