package com.shopee.sc.common.store;

import java.lang.reflect.Type;
/**
 *
 * @ClassName:  IStore
 * @Description: 存储的接口类
 * @Author: Lanjing Zeng
 * @CreateDate: 2022/1/21 10:05 AM
 * @Version: 1.0
 */
public interface IStore {

    void setName(String name);

    String getString(String key);

    String getString(String key, String defaultValue);

//    String getString(String name, String key, String defaultValue);

    boolean getBoolean(String key);

    boolean getBoolean(String key, boolean defaultValue);

//    boolean getBoolean(String name, String key, boolean defaultValue);

    int getInt(String key);

    int getInt(String key, int defaultValue);

//    int getInt(String name, String key, int defaultValue);

    long getLong(String key);

    long getLong(String key, long defaultValue);

//    long getLong(String name, String key, long defaultValue);

    float getFloat(String key);

    float getFloat(String key, float defaultValue);

//    float getFloat(String name, String key, float defaultValue);

    double getDouble(String key);

    double getDouble(String key, double defaultValue);

//    double getDouble(String name, String key, double defaultValue);

    <T> T getObject(String key);

    <T> T getObject(String key, Class<T> cls, T defaultValue);

//    <T> T getObject(String name, String key, Class<T> cls);

//    <T> T getObject(String name, String key, Class<T> cls, T defaultValue);

    <T> T getObject(String key, Type type, T defaultValue);

//    <T> T getObject(String name, String key, Type type, T defaultValue);

    boolean putBoolean(String key, boolean value);

//    boolean putBoolean(String name, String key, boolean value);

    boolean putString(String key, String value);

//    boolean putString(String name, String key, String value);

    boolean putInt(String key, int value);

//    boolean putInt(String name, String key, int value);

    boolean putLong(String key, long value);

//    boolean putLong(String name, String key, long value);

    boolean putFloat(String key, float value);

//    boolean putFloat(String name, String key, float value);

    boolean putDouble(String key, double value);

//    boolean putDouble(String name, String key, double value);

    boolean putObject(String key, Object value);

//    boolean putObject(String name, String key, Object value);

    boolean remove(String key);

//    boolean remove(String name, String key);

    boolean clear();

//    boolean clear(String name);
}
