package com.shopee.sc.common.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * 通用单 order_list 数据结构，可作为请求体/响应体
 *
 * Created by honggang.xiong on 2020-01-17.
 */
public class CommonOrderListInfo<T> implements Serializable {

    @SerializedName("order_list")
    private List<T> orderList;

    public CommonOrderListInfo(List<T> orderList) {
        this.orderList = orderList;
    }

    public List<T> getOrderList() {
        return orderList;
    }

}
