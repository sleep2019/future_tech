package com.shopee.sc.common.widget.adapter;

import android.view.View;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

/**
 * 对 BaseQuickAdapter 的扩展
 */
public abstract class BaseQuickAdapterExtra<T, K extends BaseViewHolder> extends BaseQuickAdapter<T, K> {

    public BaseQuickAdapterExtra(@Nullable List<T> data) {
        super(data);
    }

    public BaseQuickAdapterExtra(int layoutResId) {
        super(layoutResId);
    }

    public BaseQuickAdapterExtra(int layoutResId, @Nullable List<T> data) {
        super(layoutResId, data);
    }

    protected abstract void convertNonNullItem(@NonNull K helper, @NonNull T item);

    @Override
    protected final void convert(@NonNull K helper, T item) {
        if (item == null) {
            helper.itemView.setVisibility(View.GONE);
            return;
        }
        helper.itemView.setVisibility(View.VISIBLE);
        convertNonNullItem(helper, item);
    }

    public int getDataSize() {
        return getData() == null ? 0 : getData().size();
    }

    /**
     * 刷新被移除之上的所有Item，适用于有显示Item序号的页面
     *
     * @param position 移除的tem位置
     */
    public void removeAndChangeTop(@IntRange(from = 0) int position) {
        mData.remove(position);
        int internalPosition = position + getHeaderLayoutCount();
        notifyItemRemoved(internalPosition);
//        compatibilityDataSizeChanged(0);
        int changeItemCount = internalPosition - 1;
        if (changeItemCount > 0) {
            notifyItemRangeChanged(getHeaderLayoutCount(), changeItemCount);
        }
    }

    public int getItemPosition(int dataPosition) {
        return dataPosition + getHeaderLayoutCount();
    }
}
