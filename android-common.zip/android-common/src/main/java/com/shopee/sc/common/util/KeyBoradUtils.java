package com.shopee.sc.common.util;

import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;

import com.shopee.sc.logger.api.Logger;

public class KeyBoradUtils {

    public static void showSoftKeyBoard(@NonNull View view) {
        try {
            final InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm == null) {
                return;
            }
//            if(imm.isActive()){
//                return;
//            }
            if (SystemUtils.isNewland()) {
                // Newland做特殊处理
                view.postDelayed(() -> {
                    imm.showSoftInput(view, InputMethodManager.HIDE_NOT_ALWAYS);
                }, 50);
            } else {
                imm.showSoftInput(view, InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } catch (Exception e) {
            Logger.e("showSoftKeyBoard() error:", e);
        }
    }

    public static void hideSoftKeyBoard(@NonNull View view) {
        try {
            final InputMethodManager imm = (InputMethodManager) view.getContext()
                    .getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm == null) {
                return;
            }
//            if(!imm.isActive()){
//                return;
//            }
            if (SystemUtils.isNewland()) {
                // Newland做特殊处理
                view.postDelayed(() -> {
//                        imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }, 50);
            } else {
//                imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        } catch (Exception e) {
            Logger.e("hideSoftKeyBoard() error:", e);
        }
    }

}
