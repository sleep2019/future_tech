package com.shopee.sc.common.base;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;


import static android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN;

/**
 * Created by chris on 2019/1/7.
 *
 * 监听应用是在前台还是后台
 */
public class AppLifeCycleListener {
    private static boolean isBackground = true;
    private static ScreenOffReceiver screenOffReceiver;

    /**
     * 监听activity的生命周期
     *
     * @param application
     */
    public static void listenerForeground(Application application) {
        application.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

            }

            @Override
            public void onActivityStarted(Activity activity) {

            }

            @Override
            public void onActivityResumed(Activity activity) {
                if (isBackground) {
                    isBackground = false;
                    notifyForeground();
                }
            }

            @Override
            public void onActivityPaused(Activity activity) {

            }

            @Override
            public void onActivityStopped(Activity activity) {

            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {

            }
        });
    }

    /**
     * 注册灭屏的广播
     *
     * @param application
     */
    public static void registerScreenOffReceiver(Application application) {
        screenOffReceiver = new ScreenOffReceiver();
        IntentFilter screenStateFilter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        application.registerReceiver(screenOffReceiver, screenStateFilter);
    }

    /**
     * 注销灭屏的广播
     *
     * @param application
     */
    public static void unRegisterScreenOffReceiver(Application application) {
        if (screenOffReceiver != null) {
            application.unregisterReceiver(screenOffReceiver);
        }
    }

    /**
     * 切到后台时的处理
     *
     * @param level
     */
    public static void onTrimMemory(int level) {
        if (level >= TRIM_MEMORY_UI_HIDDEN) {
            isBackground = true;
            notifyBackground();
        }
    }

    /**
     * 终止程序
     */
    public static void onTerminate() {
        notifyBackground();
    }

    public static boolean isBackground() {
        return isBackground;
    }

    /**
     * 关屏广播
     */
    public static class ScreenOffReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            isBackground = true;
            notifyBackground();
        }
    }

    private static void notifyForeground() {

    }

    private static void notifyBackground() {

    }
}
