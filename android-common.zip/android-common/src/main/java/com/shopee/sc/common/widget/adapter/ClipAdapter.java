package com.shopee.sc.common.widget.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;

import com.shopee.sc.common.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-11-13.
 * <p>
 * Adapter for RecyclerView, support clip to specific size and expand.
 */
public abstract class ClipAdapter<T> extends SimpleAdapter<T> {

    private final List<T> mOriginList = new ArrayList<>();
    private final ClipSizeHolder mClipSizeHolder = new ClipSizeHolder(-1);
    private final int mToggleClipSize;

    public ClipAdapter(@NonNull List<T> list, @LayoutRes int layoutRes) {
        this(list, layoutRes, -1);
    }

    public ClipAdapter(@NonNull List<T> list, @LayoutRes int layoutRes, int initClipSize) {
        this(list, layoutRes, initClipSize, 1);
    }

    public ClipAdapter(@NonNull List<T> list, @LayoutRes int layoutRes, int initClipSize, int toggleClipSize) {
        this(list, layoutRes, initClipSize, toggleClipSize, true);
    }

    public ClipAdapter(@NonNull List<T> list, @LayoutRes int layoutRes, int initClipSize, int toggleClipSize, boolean enableClip) {
        super(list, layoutRes);
        mOriginList.addAll(list);
        if (enableClip) {
            addFooter(mClipSizeHolder);
        }
        clipTo(initClipSize);
        mToggleClipSize = Math.min(Math.max(toggleClipSize, 0), list.size());
    }

    public void setClipEnable(boolean enable) {
        if (enable) {
            if (!containFooter(mClipSizeHolder)) {
                addFooter(mClipSizeHolder);
            }
        } else {
            removeFooter(mClipSizeHolder);
        }
    }

    public void expand() {
        clipTo(-1);
    }

    /**
     * Clip to size or expand, -1 or overflow size for expand, otherwise clip to size.
     */
    public void clipTo(int size) {
        if (size < 0 || size > mOriginList.size()) {
            size = -1;
        }
        if (size != mClipSizeHolder.get()) {
            super.replaceData(size == -1 ? mOriginList : mOriginList.subList(0, size));
            mClipSizeHolder.set(size);
            refreshFooter(mClipSizeHolder);
        }
    }

    public int getClipSize() {
        return mClipSizeHolder.get();
    }

    @Override
    public final void addData(int position, @NonNull Collection<? extends T> newData) {
        // Do nothing for ClipAdapter
    }

    @Override
    public final void clear() {
        // Do nothing for ClipAdapter
    }

    @Override
    public final void replaceData(@NonNull Collection<? extends T> newData) {
        // Do nothing for ClipAdapter
    }

    @Override
    protected SimpleViewHolder onCreateFooterViewHolder(@NonNull ViewGroup parent, int footerPosition) {
        return new SimpleViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.common_item_clip_footer, parent, false));
    }

    @Override
    protected void convertFooter(@NonNull SimpleViewHolder holder, Object item, int footerPosition) {
        if (item instanceof ClipSizeHolder) {
            final boolean isExpand = ((ClipSizeHolder) item).get() < 0;
            View expandView = holder.getView(R.id.iv_expand);
            expandView.setSelected(isExpand);
            expandView.setOnClickListener(this::toggleByFooter);
        }
    }

    protected void toggleByFooter(View view) {
        if (getClipSize() < 0) {
            clipTo(mToggleClipSize);
        } else {
            expand();
        }
    }


    protected static class ClipSizeHolder {
        int clipSize;

        public ClipSizeHolder(int clipSize) {
            this.clipSize = clipSize;
        }

        public int get() {
            return clipSize;
        }

        public void set(int clipSize) {
            this.clipSize = clipSize;
        }
    }

}
