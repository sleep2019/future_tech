package com.shopee.sc.common.bean;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by heroxiong on 2018/3/14.
 */
public class Result<T> implements Serializable {

    @SerializedName("message")
    public String message;
    @SerializedName("retcode")
    public int retcode;
    @SerializedName("data")
    public T data;
    public boolean isCache;
    private Throwable throwable;

    private Result(Builder<T> builder) {
        this.data = builder.data;
        this.retcode = builder.retcode;
        this.message = builder.message;
        this.isCache = builder.isCache;
        this.throwable = builder.throwable;
    }

    public Result(T data) {
        this(data, 0);
    }

    public Result(T data, int retcode) {
        this(data, retcode, null);
    }

    public Result(T data, int retcode, String message) {
        this(data, retcode, message, false);
    }

    public Result(T data, int retcode, String message, boolean isCache) {
        this.data = data;
        this.retcode = retcode;
        this.message = message;
        this.isCache = isCache;
    }

    public boolean isSuccess() {
        return retcode == 0;
    }

    public boolean isStrictSuccess() {
        return retcode == 0 && data != null;
    }

    public String getErrorMessage() {
        if (retcode == 0) {
            return "";
        } else {
            return "error: " + retcode + ",msg = " + message;
        }
    }

    public Throwable getThrowable() {
        return throwable;
    }

    public void setThrowable(Throwable throwable) {
        this.throwable = throwable;
    }

    @Override
    public String toString() {
        return "Result{" +
                "message='" + message + '\'' +
                ", retcode=" + retcode +
                ", data=" + data +
                ", isCache=" + isCache +
                '}';
    }

    @NonNull
    public static <NewType> Result<NewType> convertToNewResult(@NonNull Result<?> originResult) {
        return new Result<>(null, originResult.retcode, originResult.message, originResult.isCache);
    }

    @NonNull
    public static <NewType> Result<NewType> convertToNewResult(@NonNull Result<?> originResult, NewType newTypeResultData) {
        return new Result<>(newTypeResultData, originResult.retcode, originResult.message, originResult.isCache);
    }


    public static class Builder<T> {

        private T data;
        private int retcode;
        private String message;
        private Throwable throwable;
        private boolean isCache = false;

        public Builder() {
            retcode = 0;
            isCache = false;
        }

        public Builder(Result<T> origin) {
            if (origin == null) {
                return;
            }
            data = origin.data;
            retcode = origin.retcode;
            message = origin.message;
            isCache = origin.isCache;
        }

        public Builder<T> data(T data) {
            this.data = data;
            return this;
        }

        public Builder<T> retcode(int retcode) {
            this.retcode = retcode;
            return this;
        }

        public Builder<T> message(String message) {
            this.message = message;
            return this;
        }

        public Builder<T> isCache(boolean isCache) {
            this.isCache = isCache;
            return this;
        }

        public Builder<T> throwable(Throwable throwable) {
            this.throwable = throwable;
            return this;
        }

        public Result<T> build() {
            return new Result<>(this);
        }
    }

}
