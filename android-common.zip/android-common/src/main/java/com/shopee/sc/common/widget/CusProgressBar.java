package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class CusProgressBar extends ProgressBar {
    public CusProgressBar(Context context) {
        super(context);
    }

    public CusProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CusProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
