package com.shopee.sc.common.helper.paging;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;

/**
 * 分页参数
 * <p>
 * Created by honggang.xiong on 2021/11/15.
 */
public class PagingParams {

    private final int mPageNumber;
    private final int mPageCount;
    private final String mSearchKey;
    private final Object mExtraObject;

    @NonNull
    public static PagingParams create(int pageNumber, int pageCount) {
        return new PagingParams(pageNumber, pageCount, null, null);
    }

    @NonNull
    public static PagingParams create(int pageNumber, int pageCount, String searchKey) {
        return new PagingParams(pageNumber, pageCount, searchKey, null);
    }

    private PagingParams(int pageNumber, int pageCount, String searchKey, Object extraObject) {
        mPageNumber = pageNumber;
        mPageCount = pageCount;
        mSearchKey = searchKey;
        mExtraObject = extraObject;
    }

    public int getPageNumber() {
        return mPageNumber;
    }

    public int getPageCount() {
        return mPageCount;
    }

    public String getSearchKey() {
        return mSearchKey;
    }

    public Object getExtraObject() {
        return mExtraObject;
    }


    /**
     * 分页参数 Factory 接口，默认实现只创建带页码及大小的参数，某些搜索场景可自定义 Factory 返回带搜索的参数
     */
    public interface Factory {
        Factory DEFAULT = PagingParams::create;

        @NonNull
        @MainThread
        PagingParams createParams(int pageNumber, int pageCount);
    }
}
