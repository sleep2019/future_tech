package com.shopee.sc.common.util;

import android.text.Html;
import android.text.Spanned;

public class HtmlTagUtils {
    public static final String COLOR_FF4742 = "#FF4742";

    public static String setFontColorFF4742(int source) {
        return setFontColor(String.valueOf(source), COLOR_FF4742);
    }

    public static String setFontColorFF4742(String source) {
        return setFontColor(source, COLOR_FF4742);
    }

    public static String setFontColor(String source, String color) {
        return "<font color=" + color + ">" + source + "</font>";
    }

    public static Spanned getRequiredSymbol(CharSequence rawText) {
        String text = rawText + HtmlTagUtils.setFontColorFF4742(" * ");
        return Html.fromHtml(text);
    }
}
