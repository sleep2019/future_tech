package com.shopee.sc.common.network;

import com.shopee.sc.common.BuildConfig;

/**
 * Created by javy on 30/07/2020.
 */
public class NetConstant {

    //net time out
    public final static int DEFAULT_NET_TIMEOUT = 60;
    //request base url
    public static String BASE_URL = "";
    //request cookie header key
    public static final String KEY_COOKIE_REQUEST_HEADER = "cookie";
    //response cookie header key
    public static final String KEY_COOKIE_RESPONSE_HEADER = "Set-Cookie";
    //device tag
    public static final String KEY_DEVICE = "device-tag";
    public static final String DEVICE_TAG = "android-pda";
    //user agent
    public static final String KEY_USER_AGENT = "User-Agent";
    public static final String USER_AGENT =
            "Mozilla/5.0 (Linux; Android; Nexus 5) Warehouse Mobile Assistant (" + BuildConfig.VERSION_NAME + ")";
    //version
    public static final String KEY_TIME = "X-Version";
    //csrf token
    public static final String KEY_CSRF_TOKEN = "X-Csrftoken";
    //tag
    public static final String TAG_REQUEST_LOG = "request";
    public static final String TAG_RESPONSE_LOG = "response";
    //cache
    public static final String HEADER_CACHE_PRAGMA = "Pragma";
    public static final String HEADER_CACHE_CONTROL = "Cache-Control";
    public static final long DEFAULT_CACHE_TIME = 24 * 60 * 60;
    public static final long DEFAULT_CACHE_SIZE = 1024 * 1024;

}
