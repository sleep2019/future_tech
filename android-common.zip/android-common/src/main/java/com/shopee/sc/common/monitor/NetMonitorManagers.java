package com.shopee.sc.common.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.shopee.sc.common.util.AppUtils;
import com.shopee.sc.logger.api.Logger;

import java.util.ArrayList;
import java.util.List;

public class NetMonitorManagers {
    private static final String TAG = NetMonitorManagers.class.getSimpleName();
    private List<INetObserver> mINetObservers;
    private NetReceiver mNetReceiver;
    private NetworkCallbackImpl mNetworkCallback;

    public static NetMonitorManagers getInstance() {
        return NetMonitorManagerHolder.mInstance;
    }

    private static class NetMonitorManagerHolder {
        private static NetMonitorManagers mInstance = new NetMonitorManagers();
    }

    private NetMonitorManagers() {
    }

    public void registeNetReceiver(Context context) {
        //1.android Nougat 7.0之后对静态广播做了限制，所以不管当前手机是什么版本，这里都直接采用动态注册广播的形式
        //2.android Lollipop 5.0 开始提供了新的api，因此尝试使用新的api
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
            if (mNetReceiver == null) {
                mNetReceiver = new NetReceiver();
            }
            LocalBroadcastManager.getInstance(context).registerReceiver(mNetReceiver, intentFilter);
            return;
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return;
        }
        if (mNetworkCallback == null) {
            mNetworkCallback = new NetworkCallbackImpl();
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            NetworkRequest.Builder networkRequestBuilder = new NetworkRequest.Builder();
            connectivityManager.registerNetworkCallback(networkRequestBuilder.build(), mNetworkCallback);
            return;
        }
        // android nougat 7.0才开始提供下面的api
        connectivityManager.registerDefaultNetworkCallback(mNetworkCallback);
    }

    public void unRegisteNetReceiver(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            if (mNetReceiver == null) {
                return;
            }
            LocalBroadcastManager.getInstance(context).unregisterReceiver(mNetReceiver);
            return;
        }
        if (mNetworkCallback == null) {
            return;
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return;
        }
        connectivityManager.unregisterNetworkCallback(mNetworkCallback);
    }

    public void addNetObserver(INetObserver INetObserver) {
        if (INetObserver == null) {
            return;
        }
        if (mINetObservers == null) {
            mINetObservers = new ArrayList<>();
        }
        if (mINetObservers.contains(INetObserver)) {
            return;
        }
        mINetObservers.add(INetObserver);
    }

    public void removeNetObserver(INetObserver INetObserver) {
        if (INetObserver == null) {
            return;
        }
        if (mINetObservers == null) {
            return;
        }
        mINetObservers.remove(INetObserver);
    }

    public void removeAllNetObservers() {
        if (mINetObservers == null) {
            return;
        }
        mINetObservers.clear();
    }

    private void notifyNetChange() {
        Context context = AppUtils.getContext();
        if (context == null) {
            return;
        }
        int netType = getAPNType(context);
        notifyNetObserver(netType);
    }

    /**
     * Get the current network state
     * <p>
     * No network-NO
     * 4G network-4G
     * 3G network-3G
     * 2G network-2G
     * WIFI network-WIFI
     * Unknown network-Unknown
     *
     * @param context
     * @return
     */
    public static int getAPNType(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) {
            return NetTypes.NONE;
        }
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo == null) {
            return NetTypes.NONE;
        }

        int nType = networkInfo.getType();
        if (nType == ConnectivityManager.TYPE_WIFI) {
            return NetTypes.WIFI;
        } else if (nType == ConnectivityManager.TYPE_MOBILE) {
            int nSubType = networkInfo.getSubtype();
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (nSubType == TelephonyManager.NETWORK_TYPE_LTE
                    && !telephonyManager.isNetworkRoaming()) {
                return NetTypes.MOBILE_4G;
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_UMTS
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_0
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_A
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSDPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSUPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_B
                    || nSubType == TelephonyManager.NETWORK_TYPE_EHRPD
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSPAP
                    && !telephonyManager.isNetworkRoaming()) {
                return NetTypes.MOBILE_3G;
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_GPRS
                    || nSubType == TelephonyManager.NETWORK_TYPE_EDGE
                    || nSubType == TelephonyManager.NETWORK_TYPE_CDMA
                    || nSubType == TelephonyManager.NETWORK_TYPE_1xRTT
                    || nSubType == TelephonyManager.NETWORK_TYPE_IDEN
                    && !telephonyManager.isNetworkRoaming()) {
                return NetTypes.MOBILE_2G;
            } else {
                return NetTypes.UNKOWN;
            }
        }
        return NetTypes.UNKOWN;
    }

    public void notifyNetObserver(@NetTypes int netType) {
        if (mINetObservers == null || mINetObservers.isEmpty()) {
            return;
        }
        for (INetObserver INetObserver : mINetObservers) {
            if (INetObserver == null) {
                continue;
            }
            INetObserver.netChange(netType);
        }
    }

    public class NetReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent == null ? "" : intent.getAction();
            if (!TextUtils.equals(action, ConnectivityManager.CONNECTIVITY_ACTION)) {
                return;
            }
            notifyNetChange();
        }
    }

    /**
     * 网络变更的回调
     * 1.无wifi和数据流量的情况下链接wifi或者数据流量都会执行onAvailable()和onCapabilitiesChanged()
     * 2.同时有wifi和数据流量的情况下断开wifi，会先执行onLost()，再执行onAvailable()，此时若把数据流量也断开会执行onLost()
     * 3.同时有wifi和数据流量的情况下断开数据流量，不执行onLost()，只会执行onCapabilitiesChanged()
     * 4.数据流量已连接，再次连接wifi，会执行onAvailable(),也会执行onCapabilitiesChanged()
     */
    public class NetworkCallbackImpl extends ConnectivityManager.NetworkCallback {
        @Override
        public void onAvailable(Network network) {
            super.onAvailable(network);
            Logger.v(TAG, "onAvailable().....");
            notifyNetChange();
        }

        @Override
        public void onLost(Network network) {
            super.onLost(network);
            Logger.v(TAG, "onLost().....");
            notifyNetChange();
        }

        @Override
        public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
            super.onCapabilitiesChanged(network, networkCapabilities);
            Logger.v(TAG, "onCapabilitiesChanged().....");
        }

        @Override
        public void onUnavailable() {
            super.onUnavailable();
            Logger.v(TAG, "onUnavailable().....");
        }
    }

    /**
     * @ClassName: INetObserver
     * @Description:
     * @Author: lanjingzeng
     * @CreateDate: 2020-03-04 09:36
     * @Version: 1.0
     */
    public interface INetObserver {
        /**
         * 主线程，若是耗时操作需要自己切换至子线程
         *
         * @param netType 网络类型
         */
        void netChange(@NetTypes int netType);
    }
}
