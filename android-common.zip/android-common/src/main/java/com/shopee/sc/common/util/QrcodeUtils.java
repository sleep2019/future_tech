package com.shopee.sc.common.util;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.text.TextUtils;

import androidx.annotation.WorkerThread;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.shopee.sc.logger.api.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by honggang.xiong on 2021/11/11.
 */
public class QrcodeUtils {

    /**
     * 生成指定内容的条形码 Bitmap
     *
     * @param content     条形码内容
     * @param targetWidth 目标宽度
     * @param aspectRatio 宽高比
     * @return Bitmap or null
     */
    @WorkerThread
    public static Bitmap createBarcode(String content, int targetWidth, int aspectRatio) {
        if (TextUtils.isEmpty(content)) {
            return null;
        }
        // 配置参数
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hints.put(EncodeHintType.MARGIN, 0);

        try {
            // 宽高都传1，encode 过程会根据编码结果重设 width
            BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.CODE_128, 1, 1, hints);
            // tempWidth -> 编码结果宽度，tempHeight -> tempWidth / aspectRatio
            final int tempWidth = bitMatrix.getWidth();
            final int tempHeight = Math.max(1, tempWidth / aspectRatio);

            Logger.i("createBarcode required width=" + targetWidth + ", height=" + (targetWidth / aspectRatio)
                    + ", temp width=" + tempWidth + ", height=" + tempHeight);
            int[] pixels = new int[tempWidth * tempHeight];
            // set pixels
            for (int x = 0; x < tempWidth; x++) {
                int color = bitMatrix.get(x, 0) ? Color.BLACK : Color.WHITE;
                for (int y = 0; y < tempHeight; y++) {
                    pixels[y * tempWidth + x] = color;
                }
            }
            Bitmap origin = Bitmap.createBitmap(pixels, tempWidth, tempHeight, Bitmap.Config.ARGB_8888);
            float scaleRatio = targetWidth * 1.0F / tempWidth;
            return UiUtils.scaleBitmap(origin, scaleRatio);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 生成指定内容的二维码 Bitmap
     *
     * @param content      条形码内容
     * @param targetWidth  目标宽度 px
     * @param targetHeight 目标高度 px
     * @return Bitmap or null
     */
    @WorkerThread
    public static Bitmap createQrcode(String content, int targetWidth, int targetHeight) {
        if (TextUtils.isEmpty(content)) {
            return null;
        }
        // 配置参数
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.Q);
        hints.put(EncodeHintType.MARGIN, 0);

        try {
            // 宽高都传1，encode 过程会根据编码结果重设 width
            BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, targetWidth, targetHeight, hints);
            // tempWidth -> 编码结果宽度，tempHeight -> 编码结果高度
            final int tempWidth = bitMatrix.getWidth();
            final int tempHeight = bitMatrix.getHeight();
            Logger.i("createQrcode required width=" + targetWidth + ", height=" + targetHeight
                    + ", temp width=" + tempWidth + ", height=" + tempHeight);

            int[] pixels = new int[tempWidth * tempHeight];
            // set pixels
            for (int x = 0; x < tempWidth; x++) {
                for (int y = 0; y < tempHeight; y++) {
                    pixels[y * tempWidth + x] = bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE;
                }
            }
            Bitmap origin = Bitmap.createBitmap(pixels, tempWidth, tempHeight, Bitmap.Config.ARGB_8888);
            float scaleRatio = targetWidth * 1.0F / tempWidth;
            return UiUtils.scaleBitmap(origin, scaleRatio);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
