package com.shopee.sc.common.plugins;


import androidx.annotation.NonNull;

import com.shopee.sc.common.functions.ILog;
import com.shopee.sc.logger.api.LogLevel;
import com.shopee.sc.logger.api.LogPrinter;
import com.shopee.sc.logger.api.Logger;

/**
 * Created by honggang.xiong on 2021/11/4.
 */
public abstract class LogPrintWrapper implements ILog {

    @NonNull
    protected abstract LogPrinter getPrinter();

    @Override
    public boolean isLoggable() {
        return getPrinter().isLoggable(Logger.isDebug(), LogLevel.ALL, null);
    }

    @Override
    public void d(String msg) {
        d(null, msg);
    }

    @Override
    public void d(String tag, String msg) {
        d(tag, msg, null);
    }

    @Override
    public void d(String tag, String msg, Throwable tr) {
        getPrinter().log(LogLevel.DEBUG, tag, msg, tr);
    }

    @Override
    public void i(String msg) {
        i(null, msg);
    }

    @Override
    public void i(String tag, String msg) {
        i(tag, msg, null);
    }

    @Override
    public void i(String tag, String msg, Throwable tr) {
        getPrinter().log(LogLevel.INFO, tag, msg, tr);
    }

    @Override
    public void w(String msg) {
        w(null, msg);
    }

    @Override
    public void w(String tag, String msg) {
        w(tag, msg, null);
    }

    @Override
    public void w(String tag, String msg, Throwable tr) {
        getPrinter().log(LogLevel.WARN, tag, msg, tr);
    }

    @Override
    public void e(String msg) {
        e(null, msg);
    }

    @Override
    public void e(String tag, String msg) {
        e(tag, msg, null);
    }

    @Override
    public void e(String tag, String msg, Throwable tr) {
        getPrinter().log(LogLevel.ERROR, tag, msg, tr);
    }
}
