package com.shopee.sc.common.network.converter;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.shopee.sc.common.bean.Result;
import com.shopee.sc.common.helper.LoginHelper;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Converter;

/**
 * Created by chris on 2019-10-11.
 */
final class CustomGsonResponseBodyConverter<T> implements Converter<ResponseBody, T> {
    private final Gson mGson;
    private final TypeAdapter<T> mAdapter;
    private final Integer mNetCodeLimitedAccount;
    private final Integer mNetCodeNotLogin;

    CustomGsonResponseBodyConverter(@NonNull Gson gson, @NonNull TypeAdapter<T> adapter,
                                    Integer netCodeLimitedAccount,
                                    Integer netCodeNotLogin) {
        mGson = gson;
        mAdapter = adapter;
        mNetCodeLimitedAccount = netCodeLimitedAccount;
        mNetCodeNotLogin = netCodeNotLogin;
    }

    @Override
    public T convert(ResponseBody value) throws IOException {
        JsonReader jsonReader = mGson.newJsonReader(value.charStream());
        try {
            T result = mAdapter.read(jsonReader);
            if (jsonReader.peek() != JsonToken.END_DOCUMENT) {
                throw new JsonIOException("JSON document was not fully consumed.");
            }
            if (result instanceof Result) {
                Result<?> body = (Result<?>) result;
                // 强制登出
                if (mNetCodeLimitedAccount != null && mNetCodeLimitedAccount == body.retcode) {
                    showLogoutDialog(body.message);
                    // 清除错误信息，无需在请求结果中Toast中显示
                    body.message = "";
                } else if (mNetCodeNotLogin != null && mNetCodeNotLogin == body.retcode) {
                    // 清除错误信息，无需在请求结果中Toast中显示
                    body.message = "";
                    // 登出，回到登录页面
                    if (LoginHelper.getLoginCallback() != null) {
                        LoginHelper.getLoginCallback().logout();
                    }
                }
            }
            return result;
        } finally {
            value.close();
        }
    }

    private void showLogoutDialog(String message) {
        if (LoginHelper.getLoginCallback() != null) {
            LoginHelper.getLoginCallback().showLogoutDialog(message);
        }
    }
}