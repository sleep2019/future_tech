package com.shopee.sc.common.base;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Lifecycle;

import com.shopee.sc.common.manager.AppManager;
import com.uber.autodispose.AutoDispose;
import com.uber.autodispose.AutoDisposeConverter;
import com.uber.autodispose.android.lifecycle.AndroidLifecycleScopeProvider;

import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public class CommonActivity extends FragmentActivity {

    private CompositeDisposable mAutoCancelDisposables = new CompositeDisposable();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Add activity to stack
        AppManager.getAppManager().addActivity(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove activity from stack
        AppManager.getAppManager().removeActivity(this);
        mAutoCancelDisposables.clear();
    }

    public void addAutoCancelDisposables(Disposable... disposables) {
        mAutoCancelDisposables.addAll(disposables);
    }

    /**
     * 绑定生命周期 防止内存泄漏
     */
    public <T> AutoDisposeConverter<T> bindAutoDispose() {
        return AutoDispose.autoDisposable(AndroidLifecycleScopeProvider
                .from(this, Lifecycle.Event.ON_DESTROY));
    }

}
