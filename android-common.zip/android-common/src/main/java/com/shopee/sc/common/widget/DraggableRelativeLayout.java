package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.core.math.MathUtils;
import androidx.customview.widget.ViewDragHelper;

/**
 * 可拖拽容器简单实现
 *
 * Created by honggang.xiong on 2020/8/26.
 */
public class DraggableRelativeLayout extends RelativeLayout {

    public static final String DRAG_TAG_VERTICAL = "dragVertical";

    private ViewDragHelper mViewDragHelper;

    public DraggableRelativeLayout(Context context) {
        this(context, null);
    }

    public DraggableRelativeLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DraggableRelativeLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mViewDragHelper = ViewDragHelper.create(this, 1.0f, new ViewDragHelperCallback());
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        return mViewDragHelper.shouldInterceptTouchEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mViewDragHelper.processTouchEvent(event);
        return super.onTouchEvent(event);
    }


    private class ViewDragHelperCallback extends ViewDragHelper.Callback {

        @Override
        public boolean tryCaptureView(@NonNull View view, int pointerId) {
            return DRAG_TAG_VERTICAL.equals(view.getTag());
        }

        @Override
        public int clampViewPositionVertical(@NonNull View child, int top, int dy) {
            return MathUtils.clamp(top, getPaddingTop(), getHeight() - getPaddingBottom() - child.getHeight());
        }

        @Override
        public int clampViewPositionHorizontal(@NonNull View child, int left, int dx) {
            return child.getLeft();
        }

        @Override
        public int getViewVerticalDragRange(@NonNull View child) {
            return getHeight();
        }
    }

}
