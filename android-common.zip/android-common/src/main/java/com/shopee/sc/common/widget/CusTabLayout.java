package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.tabs.TabLayout;

public class CusTabLayout extends TabLayout {

    private boolean mIsInterceptTouchEvent;

    public CusTabLayout(@NonNull Context context) {
        super(context);
    }

    public CusTabLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CusTabLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public View getTabView(int index) {
        TabLayout.Tab tab = getTabAt(index);
        return tab != null ? tab.view : null;
    }

    public void setInterceptTouchEvent(boolean interceptTouchEvent) {
        mIsInterceptTouchEvent = interceptTouchEvent;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (mIsInterceptTouchEvent) {
            return true;
        }
        return super.onInterceptTouchEvent(ev);
    }
}
