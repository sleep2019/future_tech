package com.shopee.sc.common.bean.config;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * Created by honggang.xiong on 2020/4/2.
 */
public class DeviceConfigInfo implements Serializable {

    @SerializedName("mobile_config_list")
    private List<DeviceBean> mobileConfigList;

    @NonNull
    public List<DeviceBean> getMobileConfigList() {
        return mobileConfigList != null ? mobileConfigList : Collections.emptyList();
    }

    public static class DeviceBean implements Serializable {

        @SerializedName("mobile_brand")
        private String mobileBrand;
        @SerializedName("mobile_model")
        private String mobileModel;
        @SerializedName("mobile_system")
        private String mobileSystem;
        @SerializedName("mobile_size")
        private String mobileSize;
        @SerializedName("mobile_resolution")
        private String mobileResolution;

        public String getMobileBrand() {
            return mobileBrand;
        }

        public String getMobileModel() {
            return mobileModel;
        }

        public String getMobileSystem() {
            return mobileSystem;
        }

        public String getMobileSize() {
            return mobileSize;
        }

        public String getMobileResolution() {
            return mobileResolution;
        }
    }

}
