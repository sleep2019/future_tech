package com.shopee.sc.common.widget.adapter;

import android.widget.CompoundButton;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.chad.library.adapter.base.util.MultiTypeDelegate;
import com.shopee.sc.common.R;
import com.shopee.sc.common.bean.CheckedItem;

import java.util.List;

/**
 * 扩展多选 Adapter，支持多种 item。需保证 T 非空
 * <p>
 * Created by honggang.xiong on 2021-02-26.
 */
public abstract class MultiItemMultiChoiceAdapter<T extends MultiItemEntity> extends MultiChoiceAdapter<T> {

    public static final int DEFAULT_VIEW_TYPE = -0xff;
    private MultiTypeDelegate<CheckedItem<T>> mMultiTypeDelegate;

    public MultiItemMultiChoiceAdapter(@Nullable List<CheckedItem<T>> data) {
        super(0, data);
        initMultiTypeDelegate();
    }

    public MultiItemMultiChoiceAdapter(@Nullable List<T> originList, boolean defaultChecked) {
        super(0, originList, defaultChecked);
        initMultiTypeDelegate();
    }

    private void initMultiTypeDelegate() {
        mMultiTypeDelegate = new MultiTypeDelegate<CheckedItem<T>>() {
            @Override
            protected int getItemType(@NonNull CheckedItem<T> checkedItem) {
                T item = checkedItem.getModel();
                if (item != null) {
                    return item.getItemType();
                }
                return DEFAULT_VIEW_TYPE;
            }
        };
        setMultiTypeDelegate(mMultiTypeDelegate);
    }

    /**
     * set your own type one by one.
     *
     * @param type        type value
     * @param layoutResId layout id
     */
    public void registerItemType(int type, @LayoutRes int layoutResId) {
        if (mMultiTypeDelegate != null) {
            mMultiTypeDelegate.registerItemType(type, layoutResId);
        }
    }

    @Nullable
    @Override
    protected CompoundButton getCheckableView(@NonNull BaseViewHolder viewHolder) {
        return viewHolder.getView(R.id.compound_button);
    }

}
