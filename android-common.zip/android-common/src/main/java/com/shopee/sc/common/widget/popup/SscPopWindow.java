package com.shopee.sc.common.widget.popup;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.PopupWindow;

import androidx.annotation.RequiresApi;

import com.shopee.sc.logger.api.Logger;

public class SscPopWindow implements PopupWindow.OnDismissListener {
    private static final String TAG = "SscPopWindow";
    private static final float DEFAULT_ALPHA = 0.7f;
    private Context mContext;
    private int mWidth;
    private int mHeight;
    private boolean mIsFocusable = false;
    private boolean mIsOutside = true;
    private int mResLayoutId = -1;
    private View mContentView;
    private PopupWindow mPopupWindow;
    private int mAnimationStyle = -1;

    private boolean mClipEnable = true;//default is true
    private boolean mIgnoreCheekPress = false;
    private int mInputMode = -1;
    private PopupWindow.OnDismissListener mOnDismissListener;
    private int mSoftInputMode = -1;
    private boolean mTouchable = true;//default is true
    private View.OnTouchListener mOnTouchListener;

    private Window mWindow;//the window of the current activity
    /**
     * Pop Window，the default is dark
     */
    private boolean mIsBackgroundDark = false;

    private float mBackgroundDarkValue = 0; //0 - 1
    /**
     * Set to click the outside of pop-window whether closed pop-window, the default is false
     */
    private boolean enableOutsideTouchDisMiss = true;
    private OnCustomPopWindowDismissListener mOnCustomPopWindowDismissListener;

    private SscPopWindow(Context context) {
        mContext = context;
    }

    public int getWidth() {
        return mWidth;
    }

    public int getHeight() {
        return mHeight;
    }

    /**
     * @param anchor
     * @param xOff
     * @param yOff
     * @return
     */
    public SscPopWindow showAsDropDown(View anchor, int xOff, int yOff) {
        if (mPopupWindow != null) {
            mPopupWindow.showAsDropDown(anchor, xOff, yOff);
        }
        return this;
    }

    public SscPopWindow showAsDropDown(View anchor) {
        if (mPopupWindow != null) {
            mPopupWindow.showAsDropDown(anchor);
        }
        return this;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public SscPopWindow showAsDropDown(View anchor, int xOff, int yOff, int gravity) {
        if (mPopupWindow != null) {
            mPopupWindow.showAsDropDown(anchor, xOff, yOff, gravity);
        }
        return this;
    }


    /**
     * Relative to parent to set 'Gravity.CENTER'、'Gravity.BOTTOM' etc
     *
     * @param parent
     * @param gravity
     * @param x       the popup's x location offset
     * @param y       the popup's y location offset
     * @return
     */
    public SscPopWindow showAtLocation(Activity activity, View parent, int gravity, int x, int y) {
        try {
            if (mPopupWindow != null && activity != null && !activity.isFinishing()) {
                mPopupWindow.showAtLocation(parent, gravity, x, y);
            }
        } catch (Exception e) {
            Logger.e(TAG, "showAtLocation: " + e.toString());
        }
        return this;
    }

    /**
     * Set attributes
     *
     * @param popupWindow
     */
    private void apply(PopupWindow popupWindow) {
        popupWindow.setClippingEnabled(mClipEnable);
        if (mIgnoreCheekPress) {
            popupWindow.setIgnoreCheekPress();
        }
        if (mInputMode != -1) {
            popupWindow.setInputMethodMode(mInputMode);
        }
        if (mSoftInputMode != -1) {
            popupWindow.setSoftInputMode(mSoftInputMode);
        }
        if (mOnDismissListener != null) {
            popupWindow.setOnDismissListener(mOnDismissListener);
        }
        if (mOnTouchListener != null) {
            popupWindow.setTouchInterceptor(mOnTouchListener);
        }
        popupWindow.setTouchable(mTouchable);


    }

    private PopupWindow build() {

        if (mContentView == null) {
            mContentView = LayoutInflater.from(mContext).inflate(mResLayoutId, null);
        }

        Activity activity = (Activity) mContentView.getContext();
        if (activity != null && mIsBackgroundDark) {
            //0 ~ 1
            final float alpha = (mBackgroundDarkValue > 0 && mBackgroundDarkValue < 1) ? mBackgroundDarkValue : DEFAULT_ALPHA;
            mWindow = activity.getWindow();
            WindowManager.LayoutParams params = mWindow.getAttributes();
            params.alpha = alpha;
            mWindow.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            mWindow.setAttributes(params);
        }

        if (mWidth != 0 && mHeight != 0) {
            mPopupWindow = new PopupWindow(mContentView, mWidth, mHeight);
        } else {
            mPopupWindow = new PopupWindow(mContentView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        if (mAnimationStyle != -1) {
            mPopupWindow.setAnimationStyle(mAnimationStyle);
        }

        apply(mPopupWindow);

        if (mWidth == 0 || mHeight == 0) {
            mPopupWindow.getContentView().measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            //Calculate width and height as if not set
            mWidth = mPopupWindow.getContentView().getMeasuredWidth();
            mHeight = mPopupWindow.getContentView().getMeasuredHeight();
        }

        //Listener dismiss
        mPopupWindow.setOnDismissListener(this);

        //Judge whether click the outside of pop-window to close
        if (!enableOutsideTouchDisMiss) {
            //Note the attributes
            mPopupWindow.setFocusable(true);
            mPopupWindow.setOutsideTouchable(false);
            mPopupWindow.setBackgroundDrawable(null);
            //Set contentView
            mPopupWindow.getContentView().setFocusable(true);
            mPopupWindow.getContentView().setFocusableInTouchMode(true);
            mPopupWindow.getContentView().setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
                        mPopupWindow.dismiss();

                        return true;
                    }
                    return false;
                }
            });
            //Fix android 6.0+
            mPopupWindow.setTouchInterceptor(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {

                    final int x = (int) event.getX();
                    final int y = (int) event.getY();

                    if ((event.getAction() == MotionEvent.ACTION_DOWN)
                            && ((x < 0) || (x >= mWidth) || (y < 0) || (y >= mHeight))) {
                        Logger.e(TAG, "out side ");
                        Logger.e(TAG, "width:" + mPopupWindow.getWidth() + "height:" + mPopupWindow.getHeight() + " x:" + x + " y  :" + y);
                        return true;
                    } else if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                        Logger.e(TAG, "out side ...");
                        return true;
                    }
                    return false;
                }
            });
        } else {
            mPopupWindow.setFocusable(mIsFocusable);
            mPopupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            mPopupWindow.setOutsideTouchable(mIsOutside);
        }
        // update
        mPopupWindow.update();

        return mPopupWindow;
    }

    public void setCustomPopWindowDismissListener(OnCustomPopWindowDismissListener listener) {
        this.mOnCustomPopWindowDismissListener = listener;
    }

    public interface OnCustomPopWindowDismissListener {
        void onCustomPopWindowDismiss();
    }

    @Override
    public void onDismiss() {
        //dissmiss();
        if (mWindow != null) {
            WindowManager.LayoutParams params = mWindow.getAttributes();
            params.alpha = 1.0f;
            mWindow.setAttributes(params);
            if (mOnCustomPopWindowDismissListener != null) {
                mOnCustomPopWindowDismissListener.onCustomPopWindowDismiss();
            }
        }
    }

    /**
     * Close popWindow
     */
    public void dismiss() {
        boolean isActivityFinish = mContext instanceof Activity
                && (((Activity) mContext).isFinishing() || ((Activity) mContext).isDestroyed());
        Logger.d(TAG, "isActivityFinish " + isActivityFinish);
        if (isActivityFinish || !isShowing()) {
            Logger.d(TAG, "activity finish or popupwindow not showing");
            return;
        }

        if (mOnDismissListener != null) {
            mOnDismissListener.onDismiss();
        }

        //Resumed as if the background is dark
        if (mWindow != null) {
            WindowManager.LayoutParams params = mWindow.getAttributes();
            params.alpha = 1.0f;
            mWindow.setAttributes(params);
        }
        if (mPopupWindow != null && mPopupWindow.isShowing()) {
            mPopupWindow.dismiss();
        }
    }

    public PopupWindow getPopupWindow() {
        return mPopupWindow;
    }

    public boolean isShowing() {
        return mPopupWindow != null && mPopupWindow.isShowing();
    }

    public void resumeWindow() {
        if (mWindow != null) {
            WindowManager.LayoutParams params = mWindow.getAttributes();
            params.alpha = mBackgroundDarkValue;
            mWindow.setAttributes(params);
        }
    }

    public static class PopupWindowBuilder {
        private SscPopWindow mSscPopWindow;

        public PopupWindowBuilder(Context context) {
            mSscPopWindow = new SscPopWindow(context);
        }

        public PopupWindowBuilder size(int width, int height) {
            mSscPopWindow.mWidth = width;
            mSscPopWindow.mHeight = height;
            return this;
        }


        public PopupWindowBuilder setFocusable(boolean focusable) {
            mSscPopWindow.mIsFocusable = focusable;
            return this;
        }


        public PopupWindowBuilder setView(int resLayoutId) {
            mSscPopWindow.mResLayoutId = resLayoutId;
            mSscPopWindow.mContentView = null;
            return this;
        }

        public PopupWindowBuilder setView(View view) {
            mSscPopWindow.mContentView = view;
            mSscPopWindow.mResLayoutId = -1;
            return this;
        }

        public PopupWindowBuilder setOutsideTouchable(boolean outsideTouchable) {
            mSscPopWindow.mIsOutside = outsideTouchable;
            return this;
        }

        /**
         * Set popup animation
         *
         * @param animationStyle
         * @return
         */
        public PopupWindowBuilder setAnimationStyle(int animationStyle) {
            mSscPopWindow.mAnimationStyle = animationStyle;
            return this;
        }


        public PopupWindowBuilder setClippingEnable(boolean enable) {
            mSscPopWindow.mClipEnable = enable;
            return this;
        }


        public PopupWindowBuilder setIgnoreCheekPress(boolean ignoreCheekPress) {
            mSscPopWindow.mIgnoreCheekPress = ignoreCheekPress;
            return this;
        }

        public PopupWindowBuilder setInputMethodMode(int mode) {
            mSscPopWindow.mInputMode = mode;
            return this;
        }

        public PopupWindowBuilder setOnDismissListener(OnCustomPopWindowDismissListener onDissmissListener) {
            mSscPopWindow.mOnCustomPopWindowDismissListener = onDissmissListener;
            return this;
        }


        public PopupWindowBuilder setSoftInputMode(int softInputMode) {
            mSscPopWindow.mSoftInputMode = softInputMode;
            return this;
        }


        public PopupWindowBuilder setTouchable(boolean touchable) {
            mSscPopWindow.mTouchable = touchable;
            return this;
        }

        public PopupWindowBuilder setTouchInterceptor(View.OnTouchListener touchInterceptor) {
            mSscPopWindow.mOnTouchListener = touchInterceptor;
            return this;
        }

        /**
         * Set whether the background is dark
         *
         * @param isDark
         * @return
         */
        public PopupWindowBuilder enableBackgroundDark(boolean isDark) {
            mSscPopWindow.mIsBackgroundDark = isDark;
            return this;
        }

        /**
         * Set the value of background
         *
         * @param darkValue
         * @return
         */
        public PopupWindowBuilder setBgDarkAlpha(float darkValue) {
            mSscPopWindow.mBackgroundDarkValue = darkValue;
            return this;
        }

        /**
         * Set to click the outside of pop-window whether closed pop-window
         *
         * @param disMiss
         * @return
         */
        public PopupWindowBuilder enableOutsideTouchableDismiss(boolean disMiss) {
            mSscPopWindow.enableOutsideTouchDisMiss = disMiss;
            return this;
        }

        public SscPopWindow create() {
            //create pop-window
            mSscPopWindow.build();
            return mSscPopWindow;
        }

    }

}

