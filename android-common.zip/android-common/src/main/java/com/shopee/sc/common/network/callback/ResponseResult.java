package com.shopee.sc.common.network.callback;

import com.shopee.sc.common.bean.Result;

/**
 * 服务器数据返回
 */
public class ResponseResult<T> implements IResponseCallback<T> {

    @Override
    public void showResult(Result<T> result, Object obj, boolean success, String msg, boolean refresh, Object... params) {

    }
}
