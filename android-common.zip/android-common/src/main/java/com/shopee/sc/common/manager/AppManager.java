package com.shopee.sc.common.manager;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;

import java.util.LinkedList;

/**
 * Created by chris on 2018/2/23.
 */

/**
 * App activity manager class: To manager Activity and exit Application
 */
public class AppManager {

    private volatile static AppManager sInstance;
    private static LinkedList<Activity> sActivityStack;

    private AppManager() {
    }

    public static AppManager getAppManager() {
        if (sInstance == null) {
            synchronized (AppManager.class) {
                if (sInstance == null) {
                    sInstance = new AppManager();
                }
            }
        }
        return sInstance;
    }

    /**
     * Add activity to stack
     */
    public void addActivity(Activity activity) {
        synchronized (this) {
            if (sActivityStack == null) {
                sActivityStack = new LinkedList<>();
            }
            sActivityStack.add(activity);
        }
    }

    /**
     * Remove the appointed activity
     */
    public void removeActivity(Activity activity) {
        synchronized (this) {
            if (sActivityStack != null) {
                sActivityStack.remove(activity);
            }
        }
    }

    /**
     * Get the current activity
     */
    public Activity currentActivity() {
        if (sActivityStack == null || sActivityStack.isEmpty()) {
            return null;
        }
        return sActivityStack.getLast();
    }

    public boolean currentActivityHasFocus() {
        return currentActivity() != null && currentActivity().hasWindowFocus();
    }

    /**
     * has the specific activity
     */
    public boolean hasActivity(Class cls) {
        if (sActivityStack == null || sActivityStack.isEmpty()) {
            return false;
        }
        for (int i = 0, size = sActivityStack.size(); i < size; i++) {
            Activity activity = sActivityStack.get(i);
            if (activity.getClass().equals(cls)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Finish the current activity
     */
    public void finishActivity() {
        if (sActivityStack == null || sActivityStack.isEmpty()) {
            return;
        }
        Activity activity = sActivityStack.getLast();
        finishActivity(activity);
    }

    /**
     * Finish the appointed activity
     */
    public void finishActivity(Activity activity) {
        synchronized (this) {
            if (activity != null) {
                if (sActivityStack != null) {
                    sActivityStack.remove(activity);
                }
                activity.finish();
                activity = null;
            }
        }
    }

    /**
     * Finish the specific class activity
     */
    public void finishActivity(Class<?> cls) {
        try {
            int size = sActivityStack.size();
            for (int i = 0; i < size; i++) {
                Activity activity = sActivityStack.get(i);
                if (activity.getClass().equals(cls)) {
                    finishActivity(activity);
                }
            }
        } catch (IndexOutOfBoundsException e) {

        }
    }

    /**
     * Finish the activities from top to the specific activity
     *
     * @param cls class of the specific activity
     */
    public void finishTopActivitiesTill(Class<?> cls) {
        if (cls == null) {
            return;
        }
        try {
            int size = sActivityStack.size();
            for (int i = 0; i < size; i++) {
                Activity activity = sActivityStack.getLast();
                if (activity.getClass().equals(cls)) {
                    break;
                } else {
                    finishActivity(activity);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Finish other activity
     */
    public void finishOtherActivity(Class<?> cls) {
        if (sActivityStack == null || sActivityStack.isEmpty()) {
            return;
        }
        for (int i = 0, size = sActivityStack.size(); i < size; i++) {
            Activity activity = sActivityStack.get(i);
            if (!activity.getClass().equals(cls)) {
                sActivityStack.get(i).finish();
            }
        }
    }

    /**
     * Finish all activity
     */
    public void finishAllActivity() {
        if (sActivityStack == null || sActivityStack.isEmpty()) {
            return;
        }
        synchronized (this) {
            for (int i = 0, size = sActivityStack.size(); i < size; i++) {
                if (null != sActivityStack.get(i)) {
                    sActivityStack.get(i).finish();
                }
            }
            sActivityStack.clear();
        }
    }

    /**
     * Exit application
     */
    public void AppExit(Context context) {
        try {
            finishAllActivity();
            ActivityManager activityMgr = (ActivityManager) context
                    .getSystemService(Context.ACTIVITY_SERVICE);
            activityMgr.killBackgroundProcesses(context.getPackageName());
            System.exit(0);
        } catch (Exception e) {

        }
    }

    public int ActivityStackSize() {
        return sActivityStack == null ? 0 : sActivityStack.size();
    }

    /**
     * Restart application
     */
    public void restartApplication(Context context) {
        final Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
    }

    /**
     * Restart activity
     */
    public void restartActivity(Activity activity) {
        Intent intent = new Intent();
        intent.setClass(activity, activity.getClass());
        activity.startActivity(intent);
        activity.overridePendingTransition(0, 0);
        activity.finish();
    }
}