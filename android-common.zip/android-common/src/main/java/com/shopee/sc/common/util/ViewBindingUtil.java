package com.shopee.sc.common.util;

import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;

import com.shopee.sc.common.viewbinding.ViewBindingCreator;
import com.shopee.sc.logger.api.Logger;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;

/**
 * Created by honggang.xiong on 2021/3/23.
 */
public class ViewBindingUtil {

    private static final String INFLATE_METHOD_NAME = "inflate";
    private static final boolean ENABLE_CACHE = true;
    private static final int MAX_CLASS_CACHE_COUNT = 64;
    private static final int MAX_METHOD_CACHE_COUNT = 64;
    private static boolean sCheckSuccess = false;
    // creator class -> ViewBinding class
    private static final LruCache<Class<?>, Class<? extends ViewBinding>> sClassCache = new LruCache<>(MAX_CLASS_CACHE_COUNT);
    // ViewBinding class -> ViewBinding inflate method
    private static final LruCache<Class<?>, Method> sMethodCache = new LruCache<>(MAX_METHOD_CACHE_COUNT);

    /**
     * App 冷启动时检查一次是否可用，不可用直接退出 App，避免 ViewBinding 生成规则变化影响深层 Activity。
     *
     * @param <VB> 泛型参数传任一生成的 VB 类，不能直接传 ViewBinding。
     * @return True if reflect available.
     */
    public static <VB extends ViewBinding> boolean checkReflectAvailable(ViewBindingCreator<VB> creator) {
        if (sCheckSuccess) {
            return true;
        }

        try {
            Class<?> viewBindingClass = getViewBindingClassFromCreator(creator, false);
            getFullInflateMethodFromClass(viewBindingClass, false);
            Logger.i("checkReflectAvailable success");
            sCheckSuccess = true;
            return true;
        } catch (Throwable e) {
            Logger.e("checkReflectAvailable error: ", e);
            return false;
        }
    }

    @NonNull
    public static <VB extends ViewBinding> VB inflate(@NonNull ViewBindingCreator<VB> creator,
                                                      @NonNull LayoutInflater inflater) {
        return inflate(creator, inflater, null, false);
    }

    @NonNull
    public static <VB extends ViewBinding> VB inflate(@NonNull ViewBindingCreator<VB> creator,
                                                      @NonNull LayoutInflater inflater,
                                                      @Nullable ViewGroup parent,
                                                      boolean attachToParent) {
        return inflate(getViewBindingClassFromCreator(creator, true), inflater, parent, attachToParent);
    }

    @NonNull
    public static <VB extends ViewBinding> VB inflate(@NonNull Class<VB> viewBindingClass,
                                                      @NonNull LayoutInflater inflater) {
        return inflate(viewBindingClass, inflater, null, false);
    }

    @NonNull
    @SuppressWarnings("unchecked")
    public static <VB extends ViewBinding> VB inflate(@NonNull Class<VB> viewBindingClass,
                                                      @NonNull LayoutInflater inflater,
                                                      @Nullable ViewGroup parent,
                                                      boolean attachToParent) {
        try {
            Method method = getFullInflateMethodFromClass(viewBindingClass, true);
            return (VB) method.invoke(null, inflater, parent, attachToParent);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException("No static method[" + INFLATE_METHOD_NAME + "] found in ViewBinding class " + viewBindingClass, e);
        }
    }


    @NonNull
    @SuppressWarnings("unchecked")
    static <VB extends ViewBinding> Class<VB> getViewBindingClassFromCreator(@NonNull ViewBindingCreator<VB> creator,
                                                                             boolean canFetchCache) {
        Class<?> creatorClass = creator.getClass();
        Class<VB> vbCls = null;
        if (ENABLE_CACHE && canFetchCache) {
            vbCls = (Class<VB>) sClassCache.get(creatorClass);
            if (vbCls != null) {
                return vbCls;
            }
        }

        Class<?> tempCls = creatorClass;
        while (vbCls == null && tempCls != null) {
            vbCls = getViewBindingClassFromType(tempCls.getGenericSuperclass());
            if (vbCls == null) {
                Type[] types = tempCls.getGenericInterfaces();
                for (Type tempType : types) {
                    vbCls = getViewBindingClassFromType(tempType);
                    if (vbCls != null) {
                        break;
                    }
                }
            }
            tempCls = tempCls.getSuperclass();
        }

        if (vbCls != null) {
            if (Logger.isDebug()) {
                Logger.d("getVBClassFromCreator success creatorClass=" + creatorClass
                        + ", vbCls=" + vbCls.getSimpleName()
                        + "\n    getGenericSuperclass=" + creatorClass.getGenericSuperclass()
                        + ", getGenericInterfaces=" + Arrays.toString(creatorClass.getGenericInterfaces()));
            }
            if (ENABLE_CACHE) {
                sClassCache.put(creatorClass, vbCls);
            }
            return vbCls;
        }

        // Generally not possible
        throw new RuntimeException("No ViewBinding parameter class found in " + creatorClass
                + ", getGenericSuperclass=" + creatorClass.getGenericSuperclass()
                + ", getGenericInterfaces=" + Arrays.toString(creatorClass.getGenericInterfaces()));
    }

    @NonNull
    private static Method getFullInflateMethodFromClass(@NonNull Class<?> viewBindingClass,
                                                        boolean canFetchCache) throws NoSuchMethodException {
        Method method;
        if (ENABLE_CACHE && canFetchCache) {
            method = sMethodCache.get(viewBindingClass);
            if (method != null) {
                return method;
            }
        }

        method = viewBindingClass.getMethod(INFLATE_METHOD_NAME, LayoutInflater.class, ViewGroup.class, boolean.class);
        if (ENABLE_CACHE) {
            sMethodCache.put(viewBindingClass, method);
        }
        return method;
    }

    @SuppressWarnings("unchecked")
    private static <VB extends ViewBinding> Class<VB> getViewBindingClassFromType(Type type) {
        if (type instanceof ParameterizedType) {
            Type[] types = ((ParameterizedType) type).getActualTypeArguments();
            for (Type tempType : types) {
                if (tempType instanceof Class<?>) {
                    Class<?> tempCls = (Class<?>) tempType;
                    if (ViewBinding.class.isAssignableFrom(tempCls)) {
                        return (Class<VB>) tempCls;
                    }
                }
            }
        }
        return null;
    }

}
