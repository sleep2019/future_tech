package com.shopee.sc.common.widget;

import com.chad.library.adapter.base.loadmore.LoadMoreView;
import com.shopee.sc.common.R;

/**
 * Created by honggang.xiong on 2019-08-29.
 */
public class CommonLoadMoreView extends LoadMoreView {

    @Override
    public int getLayoutId() {
        return R.layout.common_layout_load_more;
    }

    @Override
    protected int getLoadingViewId() {
        return R.id.container_load_more_loading;
    }

    @Override
    protected int getLoadFailViewId() {
        return R.id.container_load_more_fail;
    }

    @Override
    protected int getLoadEndViewId() {
        return R.id.container_load_more_end;
    }

}
