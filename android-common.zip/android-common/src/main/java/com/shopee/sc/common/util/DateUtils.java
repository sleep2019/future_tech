package com.shopee.sc.common.util;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.shopee.sc.logger.api.Logger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 * @ClassName: DateUtils
 * @Description: 日期相关的工具类
 * @Author: lanjingzeng
 * @CreateDate: 2020-03-30 17:46
 * @Version: 1.0
 */
public class DateUtils {

    private static final String TAG = "DateUtils";

    public static final int ONE_DAY_SECOND = 24 * 60 * 60;
    public static final int MILLIS_TO_SECOND = 1000;
    public static final int ONE_DAY_MILLISECOND = ONE_DAY_SECOND * 1000;
    public static final long ONE_THOUSAND = 1000;

    public static final int AM_LAST_HOUR = 12;
    public static final int PM_LAST_HOUR = 24;

    public static final long ONE_DAY_SECONDS = TimeUnit.DAYS.toSeconds(1);
    public static final long ONE_DAY_MILLIS = TimeUnit.DAYS.toMillis(1);
    public static final long ONE_HOUR_MILLIS = TimeUnit.HOURS.toMillis(1);

    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String DD_MM_YYYY_SLASH = "dd/MM/yyyy";
    public static final String MM_DD_YYYY_SLASH = "MM/dd/yyyy";
    public static final String YYYY_MM_DD_SLASH = "yyyy/MM/dd";
    public static final String YYYY_POINT_MM_POINT_DD = "yyyy.MM.dd";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYY_MM_DD_POINT = "yyyy.MM.dd";
    public static final String HH_MM_SS_YYYY_MM_DD = "HH:mm:ss yyyy-MM-dd";

    public static final String TIME_ZONE_UTC = "UTC";

    /**
     * SimpleDateFormat不是线程安全的，所以这里采用ThreadLocal来保证每个线程对应一个实例
     */
    public static final ThreadLocal<SimpleDateFormat> FORMAT_YMD = new ThreadLocal<SimpleDateFormat>() {
        @Override
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat(YYYY_MM_DD);
        }
    };
    public static final ThreadLocal<SimpleDateFormat> FORMAT_Y_POINT_M_POINT_D = new ThreadLocal<SimpleDateFormat>() {
        @Override
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat(YYYY_POINT_MM_POINT_DD);
        }
    };
    public static final ThreadLocal<SimpleDateFormat> FORMAT_Y_M_D_H_M_S = new ThreadLocal<SimpleDateFormat>() {
        @Override
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS);
        }
    };

    public static String formatDate(long millisecond, String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return formatDate(millisecond, simpleDateFormat);
    }

    public static String formatDate(long millisecond, SimpleDateFormat simpleDateFormat) {
        String result = "";
        if (millisecond <= 0 || simpleDateFormat == null) {
            return result;
        }
        try {
            result = simpleDateFormat.format(new Date(millisecond));
        } catch (Exception e) {
            Logger.e(TAG, "formatDate() error:" + e.getMessage(), e);
        }
        return result;
    }

    /**
     * 将时间戳格式化为字符串的形式
     *
     * @param time:         单位 秒
     * @param formatPattern 格式
     */
    public static String getDate(long time, String formatPattern) {
        return getDate(time, formatPattern, "");
    }

    /**
     * 将时间戳格式化为字符串的形式
     *
     * @param time:         单位 秒
     * @param formatPattern 格式
     * @param defaultValue  装换失败的默认字符串
     */
    public static String getDate(long time, String formatPattern, String defaultValue) {
        String result = defaultValue;
        if (time <= 0 || formatPattern == null) {
            return result;
        }
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formatPattern, Locale.getDefault());
            result = simpleDateFormat.format(new Date(time * 1000));
        } catch (Exception e) {
            Logger.e(TAG, "getDate() error:" + e.getMessage(), e);
        }
        return result;
    }

    /**
     * 取得当前系统时间（精确到秒）
     *
     * @return
     */
    public static int getCurrentSystemTime() {
        return (int) (System.currentTimeMillis() / 1000);
    }

    /**
     * 根据传入的时间（秒）得出对应那一天开始时间和结束时间
     *
     * @param second
     * @return
     * @throws ParseException
     */
    public static Date[] getStartEndTime(int second) {
        String dateStr = formatDate((long) second * MILLIS_TO_SECOND, FORMAT_YMD.get());
        if (TextUtils.isEmpty(dateStr)) {
            return null;
        }
        try {
            Date start = FORMAT_Y_M_D_H_M_S.get().parse(dateStr + " 00:00:00");
            Date end = FORMAT_Y_M_D_H_M_S.get().parse(dateStr + " 23:59:59");
            Date[] dateArr = new Date[]{start, end};
            return dateArr;
        } catch (ParseException e) {
        }
        return null;
    }

    public static int getSecondTime(Date date) {
        if (date == null) {
            return 0;
        }
        int t = (int) (date.getTime() / 1000);
        return t;
    }

    /**
     * 把时间转成UTC时间，精度只取到天
     *
     * @param dateStr 时间
     * @return UTC时间
     */
    public static long getUTCDaySecond(String dateStr) {
        if (TextUtils.isEmpty(dateStr)) {
            return 0;
        }
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD, Locale.getDefault());
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_UTC));
            Date date = simpleDateFormat.parse(dateStr);
            if (date != null) {
                return date.getTime() / 1000; // 转成秒
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 获取当前时间戳，精度只取到天，单位秒
     *
     * @return 当前当前时间戳
     */
    public static long getCurDayTimeSecond() {
        long time = System.currentTimeMillis() / 1000;
        time = time - time % ONE_DAY_SECOND;
        return time;
    }

    /**
     * 把天数转成秒
     *
     * @param dayCount 天数
     * @return 制定天数有多少秒
     */
    public static long day2Second(int dayCount) {
        if (dayCount <= 0) {
            return 0;
        }
        return ((long) dayCount) * ONE_DAY_SECOND;
    }

    /**
     * 把天数转成秒
     *
     * @param timeSecond 天数
     * @return 制定天数有多少秒
     */
    public static int second2Day(long timeSecond) {
        if (timeSecond <= 0) {
            return 0;
        }
        return (int) (timeSecond / ONE_DAY_SECOND);
    }

    /**
     * 获取当前年份
     *
     * @return 当前年份
     */
    public static int getCurYear() {
        return getYear(System.currentTimeMillis());
    }

    public static int getYear(long date) {
        if (date <= 0) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(date);
        return calendar.get(Calendar.YEAR);
    }

    public static long getCurrentTimeSecond() {
        return System.currentTimeMillis() / MILLIS_TO_SECOND;
    }


    // eg: 1 -> "01:00 - 02:00"
    public static String getOneHourString(int hourOfDay) {
        if (hourOfDay < 0 || hourOfDay >= 24) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        if (hourOfDay < 10) {
            builder.append('0');
        }
        builder.append(hourOfDay).append(":00  -  ");
        hourOfDay++;
        if (hourOfDay < 10) {
            builder.append('0');
        }
        builder.append(hourOfDay).append(":00");
        return builder.toString();
    }

    public static boolean isPeriodContainToday(long startMillis, long endMillis) {
        if (startMillis > endMillis) {
            long temp = startMillis;
            startMillis = endMillis;
            endMillis = temp;
        }

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        long todayStart = calendar.getTimeInMillis();
        return endMillis >= todayStart && startMillis < (todayStart + TimeUnit.DAYS.toMillis(1));
    }

    public static boolean isToday(long timeMillis) {
        return isSameDay(System.currentTimeMillis(), timeMillis);
    }

    public static boolean isSameDay(long millis1, long millis2) {
        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        calendar1.setTimeInMillis(millis1);
        calendar2.setTimeInMillis(millis2);
        return isSameDay(calendar1, calendar2);
    }

    public static boolean isSameDay(@NonNull Calendar calendar1, @NonNull Calendar calendar2) {
        return calendar1.get(Calendar.DAY_OF_MONTH) == calendar2.get(Calendar.DAY_OF_MONTH)
                && calendar1.get(Calendar.MONTH) == calendar2.get(Calendar.MONTH)
                && calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR);
    }

    public static boolean isSameMonth(long millis1, long millis2) {
        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        calendar1.setTimeInMillis(millis1);
        calendar2.setTimeInMillis(millis2);
        return isSameMonth(calendar1, calendar2);
    }

    public static boolean isSameMonth(@NonNull Calendar calendar1, @NonNull Calendar calendar2) {
        return calendar1.get(Calendar.MONTH) == calendar2.get(Calendar.MONTH);
    }

    public static boolean isSameYear(@NonNull Calendar calendar1, @NonNull Calendar calendar2) {
        return calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR);
    }

    /**
     * 获取用 int 值表示的日期，eg: 20210408
     *
     * @param timestamp 秒级时间戳
     */
    public static int getDayInShort(long timestamp) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timestamp * 1000);
        return calendar.get(Calendar.YEAR) * 10000 + (calendar.get(Calendar.MONTH) + 1) * 100 + calendar.get(Calendar.DAY_OF_MONTH);
    }

    public static long getDateDistance(long startTimeStamp, long endTimeStamp) {
        return TimeUnit.MILLISECONDS.toDays(Math.max(endTimeStamp - startTimeStamp, 0));
    }

}
