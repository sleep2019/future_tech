package com.shopee.sc.common.widget.adapter.viewbinding;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;

import com.chad.library.adapter.base.BaseViewHolder;

/**
 * Created by honggang.xiong on 2021/3/29.
 */
public class ViewBindingViewHolder<VB extends ViewBinding> extends BaseViewHolder {

    private final VB mViewBinding;

    public ViewBindingViewHolder(@NonNull View view) {
        this(view, null);
    }

    public ViewBindingViewHolder(@NonNull View view, @Nullable VB viewBinding) {
        super(view);
        this.mViewBinding = viewBinding;
    }

    @Nullable
    public VB getViewBinding() {
        return mViewBinding;
    }

}
