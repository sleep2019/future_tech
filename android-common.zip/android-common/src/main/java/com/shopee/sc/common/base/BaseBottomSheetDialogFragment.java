package com.shopee.sc.common.base;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.IdRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.shopee.sc.common.R;
import com.shopee.sc.common.network.NetCache;

public abstract class BaseBottomSheetDialogFragment extends BottomSheetDialogFragment {
    private BottomSheetBehavior<FrameLayout> mBehavior;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        return inflater.inflate(contentViewId(), container, false);
    }

    /**
     * return fragment layout id
     */
    @LayoutRes
    protected abstract int contentViewId();

    @Override
    public void onStart() {
        super.onStart();
        if (isDialogExpanded() && getDialog() instanceof BottomSheetDialog) {
            BottomSheetDialog dialog = (BottomSheetDialog) getDialog();
            FrameLayout bottomSheet = dialog.getDelegate().findViewById(R.id.design_bottom_sheet);
            if (bottomSheet != null && bottomSheet.getLayoutParams() instanceof CoordinatorLayout.LayoutParams) {
                mBehavior = BottomSheetBehavior.from(bottomSheet);
                // 初始为展开状态
                mBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                mBehavior.setHideable(isHideable());
            }
        }
    }

    protected boolean isDialogExpanded() {
        return false;
    }

    protected boolean isHideable() {
        return true;
    }

    @Override
    public void show(@NonNull FragmentManager manager, @Nullable String tag) {
        try {
            super.show(manager, tag);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int show(@NonNull FragmentTransaction transaction, @Nullable String tag) {
        try {
            return super.show(transaction, tag);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public void showNow(@NonNull FragmentManager manager, @Nullable String tag) {
        try {
            super.showNow(manager, tag);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Cancel all requests in dialog fragment
        NetCache.getInstance().cancel(this);
    }

    @SuppressWarnings("unchecked")
    protected <T extends View> T findViewById(@IdRes int id) {
        if (getView() == null) {
            return null;
        }
        return (T) (getView().findViewById(id));
    }

}
