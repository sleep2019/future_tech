package com.shopee.sc.common.viewbinding;

import androidx.viewbinding.ViewBinding;

/**
 * View Binding Owner，VB 对象由 {@link ViewBindingCreator} 创建后传入 {@link ViewBindingOwner}。
 *
 * 一般 Activity、Fragment 同时为 creator 及 owner；Adapter 为 creator，泛型 ViewHolder 为 owner。
 *
 * Created by honggang.xiong on 2021/3/23.
 */
public interface ViewBindingOwner<VB extends ViewBinding> {

    /**
     * 初始化后返回非空
     */
    VB getViewBinding();

    /**
     * 简短方法
     */
    default VB vb() {
        return getViewBinding();
    }

}
