package com.shopee.sc.common.widget.dropdown;

import android.view.View;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * 下拉触发view定义，view需设置多背景
 * 点击view时展示一个背景，在下拉选中后view展示其他背景
 *
 * @author zhi.xiao
 * @since 2021-10-26
 */
public class DropDownMultiBgTrigger extends CheckBoxDropDownTrigger {
    private final View mBgCheckBox;

    private int mClickDrawable;

    public DropDownMultiBgTrigger(@NonNull CheckBox checkBox) {
        this(checkBox, null);
    }

    public DropDownMultiBgTrigger(@NonNull CheckBox checkBox, @Nullable View bgCheckBox) {
        super(checkBox, bgCheckBox);
        mBgCheckBox = bgCheckBox;
    }

    public DropDownMultiBgTrigger(@NonNull CheckBox checkBox, @Nullable View bgCheckBox, int clickDrawable) {
        super(checkBox, bgCheckBox);
        mBgCheckBox = bgCheckBox;
        mClickDrawable = clickDrawable;
    }

    @Override
    public void setChecked(boolean isChecked) {
        super.setChecked(isChecked);
        if (isChecked && mBgCheckBox != null) {
            mBgCheckBox.setBackgroundResource(mClickDrawable);
        }
    }
}