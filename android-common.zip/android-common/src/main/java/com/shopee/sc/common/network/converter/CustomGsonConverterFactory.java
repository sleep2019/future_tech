package com.shopee.sc.common.network.converter;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Objects;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Retrofit;

/**
 * Created by chris on 2019-10-11.
 */
public class CustomGsonConverterFactory extends Converter.Factory {

    private final Gson mGson;
    private final Integer mNetCodeLimitedAccount;
    private final Integer mNetCodeNotLogin;

    public static CustomGsonConverterFactory create() {
        return create(new Gson());
    }

    public static CustomGsonConverterFactory create(@NonNull Gson gson) {
        return create(gson, null, null);
    }

    /**
     * 创建一个 CustomGsonConverterFactory
     *
     * @param gson                  Gson
     * @param netCodeLimitedAccount 限制账号错误码，为空则不检测
     * @param netCodeNotLogin       未登陆错误码，为空则不检测
     */
    public static CustomGsonConverterFactory create(@NonNull Gson gson, Integer netCodeLimitedAccount,
                                                    Integer netCodeNotLogin) {
        return new CustomGsonConverterFactory(gson, netCodeLimitedAccount, netCodeNotLogin);
    }

    private CustomGsonConverterFactory(@NonNull Gson gson, Integer netCodeLimitedAccount,
                                       Integer netCodeNotLogin) {
        mGson = Objects.requireNonNull(gson, "Gson is null");
        mNetCodeLimitedAccount = netCodeLimitedAccount;
        mNetCodeNotLogin = netCodeNotLogin;
    }

    @Override
    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations,
                                                            Retrofit retrofit) {
        TypeAdapter<?> adapter = mGson.getAdapter(TypeToken.get(type));
        return new CustomGsonResponseBodyConverter<>(mGson, adapter, mNetCodeLimitedAccount,
                mNetCodeNotLogin);
    }

    @Override
    public Converter<?, RequestBody> requestBodyConverter(Type type,
                                                          Annotation[] parameterAnnotations,
                                                          Annotation[] methodAnnotations,
                                                          Retrofit retrofit) {
        TypeAdapter<?> adapter = mGson.getAdapter(TypeToken.get(type));
        return new CustomGsonRequestBodyConverter<>(mGson, adapter);
    }
}
