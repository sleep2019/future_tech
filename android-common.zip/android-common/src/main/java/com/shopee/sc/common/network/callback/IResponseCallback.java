package com.shopee.sc.common.network.callback;

import com.shopee.sc.common.bean.Result;

/**
 * 服务器数据返回接口
 */
public interface IResponseCallback<T> {

    /**
     * 服务器数据，refresh是为了兼容有分页加载的页面和无分页加载的页面
     */
    void showResult(Result<T> result, Object obj, boolean success, String errorMsg, boolean refresh, Object... params);

}
