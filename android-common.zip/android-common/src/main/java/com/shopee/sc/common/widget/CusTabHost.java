package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TabHost;

public class CusTabHost extends TabHost {
    public CusTabHost(Context context) {
        super(context);
    }

    public CusTabHost(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CusTabHost(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
