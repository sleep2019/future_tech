package com.shopee.sc.common.util;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;

import com.shopee.sc.common.R;
import com.shopee.sc.logger.api.Logger;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;

/**
 * Created by heroxiong on 2018/3/19.
 */
public class UiUtils {

    private static final int MAX_SINGLE_LINE_LENGTH = 40;

    public static DisplayMetrics getDisplayMetrics() {
        return Resources.getSystem().getDisplayMetrics();
    }

    public static int getScreenWidth() {
        return getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return getDisplayMetrics().heightPixels;
    }

    public static int getStatusBarHeight(Context context) {
        int statusBarHeight = -1;
        try {
            int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                statusBarHeight = context.getResources().getDimensionPixelSize(resourceId);
            }
        } catch (Exception e) {
            Logger.e("getStatusBarHeight error " + e);
        }
        return statusBarHeight;
    }

    /**
     * dp转换成px
     */
    public static int dp2px(Context context, float dpValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * px转换成dp
     */
    public static int px2dp(Context context, float pxValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    /**
     * sp转换成px
     */
    public static int sp2px(Context context, float spValue) {
        float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }

    /**
     * px转换成sp
     */
    public static int px2sp(Context context, float pxValue) {
        float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (pxValue / fontScale + 0.5f);
    }

    /**
     * 设置字符串颜色
     */
    public static SpannableString getFuzzyColor(@NonNull String whole, @Nullable String part) {
        SpannableString spannableString = new SpannableString(whole);
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(Color.parseColor("#EE4D2D"));
        spannableString.setSpan(colorSpan, 0, part.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        return spannableString;
    }


    /**
     * Get the screen size of current window
     *
     * @param context Activity context return activity window size, Application context return system window size
     * @return the screen size of current window
     */
    public static Point getScreenSize(Context context) {
        final DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return new Point(metrics.widthPixels, metrics.heightPixels);
    }

    /**
     * Get the screen size of device in current orientation
     *
     * @return the device's screen size
     */
    public static Point getDeviceScreenSize(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point point = new Point();
        display.getRealSize(point);
        return point;
    }

    public static void captureImage(@NonNull Activity activity, @NonNull File targetFile, int requestCode) {
        AppUtils.captureImage(activity, targetFile, requestCode);
    }

    public static Bitmap loadAndCompressBitmap(Context context, int resId, int fraction) {
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = fraction;
        return BitmapFactory.decodeResource(context.getResources(), resId, opt);
    }

    public static Activity getActivityFromView(View view) {
        if (view != null) {
            Context context = view.getContext();
            while (context instanceof ContextWrapper) {
                if (context instanceof Activity) {
                    return (Activity) context;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        return null;
    }

    public static void transparentStatusBar(Activity activity, boolean isLayoutFullscreen) {
        if (isLayoutFullscreen) {
            activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setStatusBarColor(activity, Color.TRANSPARENT);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    public static void setStatusBarColor(Activity activity, @ColorInt int color) {
        Window window = activity.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(color);
    }

    @RequiresApi(Build.VERSION_CODES.M)
    public static void setStatusBarLightModeCompat(Activity activity) {
        activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setStatusBarLightModeInMIUI(activity, true);
    }

    @RequiresApi(Build.VERSION_CODES.M)
    public static void setStatusBarLightModeCompatWithPreVisibility(Activity activity) {
        int visibility = activity.getWindow().getDecorView().getSystemUiVisibility();
        activity.getWindow().getDecorView().setSystemUiVisibility(visibility | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setStatusBarLightModeInMIUI(activity, true);
    }

    private static void setStatusBarLightModeInMIUI(Activity activity, boolean isLightMode) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O && "Xiaomi".equalsIgnoreCase(Build.BRAND)) {
            Window window = activity.getWindow();
            try {
                int lightModeFlag = 0;
                Class layoutParamsClass = Class.forName("android.view.MiuiWindowManager$LayoutParams");
                Field field = layoutParamsClass.getField("EXTRA_FLAG_STATUS_BAR_DARK_MODE");
                lightModeFlag = field.getInt(layoutParamsClass);
                Method setFlagMethod = window.getClass().getMethod("setExtraFlags", int.class, int.class);
                if (isLightMode) {
                    setFlagMethod.invoke(window, lightModeFlag, lightModeFlag);
                } else {
                    setFlagMethod.invoke(window, 0, lightModeFlag);
                }
            } catch (Exception e) {
                // ignore
            }
        }
    }

    /**
     * 按比例缩放图片
     *
     * @param origin 原图
     * @param ratio  缩放比例
     * @return 新的bitmap
     */
    static Bitmap scaleBitmap(Bitmap origin, float ratio) {
        if (origin == null || ratio == 1.0F) {
            return origin;
        }
        int width = origin.getWidth();
        int height = origin.getHeight();
        Matrix matrix = new Matrix();
        matrix.preScale(ratio, ratio);
        Bitmap newBitmap = Bitmap.createBitmap(origin, 0, 0, width, height, matrix, false);
        if (newBitmap.equals(origin)) {
            return newBitmap;
        }
        Logger.i("scaleBitmap origin width=" + origin.getWidth() + ", new width=" + newBitmap.getWidth() + ", ratio=" + ratio);
        origin.recycle();
        return newBitmap;
    }

    public static void showKeyboard(@NonNull EditText editText) {
        InputMethodManager imm = (InputMethodManager) editText.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(editText, 0);
        }
    }

    public static void hideKeyboard(@NonNull EditText editText) {
        InputMethodManager imm = (InputMethodManager) editText.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
    }

    public static void showSoftKeyBoard(@NonNull View view) {
        KeyBoradUtils.showSoftKeyBoard(view);
    }

    public static void hideSoftKeyBoard(@NonNull View view) {
        KeyBoradUtils.hideSoftKeyBoard(view);
    }

    /**
     * 获取 {@link android.widget.PopupWindow#showAtLocation(View, int, int, int)} 时，PopupWindow
     * 需置于目标 View 正下方的 offsetY
     *
     * @param anchor 目标 View
     * @return offsetY
     */
    public static int getPopupOffsetYBelowAnchor(View anchor) {
        if (anchor == null) {
            return 0;
        }

        return getPopupAnchorY(anchor) + anchor.getHeight();
    }

    /**
     * 获取 {@link android.widget.PopupWindow#showAtLocation(View, int, int, int)} 时，PopupWindow
     * 需和目标 View 垂直中心对齐的 offsetY，PopupWindow 高度需已知
     *
     * @param anchor      目标 View
     * @param popupHeight PopupWindow 高度
     * @return offsetY
     */
    public static int getPopupOffsetYAlignAnchorCenter(View anchor, int popupHeight) {
        if (anchor == null) {
            return 0;
        }

        return getPopupAnchorY(anchor) + (anchor.getHeight() - popupHeight) / 2;
    }

    public static int getPopupAnchorY(@NonNull View anchor) {
        int[] temp = new int[2];
        anchor.getRootView().getLocationOnScreen(temp);
        int rootY = temp[1];
        anchor.getLocationOnScreen(temp);
        return temp[1] - rootY;
    }

    public static int getAnchorY(@NonNull View anchor) {
        int[] temp = new int[2];
        anchor.getLocationOnScreen(temp);
        return temp[1];
    }

    public static void showTextIfNotNull(@NonNull TextView textView, @Nullable String text) {
        if (TextUtils.isEmpty(text)) {
            textView.setVisibility(View.GONE);
        } else {
            textView.setVisibility(View.VISIBLE);
            textView.setText(text);
        }
    }

    public static void showTextIfNotZero(@NonNull TextView textView, @StringRes int stringRes) {
        if (stringRes == 0) {
            textView.setVisibility(View.GONE);
        } else {
            textView.setVisibility(View.VISIBLE);
            textView.setText(stringRes);
        }
    }

    public static void highlightTextView(@NonNull TextView textView, String text, String searchKey) {
        highlightTextView(textView, text, searchKey, ContextCompat.getColor(textView.getContext(), R.color.common_orange_brand));
    }

    public static void highlightTextView(@NonNull TextView textView, String text, String searchKey, @ColorInt int color) {
        int index;
        if (!TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(text)
                && (index = text.toLowerCase().indexOf(searchKey.toLowerCase())) >= 0
                && index + searchKey.length() <= text.length()) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            textView.setText(spannable);
        } else {
            textView.setText(text);
        }
    }

    public static void highlightTextView(@NonNull TextView textView, String text, String searchKey, @ColorInt int color,
                                         int style) {
        int index;
        if (!TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(text)
                && (index = text.toLowerCase().indexOf(searchKey.toLowerCase())) >= 0
                && index + searchKey.length() <= text.length()) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannable.setSpan(new StyleSpan(style), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            textView.setText(spannable);
        } else {
            textView.setText(text);
        }
    }

    // 高亮 TextView，原文本超长时做省略号处理
    public static void highlightTextViewWithEllipsis(@NonNull TextView textView, String text, String searchKey,
                                                     boolean highlightSearchKey) {
        highlightTextViewWithEllipsis(textView, text, searchKey, highlightSearchKey, MAX_SINGLE_LINE_LENGTH);
    }

    public static void highlightTextViewWithEllipsis(@NonNull TextView textView, String text, String searchKey,
                                                     boolean highlightSearchKey, int maxSingleLineLength) {
        int index;
        if (highlightSearchKey && !TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(text)
                && (index = text.toLowerCase().indexOf(searchKey.toLowerCase())) >= 0
                && index + searchKey.length() <= text.length()) {
            if (text.length() <= maxSingleLineLength) {
                SpannableString spannable = new SpannableString(text);
                int color = ContextCompat.getColor(textView.getContext(), R.color.common_orange_brand);
                spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                textView.setText(spannable);
            } else {
                int startIndex = index;
                int tempIndex;
                String prefixString = text.substring(0, startIndex);
                if ((tempIndex = prefixString.lastIndexOf(" ")) >= 0) {
                    startIndex = tempIndex;
                    prefixString = text.substring(0, startIndex);
                    if ((tempIndex = prefixString.lastIndexOf(" ", startIndex)) >= 0) {
                        startIndex = tempIndex;
                    } else {
                        startIndex = 0;
                    }
                }
                String newText = text.substring(startIndex);
                if (startIndex > 0) {
                    newText = "…" + newText;
                }
                SpannableString spannable = new SpannableString(newText);
                index = newText.toLowerCase().indexOf(searchKey.toLowerCase());
                int color = ContextCompat.getColor(textView.getContext(), R.color.common_orange_brand);
                spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                textView.setText(spannable);
            }
        } else {
            textView.setText(text);
        }
    }

    public static void boldTextView(@NonNull TextView textView, String text, String... searchKey) {
        SpannableString spannable = new SpannableString(text);
        if (searchKey != null && searchKey.length > 0 && !TextUtils.isEmpty(text)) {
            for (String key : searchKey) {
                int index = text.indexOf(key);
                if (index >= 0) {
                    spannable.setSpan(new StyleSpan(Typeface.BOLD), index, index + key.length(),
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        }

        textView.setText(spannable);
    }

    /**
     * 对某段字体放大
     *
     * @param size 单位为dp
     */
    public static void scaleHighlightTextView(@NonNull TextView textView, String text,
                                              String searchKey, int size, int color) {
        int index;
        if (!TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(text) && (index = text.indexOf(searchKey)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new AbsoluteSizeSpan(size, true), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            textView.setText(spannable);
        } else {
            textView.setText(text);
        }
    }

    public static CharSequence getHighlightText(String text, String subText, @ColorInt int color) {
        return getHighlightText(text, subText, color, -1);
    }

    public static CharSequence getHighlightText(String text, String subText, @ColorInt int color,
                                                int sizeInPx) {
        return getHighlightText(text, subText, color, sizeInPx, -1);
    }

    public static CharSequence getHighlightText(String text, String subText, @ColorInt int color,
                                                int sizeInPx, int style) {
        int index;
        if (!TextUtils.isEmpty(text) && !TextUtils.isEmpty(subText) && (index = text.indexOf(subText)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new ForegroundColorSpan(color), index, index + subText.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (sizeInPx > -1) {
                spannable.setSpan(new AbsoluteSizeSpan(sizeInPx), index, index + subText.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (style > -1) {
                spannable.setSpan(new StyleSpan(style), index, index + subText.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            return spannable;
        } else {
            return text;
        }
    }

    public static CharSequence getHighlightAllText(final String text, final String subText, final @ColorInt int color) {
        int index;
        if (!TextUtils.isEmpty(text) && !TextUtils.isEmpty(subText) && (index = text.indexOf(subText)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            while (index >= 0) {
                spannable.setSpan(new ForegroundColorSpan(color), index, index + subText.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                index = text.indexOf(subText, index + subText.length());
            }
            return spannable;
        } else {
            return text;
        }
    }

    public static CharSequence getClickableText(String text, String subText, @ColorInt int color,
                                                boolean showUnderline, @Nullable View.OnClickListener onClickListener) {
        int index;
        if (!TextUtils.isEmpty(text) && !TextUtils.isEmpty(subText) && (index = text.indexOf(subText)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new SimpleClickableSpan(color, showUnderline, onClickListener),
                    index, index + subText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            return spannable;
        } else {
            return text;
        }
    }


    public static class SimpleClickableSpan extends ClickableSpan {

        private final int mColorInt;
        private final boolean mShowUnderline;
        private final View.OnClickListener mOnClickListener;

        public SimpleClickableSpan(@ColorInt int colorInt, boolean showUnderline,
                                   @Nullable View.OnClickListener onClickListener) {
            mColorInt = colorInt;
            mShowUnderline = showUnderline;
            mOnClickListener = onClickListener;
        }

        @Override
        public void onClick(@NonNull View widget) {
            if (mOnClickListener != null) {
                mOnClickListener.onClick(widget);
            }
        }

        @Override
        public void updateDrawState(@NonNull TextPaint ds) {
            ds.setColor(mColorInt);
            ds.setUnderlineText(mShowUnderline);
        }
    }

    /**
     * 给imageView 的svg初始化颜色
     */
    public static Drawable initSvgColor(Context context, int imgRes, @ColorInt int tint) {
        //利用ContextCompat工具类获取drawable图片资源
        Drawable drawable = ContextCompat.getDrawable(context, imgRes);
        //简单的使用tint改变drawable颜色
        DrawableCompat.wrap(drawable).mutate();
        DrawableCompat.setTint(drawable, tint);
        return drawable;
    }

    /**
     * 给标题栏控件动态增加paddingTop
     */
    public static void fitTitleBar(Activity activity, final View titleBar) {
        transparentStatusBar(activity, true);
        final ViewGroup.LayoutParams layoutParams = titleBar.getLayoutParams();
        int statusBarHeight = getStatusBarHeight(activity);
        if (layoutParams.height == ViewGroup.LayoutParams.WRAP_CONTENT ||
                layoutParams.height == ViewGroup.LayoutParams.MATCH_PARENT) {
            titleBar.post(new Runnable() {
                @Override
                public void run() {
                    layoutParams.height = titleBar.getHeight() + statusBarHeight;
                    titleBar.setPadding(titleBar.getPaddingLeft(),
                            titleBar.getPaddingTop() + statusBarHeight,
                            titleBar.getPaddingRight(),
                            titleBar.getPaddingBottom());
                }
            });
        } else {
            layoutParams.height += statusBarHeight;
            titleBar.setPadding(titleBar.getPaddingLeft(),
                    titleBar.getPaddingTop() + statusBarHeight,
                    titleBar.getPaddingRight(),
                    titleBar.getPaddingBottom());
        }
    }

    /**
     * 设置textView长度，如果超过view宽度，截断
     *
     * @param textView       控件
     * @param textViewLength textview最大长度
     * @param originText     字符串长度
     * @param specialString  截断标识字符串
     */
    public static void dealTextLength(@NonNull TextView textView, float textViewLength, String originText, String specialString) {
        float originTextWidth = textView.getPaint().measureText(originText);

        //控件长度大于文字长度 直接显示
        if (textViewLength >= originTextWidth) {
            textView.setText(originText);
        } else {
            //获取指定省略位置 "("
            int lastIndexOfPoint = originText.lastIndexOf(specialString);
            if (lastIndexOfPoint == -1) {
                //找不到 直接显示
                textView.setText(originText);
            } else {
                //找到了 对字符串切分
                String prefixText = originText.substring(0, lastIndexOfPoint);
                String suffixText = "..." + originText.substring(lastIndexOfPoint, originText.length());

                float prefixWidth = textView.getPaint().measureText(prefixText);
                float suffixWidth = textView.getPaint().measureText(suffixText);

                //后缀太长 不处理
                if (suffixWidth > textViewLength) {
                    textView.setText(originText);
                } else {
                    //每减少前缀一个字符都去判断是否能塞满控件
                    while (textViewLength - prefixWidth < suffixWidth && !prefixText.isEmpty()) {
                        prefixText = prefixText.substring(0, prefixText.length() - 1);
                        prefixWidth = textView.getPaint().measureText(prefixText);
                    }
                    //能塞满
                    String resultText = prefixText + suffixText;
                    textView.setText(resultText);
                }
            }
        }
    }

    public static int getDimensionFromResourceInDp(@NonNull Context context, int resourceId) {
        return UiUtils.px2dp(context, context.getResources().getDimension(resourceId));
    }

    /**
     * view颜色渐变动画设置
     *
     * @param view 设置渐变动画view对象
     * @param startColor 开始颜色
     * @param endColor 结束颜色
     * @param duration 动画时长
     */
    public static void startAnimation(@NonNull View view, int startColor, int endColor, long duration) {
        // 创建动画,这里的关键就是使用ArgbEvaluator, 后面2个参数就是 开始的颜色,和结束的颜色.
        ValueAnimator colorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), startColor, endColor);
        colorAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int color = (int) animation.getAnimatedValue();
                view.setBackgroundColor(color);
            }
        });
        colorAnimator.setDuration(duration);
        colorAnimator.start();
    }

    public static int px2dp(float pxValue) {
        return px2dp(AppUtils.getContext(), pxValue);
    }

    public static int dp2px(float dpValue) {
        return dp2px(AppUtils.getContext(), dpValue);
    }

    public static int px2sp(float pxValue) {
        return px2sp(AppUtils.getContext(), pxValue);
    }

    public static int sp2px(float spValue) {
        return sp2px(AppUtils.getContext(), spValue);
    }

    /**
     * 通过Context跳转页面
     */
    public static void startActivity(Context context, Intent intent) {
        startActivity(context, intent, false);
    }

    /**
     * 通过Context跳转页面
     */
    public static void startActivity(Context context, Intent intent, boolean finish) {
        startActivity(context, intent, -1, finish);
    }

    /**
     * 通过Context跳转页面
     */
    public static void startActivity(Context context, Intent intent, int reqCode) {
        startActivity(context, intent, reqCode, false);
    }

    /**
     * 通过Context跳转页面
     */
    private static void startActivity(Context context, Intent intent, int reqCode, boolean finish) {
        if (context == null || intent == null) {
            return;
        }
        //android 9.0增加的限制：如果是非Activity启动新页面，需要增加flag:FLAG_ACTIVITY_NEW_TASK
        if (!(context instanceof Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        if (reqCode == -1) {
            context.startActivity(intent);
            if (finish) {
                if (!(context instanceof Activity)) {
                    return;
                }
                ((Activity) context).finish();
            }
        } else {
            if (context instanceof Activity) {
                ((Activity) context).startActivityForResult(intent, reqCode);
            }
        }
    }

    /**
     * 通过fragment跳转页面
     */
    public static void startActivity(Fragment fragment, Intent intent, int reqCode) {
        startActivity(fragment, intent, reqCode, false);
    }

    /**
     * 通过fragment跳转页面
     */
    public static void startActivity(Fragment fragment, Intent intent, int reqCode, boolean finish) {
        if (fragment == null || intent == null) {
            return;
        }
        Activity activity = fragment.getActivity();
        //android 9.0增加的限制：如果是非Activity启动新页面，需要增加flag:FLAG_ACTIVITY_NEW_TASK
        if (activity == null) {
            return;
        }
        if (reqCode == -1) {
            activity.startActivity(intent);
            if (finish) {
                activity.finish();
            }
        } else {
            fragment.startActivityForResult(intent, reqCode);
        }
    }

    public static void setText(TextView tv, CharSequence text, String defaultStr) {
        setText(tv, text, defaultStr, View.GONE);
    }

    public static void setText(TextView tv, CharSequence text, String defaultStr, int visibility) {
        if (TextUtils.isEmpty(text)) {
            text = defaultStr;
        }
        if (TextUtils.isEmpty(text)) {
            tv.setVisibility(visibility);
        } else {
            tv.setText(text);
            tv.setVisibility(View.VISIBLE);
        }
    }

    public static void setText(View view, int idRes, String text, String defaultStr) {
        if (view == null) {
            return;
        }
        TextView tv = (TextView) view.findViewById(idRes);
        if (tv == null) {
            return;
        }
        text = text == null ? defaultStr : text;
        tv.setText(text);
    }

    /**
     * 获取以特定颜色显示部分文字的Spanned，用于显示
     *
     * @param titles           需要拼接的文字信息
     * @param needFormatColors 对应的title是否需要使用指定颜色显示
     * @param htmlColorFormat  指定需要特殊显示的颜色 格式为：<font color='#FF514B'>%1$s</font>,如果传null指使用默认的<font color='#FF2B35'>%1$s</font> 即默认红色
     * @return 可用于显示的Spanned
     */
    public static Spanned getColorFormatStr(String[] titles, boolean[] needFormatColors, String htmlColorFormat) {
        return getColorFormatStr(null, titles, needFormatColors, htmlColorFormat);
    }

    /**
     * 获取以特定颜色显示部分文字的Spanned，用于显示
     *
     * @param stringBuilder    可传null，adapter使用时为了避免内存抖动可传入StringBuilder，避免方法内部自己创建实例
     * @param titles           需要拼接的文字信息
     * @param needFormatColors 对应的title是否需要使用指定颜色显示
     * @param htmlColorFormat  指定需要特殊显示的颜色 格式为：<font color='#FF514B'>%1$s</font> 如果传null指使用默认的<font color='#FF2B35'>%1$s</font> 即默认红色
     * @return 可用于显示的Spanned
     */
    public static Spanned getColorFormatStr(StringBuilder stringBuilder, String[] titles, boolean[] needFormatColors, String htmlColorFormat) {
        return getColorFormatStr(stringBuilder, titles, needFormatColors, " ", htmlColorFormat);
    }

    /**
     * 获取以特定颜色显示部分文字的Spanned，用于显示
     *
     * @param stringBuilder    可传null，adapter使用时为了避免内存抖动可传入StringBuilder，避免方法内部自己创建实例
     * @param titles           需要拼接的文字信息
     * @param needFormatColors 对应的title是否需要使用指定颜色显示
     * @param interval         分隔符
     * @param htmlColorFormat  指定需要特殊显示的颜色 格式为：<font color='#FF514B'>%1$s</font> 如果传null指使用默认的<font color='#FF2B35'>%1$s</font> 即默认红色
     * @return 可用于显示的Spanned
     */
    public static Spanned getColorFormatStr(StringBuilder stringBuilder, String[] titles, boolean[] needFormatColors, String interval, String htmlColorFormat) {
        if (stringBuilder == null) {
            stringBuilder = new StringBuilder();
        }
        if (TextUtils.isEmpty(htmlColorFormat)) {
            htmlColorFormat = "<font color='#FF2B35'>%1$s</font>";
        }

        if (titles == null || needFormatColors == null || titles.length != needFormatColors.length) {
            return Html.fromHtml(stringBuilder.toString());
        }
        int length = titles.length;
        for (int i = 0; i < length; i++) {
            if (TextUtils.isEmpty(titles[i])) {
                continue;
            }
            if (!TextUtils.isEmpty(stringBuilder.toString())) {
                stringBuilder.append(interval);
            }

            if (needFormatColors[i]) {
                stringBuilder.append(String.format(htmlColorFormat, titles[i]));
            } else {
                stringBuilder.append(titles[i]);
            }
        }
        //将字符长中的"\n"换成"<br />"，这样换行才会有效，否则经过Html转换格式后\n将会被忽略无法换行
        return Html.fromHtml(stringBuilder.toString().replace("\n", "<br />"));
    }

    public static <T> T getFirstItem(List<T> list) {
        T first = null;
        int size = list == null ? 0 : list.size();
        if (size > 0) {
            first = list.get(0);
        }
        return first;
    }

    /**
     * 当有焦点的时候强制隐藏软键盘
     */
    public static void hideSystemInputWhenHasFocus(Activity context) {
        if (null != context && null != context.getCurrentFocus()) {
            ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow
                    (context.getCurrentFocus().getWindowToken(), 0);
        }
    }

    public static void setTextView(TextView tv, Typeface typeface, @ColorInt int textColor, int textSizeUnit, float textSize, String text) {
        if (tv == null) {
            return;
        }
        if (typeface != null) {
            tv.setTypeface(typeface);
        }
        if (textColor != -1) {
            tv.setTextColor(textColor);
        }
        if (textSize != -1 && textSizeUnit != -1) {
            tv.setTextSize(textSizeUnit, textSize);
        }
        tv.setText(text);
    }


}
