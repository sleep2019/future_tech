package com.shopee.sc.common.monitor;

public class NetObserver implements NetMonitorManagers.INetObserver {
    @Override
    public void netChange(@NetTypes int netType) {
        //开始离线任务
    }
}
