package com.shopee.sc.common.bean;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-05-28.
 */
public class CheckedItem<T> {

    /**
     * 回调时返回的数据，如不需要，可传空
     */
    private final T model;

    /**
     * 默认选中状态，单选时整个数据集至多有一个为true，多选时无要求
     */
    private final boolean defaultChecked;

    /**
     * 当前选中状态
     */
    private boolean currentChecked;
    private boolean checkable;

    public static <T> List<CheckedItem<T>> generateSingleOrNoneCheckedList(List<T> originList, int defaultCheckedPosition) {
        List<CheckedItem<T>> result = new ArrayList<>();
        if (originList != null && !originList.isEmpty()) {
            for (int i = 0; i < originList.size(); i++) {
                result.add(new CheckedItem<>(originList.get(i), i == defaultCheckedPosition));
            }
        }
        return result;
    }

    public static <T> List<CheckedItem<T>> generateMultiCheckedList(List<T> originList, boolean defaultChecked) {
        List<CheckedItem<T>> result = new ArrayList<>();
        if (originList != null && !originList.isEmpty()) {
            for (int i = 0; i < originList.size(); i++) {
                result.add(new CheckedItem<>(originList.get(i), defaultChecked));
            }
        }
        return result;
    }

    public CheckedItem(T model, boolean defaultChecked) {
        this(model, defaultChecked, true);
    }

    public CheckedItem(T model, boolean defaultChecked, boolean checkable) {
        this.model = model;
        this.defaultChecked = defaultChecked;
        this.checkable = checkable;
        currentChecked = defaultChecked;
    }

    public boolean changeToDefault() {
        return changeCurrentChecked(defaultChecked);
    }

    public boolean changeCurrentChecked(boolean checked) {
        if (currentChecked == checked) {
            return false;
        }
        currentChecked = checked;
        return true;
    }

    public T getModel() {
        return model;
    }

    public boolean isDefaultChecked() {
        return defaultChecked;
    }

    public boolean isCurrentChecked() {
        return currentChecked;
    }

    public boolean isCheckable() {
        return checkable;
    }

    public void setCheckable(boolean checkable) {
        this.checkable = checkable;
    }

    @NonNull
    @Override
    public String toString() {
        return "CheckedItem{" +
                "model=" + model +
                ", defaultChecked=" + defaultChecked +
                ", currentChecked=" + currentChecked +
                ", checkable=" + checkable +
                '}';
    }
}
