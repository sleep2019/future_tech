package com.shopee.sc.common.util;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

import static android.os.VibrationEffect.DEFAULT_AMPLITUDE;

public class VibrateUtils {

    private static Vibrator sVibrator = null;

    public static synchronized void vibrate() {
        if (sVibrator == null) {
            Context context = AppUtils.getContext();
            if (context != null) {
                sVibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            }
        }
        if (sVibrator != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    sVibrator.vibrate(VibrationEffect.createOneShot(300, DEFAULT_AMPLITUDE));
                } else {
                    sVibrator.vibrate(300);
                }
            } catch (Exception e) {
                // https://bugly.qq.com/v2/crash-reporting/crashes/9e1d32150a/352002?pid=1
            }
        }
    }
}
