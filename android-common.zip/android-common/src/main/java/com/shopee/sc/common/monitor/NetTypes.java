package com.shopee.sc.common.monitor;

import androidx.annotation.IntDef;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @ClassName: NetType
 * @Description: 定义网络类型
 * @Author: lanjingzeng
 * @CreateDate: 2020-03-04 09:22
 * @Version: 1.0
 */
@IntDef({NetTypes.NONE, NetTypes.UNKOWN, NetTypes.WIFI, NetTypes.MOBILE_2G, NetTypes.MOBILE_3G, NetTypes.MOBILE_4G})
@Target({ElementType.PARAMETER})
@Retention(RetentionPolicy.SOURCE)
public @interface NetTypes {
    int NONE = -1;
    int UNKOWN = 0;
    int WIFI = 1;
    int MOBILE_2G = 2;
    int MOBILE_3G = 3;
    int MOBILE_4G = 4;

}
