package com.shopee.sc.common.widget.popup;

import android.app.Activity;
import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.PopupWindow;

import androidx.annotation.IdRes;
import androidx.annotation.LayoutRes;

import com.shopee.sc.common.R;
import com.shopee.sc.common.misc.SoftKeyBoardListener;

/**
 * Created by chris on 2019/4/20.
 */
public class InputNumView extends PopupWindow implements PopupWindow.OnDismissListener,
        SoftKeyBoardListener.OnSoftKeyBoardChangeListener {

    private View mPopView;
    private Activity mActivity;
    private boolean mIsOpenSoftKeyboard = false;

    public InputNumView(Activity activity, @LayoutRes int resource, int width, int height) {
        super();
        mActivity = activity;
        mPopView = LayoutInflater.from(activity).inflate(resource, null);
        this.setContentView(mPopView);
        // 设置弹出窗体可点击
        this.setFocusable(true);
        this.setWidth(width);
        this.setHeight(height);
        // 设置弹出窗体动画效果
        this.setAnimationStyle(R.style.CommonAnimation_CustomDialog_Bottom);
        this.setOnDismissListener(this);
        if (mIsOpenSoftKeyboard) {
            setKeyboard();
        }
        SoftKeyBoardListener.setListener(mActivity.getWindow().getDecorView(), this);
    }

    public <T extends View> T findViewById(@IdRes int id) {
        return getContentView().findViewById(id);
    }

    @Override
    public void onDismiss() {
        setBackgroundAlpha(1.0f);
    }

    /**
     * 打开/隐藏 软键盘
     */
    public void setKeyboard() {
        InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
    }

    public boolean openSoftKeyboard() {
        return mIsOpenSoftKeyboard;
    }

    public void setOpenSoftKeyboard(boolean isOpenKeyboard) {
        this.mIsOpenSoftKeyboard = isOpenKeyboard;
    }

    public void setBackgroundAlpha(float bgAlpha) {
        WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
        lp.alpha = bgAlpha;
        mActivity.getWindow().setAttributes(lp);
    }

    @Override
    public void keyBoardShow(int height) {

    }

    @Override
    public void keyBoardHide(int height) {
        if (isShowing()) {
            dismiss();
        }
    }

    protected void show() {
        if (!mActivity.isDestroyed() && !mActivity.isFinishing()) {
            final View view = ((ViewGroup) mActivity.findViewById(android.R.id.content)).getChildAt(0);
            view.post(() -> {
                if (mActivity != null && !mActivity.isDestroyed() && !mActivity.isFinishing()) {
                    showAtLocation(view, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
                }
            });
        }
    }

    public Context getContext() {
        return mActivity;
    }

}
