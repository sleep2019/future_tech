package com.shopee.sc.common.manager;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.lifecycle.Lifecycle;

import com.shopee.sc.common.R;
import com.shopee.sc.common.util.AppUtils;
import com.shopee.sc.common.util.UiUtils;
import com.shopee.sc.common.widget.floating.FloatingWindow;
import com.shopee.sc.logger.api.Logger;

/**
 * @ClassName: TransifyManager
 * @Description: 显示Transify开关的悬浮窗管理类
 * @Author: Lanjing Zeng
 * @CreateDate: 2021/12/10 3:21 PM
 * @Version: 1.0
 */
public final class TransifyManager {
    private static final String TAG = "TransifyManager";

    private FloatingWindow mFloatingWindow;
    private TransifyListener mTransifyListener;
    private boolean mNeedShowFloatingPermTips = true;
    private AlertDialog mFloatingTipsDialog;
    /**
     * 页面正在显示"打开悬浮窗权限"的提示框的情况下，页面意外被finish掉，是否还需要在下一个页面继续显示该权限提示框
     * <p>
     * 目前只有OPS PDA才需要设置该参数为true:对应自动登录时从登录页跳转至首页的情况(OPS PDA没有splash页面)
     */
    private boolean mPermDialogAccidentDismissNeedShowInNextPage;

    private TransifyManager() {
    }

    private static class TransifyManagerHolder {
        private static final TransifyManager instance = new TransifyManager();
    }

    public static TransifyManager getInstance() {
        return TransifyManagerHolder.instance;
    }

    public void setTransifyListener(TransifyListener transifyListener) {
        this.mTransifyListener = transifyListener;
    }

    public void setPermDialogAccidentDismissNeedShowInNextPage(boolean permDialogAccidentDismissNeedShowInNextPage) {
        this.mPermDialogAccidentDismissNeedShowInNextPage = permDialogAccidentDismissNeedShowInNextPage;
    }

    /**
     * 根据字符串的资源id，返回其对应的字符串
     *
     * @param context 上下文
     * @param resId   字符串资源id
     * @return 若当前需要显示transify键值，则显示翻译的key，否则显示翻译key对应的value值
     */
    public String getString(Context context, @StringRes int resId) {
        if (showTransifyKey()) {
            return context.getResources().getResourceEntryName(resId);
        } else {
            return context.getString(resId);
        }
    }

    /**
     * 是否支持显示切换Transify的悬浮窗
     *
     * @return true：支持 false:不支持
     */
    public boolean supportShowTransifyFloating() {
        if (mTransifyListener == null) {
            return false;
        }
        return mTransifyListener.needShowTransifyFloating();
    }

    /**
     * 是否支持显示values/strings.xml文件夹中定义字符串时的name(翻译的key键值)。 Staging、Live环境不支持，其他环境视用户设置而定
     *
     * @return
     */
    public boolean showTransifyKey() {
        if (!supportShowTransifyFloating()) {
            return false;
        }
        if (mTransifyListener == null) {
            return false;
        }
        return mTransifyListener.needShowKeyWhenDisplayTransifyFloating();
    }

    @MainThread
    public void showTransifyFloating(@NonNull Activity context) {
        Logger.i(TAG, "showTransifyFloatingView() mFloatingWindow：" + mFloatingWindow + " 当前是否是主进程:" + AppUtils.isMainProcess(context));
        if (mTransifyListener == null) {
            return;
        }
        if (!supportShowTransifyFloating()) {
            return;
        }
        if (!(context instanceof ComponentActivity)) {
            return;
        }
        ComponentActivity componentActivity = (ComponentActivity) context;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            Logger.i(TAG, "showTransifyFloating():No floating permission");
            if (!mTransifyListener.needShowFloatingPermDialog()) {
                return;
            }
            //LifecycleOwners must call register before they are STARTED.
            if (componentActivity.getLifecycle().getCurrentState().ordinal() >= Lifecycle.State.STARTED.ordinal()) {
                return;
            }
            ActivityResultLauncher launcher = getLauncher(componentActivity);
            showFloatingPermDialog(componentActivity, launcher);
        } else {
            dismissFloatingPermDialog();
            if (mFloatingWindow == null) {
                FloatingWindow.Builder builder = FloatingWindow.newBuilder(context, R.layout.common_layout_transify_floating);
                int screenHeight = UiUtils.getScreenHeight();
                int offY = UiUtils.dp2px(AppUtils.getContext(), 410);
                offY = offY > screenHeight ? screenHeight * 3 / 4 : offY;
                builder.setMovable(true).setLayoutInScreen(true).setNeedPerformClick(false).setOffsetY(offY);
                mFloatingWindow = builder.build();
            }
            SwitchCompat sw = mFloatingWindow.findViewById(R.id.sw);
            mFloatingWindow.setChildViewMovableOnTouchListener(R.id.sw);//主动为SwitchCompat添加滑动监听，否则滑动时SwitchCompat无拖拽效果
            mFloatingWindow.findViewById(R.id.tv_title).setLongClickable(false);
            sw.setChecked(showTransifyKey());
            sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
                setShowTransifyKey(isChecked);
            });
            mFloatingWindow.show();
        }
    }

    private ActivityResultLauncher getLauncher(ComponentActivity componentActivity) {
        ActivityResultLauncher launcher = componentActivity.registerForActivityResult(new ActivityResultContract() {
            @NonNull
            @Override
            public Intent createIntent(@NonNull Context context, Object input) {
                Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + context.getPackageName()));
                return intent;
            }

            @Override
            public Boolean parseResult(int resultCode, @Nullable Intent intent) {
                return resultCode == Activity.RESULT_OK;
            }
        }, (ActivityResultCallback<Boolean>) result -> showTransifyFloating(componentActivity));
        return launcher;
    }

    public void dismissTransifyFloating() {
        if (mFloatingWindow == null) {
            return;
        }
        if (!mFloatingWindow.isShowing()) {
            return;
        }
        mFloatingWindow.dismiss();
        mFloatingWindow = null;
        dismissFloatingPermDialog();
    }

    private void setShowTransifyKey(boolean showKey) {
        Logger.i(TAG, "setShowTransifyKey() 当前是否是主进程:" + AppUtils.isMainProcess(AppUtils.getContext()));
        mTransifyListener.switchTransify(showKey);
    }

    private void showFloatingPermDialog(Activity activity, ActivityResultLauncher launcher) {
        if (mFloatingTipsDialog == null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            View view = activity.getLayoutInflater().inflate(R.layout.common_dialog_transify_floating_perm_tips, null);
            view.findViewById(R.id.iv_close).setOnClickListener(v -> {
                mTransifyListener.closeFloatingPermDialog();
                dismissFloatingPermDialog();
            });
            view.findViewById(R.id.tv_confirm).setOnClickListener(v -> {
                launcher.launch(null);
            });
            builder.setView(view);
            builder.setCancelable(false);
            mFloatingTipsDialog = builder.create();
            mFloatingTipsDialog.setOwnerActivity(activity);
        }
        if (!mFloatingTipsDialog.isShowing()) {
            mFloatingTipsDialog.show();
        }
        if (!mPermDialogAccidentDismissNeedShowInNextPage) {
            return;
        }
        mFloatingTipsDialog.setOnDismissListener(dialog -> {
            mFloatingTipsDialog = null;
        });
        mFloatingTipsDialog.setCanceledOnTouchOutside(true);
        activity.getApplication().registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            Activity nextActivity;

            @Override
            public void onActivityPostCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {

            }

            @Override
            public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {

            }

            @Override
            public void onActivityStarted(@NonNull Activity activity) {
                if (mFloatingTipsDialog != null && mFloatingTipsDialog.isShowing()) {
                    nextActivity = activity;
                }
            }

            @Override
            public void onActivityResumed(@NonNull Activity activity) {

            }

            @Override
            public void onActivityPaused(@NonNull Activity activity) {

            }

            @Override
            public void onActivityStopped(@NonNull Activity activity) {

            }

            @Override
            public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(@NonNull Activity activity) {
                if (mFloatingTipsDialog != null && mFloatingTipsDialog.isShowing()
                        && mFloatingTipsDialog.getOwnerActivity().equals(activity)
                        && nextActivity != null) {
                    Logger.i(TAG, "需要在下面一个继续显示悬浮窗权限的对话框 " +
                            "currentActivity:" + activity.getClass().getName() + "  nextActivity:" + nextActivity.getClass().getName());
                    dismissFloatingPermDialog();
                    mFloatingTipsDialog = null;
                    showFloatingPermDialog(nextActivity, launcher);
                }
            }
        });
    }

    private void dismissFloatingPermDialog() {
        if (mFloatingTipsDialog == null) {
            return;
        }
        if (mFloatingTipsDialog.isShowing()) {
            mFloatingTipsDialog.dismiss();
        }
        mFloatingTipsDialog = null;
    }

    public interface TransifyListener {

        /**
         * 是否需要显示transify的悬浮窗
         *
         * @return true:需要 false:不需要
         */
        boolean needShowTransifyFloating();

        /**
         * 显示Transify悬浮窗的前提下，是否需要显示翻译key
         *
         * @return true:需要 false:不需要
         */
        boolean needShowKeyWhenDisplayTransifyFloating();

        /**
         * 显示Transify悬浮窗的前提下，切换Transify开关
         *
         * @param showKey true:需要显示翻译key false:不需要显示翻译key
         */
        void switchTransify(boolean showKey);


        /**-----------以下两个方法只有在多进程应用中才需要自定义实现，用于控制无悬浮窗权限时是否需要显示打开悬浮窗权限的对话框-----------**/

        /**
         * 关闭悬浮窗权限的对话框
         */
        default void closeFloatingPermDialog() {
            TransifyManager.getInstance().mNeedShowFloatingPermTips = false;
        }

        /**
         * 是否需要显示悬浮窗权限的对话框
         *
         * @return true:需要 false:不需要
         */
        default boolean needShowFloatingPermDialog() {
            return TransifyManager.getInstance().mNeedShowFloatingPermTips;
        }
    }
}