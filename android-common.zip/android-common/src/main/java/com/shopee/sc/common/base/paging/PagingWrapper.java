package com.shopee.sc.common.base.paging;

import com.shopee.sc.common.bean.PagingResp;

/**
 * All same to PagingResp
 */
public class PagingWrapper<T> extends PagingResp<T> {

}
