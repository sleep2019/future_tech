package com.shopee.sc.common.manager;

import com.shopee.sc.common.cache.ACache;
import com.shopee.sc.common.util.AppUtils;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by heroxiong on 2018/3/26.
 */

public class CookieManager {

    private static final String SP_KEY_COOKIE = "key_cookie";
    private ACache mACache;

    public static CookieManager getInstance() {
        return Internal.INSTANCE;
    }

    private CookieManager() {
        mACache = ACache.get(AppUtils.getContext(), true);
    }

    public void setCookie(Set<String> cookies) {
        mACache.putStringSet(SP_KEY_COOKIE, cookies);
    }

    public Set<String> getCookie() {
        return mACache.getStringSet(SP_KEY_COOKIE, new HashSet<>());
    }

    public void clearCookie() {
        mACache.remove(SP_KEY_COOKIE);
    }

    private static class Internal {
        private static final CookieManager INSTANCE = new CookieManager();
    }

}
