package com.shopee.sc.common.network.interceptor;

import android.os.SystemClock;

import androidx.annotation.NonNull;

import com.shopee.sc.logger.api.Logger;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import okhttp3.Interceptor;
import okhttp3.Response;

/**
 * 时间校准 Interceptor，采用类似 NTP 协议的方法对本地时间进行校准，误差来自于以下两方面：
 * a、本类使用 http 响应头中的标准字段 "date" 来确定 server 时间，单位为秒，本地加 500ms 后误差在
 * [-500, 500] ms 之间；如果后台自定义响应头返回毫秒时间戳，本项误差可降至 1ms；
 * b、http 请求耗时，若请求整体耗时 n ms，则本项误差在 (-n/2, n/2) 之间。
 *
 * 总误差为 (-500 - n/2, 500 + n/2) ms。
 * 其中，a 的误差不可避免，b 的误差可以进行收敛，当收敛至指定阈值后，不再进行校准以减少消耗。
 *
 * Created by honggang.xiong on 2020/7/7.
 */
public class OkHttpTimingInterceptor implements Interceptor {

    private static final String TAG = "TimingInterceptor";

    public static final long DEFAULT_TIMING_THRESHOLD = 256; // 默认阈值，单位 ms

    private final SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss:SSS", Locale.US);
    private volatile long mMinCost = Long.MAX_VALUE;

    private final OnTimeCorrectedListener mOnTimeCorrectedListener;
    // 时间校准阈值（http 请求耗时阈值），如果达到阈值，不再进行校准；设为负值则会一直进行校准及收敛
    private final long mThreshold;

    public OkHttpTimingInterceptor(OnTimeCorrectedListener onTimeCorrectedListener) {
        this(onTimeCorrectedListener, DEFAULT_TIMING_THRESHOLD);
    }

    public OkHttpTimingInterceptor(OnTimeCorrectedListener onTimeCorrectedListener, long thresholdMillis) {
        mOnTimeCorrectedListener = onTimeCorrectedListener;
        mThreshold = thresholdMillis;
    }

    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        // 已达到校准阈值，不再进行校准
        if (mMinCost <= mThreshold) {
            return chain.proceed(chain.request());
        }

        long start = SystemClock.elapsedRealtime();
        Response response = chain.proceed(chain.request());
        long end = SystemClock.elapsedRealtime();
        long cost = end - start;
        Logger.d(TAG, "cost " + cost + "ms, mMinCost=" + mMinCost + "ms");
        // 未收敛，直接返回
        if (cost >= mMinCost) {
            return response;
        }

        Date serverDate = response.headers().getDate("date");
        if (serverDate != null) {
            synchronized (this) {
                // double check
                if (cost < mMinCost) {
                    mMinCost = cost;
                    long correctedMillis = serverDate.getTime() + 500 + cost / 2;
                    Logger.i("Time corrected: server data=" + mSimpleDateFormat.format(serverDate)
                            + ", corrected date=" + mSimpleDateFormat.format(new Date(correctedMillis))
                            + ", current date=" + mSimpleDateFormat.format(new Date()));
                    notifyListener(correctedMillis, correctedMillis - end);
                }
            }
        }

        return response;
    }

    private void notifyListener(long correctedMillis, long diffToElapsedRealtime) {
        if (mOnTimeCorrectedListener != null) {
            mOnTimeCorrectedListener.onTimeCorrected(correctedMillis, diffToElapsedRealtime);
        }
    }


    public interface OnTimeCorrectedListener {

        /**
         * 当有误差更小的校准时间时，回调此方法
         *
         * @param correctedMillis       校准时间
         * @param diffToElapsedRealtime 校准时间与 {@link SystemClock#elapsedRealtime()} 的差值，
         *                              相加即可得到当前时间，可避免系统时间被修改造成的影响
         */
        void onTimeCorrected(long correctedMillis, long diffToElapsedRealtime);
    }

}
