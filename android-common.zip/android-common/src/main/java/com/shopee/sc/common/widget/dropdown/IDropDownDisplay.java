package com.shopee.sc.common.widget.dropdown;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * 下拉菜单显示
 *
 * Created by honggang.xiong on 2021/4/7.
 */
public interface IDropDownDisplay {

    boolean isShowing();

    void show();

    void hide();

    /**
     * 使用 Dialog 或 PopupWindow 时可重写该方法
     */
    default void setOnViewDismissListener(@Nullable OnViewDismissListener listener) {
    }

    /**
     * 当前 DropDownDisplay 是否需要默认的 mask，默认 true；使用 Dialog 或 PopupWindow 可返回 false
     */
    default boolean needMask() {
        return true;
    }


    interface OnViewDismissListener {

        void onViewDismiss(@NonNull IDropDownDisplay display);
    }

}
