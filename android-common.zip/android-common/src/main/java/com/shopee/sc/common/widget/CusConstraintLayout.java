package com.shopee.sc.common.widget;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

public class CusConstraintLayout extends ConstraintLayout {
    public CusConstraintLayout(Context context) {
        super(context);
    }

    public CusConstraintLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CusConstraintLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void setOnClickListener(@Nullable OnClickListener listener) {
        super.setOnClickListener(new ViewClickProxy(listener));
    }
}
