package com.shopee.sc.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class TimeUtils {

    public static final long ONE_DAY_SECONDS = TimeUnit.DAYS.toSeconds(1);

    public static final String DAY_MONTH_YEAR = "dd-MM-yyyy";
    public static final String DAY_MONTH_YEAR_SLASH = "dd/MM/yyyy";
    public static final String HOUR_DAY_MONTH_YEAR = "HH:mm dd-MM-yyyy";
    public static final String YEAR_MONTH_DAY_HOUR = "yyyy-MM-dd HH:mm:ss";
    public static final String YEAR_MONTH_DAY_HOUR_SHORT = "yyyyMMdd HH:mm:ss";
    public static final String YEAR_MONTH_DAY_HOUR_MINUTE = "yyyy/MM/dd HH:mm";
    public static final String YEAR_MONTH_DAY = "yyyy-MM-dd";
    public static final String MONTH_DAY = "MM-dd";

    /**
     * 格式化时间
     *
     * @param timeSecond    时间戳，单位 s
     * @param formatPattern 格式
     * @return 格式化后的时间
     */
    public static String formatNetTime(long timeSecond, String formatPattern) {
        return formatTime(timeSecond * 1000, formatPattern);
    }

    /**
     * 格式化时间
     *
     * @param timeMillis    时间戳，单位 ms
     * @param formatPattern 格式
     * @return 格式化后的时间
     */
    public static String formatTime(long timeMillis, String formatPattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(formatPattern, Locale.getDefault());
        return sdf.format(new Date(timeMillis));
    }

    public static String formatPeriod(long startMillis, long endMillis, String formatPattern, String divider) {
        return formatTime(startMillis, formatPattern) + divider + formatTime(endMillis, formatPattern);
    }

    /**
     * 格式化秒数为 HH:mm:ss
     *
     * @param secondLeft 秒数
     * @return HH:mm:ss
     */
    public static String formatSecond(long secondLeft) {
        if (secondLeft < 0) {
            return "";
        }
        secondLeft %= ONE_DAY_SECONDS;
        long hour = secondLeft / 3600;
        secondLeft -= hour * 3600;
        long minute = secondLeft / 60;
        secondLeft -= minute * 60;

        StringBuilder builder = new StringBuilder();
        if (hour < 10) {
            builder.append('0');
        }
        builder.append(hour).append(':');
        if (minute < 10) {
            builder.append('0');
        }
        builder.append(minute).append(':');
        if (secondLeft < 10) {
            builder.append('0');
        }
        builder.append(secondLeft);
        return builder.toString();
    }

}
