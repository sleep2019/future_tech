package com.shopee.sc.common.base.mvp.presenter;

import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;

import com.shopee.sc.common.base.mvp.BaseMvpContract;
import com.shopee.sc.common.base.rx.RxLifecycleTransformer;
import com.shopee.sc.common.network.NetCache;

import io.reactivex.ObservableTransformer;

public abstract class BaseMvpPresenter<V extends BaseMvpContract.View> implements LifecycleObserver {

    private V mView;
    private LifecycleOwner mLifecycleOwner;

    public BaseMvpPresenter(V view, LifecycleOwner lifecycleOwner) {
        if (lifecycleOwner != null) {
            lifecycleOwner.getLifecycle().addObserver(this);
        }
        mView = view;
        mLifecycleOwner = lifecycleOwner;
    }

    protected <T> ObservableTransformer<T, T> getIoMainTransformer() {
        return RxLifecycleTransformer.ioToMain(mLifecycleOwner);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public void onDestroy() {
        // Cancel all requests in activity
        NetCache.getInstance().cancel(this);
        mView = null;
    }

    @NonNull
    protected V getView() {
//        if (mView == null) {
//            throw new IllegalStateException("View has been detached!");
//        }
        return mView;
    }
}