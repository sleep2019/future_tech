package com.shopee.sc.common.widget;

import android.util.SparseArray;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public abstract class RegisteredFragmentPagerAdapter extends FragmentPagerAdapter {

    protected SparseArray<Fragment> mRegisteredItems = new SparseArray<>();

    public RegisteredFragmentPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    public RegisteredFragmentPagerAdapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        Object obj = super.instantiateItem(container, position);
        if (obj instanceof Fragment) {
            mRegisteredItems.put(position, (Fragment) obj);
        }
        return obj;
    }

    public Fragment getRegisteredItem(int position) {
        return mRegisteredItems.get(position);
    }
}
