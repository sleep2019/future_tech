package com.shopee.sc.common.bean.print;

import com.google.gson.annotations.SerializedName;

/**
 * Created by chris on 2019-11-05.
 */
public class PrintHtmlParams {

    @SerializedName("html_str")
    String htmlData;
//    @SerializedName("device")
//    String device; // optional
//    @SerializedName("scale")
//    @Expose(serialize = false, deserialize = false)
//    int scale; // optional
    @SerializedName("height")
    int height;
    @SerializedName("width")
    int width;
//    @SerializedName("begin_page")
//    @Expose(serialize = false, deserialize = false)
//    int beginPage; // optional
//    @SerializedName("end_page")
//    @Expose(serialize = false, deserialize = false)
//    int endPage; // optional
//    @SerializedName("printer_mode")
//    @Expose(serialize = false, deserialize = false)
//    String printerMode; // optional
    @SerializedName("repeat_times")
    int repeatTimes; // optional
//    @SerializedName("header_footer_print")
//    @Expose(serialize = false, deserialize = false)
//    boolean headerFooterPrint;

    public PrintHtmlParams(String htmlData, int height, int width) {
        this.htmlData = htmlData;
        this.height = height;
        this.width = width;
    }

    public PrintHtmlParams(String htmlData, int height, int width, int repeatTimes) {
        this.htmlData = htmlData;
        this.height = height;
        this.width = width;
        this.repeatTimes = repeatTimes;
    }
}
