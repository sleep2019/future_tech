package com.shopee.sc.common.helper;

import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

/**
 * Created by chris on 2020-01-15.
 *
 * 提供 dp 作为适配单位
 */
public final class UIMatchingHelper {
    /**
     * 屏幕适配的基准
     */
    public static final int MATCH_BASE_WIDTH = 0;
    public static final int MATCH_BASE_HEIGHT = 1;

    private static MatchInfo sMatchInfo;

    private static Application.ActivityLifecycleCallbacks mActivityLifecycleCallback;

    private UIMatchingHelper() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    /**
     * 初始化
     *
     * @param application
     */
    public static void setup(@NonNull final Application application) {
        DisplayMetrics displayMetrics = application.getResources().getDisplayMetrics();
        if (sMatchInfo == null) {
            // 记录系统的原始值
            sMatchInfo = new MatchInfo();
            sMatchInfo.setScreenWidth(displayMetrics.widthPixels);
            sMatchInfo.setScreenWidthDp(application.getResources().getConfiguration().screenWidthDp);
            sMatchInfo.setScreenHeight(displayMetrics.heightPixels);
            sMatchInfo.setAppDensity(displayMetrics.density);
            sMatchInfo.setAppDensityDpi(displayMetrics.densityDpi);
            sMatchInfo.setAppScaledDensity(displayMetrics.scaledDensity);
            sMatchInfo.setAppXdpi(displayMetrics.xdpi);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            // 添加字体变化的监听
            application.registerComponentCallbacks(new ComponentCallbacks() {
                @Override
                public void onConfigurationChanged(Configuration newConfig) {
                    // 字体改变后,将 appScaledDensity 重新赋值
                    if (newConfig != null && newConfig.fontScale > 0) {
                        sMatchInfo.setAppScaledDensity(application.getResources().getDisplayMetrics().scaledDensity);
                    }
                }

                @Override
                public void onLowMemory() {
                }
            });
        }
    }

    /**
     * 在 application 中全局激活适配 或者 也可单独使用 match() 方法在指定页面中配置适配
     */
    @RequiresApi(api = Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    public static void register(@NonNull final Application application, final float designSize, final int matchBase) {
        if (mActivityLifecycleCallback == null) {
            mActivityLifecycleCallback = new Application.ActivityLifecycleCallbacks() {
                @Override
                public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                    if (activity != null) {
                        match(activity, designSize, matchBase);
                        // 在 {@link ComponentCallbacks#onConfigurationChanged(Configuration)} match application 后，
                        // application Resources 中的 DisplayMetrics 会被重置，所以在此处进行 check & match application，
                        // 可达到全局一致
                        if (activity.getResources().getDisplayMetrics().density != application.getResources().getDisplayMetrics().density) {
                            match(application, designSize, matchBase);
                        }
                    }
                }

                @Override
                public void onActivityStarted(Activity activity) {

                }

                @Override
                public void onActivityResumed(Activity activity) {

                }

                @Override
                public void onActivityPaused(Activity activity) {

                }

                @Override
                public void onActivityStopped(Activity activity) {

                }

                @Override
                public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

                }

                @Override
                public void onActivityDestroyed(Activity activity) {

                }
            };
            application.registerActivityLifecycleCallbacks(mActivityLifecycleCallback);
        }
    }

    /**
     * 全局取消所有的适配
     */
    @RequiresApi(api = Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    public static void unregister(@NonNull final Application application) {
        if (mActivityLifecycleCallback != null) {
            application.unregisterActivityLifecycleCallbacks(mActivityLifecycleCallback);
            mActivityLifecycleCallback = null;
        }
        cancelMatch(application);
    }


    /**
     * 根据宽度适配屏幕（放在 Activity 的 setContentView() 之前执行）
     *
     * @param context
     * @param designSize
     */
    public static void setMatchBaseWidth(@NonNull final Context context, final float designSize) {
        match(context, designSize, MATCH_BASE_WIDTH);
    }

    /**
     * 根据宽度适配屏幕（放在 Activity 的 setContentView() 之前执行）
     *
     * @param context
     * @param designSize
     */
    public static void setMatchBaseHeight(@NonNull final Context context, final float designSize) {
        match(context, designSize, MATCH_BASE_HEIGHT);
    }

    /**
     * 适配屏幕（放在 Activity 的 setContentView() 之前执行）
     *
     * @param context
     * @param designSize 设计图的尺寸
     * @param matchBase  适配基准
     */
    public static void match(@NonNull final Context context, final float designSize, int matchBase) {
        if (designSize == 0) {
            throw new UnsupportedOperationException("The designSize cannot be equal to 0");
        }
        matchByDip(context, designSize, matchBase);
    }

    /**
     * 重置适配信息，取消适配
     *
     * @param context
     */
    public static void cancelMatch(@NonNull final Context context) {
        if (sMatchInfo != null) {
            final DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
            if (displayMetrics.density != sMatchInfo.getAppDensity()) {
                displayMetrics.density = sMatchInfo.getAppDensity();
            }
            if (displayMetrics.densityDpi != sMatchInfo.getAppDensityDpi()) {
                displayMetrics.densityDpi = (int) sMatchInfo.getAppDensityDpi();
            }
            if (displayMetrics.scaledDensity != sMatchInfo.getAppScaledDensity()) {
                displayMetrics.scaledDensity = sMatchInfo.getAppScaledDensity();
            }
            context.getResources().getConfiguration().screenWidthDp = sMatchInfo.getScreenWidthDp();
        }
    }

    /**
     * 使用 dp 作为适配单位
     *
     * dp 与 px 之间的换算:
     * <li> px = density * dp </li>
     * <li> density = dpi / 160 </li>
     * <li> px = dp * (dpi / 160) </li>
     *
     * @param context
     * @param designSize 设计图的宽/高（单位: dp）
     * @param base       适配基准
     */
    private static void matchByDip(@NonNull final Context context, final float designSize, int base) {
        final float targetDensity;
        if (base == MATCH_BASE_HEIGHT) {
            targetDensity = sMatchInfo.getScreenHeight() * 1f / designSize;
        } else { // 默认按宽度
            targetDensity = sMatchInfo.getScreenWidth() * 1f / designSize;
            // 某些 AlertDialog 在测量时会使用该值，一般来说 screenWidthDp 大于 designSize，不改的话会导致弹窗宽度溢出屏幕
            context.getResources().getConfiguration().screenWidthDp = (int) designSize;
        }
        final int targetDensityDpi = (int) (targetDensity * 160);
        final float targetScaledDensity = targetDensity * (sMatchInfo.getAppScaledDensity() / sMatchInfo.getAppDensity());
        final DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        displayMetrics.density = targetDensity;
        displayMetrics.densityDpi = targetDensityDpi;
        displayMetrics.scaledDensity = targetScaledDensity;
    }

    /**
     * 获取适配信息
     */
    public static MatchInfo getMatchInfo() {
        return sMatchInfo;
    }

    /**
     * 适配信息
     */
    public static class MatchInfo {
        private int screenWidth;
        private int screenWidthDp;
        private int screenHeight;
        private float appDensity;
        private float appDensityDpi;
        private float appScaledDensity;
        private float appXdpi;

        public int getScreenWidth() {
            return screenWidth;
        }

        public void setScreenWidth(int screenWidth) {
            this.screenWidth = screenWidth;
        }

        public int getScreenWidthDp() {
            return screenWidthDp;
        }

        public void setScreenWidthDp(int screenWidthDp) {
            this.screenWidthDp = screenWidthDp;
        }

        public int getScreenHeight() {
            return screenHeight;
        }

        public void setScreenHeight(int screenHeight) {
            this.screenHeight = screenHeight;
        }

        public float getAppDensity() {
            return appDensity;
        }

        public void setAppDensity(float appDensity) {
            this.appDensity = appDensity;
        }

        public float getAppDensityDpi() {
            return appDensityDpi;
        }

        public void setAppDensityDpi(float appDensityDpi) {
            this.appDensityDpi = appDensityDpi;
        }

        public float getAppScaledDensity() {
            return appScaledDensity;
        }

        public void setAppScaledDensity(float appScaledDensity) {
            this.appScaledDensity = appScaledDensity;
        }

        public float getAppXdpi() {
            return appXdpi;
        }

        public void setAppXdpi(float appXdpi) {
            this.appXdpi = appXdpi;
        }
    }
}