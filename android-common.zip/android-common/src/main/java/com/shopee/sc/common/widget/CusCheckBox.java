package com.shopee.sc.common.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;

@SuppressLint("AppCompatCustomView")
public class CusCheckBox extends FixCheckBox {

    public CusCheckBox(Context context) {
        super(context);
    }

    public CusCheckBox(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CusCheckBox(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
