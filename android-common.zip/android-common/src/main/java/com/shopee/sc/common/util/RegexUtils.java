package com.shopee.sc.common.util;

import android.text.TextUtils;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by chris on 2018/9/29.
 */
public class RegexUtils {

    private static final Pattern PATTERN_IPV4 = Pattern.compile("^((25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)$");

    private RegexUtils() {

    }

    public static boolean regular(String regex, String str) {
        // 空正则不校验
        if (TextUtils.isEmpty(regex)) {
            return true;
        }
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(str);
        return m.matches();
    }

    public static boolean isContainLetter(String str) {
        String regex = ".*[a-zA-Z]+.*";
        Matcher m = Pattern.compile(regex).matcher(str);
        return m.matches();
    }

    public static boolean isDigit(String str) {
        // 该正则表达式可以匹配所有的数字(包括负数)
        final Pattern pattern = Pattern.compile("-?[0-9]+(\\.[0-9]+)?");
        String bigStr;
        try {
            bigStr = new BigDecimal(str).toString();
        } catch (Exception e) {
            return false;
        }

        return pattern.matcher(bigStr).matches();
    }

    public static boolean isLetterDigit(String str) {
        String regex = "^[a-z0-9A-Z]+$";
        return str.matches(regex);
    }

    public static boolean isValidIPv4(String str) {
        return !TextUtils.isEmpty(str) && PATTERN_IPV4.matcher(str).matches();
    }

}
