package com.shopee.sc.common.helper.paging;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.LayoutRes;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.loadmore.LoadMoreView;
import com.shopee.sc.common.R;
import com.shopee.sc.common.bean.PagingBean;
import com.shopee.sc.common.widget.CommonLoadMoreView;

import java.util.ArrayList;
import java.util.Objects;

/**
 * 分页加载 Helper
 * <p>
 * Created by honggang.xiong on 2021/11/15.
 */
public class PagingLoadHelper<T> implements PagingCallback<T> {

    private static final String TAG = "DetailLoadingHelper";

    public static final int DEFAULT_PAGE_INITIAL_INDEX = 1;
    public static final int DEFAULT_PAGE_SIZE = 10;

    @NonNull
    private final SwipeRefreshLayout mPagingSwipeRefresh;
    @NonNull
    private final RecyclerView mPagingRecycler;
    @NonNull
    private final BaseQuickAdapter<T, ? extends BaseViewHolder> mPagingAdapter;

    @NonNull
    private final PagingParams.Factory mPagingParamsFactory;
    @NonNull
    private final PagingSource<T> mPagingSource;
    @NonNull
    private final LoadingStyle mLoadingStyle;

    private final int mPageInitialIndex;
    private final int mPageSize;
    private final boolean mEnableEmptyAutoRefresh;
    private final boolean mShowLoadFinishOnFirstPage;
    private final boolean mShowLoadFinishOnOtherPage;

    private final LifecycleOwner mLifecycleOwner;
    private final RichPagingCallback<T> mRichCallback;

    private int mNextPageIndex;
    private boolean mPendingUpdate = false; // 是否需要延迟更新
    private boolean mHasLoadData = false;
    private boolean mIsResumed = false;

    /**
     * Suggest to be invoked in android.app.Activity#onCreate(Bundle) or
     * {@link androidx.fragment.app.Fragment#onViewCreated(View, Bundle)}
     *
     * @param swipeRefreshLayout 下拉刷新 layout
     * @param recyclerView       RecyclerView
     * @param adapter            BaseQuickAdapter
     */
    public static <T> Builder<T> newBuilder(@NonNull SwipeRefreshLayout swipeRefreshLayout,
                                            @NonNull RecyclerView recyclerView,
                                            @NonNull BaseQuickAdapter<T, ? extends BaseViewHolder> adapter) {
        return new Builder<>(swipeRefreshLayout, recyclerView, adapter);
    }

    private PagingLoadHelper(Builder<T> builder) {
        mPagingSwipeRefresh = builder.mPagingSwipeRefresh;
        mPagingRecycler = builder.mPagingRecycler;
        mPagingAdapter = builder.mPagingAdapter;

        mPagingParamsFactory = builder.mPagingParamsFactory;
        mPagingSource = builder.mPagingSource;
        mLoadingStyle = builder.mLoadingStyle;

        mPageInitialIndex = builder.mPageInitialIndex;
        mPageSize = builder.mPageSize;
        mEnableEmptyAutoRefresh = builder.mEnableEmptyAutoRefresh;
        mShowLoadFinishOnFirstPage = builder.mShowLoadFinishOnFirstPage;
        mShowLoadFinishOnOtherPage = builder.mShowLoadFinishOnOtherPage;

        mLifecycleOwner = builder.mLifecycleOwner;
        mRichCallback = builder.mRichPagingCallback;

        mNextPageIndex = mPageInitialIndex;

        // init SwipeRefreshLayout
        mPagingSwipeRefresh.setOnRefreshListener(() -> loadData(PagingType.SWIPE_REFRESH));
        mPagingSwipeRefresh.setColorSchemeResources(R.color.commonColorPrimary, R.color.commonColorAccent,
                R.color.commonColorPrimaryDark);

        // init RecyclerView
        mPagingRecycler.setLayoutManager(new LinearLayoutManager(mPagingRecycler.getContext()));

        // init BaseQuickAdapter
        mPagingAdapter.openLoadAnimation();
        mPagingAdapter.bindToRecyclerView(mPagingRecycler);
        mPagingAdapter.setLoadMoreView(builder.mLoadMoreView);
        mPagingAdapter.setOnLoadMoreListener(() -> loadData(PagingType.LOAD_MORE), mPagingRecycler);
        if (builder.mEmptyView != null) {
            mPagingAdapter.setEmptyView(builder.mEmptyView);
        } else if (builder.mEmptyViewLayoutId > 0) {
            mPagingAdapter.setEmptyView(builder.mEmptyViewLayoutId, mPagingRecycler);
        }

        if (mLifecycleOwner != null) {
            mLifecycleOwner.getLifecycle().addObserver(new LifecycleEventObserver() {
                @Override
                public void onStateChanged(@NonNull LifecycleOwner source, @NonNull Lifecycle.Event event) {
                    switch (event) {
                        case ON_CREATE:
                            onCreate();
                            break;
                        case ON_RESUME:
                            onResume();
                            break;
                        case ON_PAUSE:
                            onPause();
                            break;
                        case ON_DESTROY:
                            onDestroy();
                            break;
                    }
                }
            });
        }
    }

    public void performCreate() {
        if (mLifecycleOwner == null) {
            onCreate();
        }
    }

    public void performResume() {
        if (mLifecycleOwner == null) {
            onResume();
        }
    }

    public void performPause() {
        if (mLifecycleOwner == null) {
            onPause();
        }
    }

    public void performDestroy() {
        if (mLifecycleOwner == null) {
            onDestroy();
        }
    }

    void onCreate() {
        mHasLoadData = false;
    }

    void onResume() {
        mIsResumed = true;
        if (!mHasLoadData || (mEnableEmptyAutoRefresh && mPagingAdapter.getData().isEmpty())) {
            loadData(PagingType.EMPTY_REFRESH);
        } else if (mPendingUpdate) {
            forceRefresh();
        }
        mPendingUpdate = false;
    }

    void onPause() {
        mIsResumed = false;
    }

    void onDestroy() {
        stopCurrentLoad();
    }

    public void stopCurrentLoad() {
        mPagingSource.stopCurrentLoad();
    }

    public boolean isPendingUpdate() {
        return mPendingUpdate;
    }

    @MainThread
    public void setPendingUpdate(boolean pendingUpdate) {
        mPendingUpdate = pendingUpdate;
    }

    @MainThread
    public void setPendingUpdateOrForceRefresh(boolean pendingUpdate) {
        if (pendingUpdate && mIsResumed) {
            forceRefresh();
        } else {
            mPendingUpdate = pendingUpdate;
        }
    }

    @MainThread
    public void forceRefresh() {
        loadData(PagingType.EVENT_REFRESH);
    }

    public void loadData(@NonNull PagingType type) {
        mPagingSource.stopCurrentLoad();

        mLoadingStyle.showLoading(type, mPagingSwipeRefresh, true);

        int page = mNextPageIndex;
        if (type.isForceFetch()) {
            page = mPageInitialIndex;
            mPagingAdapter.setEnableLoadMore(false); // 防止下拉刷新的时候还可以上拉加载
        }
        PagingParams params = mPagingParamsFactory.createParams(page, mPageSize);
        mPagingSource.load(params, type, this);

        if (mRichCallback != null) {
            mRichCallback.onLoadStart(params, type);
        }
    }

    @Override
    public void handleDataList(@NonNull PagingType type, @NonNull PagingBean<T> pagingBean) {
        mHasLoadData = true;
        if (mRichCallback != null) {
            mRichCallback.preHandleDataList(type, pagingBean);
        }

        boolean isForceFetch = type.isForceFetch();
        if (isForceFetch) {
            // 刷新成功再设为初始 index
            mNextPageIndex = mPageInitialIndex;
            mLoadingStyle.showLoading(type, mPagingSwipeRefresh, false);
            if (mRichCallback != null) {
                mRichCallback.updateFirstPageDataList(mPagingAdapter, type, pagingBean);
            } else {
                mPagingAdapter.setNewData(new ArrayList<>(pagingBean.finalList));
            }
        } else {
            mPagingAdapter.addData(pagingBean.finalList);
        }
        mNextPageIndex++;

        if (pagingBean.originCount < mPageSize) {
            // 加载结束后是否显示 "no more data"
            boolean showLoadFinish = (isForceFetch && mShowLoadFinishOnFirstPage)
                    || (!isForceFetch && mShowLoadFinishOnOtherPage);
            mPagingAdapter.loadMoreEnd(!showLoadFinish);
        } else {
            mPagingAdapter.loadMoreComplete();
        }

        if (mRichCallback != null) {
            mRichCallback.handleDataList(type, pagingBean);
        }
    }

    @Override
    public void handleLoadFailed(@NonNull PagingType type) {
        if (type.isForceFetch()) {
            mLoadingStyle.showLoading(type, mPagingSwipeRefresh, false);
            mPagingAdapter.setEnableLoadMore(true);
        } else {
            mPagingAdapter.loadMoreFail();
        }

        if (mRichCallback != null) {
            mRichCallback.handleLoadFailed(type);
        }
    }

    @Override
    public void handleLoadCancelled(@NonNull PagingType type) {
        if (type.isForceFetch()) {
            mLoadingStyle.showLoading(type, mPagingSwipeRefresh, false);
            mPagingAdapter.setEnableLoadMore(true);
        } else {
            mPagingAdapter.loadMoreFail();
        }

        if (mRichCallback != null) {
            mRichCallback.handleLoadCancelled(type);
        }
    }

    @NonNull
    public BaseQuickAdapter<T, ? extends BaseViewHolder> getPagingAdapter() {
        return mPagingAdapter;
    }

    public int getPageInitialIndex() {
        return mPageInitialIndex;
    }

    public int getPageSize() {
        return mPageSize;
    }


    public interface LoadingStyle {
        void showLoading(@NonNull PagingType type, @NonNull SwipeRefreshLayout swipeRefreshLayout, boolean isLoading);
    }

    public static class SimpleLoadingStyle implements LoadingStyle {
        @Override
        public void showLoading(@NonNull PagingType type, @NonNull SwipeRefreshLayout swipeRefreshLayout, boolean isLoading) {
            if (type.isForceFetch()) {
                swipeRefreshLayout.setRefreshing(isLoading);
            }
        }
    }

    public static class Builder<T> {
        // 非空必填
        @NonNull
        private final SwipeRefreshLayout mPagingSwipeRefresh;
        @NonNull
        private final RecyclerView mPagingRecycler;
        @NonNull
        private final BaseQuickAdapter<T, ? extends BaseViewHolder> mPagingAdapter;

        // 非空选填
        @NonNull
        private PagingParams.Factory mPagingParamsFactory = PagingParams.Factory.DEFAULT;
        @NonNull
        private PagingSource<T> mPagingSource = PagingSource.emptySource();
        @NonNull
        private LoadingStyle mLoadingStyle = new SimpleLoadingStyle();
        @NonNull
        private LoadMoreView mLoadMoreView = new CommonLoadMoreView();

        private int mPageInitialIndex = DEFAULT_PAGE_INITIAL_INDEX;
        private int mPageSize = DEFAULT_PAGE_SIZE;
        private boolean mEnableEmptyAutoRefresh = true;
        private boolean mShowLoadFinishOnFirstPage = false;
        private boolean mShowLoadFinishOnOtherPage = true;

        // 可空选填
        private View mEmptyView;
        private int mEmptyViewLayoutId = 0;
        private LifecycleOwner mLifecycleOwner;
        private RichPagingCallback<T> mRichPagingCallback;

        Builder(@NonNull SwipeRefreshLayout swipeRefreshLayout, @NonNull RecyclerView recyclerView,
                @NonNull BaseQuickAdapter<T, ? extends BaseViewHolder> adapter) {
            mPagingSwipeRefresh = Objects.requireNonNull(swipeRefreshLayout, "swipeRefreshLayout cannot be null");
            mPagingRecycler = Objects.requireNonNull(recyclerView, "recyclerView cannot be null");
            mPagingAdapter = Objects.requireNonNull(adapter, "adapter cannot be null");
        }

        @NonNull
        public SwipeRefreshLayout getPagingSwipeRefresh() {
            return mPagingSwipeRefresh;
        }

        @NonNull
        public RecyclerView getPagingRecycler() {
            return mPagingRecycler;
        }

        @NonNull
        public BaseQuickAdapter<T, ? extends BaseViewHolder> getPagingAdapter() {
            return mPagingAdapter;
        }

        /**
         * 设置分页参数 Factory，默认为 {@link PagingParams.Factory#DEFAULT}
         */
        public Builder<T> setPagingParamsFactory(@NonNull PagingParams.Factory pagingParamsFactory) {
            mPagingParamsFactory = Objects.requireNonNull(pagingParamsFactory);
            return this;
        }

        /**
         * 设置分页数据源，默认为 {@link PagingSource#EMPTY_SOURCE}
         */
        public Builder<T> setPagingSource(@NonNull PagingSource<T> pagingSource) {
            mPagingSource = Objects.requireNonNull(pagingSource);
            return this;
        }

        /**
         * 设置分页加载样式，默认为 {@link SimpleLoadingStyle}
         */
        public Builder<T> setLoadingStyle(@NonNull LoadingStyle loadingStyle) {
            mLoadingStyle = Objects.requireNonNull(loadingStyle);
            return this;
        }

        /**
         * 设置分页 LoadMoreView
         */
        public Builder<T> setLoadMoreView(@NonNull LoadMoreView loadMoreView) {
            mLoadMoreView = Objects.requireNonNull(loadMoreView);
            return this;
        }

        /**
         * 设置分页起始下标，默认 1
         */
        public Builder<T> setPageInitialIndex(int pageInitialIndex) {
            mPageInitialIndex = pageInitialIndex;
            return this;
        }

        /**
         * 设置分页每页大小，默认 10
         */
        public Builder<T> setPageSize(int pageSize) {
            mPageSize = pageSize;
            return this;
        }

        /**
         * 空数据返回页面时，是否自动触发刷新，默认 true
         */
        public Builder<T> setEnableEmptyAutoRefresh(boolean enableEmptyAutoRefresh) {
            mEnableEmptyAutoRefresh = enableEmptyAutoRefresh;
            return this;
        }

        /**
         * 首页数据不足一页时，是否显示 "no more data"，默认 false
         */
        public Builder<T> setShowLoadFinishOnFirstPage(boolean showLoadFinishOnFirstPage) {
            mShowLoadFinishOnFirstPage = showLoadFinishOnFirstPage;
            return this;
        }

        /**
         * 其他页数据不足一页时，是否显示 "no more data"，默认 true
         */
        public Builder<T> setShowLoadFinishOnOtherPage(boolean showLoadFinishOnOtherPage) {
            mShowLoadFinishOnOtherPage = showLoadFinishOnOtherPage;
            return this;
        }

        /**
         * 设置分页 emptyView
         */
        public Builder<T> setEmptyView(@Nullable View emptyView) {
            mEmptyView = emptyView;
            if (mEmptyView != null) {
                mEmptyViewLayoutId = 0;
            }
            return this;
        }

        /**
         * 设置分页 emptyView
         */
        public Builder<T> setEmptyView(@LayoutRes int layoutResId) {
            mEmptyViewLayoutId = layoutResId;
            if (mEmptyViewLayoutId > 0) {
                mEmptyView = null;
            }
            return this;
        }

        /**
         * 设置 LifecycleOwner
         *
         * @param lifecycleOwner 非空时将通过 owner 自动处理生命周期事件并屏蔽外部调用
         */
        public Builder<T> setLifecycleOwner(@Nullable LifecycleOwner lifecycleOwner) {
            mLifecycleOwner = lifecycleOwner;
            return this;
        }

        public Builder<T> setRichPagingCallback(@Nullable RichPagingCallback<T> richPagingCallback) {
            mRichPagingCallback = richPagingCallback;
            return this;
        }

        public PagingLoadHelper<T> build() {
            return new PagingLoadHelper<>(this);
        }
    }

}

