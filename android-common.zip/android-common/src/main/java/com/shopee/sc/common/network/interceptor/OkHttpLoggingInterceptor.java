package com.shopee.sc.common.network.interceptor;

import android.os.SystemClock;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;

/**
 * Created by honggang.xiong on 2019-05-09.
 */
public class OkHttpLoggingInterceptor implements Interceptor {

    private static final Charset UTF_8 = StandardCharsets.UTF_8;
    private static final String X_REQUEST_ID = "x-request-id";
    private LogListener listener;
    private final String mCustomMultipartDispositionPrefix;

    public interface LogListener {
        void onLogReady(String logStr);
    }

    public OkHttpLoggingInterceptor(String customMultipartName, LogListener listener) {
        mCustomMultipartDispositionPrefix = customMultipartName == null ? null
                : "form-data; name=\"" + customMultipartName + "\"";
        this.listener = listener;
    }

    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request originRequest = chain.request();
        if (listener == null) { // if lister not set, do nothing
            return chain.proceed(originRequest);
        }

        RequestBody requestBody = originRequest.body();
        String requestStr = getRequestStrFromRequestBody(requestBody, mCustomMultipartDispositionPrefix);

        long start = SystemClock.elapsedRealtime();
        Response originResponse = chain.proceed(originRequest);
        long timeCost = SystemClock.elapsedRealtime() - start;

        String[] responseStrHolder = new String[1];
        originResponse = getResponseStr(originResponse, responseStrHolder);

        String logStr = originRequest.url()
                + "  method=" + originRequest.method()
                + "  protocol=" + originResponse.protocol()
                + "\n httpCode=" + originResponse.code()
                + "  time=" + timeCost + "ms"
                + "  requestId=" + originResponse.header(X_REQUEST_ID)
                + "\n request: " + requestStr
                + "\n response: " + responseStrHolder[0];
        listener.onLogReady(logStr);
        return originResponse;
    }


    public static String getRequestStrFromRequestBody(RequestBody requestBody, String customPrefix) {
        try {
            String directStr = getRequestStrDirect(requestBody);
            if (directStr != null) {
                return directStr;
            } else if (customPrefix != null && requestBody instanceof MultipartBody) {
                MultipartBody multipartBody = (MultipartBody) requestBody;
                for (MultipartBody.Part part : multipartBody.parts()) {
                    Headers headers = part.headers();
                    if (headers != null) {
                        String name = headers.get("Content-Disposition");
                        if (name != null && name.startsWith(customPrefix)) {
                            return getRequestStrDirect(part.body());
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String getRequestStrDirect(RequestBody requestBody) throws IOException {
        if (requestBody != null && requestBody.contentLength() >= 0 && isPlaintext(requestBody.contentType())) {
            Buffer buffer = new Buffer();
            requestBody.writeTo(buffer);
            return buffer.readString(getCharset(requestBody.contentType()));
        }
        return null;
    }

    public static Response getResponseStr(Response originResponse, String[] responseStrHolder) throws IOException {
        ResponseBody responseBody = originResponse.body();
        if (responseBody != null && isPlaintext(responseBody.contentType())) {
            byte[] bytes = responseBody.bytes();
            responseStrHolder[0] = new String(bytes, getCharset(responseBody.contentType()));
            originResponse = originResponse.newBuilder()
                    .body(ResponseBody.create(responseBody.contentType(), bytes))
                    .build();
        }
        return originResponse;
    }

    private static boolean isPlaintext(MediaType mediaType) {
        if (mediaType == null) return false;
        if ("text".equals(mediaType.type())) {
            return true;
        }
        String subtype = mediaType.subtype();
        return subtype != null && (subtype.contains("json")
                || subtype.contains("xml")
                || subtype.contains("plain")
                || subtype.contains("html"));
    }

    private static Charset getCharset(MediaType contentType) {
        return contentType != null ? contentType.charset(UTF_8) : UTF_8;
    }

}
