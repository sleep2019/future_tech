# Sc Android Common Lib

Android Common base lib for Supply-Chain Android.

## Release Version

## 1.1.1-beta9 (2022-08-08):
- [bugfix] 升级scanner为v1.0.3.9

## 1.1.1-beta8 (2022-07-27):
- [bugfix] 升级store为v2.0.4-beta28

## 1.1.1-beta7 (2022-07-19):
- [jira] [SPSCTP-4477 数据加密库拆分] (https://jira.shopee.io/browse/SPSCTP-4477)

## 1.1.1-beta6 (2022-06-30):
 - [bugfix] [SPSCTP-4408 ACache init support multiple thread](https://jira.shopee.io/browse/SPSCTP-4408)


## 1.1.1-beta5 (2022-06-27):
 - [bugfix] [SPSCTP-4362 ListPopupWindow support smooth scroll to special position](https://jira.shopee.io/browse/SPSCTP-4362)



## 1.1.0-beta24 (2022-06-17):
 - [bugfix] [SPTWS-8112 BaseMvpPresenter.getView() method maybe throw Exception](https://jira.shopee.io/browse/SPTWS-8112)
