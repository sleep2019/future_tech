# ui-library

## 参考文档
ItemComponentView:https://confluence.shopee.io/display/SPSC/%5BSCA%5D+WMS+ItemComponentView

## Release Version

## 1.0.7.3 (2022-03-07):
 - [feature] 1.CustomOneButton增加设置getText()方法获取当前按钮上的文字


## 1.0.7.0 (2021-04-16):
 - [feature] 1.CustomOneButton设置了android:textAllCaps="true"属性时，如果xml中设置的text是小写或者大小写混合，会出现左侧icon和文字这一整体未完全居中的情况(实际是靠右了)
 

## 1.0.6.9 (2021-03-25):
 - [feature] 1.CustomTabLayout新增setTabTitle()的api，支持动态设置标题


## 1.0.6.8 (2021-01-19):
 - [feature] 1.CustomTabLayout支持weight相关属性后引起的性能问题优化
 
 
## 1.0.6.7 (2021-01-15):
 - [feature] 1.CustomTabLayout增加编辑模式
 
 
## 1.0.6.6 (2021-01-14):
 - [feature] 1.ItemConponentView修改属性命名:uiLibraryLeftLayout_centerVertical
 - [feature] 2.ItemConponentView支持的View样式扩展(支持设置uiLibraryLeftLayout_weight和uiLibraryRightLayout_weight属性)
 - [feature] 3.ItemConponentView增加对外api


## 1.0.6.5 (2020-12-22):
 - [feature] 1.CustomTabLayout增加getTabLayout()方法
 
 
## 1.0.6.4 (2020-12-15):
 - [feature] 1.增加选择日期的控件
  
   
## 1.0.6.2 (2020-12-11):
 - [feature] 1.ItemComponentView增加在xml中设置backgroud
 - [feature] 2.CustomTabLayout增加当前选择哪一个item的api
 
 
 ## 1.0.6.1 (2020-11-18):
 - [feature] 1.CustomTabLayout内部实现修改