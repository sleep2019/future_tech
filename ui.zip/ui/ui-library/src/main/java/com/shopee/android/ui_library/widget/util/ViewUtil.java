package com.shopee.android.ui_library.widget.util;

import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ViewUtil {
    /**
     * 从xml中解析出来textsize的单位是px,所以这里设置textsize时指定px为单位，否则android默认使用sp做为单位，导致字体比预期偏大
     *
     * @param view
     * @param textSize
     */
    public static void setTextSize(TextView view, float textSize) {
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
    }

    public static void setMargin(View view, int margin, int leftMargin, int topMargin, int rightMargin, int bottomMargin) {
        if (view == null) {
            return;
        }
        if (margin != 0) {
            setMargin(view, margin, margin, margin, margin);
        } else {
            setMargin(view, leftMargin, topMargin, rightMargin, bottomMargin);
        }
    }

    public static void setMargin(View view, int leftMargin, int topMargin, int rightMargin, int bottomMargin) {
        if (view == null) {
            return;
        }
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        lp.leftMargin = leftMargin;
        lp.topMargin = topMargin;
        lp.rightMargin = rightMargin;
        lp.bottomMargin = bottomMargin;
        view.setLayoutParams(lp);
    }

    public static void setVisibility(View view, int visibility) {
        if (view == null) {
            return;
        }
        if (visibility == View.VISIBLE) {
            view.setVisibility(View.VISIBLE);
        } else if (visibility == View.INVISIBLE) {
            view.setVisibility(View.INVISIBLE);
        } else if (visibility == View.GONE) {
            view.setVisibility(View.GONE);
        }
    }

    public static void setPadding(View view, int padding, int leftPadding, int topPadding, int rightPadding, int bottomPadding) {
        if (view == null) {
            return;
        }
        if (padding != 0) {
            setPadding(view, padding, padding, padding, padding);
        } else {
            setPadding(view, leftPadding, topPadding, rightPadding, bottomPadding);
        }
    }

    public static void setPadding(View view, int leftPadding, int topPadding, int rightPadding, int bottomPadding) {
        if (view == null) {
            return;
        }
        view.setPadding(leftPadding, topPadding, rightPadding, bottomPadding);
    }

    public static void setText(TextView textView, CharSequence charSequence, String defaultStr) {
        if (textView == null) {
            return;
        }
        if (charSequence == null) {
            charSequence = defaultStr;
        }
        textView.setText(charSequence);
    }

    public static void setOnEditorActionListener(TextView textView, TextView.OnEditorActionListener l) {
        if (textView == null) {
            return;
        }
        textView.setOnEditorActionListener(l);
    }

    public static void setEnabled(View view, boolean enabled) {
        if (view == null) {
            return;
        }
        view.setEnabled(enabled);
    }

    public static void appendText(TextView textView, CharSequence charSequence, String defaultStr) {
        if (textView == null) {
            return;
        }
        if (charSequence == null) {
            charSequence = defaultStr;
        }
        textView.append(charSequence);
    }

    public static void setHint(TextView textView, CharSequence hint) {
        if (textView == null) {
            return;
        }
        if (TextUtils.isEmpty(hint)) {
            return;
        }
        textView.setHint(hint);
    }

    public static void setOnClickListener(View view, View.OnClickListener listener) {
        if (view == null || listener == null) {
            return;
        }
        view.setOnClickListener(listener);
    }
}
