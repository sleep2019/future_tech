package com.shopee.android.ui.choice;

import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Objects;

/**
 * Created by honggang.xiong on 2019-09-27.
 */
public class ChoiceViewHolder extends RecyclerView.ViewHolder {

    /**
     * 可取消选中时，使用 {@link android.widget.CheckBox}
     * 不可取消选中时，使用 {@link android.widget.RadioButton}
     */
    @NonNull
    private CompoundButton mCheckableView;

    /**
     * 默认只对 mTvTitle setText，当不需要额外的 TextView，该变量直接指向 mCheckableView 即可
     */
    @NonNull
    private TextView mTvTitle;

    /**
     * 不可选择时的 mask
     */
    @Nullable
    private View mMaskView;

    /**
     * 额外描述
     */
    @Nullable
    private TextView mTvDesc;

    public ChoiceViewHolder(@NonNull View itemView, @NonNull CompoundButton checkableView) {
        // mTvTitle equals to mCheckableView, it's ok
        this(itemView, checkableView, checkableView);
    }

    public ChoiceViewHolder(@NonNull View itemView, @NonNull CompoundButton checkableView, @NonNull TextView tvTitle) {
        this(itemView, checkableView, tvTitle, null);
    }

    public ChoiceViewHolder(@NonNull View itemView, @NonNull CompoundButton checkableView, @NonNull TextView tvTitle, @Nullable View maskView) {
        this(itemView, checkableView, tvTitle, maskView, null);
    }

    public ChoiceViewHolder(@NonNull View itemView, @NonNull CompoundButton checkableView, @NonNull TextView tvTitle, @Nullable View maskView, @Nullable TextView tvDesc) {
        super(itemView);
        mCheckableView = Objects.requireNonNull(checkableView);
        mTvTitle = Objects.requireNonNull(tvTitle);
        mMaskView = maskView;
        mTvDesc = tvDesc;
        if (mMaskView != null) {
            mMaskView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // If sub class provide a mask, set an empty listener for intercept touch event
                }
            });
        }
    }

    public void bindData(CheckedItem item, boolean adapterEnable) {
        mCheckableView.setChecked(item.isCurrentChecked());
        mTvTitle.setText(item.getTitle());
        if (mMaskView != null) {
            mMaskView.setVisibility(adapterEnable ? View.GONE : View.VISIBLE);
        }
        if (mTvDesc != null) {
            if (item.getDesc() == null) {
                mTvDesc.setVisibility(View.GONE);
            } else {
                mTvDesc.setVisibility(View.VISIBLE);
                mTvDesc.setText(item.getDesc());
            }
        }
    }

    @NonNull
    public CompoundButton getCheckableView() {
        return mCheckableView;
    }

    @NonNull
    public TextView getTvTitle() {
        return mTvTitle;
    }

    @Nullable
    public View getMaskView() {
        return mMaskView;
    }

    @Nullable
    public TextView getTvDesc() {
        return mTvDesc;
    }


    public interface Factory {
        ChoiceViewHolder generate(@NonNull ViewGroup parent, int viewType);
    }

}
