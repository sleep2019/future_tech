package com.shopee.android.ui_library.widget.button;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

/**
 * @ClassName: DrawbleTextView
 * @Description: TextView的left drawable/right drawable居中显示
 * @Author: lanjingzeng
 * @CreateDate: 2020/6/29 12:01 PM
 * @Version: 1.0
 */
public class DrawbleTextView extends AppCompatTextView {

    private boolean mAllCaps;

    public DrawbleTextView(Context context) {
        super(context);
    }

    public DrawbleTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public DrawbleTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void setAllCaps(boolean allCaps) {
        mAllCaps = allCaps;
        setText(getText().toString().toUpperCase());
        super.setAllCaps(allCaps);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //获取左边的图片
        Drawable drawableLeft = getCompoundDrawables()[0];
        if (drawableLeft != null) {
            //如果TextView设置了Gravity，需要将其还原成Left,这样将画布平移后文字才是居中的
            setGravity(Gravity.LEFT);
            //取得字符串的宽度值
            float textWidth;
            if (mAllCaps) {
                textWidth = getPaint().measureText(getText().toString().toUpperCase());
            } else {
                textWidth = getPaint().measureText(getText().toString());
            }
            //获取图片的间距
            int drawablePadding = getCompoundDrawablePadding();
            int drawableWidth;
            //返回图片的固有宽度
            drawableWidth = drawableLeft.getIntrinsicWidth();
            float bodyWidth = textWidth + drawableWidth + drawablePadding;
            canvas.translate((getWidth() - bodyWidth) / 2, 0);
        }
        Drawable drawableRight = getCompoundDrawables()[2];
        if (drawableRight != null) {
            setGravity(Gravity.LEFT);
            float textWidth = getPaint().measureText(getText().toString());
            int drawablePadding = getCompoundDrawablePadding();
            int drawableWidth = 0;
            drawableWidth = drawableRight.getIntrinsicWidth();
            float bodyWidth = textWidth + drawableWidth + drawablePadding;
            setPadding(0, 0, (int) (getWidth() - bodyWidth), 0);
            canvas.translate((getWidth() - bodyWidth) / 2, 0);
        }
        super.onDraw(canvas);
    }
}
