package com.shopee.android.ui.choice;

import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-09-27.
 */
public abstract class BaseChoiceAdapter<T> extends RecyclerView.Adapter<ChoiceViewHolder> {

    private ChoiceViewHolder.Factory mFactory;
    @NonNull
    private final List<CheckedItem<T>> mData;
    private boolean mAdapterEnabled = true;

    public BaseChoiceAdapter(@Nullable List<CheckedItem<T>> originList, @NonNull ChoiceViewHolder.Factory factory) {
        mFactory = factory;
        mData = originList != null ? originList : new ArrayList<CheckedItem<T>>();
    }

    protected abstract void onCheckableViewClicked(int position, CompoundButton checkableView);

    @NonNull
    @Override
    public ChoiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final ChoiceViewHolder viewHolder = mFactory.generate(parent, viewType);
        viewHolder.getCheckableView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseChoiceAdapter.this.onCheckableViewClicked(viewHolder.getLayoutPosition(), viewHolder.getCheckableView());
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ChoiceViewHolder viewHolder, int position) {
        viewHolder.bindData(getItem(position), mAdapterEnabled);
    }

    @NonNull
    public List<CheckedItem<T>> getData() {
        return mData;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public CheckedItem<T> getItem(int position) {
        if (0 <= position && position < getData().size()) {
            return getData().get(position);
        } else {
            return null;
        }
    }

    protected void replaceData(@NonNull Collection<CheckedItem<T>> data) {
        if (data != mData) {
            mData.clear();
            mData.addAll(data);
        }
        notifyDataSetChanged();
    }

    public void setAllToDefault() {
        boolean changed = false;
        for (CheckedItem<T> checkedItem : mData) {
            if (checkedItem.changeToDefault()) {
                changed = true;
            }
        }
        if (changed) {
            notifyDataSetChanged();
        }
    }

    public void clearCheck() {
        boolean changed = false;
        for (CheckedItem<T> checkedItem : mData) {
            if (checkedItem.changeCurrentChecked(false)) {
                changed = true;
            }
        }
        if (changed) {
            notifyDataSetChanged();
        }
    }

    protected boolean changeCheckStatusInternal(int position, boolean checked) {
        CheckedItem<T> item = getItem(position);
        if (item != null) {
            return item.changeCurrentChecked(checked);
        }
        return false;
    }

    public boolean isAdapterEnabled() {
        return mAdapterEnabled;
    }

    public void setAdapterEnabled(boolean adapterEnabled) {
        if (mAdapterEnabled != adapterEnabled) {
            mAdapterEnabled = adapterEnabled;
            notifyDataSetChanged();
        }
    }


    public interface OnCheckedChangeListener<T> {
        void onCheckedChanged(T checkedData, int checkedPosition);
    }

}
