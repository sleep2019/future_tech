package com.shopee.android.ui.choice;

import android.widget.CompoundButton;

import androidx.annotation.NonNull;

import java.util.Collection;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-09-27.
 */
public class MultiChoiceAdapter<T> extends BaseChoiceAdapter<T> {

    private OnMultiCheckedChangeListener<T> mOnMultiCheckedChangeListener;

    public MultiChoiceAdapter(List<CheckedItem<T>> checkedItems, ChoiceViewHolder.Factory generator) {
        super(checkedItems, generator);
    }

    @Override
    protected void onCheckableViewClicked(int position, CompoundButton checkableView) {
        toggleCheckedStatus(position, checkableView.isChecked());
    }

    public void toggleCheckedStatus(int position, boolean checked) {
        if (position < -1 || position >= getData().size()) {
            return;
        }
        if (changeCheckStatusInternal(position, checked)) {
            notifyDataSetChanged();
            if (mOnMultiCheckedChangeListener != null) {
                mOnMultiCheckedChangeListener.onMultiCheckedChanged(getItem(position).getModel(), position, checked);
            }
        }
    }

    @Override
    public void replaceData(@NonNull Collection<CheckedItem<T>> data) {
        super.replaceData(data);
    }

    public void setOnMultiCheckedChangeListener(OnMultiCheckedChangeListener<T> onMultiCheckedChangeListener) {
        this.mOnMultiCheckedChangeListener = onMultiCheckedChangeListener;
    }


    public interface OnMultiCheckedChangeListener<T> {
        void onMultiCheckedChanged(T data, int position, boolean checked);
    }
}
