package com.shopee.android.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Simple Adapter for ListView or GridView.
 *
 * Created by honggang.xiong on 2019-11-15.
 */
public abstract class SimpleListAdapter<T> extends BaseAdapter {

    @LayoutRes
    protected final int mDefaultLayoutRes;
    private final List<T> mDataList = new ArrayList<>();

    public SimpleListAdapter(@LayoutRes int layoutRes) {
        this(null, layoutRes);
    }

    public SimpleListAdapter(@Nullable List<T> list, @LayoutRes int layoutRes) {
        if (list != null && !list.isEmpty()) {
            mDataList.addAll(list);
        }
        mDefaultLayoutRes = layoutRes;
    }

    @Override
    public int getCount() {
        return mDataList.size();
    }

    @Override
    public T getItem(int position) {
        if (position < 0 || position >= mDataList.size()) {
            return null;
        }
        return mDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        SimpleListViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(mDefaultLayoutRes, parent, false);
            viewHolder = new SimpleListViewHolder(convertView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (SimpleListViewHolder) convertView.getTag();
        }

        convert(viewHolder, mDataList.get(position), position);
        return convertView;
    }

    protected abstract void convert(@NonNull SimpleListViewHolder holder, T item, int position);

    /**
     * Replace whole mDataList with the new data.
     *
     * @param newData The new data collection
     */
    public void replaceData(@NonNull Collection<? extends T> newData) {
        mDataList.clear();
        mDataList.addAll(newData);
        notifyDataSetChanged();
    }
}
