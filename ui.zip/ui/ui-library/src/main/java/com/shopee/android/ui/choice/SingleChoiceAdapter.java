package com.shopee.android.ui.choice;

import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-09-27.
 */
public class SingleChoiceAdapter<T> extends BaseChoiceAdapter<T> {

    /**
     * 单选框当前选中的位置，-1 代表无选中
     */
    private int mCheckedPosition = -1;
    private OnCheckedChangeListener<T> mOnCheckedChangeListener;

    public SingleChoiceAdapter(List<T> originList, ChoiceViewHolder.Factory generator, int defaultCheckedPosition) {
        super(generateSingleOrNoneCheckedList(originList, defaultCheckedPosition), generator);
        if (-1 <= defaultCheckedPosition && defaultCheckedPosition < getData().size()) {
            mCheckedPosition = defaultCheckedPosition;
        }
    }

    /**
     * 使用该构造方法时，需确保至多只有一个 item 处于选中态
     */
    public SingleChoiceAdapter(List<CheckedItem<T>> checkedItems, ChoiceViewHolder.Factory generator) {
        super(checkedItems, generator);
        int size = checkedItems.size();
        for (int i = 0; i < size; i++) {
            CheckedItem<T> checkedItem = checkedItems.get(i);
            if (checkedItem.isDefaultChecked()) {
                if (mCheckedPosition == -1) {
                    mCheckedPosition = i;
                } else {
                    throw new IllegalStateException("Can't init SingleChoiceAdapter with more than 1 item checked! Error position is: " + i);
                }
            }
        }
    }

    @Override
    protected void onCheckableViewClicked(int position, CompoundButton checkableView) {
        if (checkableView.isChecked()) {
            check(position);
        } else if (position == mCheckedPosition) {
            clearCheck();
        }
    }

    public int getCheckedPosition() {
        return mCheckedPosition;
    }

    @Nullable
    public T getCheckedData() {
        CheckedItem<T> checkedItem = getItem(mCheckedPosition);
        return checkedItem != null ? checkedItem.getModel() : null;
    }

    public void replaceSingleChoiceData(@Nullable List<T> originList, int defaultCheckedPosition) {
        replaceData(generateSingleOrNoneCheckedList(originList, defaultCheckedPosition));
        if (-1 <= defaultCheckedPosition && defaultCheckedPosition < getData().size()) {
            mCheckedPosition = defaultCheckedPosition;
        }
    }

    public void clearCheck() {
        check(-1);
    }

    public void check(int newPosition) {
        if (newPosition < -1 || newPosition >= getData().size()) {
            return;
        }
        if (newPosition == mCheckedPosition) {
            return;
        }

        boolean changed = changeCheckStatusInternal(mCheckedPosition, false);
        changed |= changeCheckStatusInternal(newPosition, true);
        if (changed) {
            notifyDataSetChanged();
        }
        setCheckedPosition(newPosition);
    }

    private void setCheckedPosition(int position) {
        mCheckedPosition = position;
        CheckedItem<T> curItem = getItem(position);
        if (mOnCheckedChangeListener != null) {
            mOnCheckedChangeListener.onCheckedChanged(curItem != null ? curItem.getModel() : null, mCheckedPosition);
        }
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener<T> onCheckedChangeListener) {
        this.mOnCheckedChangeListener = onCheckedChangeListener;
    }

    @NonNull
    public static <T> List<CheckedItem<T>> generateSingleOrNoneCheckedList(@Nullable List<T> originList, int defaultCheckedPosition) {
        List<CheckedItem<T>> result = new ArrayList<>();
        if (originList != null && !originList.isEmpty()) {
            for (int i = 0; i < originList.size(); i++) {
                result.add(new CheckedItem<>(originList.get(i), i == defaultCheckedPosition));
            }
        }
        return result;
    }


    public interface OnCheckedChangeListener<T> {
        void onCheckedChanged(T checkedData, int checkedPosition);
    }

}
