package com.shopee.android.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.IntRange;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Simple Adapter for RecyclerView with header and footer.
 *
 * Created by honggang.xiong on 2019-11-13.
 */
public abstract class SimpleAdapter<T> extends RecyclerView.Adapter<SimpleViewHolder> {

    public static final int DEFAULT_ITEM_VIEW_TYPE = 0;
    private static final int FLAG_NORMAL_TYPE = 1 << 30;
    private static final int FLAG_HEADER_TYPE = 1 << 29;
    private static final int FLAG_FOOTER_TYPE = 1 << 28;

    protected final List<T> mDataList = new ArrayList<>();

    /**
     * Use Object not generic, cause each header and footer may be a different object.
     */
    private final List<Object> mHeaderList = new ArrayList<>();
    private final List<Object> mFooterList = new ArrayList<>();
    @LayoutRes
    protected final int mDefaultLayoutRes;

    public SimpleAdapter() {
        this(null, 0);
    }

    public SimpleAdapter(@Nullable List<T> list) {
        this(list, 0);
    }

    public SimpleAdapter(@Nullable List<T> list, @LayoutRes int layoutRes) {
        if (list != null && !list.isEmpty()) {
            mDataList.addAll(list);
        }
        mDefaultLayoutRes = layoutRes;
    }

    /**
     * For header and footer, use its index in mHeaderList or mFooterList calculate with specific flag as
     * its viewType.
     * For normal data item, subclass can return its custom viewType in {@link #getDataItemViewType(int)}
     *
     * @param position Position in RecyclerView
     * @return Final viewType
     */
    @Override
    public final int getItemViewType(int position) {
        if (position < mHeaderList.size()) {
            return FLAG_HEADER_TYPE | position;
        } else if (position >= mHeaderList.size() + mDataList.size()) {
            return FLAG_FOOTER_TYPE | (position - mHeaderList.size() - mDataList.size());
        }
        return FLAG_NORMAL_TYPE | getDataItemViewType(position - mHeaderList.size());
    }

    /**
     * Return the view type of the item in mDataList.
     *
     * @param dataPosition Position of item in mDataList.
     * @return viewType
     */
    protected int getDataItemViewType(int dataPosition) {
        return DEFAULT_ITEM_VIEW_TYPE;
    }

    @NonNull
    @Override
    public SimpleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (isNormalType(viewType)) {
            int itemViewType = viewType & ~FLAG_NORMAL_TYPE;
            if (itemViewType == DEFAULT_ITEM_VIEW_TYPE && mDefaultLayoutRes != 0) {
                return new SimpleViewHolder(LayoutInflater.from(parent.getContext()).inflate(mDefaultLayoutRes, parent, false));
            } else {
                return onCreateItemViewHolder(parent, itemViewType);
            }
        } else if (isHeaderType(viewType)) {
            int headerPosition = viewType & ~FLAG_HEADER_TYPE;
            return onCreateHeaderViewHolder(parent, headerPosition);
        } else if (isFooterType(viewType)) {
            int footerPosition = viewType & ~FLAG_FOOTER_TYPE;
            return onCreateFooterViewHolder(parent, footerPosition);
        }
        throw new IllegalArgumentException("unsupported view type: " + viewType);
    }

    /**
     * Return ViewHolder for normal data, subclass should override this method if using custom viewType
     * or mDefaultLayoutRes not specified.
     */
    protected SimpleViewHolder onCreateItemViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SimpleViewHolder(new View(parent.getContext()));
    }

    /**
     * Return ViewHolder for header, subclass should override this method if using header.
     */
    protected SimpleViewHolder onCreateHeaderViewHolder(@NonNull ViewGroup parent, int headerPosition) {
        return new SimpleViewHolder(new View(parent.getContext()));
    }

    /**
     * Return ViewHolder for footer, subclass should override this method if using footer.
     */
    protected SimpleViewHolder onCreateFooterViewHolder(@NonNull ViewGroup parent, int footerPosition) {
        return new SimpleViewHolder(new View(parent.getContext()));
    }

    @Override
    public void onBindViewHolder(@NonNull SimpleViewHolder holder, int position) {
        int viewType = holder.getItemViewType();
        if (isNormalType(viewType)) {
            int dataPosition = position - mHeaderList.size();
            convert(holder, mDataList.get(dataPosition), dataPosition);
        } else if (isHeaderType(viewType)) {
            int headerPosition = viewType & ~FLAG_HEADER_TYPE;
            convertHeader(holder, mHeaderList.get(headerPosition), headerPosition);
        } else if (isFooterType(viewType)) {
            int footerPosition = viewType & ~FLAG_FOOTER_TYPE;
            convertFooter(holder, mFooterList.get(footerPosition), footerPosition);
        }
    }

    /**
     * Implement this method and use the holder to adapt the view to the given item.
     *
     * @param holder       A fully initialized holder
     * @param item         The item that needs to be displayed
     * @param dataPosition Position of item in mDataList
     */
    protected abstract void convert(@NonNull SimpleViewHolder holder, T item, int dataPosition);

    /**
     * Implement this method and use the holder to adapt the header view.
     *
     * @param holder         A fully initialized holder
     * @param item           The item that needs to be displayed
     * @param headerPosition Position of item in mHeaderList
     */
    protected void convertHeader(@NonNull SimpleViewHolder holder, Object item, int headerPosition) {
    }

    /**
     * Implement this method and use the holder to adapt the footer view.
     *
     * @param holder         A fully initialized holder
     * @param item           The item that needs to be displayed
     * @param footerPosition Position of item in mFooterList
     */
    protected void convertFooter(@NonNull SimpleViewHolder holder, Object item, int footerPosition) {
    }

    /**
     * Add new data to the end of mDataList.
     *
     * @param newData The new data collection
     */
    public void addData(@NonNull Collection<? extends T> newData) {
        addData(mDataList.size(), newData);
    }

    /**
     * Add new data in to certain location.
     *
     * @param position The insert position
     * @param newData  The new data collection
     */
    public void addData(@IntRange(from = 0) int position, @NonNull Collection<? extends T> newData) {
        mDataList.addAll(position, newData);
        notifyItemRangeInserted(position + mHeaderList.size(), newData.size());
    }

    /**
     * Clear whole mDataList.
     */
    public void clear() {
        mDataList.clear();
        notifyDataSetChanged();
    }

    /**
     * Replace whole mDataList with the new data.
     *
     * @param newData The new data collection
     */
    public void replaceData(@NonNull Collection<? extends T> newData) {
        mDataList.clear();
        mDataList.addAll(newData);
        notifyDataSetChanged();
    }

    /**
     * Get the data of list
     *
     * @return 列表数据
     */
    @NonNull
    public List<T> getData() {
        return mDataList;
    }

    /**
     * Get the data item associated with the specified position in the data set.
     *
     * @param dataPosition Position of the item whose data we want within the adapter's
     *                     data set.
     * @return The data at the specified position.
     */
    @Nullable
    public T getItem(@IntRange(from = 0) int dataPosition) {
        if (dataPosition >= 0 && dataPosition < mDataList.size()) {
            return mDataList.get(dataPosition);
        } else {
            return null;
        }
    }

    public void addHeader(@NonNull Object item) {
        addHeader(item, mHeaderList.size());
    }

    public void addHeader(@NonNull Object item, int position) {
        mHeaderList.add(position, item);
        notifyItemInserted(position);
    }

    public boolean containHeader(@NonNull Object item) {
        return mHeaderList.contains(item);
    }

    public void removeHeader(@NonNull Object item) {
        int index = mHeaderList.indexOf(item);
        removeHeader(index);
    }

    public void removeHeader(int headerPosition) {
        if (headerPosition >= 0 && headerPosition < mHeaderList.size()) {
            mHeaderList.remove(headerPosition);
            notifyItemRemoved(headerPosition);
        }
    }

    public void refreshHeader(@NonNull Object item) {
        refreshHeader(mHeaderList.indexOf(item));
    }

    public void refreshHeader(int headerPosition) {
        if (headerPosition >= 0 && headerPosition < mHeaderList.size()) {
            notifyItemChanged(headerPosition);
        }
    }

    public void addFooter(@NonNull Object item) {
        addFooter(item, mFooterList.size());
    }

    public void addFooter(@NonNull Object item, int position) {
        mFooterList.add(position, item);
        notifyItemInserted(mHeaderList.size() + mDataList.size() + position);
    }

    public boolean containFooter(@NonNull Object item) {
        return mFooterList.contains(item);
    }

    public void removeFooter(@NonNull Object item) {
        int index = mFooterList.indexOf(item);
        removeFooter(index);
    }

    public void removeFooter(int footerPosition) {
        if (footerPosition >= 0 && footerPosition < mFooterList.size()) {
            mFooterList.remove(footerPosition);
            notifyItemRemoved(mHeaderList.size() + mDataList.size() + footerPosition);
        }
    }

    public void refreshFooter(@NonNull Object item) {
        refreshFooter(mFooterList.indexOf(item));
    }

    public void refreshFooter(int footerPosition) {
        if (footerPosition >= 0 && footerPosition < mFooterList.size()) {
            notifyItemChanged(mHeaderList.size() + mDataList.size() + footerPosition);
        }
    }

    @Override
    public int getItemCount() {
        return mDataList.size() + mHeaderList.size() + mFooterList.size();
    }

    public int getDataSize() {
        return mDataList.size();
    }

    private boolean isNormalType(int viewType) {
        return (viewType & FLAG_NORMAL_TYPE) == FLAG_NORMAL_TYPE;
    }

    private boolean isHeaderType(int viewType) {
        return (viewType & FLAG_HEADER_TYPE) == FLAG_HEADER_TYPE;
    }

    private boolean isFooterType(int viewType) {
        return (viewType & FLAG_FOOTER_TYPE) == FLAG_FOOTER_TYPE;
    }

}
