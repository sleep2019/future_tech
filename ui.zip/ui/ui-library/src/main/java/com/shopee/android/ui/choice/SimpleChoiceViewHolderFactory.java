package com.shopee.android.ui.choice;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.shopee.android.ui_library.R;

/**
 * Created by honggang.xiong on 2019-09-27.
 */
public class SimpleChoiceViewHolderFactory implements ChoiceViewHolder.Factory {

    public static final int DRAWABLE_END_STYLE_ROUND = 1;
    public static final int DRAWABLE_END_STYLE_RECT = 2;
    public static final int DRAWABLE_END_STYLE_TICK = 3;

    /**
     * @return 默认单选框 ViewHolder Factory，圆形标记，不可取消选中
     */
    public static SimpleChoiceViewHolderFactory createSingleChoiceNormal() {
        return create(DRAWABLE_END_STYLE_ROUND, true);
    }

    /**
     * @return 默认多选框 ViewHolder Factory，方形标记，可取消选中
     */
    public static SimpleChoiceViewHolderFactory createMultiChoiceNormal() {
        return create(DRAWABLE_END_STYLE_RECT, false);
    }

    public static SimpleChoiceViewHolderFactory create(int drawableEndStyle) {
        return create(drawableEndStyle, true);
    }

    public static SimpleChoiceViewHolderFactory create(int drawableEndStyle, boolean useRadioButton) {
        return new SimpleChoiceViewHolderFactory(drawableEndStyle, useRadioButton, false);
    }

    public static SimpleChoiceViewHolderFactory create(int drawableEndStyle, boolean useRadioButton, boolean showDivider) {
        return new SimpleChoiceViewHolderFactory(drawableEndStyle, useRadioButton, showDivider);
    }

    private final int mDrawableEndStyle;
    private final boolean mUseRadioButton;
    private final boolean mShowDivider;

    private SimpleChoiceViewHolderFactory(int drawableEndStyle, boolean useRadioButton, boolean showDivider) {
        mDrawableEndStyle = drawableEndStyle;
        mUseRadioButton = useRadioButton;
        mShowDivider = showDivider;
    }

    @Override
    public ChoiceViewHolder generate(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(getLayoutId(), parent, false);
        CompoundButton compoundButton = itemView.findViewById(R.id.compound_button);
        compoundButton.setCompoundDrawablesWithIntrinsicBounds(0, 0, getDrawableRes(), 0);
        TextView tvTitle = itemView.findViewById(R.id.tv_ratio_title);
        View maskView = itemView.findViewById(R.id.view_mask);
        TextView tvDesc = itemView.findViewById(R.id.tv_ratio_desc);
        itemView.findViewById(R.id.divider).setVisibility(mShowDivider ? View.VISIBLE : View.GONE);
        return new ChoiceViewHolder(itemView, compoundButton, tvTitle, maskView, tvDesc);
    }

    private int getLayoutId() {
        return mUseRadioButton ? R.layout.ui_library_item_choice_radio : R.layout.ui_library_item_choice_checkbox;
    }

    private int getDrawableRes() {
        if (mDrawableEndStyle == DRAWABLE_END_STYLE_RECT) {
            return R.drawable.ui_library_selector_radio_rect;
        } else if (mDrawableEndStyle == DRAWABLE_END_STYLE_TICK) {
            return R.drawable.ui_library_selector_radio_tick;
        } else {
            return R.drawable.ui_library_selector_radio_round;
        }
    }

}
