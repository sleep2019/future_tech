package com.shopee.android.ui.widget.picker;

/**
 * Numeric Wheel adapter.
 */
public class NumericWheelAdapter implements WheelAdapter<Integer> {

    /**
     * The default min value
     */
    public static final int DEFAULT_MAX_VALUE = 9;

    /**
     * The default max value
     */
    public static final int DEFAULT_MIN_VALUE = 0;

    // Values
    private int mMinValue;
    private int mMaxValue;

    private String mSuffix;
    private String mPrefix;

    /**
     * Default constructor
     */
    public NumericWheelAdapter() {
        this(DEFAULT_MIN_VALUE, DEFAULT_MAX_VALUE);
    }

    /**
     * Constructor
     *
     * @param minValue the wheel min value
     * @param maxValue the wheel max value
     */
    public NumericWheelAdapter(int minValue, int maxValue) {
        this(minValue, maxValue, null);
    }

    public NumericWheelAdapter(int minValue, int maxValue, String suffix) {
        this(minValue, maxValue, suffix, null);
    }

    public NumericWheelAdapter(int minValue, int maxValue, String suffix, String prefix) {
        mMinValue = minValue;
        mMaxValue = maxValue;
        mSuffix = suffix;
        mPrefix = prefix;
    }

    @Override
    public Integer getItem(int index) {
        if (index >= 0 && index < getItemCount()) {
            return mMinValue + index;
        }
        return 0;
    }

    @Override
    public String getDisplayText(int index) {
        int value = getItem(index);
        return (mPrefix == null ? "" : mPrefix)
                + (value < 10 ? "0" : "") + value
                + (mSuffix == null ? "" : mSuffix);
    }

    @Override
    public int getItemCount() {
        return mMaxValue - mMinValue + 1;
    }

    @Override
    public int indexOf(Integer o) {
        return o - mMinValue;
    }
}
