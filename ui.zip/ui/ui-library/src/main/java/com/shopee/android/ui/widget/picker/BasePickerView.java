package com.shopee.android.ui.widget.picker;

import android.animation.Animator;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.FrameLayout;

import com.shopee.android.ui_library.R;

public abstract class BasePickerView {

    private Context mContext;
    private ViewGroup mDecorView;  // activity 的 root View
    private ViewGroup mRootView;   // 附加 View 的 root View
    private ViewGroup mDialogView; // 附加 Dialog 的 root View
    protected ViewGroup mContentContainer;

    private OnDismissListener mOnDismissListener;
    private boolean mDismissing;
    private boolean mIsShowing;

    protected boolean mIsDialog;
    private Dialog mDialog;

    public BasePickerView(Context context, boolean isDialog) {
        mContext = context;
        mIsDialog = isDialog;
        initViews();
        initEvents();
    }

    protected void initViews() {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);

        if (isDialog()) {
            mDialogView = (ViewGroup) layoutInflater.inflate(R.layout.ui_library_layout_base_picker_view, null, false);
            mDialogView.setBackgroundColor(Color.TRANSPARENT);
            mContentContainer = mDialogView.findViewById(R.id.content_container);
            mContentContainer.setLayoutParams(lp);
            createDialog();
            mDialogView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BasePickerView.this.dismiss();
                }
            });
        } else {
            mDecorView = ((Activity) mContext).getWindow().getDecorView().findViewById(android.R.id.content);
            mRootView = (ViewGroup) layoutInflater.inflate(R.layout.ui_library_layout_base_picker_view, mDecorView, false);
            mRootView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            mContentContainer = mRootView.findViewById(R.id.content_container);
            mContentContainer.setLayoutParams(lp);
        }
    }

    protected void initEvents() {
    }

    /**
     * 添加这个View到Activity的根视图
     */
    public void show() {
        if (isDialog()) {
            showDialog();
        } else {
            if (isShowing()) {
                return;
            }
            mIsShowing = true;
            onAttached(mRootView);
            mRootView.requestFocus();
        }
    }

    /**
     * show的时候调用
     *
     * @param view 这个View
     */
    private void onAttached(View view) {
        mDecorView.addView(view);
        mContentContainer.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                mContentContainer.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                mContentContainer.setTranslationY(mContentContainer.getHeight());
                mContentContainer.animate().translationY(0).setDuration(300).start();
            }
        });
    }

    /**
     * 检测该 View 是不是已经添加到根视图
     *
     * @return 如果视图已经存在该 View 返回 true
     */
    public boolean isShowing() {
        return !isDialog() && (mRootView.getParent() != null || mIsShowing);
    }

    public void dismiss() {
        if (isDialog()) {
            dismissDialog();
        } else {
            if (mDismissing) {
                return;
            }

            mDismissing = true;

            mContentContainer.animate()
                    .translationY(mContentContainer.getHeight())
                    .setDuration(300)
                    .setListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animation) {

                        }

                        @Override
                        public void onAnimationEnd(Animator animation) {
                            mDecorView.post(new Runnable() {
                                @Override
                                public void run() {
                                    dismissImmediately();
                                }
                            });
                        }

                        @Override
                        public void onAnimationCancel(Animator animation) {

                        }

                        @Override
                        public void onAnimationRepeat(Animator animation) {

                        }
                    })
                    .start();
        }
    }

    public void dismissImmediately() {
        // 从 activity 根视图移除
        mDecorView.removeView(mRootView);
        mIsShowing = false;
        mDismissing = false;
        if (mOnDismissListener != null) {
            mOnDismissListener.onDismiss(BasePickerView.this);
        }
    }

    public BasePickerView setOnDismissListener(OnDismissListener onDismissListener) {
        this.mOnDismissListener = onDismissListener;
        return this;
    }

    protected BasePickerView setOutSideCancelable(boolean isCancelable) {
        if (mRootView != null) {
            View view = mRootView.findViewById(R.id.outer_container);

            if (isCancelable) {
                view.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            dismiss();
                        }
                        return false;
                    }
                });
            } else {
                view.setOnTouchListener(null);
            }
        }

        return this;
    }

    public final <T extends View> T findViewById(int id) {
        return mContentContainer.findViewById(id);
    }

    public void createDialog() {
        if (mDialogView != null) {
            mDialog = new Dialog(mContext, R.style.UiLibraryCustomDialog_BottomAnimation);
            mDialog.setCancelable(true);
            mDialog.setContentView(mDialogView);
            Window window = mDialog.getWindow();
            if (window != null) {
                window.setGravity(Gravity.BOTTOM);
            }
        }
    }

    public void showDialog() {
        if (mDialog != null) {
            mDialog.show();
        }
    }

    public void dismissDialog() {
        if (mDialog != null) {
            mDialog.dismiss();
        }
    }

    public boolean isDialog() {
        return mIsDialog;
    }

    public ViewGroup getDialogContainerLayout() {
        return mContentContainer;
    }

    public Dialog getDialog() {
        return mDialog;
    }


    public interface OnDismissListener {
        void onDismiss(BasePickerView basePickerView);
    }

}
