package com.shopee.android.ui.widget.dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shopee.android.ui.choice.SimpleChoiceViewHolderFactory;
import com.shopee.android.ui.choice.SingleChoiceAdapter;
import com.shopee.android.ui_library.R;

import java.util.List;

/**
 * Created by honggang.xiong on 2019-05-27.
 */
public class SingleChoiceDialog<T> extends CustomizeDialog {

    private TextView mTvTitle;
    private Button mBtnConfirm;
    private SingleChoiceAdapter<T> mSingleChoiceAdapter;
    private SingleChoiceAdapter.OnCheckedChangeListener<T> mOuterListener;
    private boolean mDismissOnCheckedChanged = false;

    public SingleChoiceDialog(@NonNull Context context, @NonNull SingleChoiceAdapter<T> adapter, boolean useRoundStyle) {
        super(context, useRoundStyle ? R.layout.ui_library_dialog_single_choice_round : R.layout.ui_library_dialog_single_choice, POSITION_BOTTOM);

        mTvTitle = findViewById(R.id.tv_title);
        mBtnConfirm = findViewById(R.id.btn_confirm);
        View ivClose = findViewById(R.id.iv_close);
        View viewTransparent = findViewById(R.id.view_transparent);
        if (ivClose != null) {
            ivClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SingleChoiceDialog.this.dismiss();
                }
            });
        }
        if (viewTransparent != null) {
            viewTransparent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SingleChoiceDialog.this.dismiss();
                }
            });
        }

        mSingleChoiceAdapter = adapter;
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(adapter);
        adapter.setOnCheckedChangeListener(new SingleChoiceAdapter.OnCheckedChangeListener<T>() {
            @Override
            public void onCheckedChanged(T checkedData, int checkedPosition) {
                mBtnConfirm.setEnabled(checkedPosition != -1);
                if (mOuterListener != null) {
                    mOuterListener.onCheckedChanged(checkedData, checkedPosition);
                }
                if (mDismissOnCheckedChanged) {
                    SingleChoiceDialog.this.dismiss();
                }
            }
        });
        mBtnConfirm.setEnabled(adapter.getCheckedPosition() != -1);
    }

    public void setTitleText(CharSequence title) {
        mTvTitle.setText(title);
    }

    public void setConfirmText(CharSequence title) {
        mBtnConfirm.setText(title);
    }

    public void setConfirmClickedListener(View.OnClickListener listener) {
        setConfirmClickedListener(listener, true);
    }

    public void setConfirmClickedListener(final View.OnClickListener listener, final boolean autoDismiss) {
        mBtnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onClick(v);
                }
                if (autoDismiss) {
                    SingleChoiceDialog.this.dismiss();
                }
            }
        });
    }

    public void check(int position) {
        mSingleChoiceAdapter.check(position);
    }

    public int getCheckedPosition() {
        return mSingleChoiceAdapter.getCheckedPosition();
    }

    public void setOnCheckedChangeListener(SingleChoiceAdapter.OnCheckedChangeListener<T> onCheckedChangeListener) {
        mOuterListener = onCheckedChangeListener;
    }

    public void setDismissOnCheckedChanged(boolean dismissOnCheckedChanged) {
        mDismissOnCheckedChanged = dismissOnCheckedChanged;
    }

    public static <T> Builder<T> newBuilder(Context context, List<T> data, int checkedPosition) {
        return new Builder<>(context, new SingleChoiceAdapter<>(data, SimpleChoiceViewHolderFactory.createSingleChoiceNormal(), checkedPosition));
    }

    public static <T> Builder<T> newBuilder(Context context, SingleChoiceAdapter<T> adapter) {
        return new Builder<>(context, adapter);
    }


    public static final class Builder<T> {

        private Context mContext;
        private SingleChoiceAdapter<T> mAdapter;
        private CharSequence mTitle = "";
        private CharSequence mConfirmMsg;
        private View.OnClickListener mConfirmOnclickListener;
        private DialogInterface.OnDismissListener mOnDismissListener;
        private SingleChoiceAdapter.OnCheckedChangeListener<T> mOnCheckedChangeListener;

        private boolean mUseRoundStyle = false;
        private boolean mDismissOnConfirmClicked = true;
        private boolean mDismissOnCheckedChanged = false;
        private boolean mCancelable = true;

        private Builder(@NonNull Context context, SingleChoiceAdapter<T> adapter) {
            mContext = context;
            mAdapter = adapter;
        }

        public Builder<T> useRoundStyle(boolean useRoundStyle) {
            mUseRoundStyle = useRoundStyle;
            return this;
        }

        public Builder<T> title(@Nullable CharSequence val) {
            mTitle = val;
            return this;
        }

        public Builder<T> title(@StringRes int val) {
            mTitle = mContext.getText(val);
            return this;
        }

        public Builder<T> confirm(CharSequence msg, View.OnClickListener listener) {
            mConfirmMsg = msg;
            mConfirmOnclickListener = listener;
            return this;
        }

        public Builder<T> confirm(@StringRes int val, View.OnClickListener listener) {
            mConfirmMsg = mContext.getText(val);
            mConfirmOnclickListener = listener;
            return this;
        }

        public Builder<T> dismissOnConfirmClicked(boolean dismissWhenConfirmClicked) {
            mDismissOnConfirmClicked = dismissWhenConfirmClicked;
            return this;
        }

        public Builder<T> dismissOnCheckedChanged(boolean dismissOnCheckedChange) {
            mDismissOnCheckedChanged = dismissOnCheckedChange;
            return this;
        }

        public Builder<T> setCancelable(boolean cancelable) {
            mCancelable = cancelable;
            return this;
        }

        public Builder<T> setOnDismissListener(DialogInterface.OnDismissListener onDismissListener) {
            mOnDismissListener = onDismissListener;
            return this;
        }

        public Builder<T> setOnCheckedChangeListener(SingleChoiceAdapter.OnCheckedChangeListener<T> onCheckedChangeListener) {
            mOnCheckedChangeListener = onCheckedChangeListener;
            return this;
        }

        public SingleChoiceDialog<T> build() {
            SingleChoiceDialog<T> dialog = new SingleChoiceDialog<>(mContext, mAdapter, mUseRoundStyle);
            dialog.setTitleText(mTitle);
            dialog.setConfirmText(mConfirmMsg);
            dialog.setConfirmClickedListener(mConfirmOnclickListener, mDismissOnConfirmClicked);
            dialog.setOnDismissListener(mOnDismissListener);
            dialog.setOnCheckedChangeListener(mOnCheckedChangeListener);
            dialog.setDismissOnCheckedChanged(mDismissOnCheckedChanged);
            dialog.setCancelable(mCancelable);
            if (mCancelable) {
                dialog.setCanceledOnTouchOutside(true);
            }
            return dialog;
        }

        public SingleChoiceDialog<T> show() {
            SingleChoiceDialog<T> dialog = build();
            dialog.show();
            return dialog;
        }
    }

}
