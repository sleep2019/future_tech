package com.shopee.android.ui_library.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.RequiresApi;
import androidx.annotation.StringRes;

import com.shopee.android.ui_library.R;
import com.shopee.android.ui_library.widget.util.ViewUtil;

/**
 * @ClassName: EmptyLayout
 * @Description: 空视图
 * @Author: lanjingzeng
 * @CreateDate: 2020/6/29 3:57 PM
 * @Version: 1.0
 */
public class EmptyLayout extends RelativeLayout {
    private TextView mTvTips;
    private ImageView mIvNoData;
    private Context mContext;

    public EmptyLayout(Context context) {
        super(context);
        init(context, null, 0, 0);
    }

    public EmptyLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs, 0, 0);
    }

    public EmptyLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr, 0);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public EmptyLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs, defStyleAttr, defStyleRes);
    }


    private void init(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        mContext = context;
        //初始化view
        //先处理自身的padding,否则设置的padding无效
        setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom());
        View contentView = LayoutInflater.from(context).inflate(R.layout.ui_library_empty_layout, this, true);
        mIvNoData = (ImageView) contentView.findViewById(R.id.iv_empty_data);
        mTvTips = (TextView) contentView.findViewById(R.id.tv_tips);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.EmptyLayout, defStyleAttr, defStyleRes);
        Drawable emptyBackgroundDrawable = typedArray.getDrawable(R.styleable.EmptyLayout_uiLibraryEmptyBackground);
        Drawable emptySrcDrawable = typedArray.getDrawable(R.styleable.EmptyLayout_uiLibraryEmptySrc);
        String emtyText = typedArray.getString(R.styleable.EmptyLayout_uiLibraryEmptyText);
        if (emptyBackgroundDrawable != null) {
            contentView.setBackground(emptyBackgroundDrawable);
        }

        if (!TextUtils.isEmpty(emtyText)) {
            setEmptyMsg(emtyText);
        }

        if (emptySrcDrawable != null) {
            setEmptyDrawble(emptySrcDrawable);
        }

        typedArray.recycle();
    }

    public void setEmptyMsg(@StringRes int stringRes) {
        String msg = mContext.getString(stringRes);
        setEmptyMsg(msg);
    }

    public void setEmptyMsg(CharSequence charSequence) {
        ViewUtil.setText(mTvTips, charSequence, mContext.getString(R.string.ui_library_empty_layout_no_data_tips));
    }

    public void setEmptyDrawble(@DrawableRes int drawableRes) {
        Drawable drawable = mContext.getResources().getDrawable(drawableRes);
        setEmptyDrawble(drawable);
    }

    public void setEmptyDrawble(Drawable drawable) {
        mIvNoData.setImageDrawable(drawable);
    }
}
