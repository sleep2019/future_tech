package com.shopee.android.ui_library.widget.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.shopee.android.ui_library.R;
import com.shopee.android.ui_library.widget.util.ViewUtil;

/**
 * @ClassName: CustomOneButton
 * @Description: 公共按钮
 * @Author: lanjingzeng
 * @CreateDate: 2020/6/23 5:02 PM
 * @Version: 1.0
 */
public class CustomOneButton extends RelativeLayout {
    private DrawbleTextView mTv;

    public CustomOneButton(Context context) {
        super(context);
        init(context, null, 0, 0);
    }

    public CustomOneButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs, 0, 0);
    }

    public CustomOneButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr, 0);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public CustomOneButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs, defStyleAttr, defStyleRes);
    }

    private void init(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        //初始化view
        //先处理自身的padding,否则设置的padding无效
        setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom());
        View contentView = LayoutInflater.from(context).inflate(R.layout.ui_library_custom_one_botton, this, true);
        //设置了clickable为true 才会响应press的状态，变更控件的背景
        contentView.setClickable(true);
        mTv = (DrawbleTextView) contentView.findViewById(R.id.btn);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomOneButton, defStyleAttr, defStyleRes);
        float padding = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnPadding, 0);
        float leftPadding = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnPaddingLeft, 0);
        float topPadding = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnPaddingTop, 0);
        float rightPadding = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnPaddingRight, 0);
        float bottomPadding = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnPaddingBottom, 0);

        float margin = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnMargin, 0);
        float leftMargin = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnMarginLeft, 0);
        float topMargin = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnMarginTop, 0);
        float rightMargin = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnMarginRight, 0);
        float bottomMargin = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnMarginBottom, 0);
        String text = typedArray.getString(R.styleable.CustomOneButton_uiLibraryText);
        boolean textAllCaps = typedArray.getBoolean(R.styleable.CustomOneButton_android_textAllCaps, false);
        int textStyle = typedArray.getInt(R.styleable.CustomOneButton_uiLibraryTextStyle, Typeface.NORMAL);
        float textSize = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryTextSize, getResources().getDimension(R.dimen.ui_library_custom_one_button_text_size));
        ColorStateList textColorStateList = typedArray.getColorStateList(R.styleable.CustomOneButton_uiLibraryTextColor);
        if (textColorStateList == null) {
            textColorStateList = ColorStateList.valueOf(getResources().getColor(R.color.ui_library_custom_one_button_txt_white_FFFFFF));
        }
        Drawable btnBackgroundDrawable = typedArray.getDrawable(R.styleable.CustomOneButton_uiLibraryBtnBackground);
        if (btnBackgroundDrawable == null) {
            btnBackgroundDrawable = getResources().getDrawable(R.drawable.ui_library_bg_custom_one_button_orange_selector_gradient_2);
        }
        Drawable rootBackgroundDrawable = typedArray.getDrawable(R.styleable.CustomOneButton_uiLibraryRootBackground);

        Drawable btnDrawableLeft = typedArray.getDrawable(R.styleable.CustomOneButton_uiLibraryBtnDrawableLeft);
        float btnDrawablePadding = typedArray.getDimension(R.styleable.CustomOneButton_uiLibraryBtnDrawablePadding, 0);
        ViewUtil.setPadding(mTv, (int) padding, (int) leftPadding, (int) topPadding, (int) rightPadding, (int) bottomPadding);
        ViewUtil.setMargin(mTv, (int) margin, (int) leftMargin, (int) topMargin, (int) rightMargin, (int) bottomMargin);
        ViewUtil.setTextSize(mTv, textSize);
        setTextStyle(mTv, textStyle);
        mTv.setTextColor(textColorStateList);
        mTv.setAllCaps(textAllCaps);
        if (rootBackgroundDrawable != null) {
            contentView.setBackground(rootBackgroundDrawable);
        }
        if (btnBackgroundDrawable != null) {
            mTv.setBackground(btnBackgroundDrawable);
        }
        if (btnDrawableLeft != null) {
            btnDrawableLeft.setBounds(0, 0, btnDrawableLeft.getIntrinsicWidth(), btnDrawableLeft.getMinimumHeight());
            mTv.setCompoundDrawables(btnDrawableLeft, null, null, null);
            mTv.setCompoundDrawablePadding((int) btnDrawablePadding);
        }
        if (!TextUtils.isEmpty(text)) {
            mTv.setText(text);
        }

        boolean enabled = typedArray.getBoolean(R.styleable.CustomOneButton_android_enabled, true);
        setEnabled(enabled);

        typedArray.recycle();
    }

    public void setTextStyle(TextView textView, int style) {
        if (style == 0) {//与attr中定义的值相对应
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        } else if (style == 1) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        } else if (style == 2) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
        } else if (style == 3) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD_ITALIC));
        }
    }

    public void setText(CharSequence charSequence) {
        ViewUtil.setText(mTv, charSequence, "");
    }

    public CharSequence getText(){
        return mTv.getText();
    }
}
