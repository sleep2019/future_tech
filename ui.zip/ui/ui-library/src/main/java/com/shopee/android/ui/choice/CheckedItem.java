package com.shopee.android.ui.choice;

/**
 * Created by honggang.xiong on 2019-09-27.
 */
public class CheckedItem<T> {

    /**
     * 回调时返回的数据，如不需要，可传空
     */
    private final T model;

    /**
     * 默认选中状态，单选时整个数据集至多有一个为true，多选时无要求
     */
    private final boolean defaultChecked;

    /**
     * 当前选中状态
     */
    private boolean currentChecked;

    /**
     * 选项标题
     */
    private String title;

    /**
     * 选项描述
     */
    private String desc;

    public CheckedItem(T model, boolean defaultChecked) {
        this(model, defaultChecked, tryGetTitleFromModel(model), null);
    }

    public CheckedItem(T model, boolean defaultChecked, String title) {
        this(model, defaultChecked, title, null);
    }

    public CheckedItem(T model, boolean defaultChecked, String title, String desc) {
        this.model = model;
        this.defaultChecked = defaultChecked;
        this.title = title;
        this.desc = desc;
        currentChecked = defaultChecked;
    }

    private static String tryGetTitleFromModel(Object model) {
        if (model != null) {
            if (model instanceof String) {
                return (String) model;
            }
            if (model instanceof ICheckedItemDisplayTitle) {
                return ((ICheckedItemDisplayTitle) model).getCheckedItemDisplayTitle();
            }
        }
        return null;
    }

    public boolean changeToDefault() {
        return changeCurrentChecked(defaultChecked);
    }

    public boolean changeCurrentChecked(boolean checked) {
        if (currentChecked == checked) {
            return false;
        }
        currentChecked = checked;
        return true;
    }

    public T getModel() {
        return model;
    }

    public boolean isDefaultChecked() {
        return defaultChecked;
    }

    public boolean isCurrentChecked() {
        return currentChecked;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public String toString() {
        return "CheckedItem{" +
                "model=" + model +
                ", defaultChecked=" + defaultChecked +
                ", currentChecked=" + currentChecked +
                ", title='" + title + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }
}
