package com.shopee.android.ui_library.widget.item;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.annotation.RequiresApi;
import androidx.annotation.StringRes;

import com.shopee.android.ui_library.R;
import com.shopee.android.ui_library.widget.util.ViewUtil;


/**
 * @ClassName: ItemComponentView
 * @Description: item数据视图
 * 参考文档：https://confluence.shopee.io/pages/viewpage.action?pageId=147970901
 * @Author: lanjingzeng
 * @CreateDate: 2020/6/2 6:35 PM
 * @Version: 1.0
 */
public class ItemComponentView extends RelativeLayout {
    public final static int ITEM_LEFT_ONE_TEXT = 1;
    public final static int ITEM_LEFT_TWO_TEXT = 2;
    public final static int ITEM_RIGHT_ONE_TEXT = 3;
    public final static int ITEM_RIGHT_TAG = 4;
    public final static int ITEM_RIGHT_ICON = 5;
    public final static int ITEM_RIGHT = 6;

    private static final int MODE_LEFT_ONE_TEXT = 11;
    private static final int MODE_LEFT_ONE_TEXT_RIGHT_ICON = 12;
    private static final int MODE_LEFT_ONE_TEXT_RIGHT_TEXT = 13;
    private static final int MODE_LEFT_ONE_TEXT_RIGHT_TAG = 14;
    private static final int MODE_LEFT_ONE_TEXT_RIGHT_TEXT_ICON = 15;
    private static final int MODE_LEFT_ONE_TEXT_RIGHT_TAG_ICON = 16;
    private static final int MODE_LEFT_ONE_TEXT_RIGHT_TEXT_TAG = 17;
    private static final int MODE_LEFT_ONE_TEXT_RIGHT_TEXT_TAG_ICON = 18;

    private static final int MODE_LEFT_TWO_TEXT = 21;
    private static final int MODE_LEFT_TWO_TEXT_RIGHT_ICON = 22;
    private static final int MODE_LEFT_TWO_TEXT_RIGHT_TEXT = 23;
    private static final int MODE_LEFT_TWO_TEXT_RIGHT_TAG = 24;
    private static final int MODE_LEFT_TWO_TEXT_RIGHT_TEXT_ICON = 25;
    private static final int MODE_LEFT_TWO_TEXT_RIGHT_TAG_ICON = 26;
    private static final int MODE_LEFT_TWO_TEXT_RIGHT_TEXT_TAG = 27;
    private static final int MODE_LEFT_TWO_TEXT_RIGHT_TEXT_TAG_ICON = 28;

    private static final int MODE_RIGHT_TEXT = 31;

    private static final int BASELINE_LEFT = 1;
    private static final int BASELINE_RIGHT = 2;

    private static final int LAYOUT_DERACTION_LTR = 0;
    private static final int LAYOUT_DERACTION_RTL = 1;

    private static final ImageView.ScaleType[] sScaleTypeArray = {
            ImageView.ScaleType.MATRIX,
            ImageView.ScaleType.FIT_XY,
            ImageView.ScaleType.FIT_START,
            ImageView.ScaleType.FIT_CENTER,
            ImageView.ScaleType.FIT_END,
            ImageView.ScaleType.CENTER,
            ImageView.ScaleType.CENTER_CROP,
            ImageView.ScaleType.CENTER_INSIDE
    };

    protected Context mContext;
    private RelativeLayout mRlLeft;
    private LinearLayout mLlRight;
    protected TextView mTvLeftOne;
    protected TextView mTvLeftTwo;
    protected RelativeLayout mRlRight;
    protected TextView mTvRightOne;
    protected TextView mTvTag;
    protected ImageView mIvIcon;
    private float mWeightSum;
    private float mLeftWeight;
    private float mRightWeight;

    public ItemComponentView(Context context) {
        super(context);
        init(context, null, 0, 0);
    }

    public ItemComponentView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs, 0, 0);
    }

    public ItemComponentView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr, 0);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ItemComponentView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs, defStyleAttr, defStyleRes);
    }

    private void init(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        this.mContext = context;
        //初始化view
        //先处理自身的padding,否则设置的padding无效
        setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom());
        View contentView = LayoutInflater.from(mContext).inflate(R.layout.ui_library_item_component, this, true);
        mRlLeft = (RelativeLayout) contentView.findViewById(R.id.rl_left);
        mTvLeftOne = (TextView) contentView.findViewById(R.id.tv_left_one);
        mTvLeftTwo = (TextView) contentView.findViewById(R.id.tv_left_two);
        mRlRight = (RelativeLayout) contentView.findViewById(R.id.rl_right);
        mLlRight = (LinearLayout) contentView.findViewById(R.id.ll_right_info);
        EditText etRightOne = (EditText) contentView.findViewById(R.id.et_right_one);
        TextView tvRightOne = (TextView) contentView.findViewById(R.id.tv_right_one);
        mTvTag = (TextView) contentView.findViewById(R.id.tv_tag);
        mIvIcon = (ImageView) contentView.findViewById(R.id.iv_icon);

        //处理mTvLeftOne视图
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.ItemComponentView, defStyleAttr, defStyleRes);

        float textSize = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOneTextSize, getResources().getDimension(R.dimen.ui_library_item_component_text_size_16));
        ColorStateList textColorStateList = typedArray.getColorStateList(R.styleable.ItemComponentView_uiLibraryLeftOneTextColor);
        if (textColorStateList == null) {
            textColorStateList = ColorStateList.valueOf(getResources().getColor(R.color.ui_library_item_component_txt_black_191919));
        }
        int hintColor = typedArray.getColor(R.styleable.ItemComponentView_uiLibraryLeftOneHintColor, getResources().getColor(R.color.ui_library_item_component_txt_black_191919));
        int textStyle = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryLeftOneTextStyle, Typeface.NORMAL);
        float margin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOneMargin, 0);
        float leftMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOneMarginLeft, 0);
        float topMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOneMarginTop, 0);
        float rightMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOneMarginRight, 0);
        float bottomMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOneMarginBottom, 0);
        float padding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOnePading, 0);
        float leftPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOnePadingLeft, 0);
        float topPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOnePadingTop, 0);
        float rightPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOnePadingRight, 0);
        float bottomPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftOnePadingBottom, 0);
        String text = typedArray.getString(R.styleable.ItemComponentView_uiLibraryLeftOneText);
        String hint = typedArray.getString(R.styleable.ItemComponentView_uiLibraryLeftOneHint);
        Drawable backgroundDrawable = typedArray.getDrawable(R.styleable.ItemComponentView_uiLibraryLeftOneBackground);

        ViewUtil.setPadding(mTvLeftOne, (int) padding, (int) leftPadding, (int) topPadding, (int) rightPadding, (int) bottomPadding);
        ViewUtil.setMargin(mTvLeftOne, (int) margin, (int) leftMargin, (int) topMargin, (int) rightMargin, (int) bottomMargin);
        ViewUtil.setTextSize(mTvLeftOne, textSize);
        mTvLeftOne.setTextColor(textColorStateList);
        mTvLeftOne.setHintTextColor(hintColor);
        setTextStyle(mTvLeftOne, textStyle);
        if (!TextUtils.isEmpty(text)) {
            mTvLeftOne.setText(text);
        }
        if (!TextUtils.isEmpty(hint)) {
            mTvLeftOne.setHint(hint);
        }
        if (backgroundDrawable != null) {
            mTvLeftOne.setBackground(backgroundDrawable);
        }

        //处理mTvLeftTwo视图
        textSize = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoTextSize, getResources().getDimension(R.dimen.ui_library_item_component_text_size_14));
        textColorStateList = typedArray.getColorStateList(R.styleable.ItemComponentView_uiLibraryLeftTwoTextColor);
        if (textColorStateList == null) {
            textColorStateList = ColorStateList.valueOf(getResources().getColor(R.color.ui_library_item_component_txt_gray_8C9AAB));
        }
        hintColor = typedArray.getColor(R.styleable.ItemComponentView_uiLibraryLeftTwoHintColor, getResources().getColor(R.color.ui_library_item_component_txt_gray_8C9AAB));
        textStyle = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryLeftTwoTextStyle, Typeface.NORMAL);
        margin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoMargin, 0);
        leftMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoMarginLeft, 0);
        topMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoMarginTop, getResources().getDimension(R.dimen.ui_library_item_component_space_8));
        rightMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoMarginRight, 0);
        bottomMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoMarginBottom, 0);
        padding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoPading, 0);
        leftPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoPadingLeft, 0);
        topPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoPadingTop, 0);
        rightPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoPadingRight, 0);
        bottomPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryLeftTwoPadingBottom, 0);
        text = typedArray.getString(R.styleable.ItemComponentView_uiLibraryLeftTwoText);
        hint = typedArray.getString(R.styleable.ItemComponentView_uiLibraryLeftTwoHint);
        int visibility = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryLeftTwoVisibility, View.VISIBLE);
        backgroundDrawable = typedArray.getDrawable(R.styleable.ItemComponentView_uiLibraryLeftTwoBackground);

        ViewUtil.setPadding(mTvLeftTwo, (int) padding, (int) leftPadding, (int) topPadding, (int) rightPadding, (int) bottomPadding);
        ViewUtil.setMargin(mTvLeftTwo, (int) margin, (int) leftMargin, (int) topMargin, (int) rightMargin, (int) bottomMargin);
        ViewUtil.setTextSize(mTvLeftTwo, textSize);
        setTextStyle(mTvLeftTwo, textStyle);
        mTvLeftTwo.setTextColor(textColorStateList);
        mTvLeftTwo.setHintTextColor(hintColor);
        if (!TextUtils.isEmpty(text)) {
            mTvLeftTwo.setText(text);
        }
        if (!TextUtils.isEmpty(hint)) {
            mTvLeftTwo.setHint(hint);
        }
        ViewUtil.setVisibility(mTvLeftTwo, visibility);
        if (backgroundDrawable != null) {
            mTvLeftTwo.setBackground(backgroundDrawable);
        }

        //处理mLlRight视图
        visibility = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryRightRlVisibility, View.VISIBLE);
        ViewUtil.setVisibility(mRlRight, visibility);

        backgroundDrawable = typedArray.getDrawable(R.styleable.ItemComponentView_uiLibraryRightRlBackground);
        if (backgroundDrawable != null) {
            mRlRight.setBackground(backgroundDrawable);
        }

        //处理mTvRightOne视图
        boolean editMode = typedArray.getBoolean(R.styleable.ItemComponentView_uiLibraryRightOneEditMode, false);
        boolean singleLine = typedArray.getBoolean(R.styleable.ItemComponentView_uiLibraryRightOneSingleLine, false);
        textSize = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOneTextSize, getResources().getDimension(R.dimen.ui_library_item_component_text_size_16));
        textColorStateList = typedArray.getColorStateList(R.styleable.ItemComponentView_uiLibraryRightOneTextColor);
        if (textColorStateList == null) {
            textColorStateList = ColorStateList.valueOf(getResources().getColor(R.color.ui_library_item_component_txt_black_191919));
        }
        hintColor = typedArray.getColor(R.styleable.ItemComponentView_uiLibraryRightOneHintColor, getResources().getColor(R.color.ui_library_item_component_txt_black_191919));
        textStyle = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryRightOneTextStyle, Typeface.NORMAL);
        margin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOneMargin, 0);
        leftMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOneMarginLeft, getResources().getDimension(R.dimen.ui_library_item_component_space_8));
        topMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOneMarginTop, 0);
        rightMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOneMarginRight, 0);
        bottomMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOneMarginBottom, 0);
        padding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOnePading, 0);
        leftPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOnePadingLeft, 0);
        topPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOnePadingTop, 0);
        rightPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOnePadingRight, 0);
        bottomPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryRightOnePadingBottom, 0);
        text = typedArray.getString(R.styleable.ItemComponentView_uiLibraryRightOneText);
        hint = typedArray.getString(R.styleable.ItemComponentView_uiLibraryRightOneHint);
        visibility = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryRightOneVisibility, View.VISIBLE);
        backgroundDrawable = typedArray.getDrawable(R.styleable.ItemComponentView_uiLibraryRightOneBackground);
        if (editMode) {
            mTvRightOne = etRightOne;
            tvRightOne.setVisibility(View.GONE);
        } else {
            mTvRightOne = tvRightOne;
            etRightOne.setVisibility(View.GONE);
        }
        ViewUtil.setPadding(mTvRightOne, (int) padding, (int) leftPadding, (int) topPadding, (int) rightPadding, (int) bottomPadding);
        ViewUtil.setMargin(mTvRightOne, (int) margin, (int) leftMargin, (int) topMargin, (int) rightMargin, (int) bottomMargin);
        ViewUtil.setTextSize(mTvRightOne, textSize);
        setTextStyle(mTvRightOne, textStyle);
        mTvRightOne.setTextColor(textColorStateList);
        mTvRightOne.setHintTextColor(hintColor);

        mTvRightOne.setSingleLine(singleLine);
        if (!TextUtils.isEmpty(text)) {
            mTvRightOne.setText(text);
        }
        if (!TextUtils.isEmpty(hint)) {
            mTvRightOne.setHint(hint);
        }
        ViewUtil.setVisibility(mTvRightOne, visibility);
        if (backgroundDrawable != null) {
            mTvRightOne.setBackground(backgroundDrawable);
        }

        //处理mTvTag视图
        textSize = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagTextSize, getResources().getDimension(R.dimen.ui_library_item_component_text_size_10));
        textColorStateList = typedArray.getColorStateList(R.styleable.ItemComponentView_uiLibraryTagTextColor);
        if (textColorStateList == null) {
            textColorStateList = ColorStateList.valueOf(getResources().getColor(R.color.ui_library_item_component_txt_green_55CC77));
        }
        hintColor = typedArray.getColor(R.styleable.ItemComponentView_uiLibraryTagHintColor, getResources().getColor(R.color.ui_library_item_component_txt_green_55CC77));
        textStyle = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryTagTextStyle, Typeface.NORMAL);
        margin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagMargin, 0);
        leftMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagMarginLeft, getResources().getDimension(R.dimen.ui_library_item_component_space_8));
        topMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagMarginTop, 0);
        rightMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagMarginRight, 0);
        bottomMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagMarginBottom, 0);
        padding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagPading, 0);
        leftPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagPadingLeft, 0);
        topPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagPadingTop, 0);
        rightPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagPadingRight, 0);
        bottomPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryTagPadingBottom, 0);
        text = typedArray.getString(R.styleable.ItemComponentView_uiLibraryTagText);
        hint = typedArray.getString(R.styleable.ItemComponentView_uiLibraryTagHint);
        visibility = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryTagVisibility, View.VISIBLE);
        backgroundDrawable = typedArray.getDrawable(R.styleable.ItemComponentView_uiLibraryTagBackground);

        ViewUtil.setPadding(mTvTag, (int) padding, (int) leftPadding, (int) topPadding, (int) rightPadding, (int) bottomPadding);
        ViewUtil.setMargin(mTvTag, (int) margin, (int) leftMargin, (int) topMargin, (int) rightMargin, (int) bottomMargin);
        ViewUtil.setTextSize(mTvTag, textSize);
        setTextStyle(mTvTag, textStyle);
        mTvTag.setTextColor(textColorStateList);
        mTvTag.setHintTextColor(hintColor);
        if (!TextUtils.isEmpty(text)) {
            mTvTag.setText(text);
        }
        if (!TextUtils.isEmpty(hint)) {
            mTvTag.setHint(hint);
        }
        ViewUtil.setVisibility(mTvTag, visibility);
        if (backgroundDrawable != null) {
            mTvTag.setBackground(backgroundDrawable);
        }

        //处理mIvIcon视图
        backgroundDrawable = typedArray.getDrawable(R.styleable.ItemComponentView_uiLibraryIconBackground);
        Drawable iconSrc = typedArray.getDrawable(R.styleable.ItemComponentView_uiLibraryIconSrc);
        int scaleType = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryIconScaleType, -1);
        float width = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconWidth, ViewGroup.LayoutParams.WRAP_CONTENT);
        float height = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconHeight, ViewGroup.LayoutParams.WRAP_CONTENT);
        margin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconMargin, 0);
        leftMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconMarginLeft, getResources().getDimension(R.dimen.ui_library_item_component_space_5));
        topMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconMarginTop, 0);
        rightMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconMarginRight, 0);
        bottomMargin = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconMarginBottom, 0);
        padding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconPading, 0);
        leftPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconPadingLeft, 0);
        topPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconPadingTop, 0);
        rightPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconPadingRight, 0);
        bottomPadding = typedArray.getDimension(R.styleable.ItemComponentView_uiLibraryIconPadingBottom, 0);
        visibility = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryIconVisibility, View.VISIBLE);

        ViewUtil.setPadding(mIvIcon, (int) padding, (int) leftPadding, (int) topPadding, (int) rightPadding, (int) bottomPadding);
        ViewUtil.setMargin(mIvIcon, (int) margin, (int) leftMargin, (int) topMargin, (int) rightMargin, (int) bottomMargin);
        ViewUtil.setVisibility(mIvIcon, visibility);

        ViewGroup.LayoutParams lp = mIvIcon.getLayoutParams();
        if (lp == null) {
            lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        lp.width = (int) width;
        lp.height = (int) height;
        mIvIcon.setLayoutParams(lp);

        if (backgroundDrawable != null) {
            mIvIcon.setBackground(backgroundDrawable);
        }
        if (iconSrc != null) {
            mIvIcon.setImageDrawable(iconSrc);
        }

        if (scaleType >= 0 && scaleType < sScaleTypeArray.length) {
            mIvIcon.setScaleType(sScaleTypeArray[scaleType]);
        }

        //处理当前的显示模式
        int mode = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryMode, MODE_LEFT_TWO_TEXT_RIGHT_TEXT_TAG_ICON);
        dealWithMode(mode);

        //如果设置了weight就按照weight分配宽度
        mWeightSum = typedArray.getFloat(R.styleable.ItemComponentView_uiLibraryWeightSum, 0.0f);
        mLeftWeight = typedArray.getFloat(R.styleable.ItemComponentView_uiLibraryLeftLayout_weight, 0.0f);
        mRightWeight = typedArray.getFloat(R.styleable.ItemComponentView_uiLibraryRightLayout_weight, 0.0f);

        //处理方向
        int layoutDirection = typedArray.getInt(R.styleable.ItemComponentView_android_layoutDirection, LAYOUT_DERACTION_LTR);
        dealWithLayoutDirection(layoutDirection);

        //处理以左/右那部分为基准（如果不处理会出现可能左（右）过长，把右（左）挤出页面的问题）
        int baseLine = typedArray.getInt(R.styleable.ItemComponentView_uiLibraryBaseLine, BASELINE_LEFT);
        dealWithBaseLine(layoutDirection, baseLine);

        //左边的视图是否需要居中显示（例如左侧只有一个标题，右侧标题操作一行，这种情况有时左侧标题需要居中，有时需要居上）
        boolean leftLayoutCenterVertival = typedArray.getBoolean(R.styleable.ItemComponentView_uiLibraryLeftLayout_centerVertical, false);
        setLeftCenterVertical(leftLayoutCenterVertival);

        typedArray.recycle();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int measureWidth = MeasureSpec.getSize(widthMeasureSpec);
        if (mLeftWeight == 0.0f && mRightWeight == 0.0f) {
            return;
        }
        if (mWeightSum == 0.0f) {
            mWeightSum = mLeftWeight + mRightWeight;
        }
        if (mLeftWeight > 0) {
            int rlLeftWidth = (int) (measureWidth * mLeftWeight / mWeightSum);
            ViewGroup.LayoutParams rlLeftLp = mRlLeft.getLayoutParams();
            if (rlLeftLp != null) {
                if (rlLeftLp.width != rlLeftWidth) {
                    rlLeftLp.width = rlLeftWidth;
                    mRlLeft.setLayoutParams(rlLeftLp);
                }
            }
        }
        if (mRightWeight > 0) {
            int rlRightWidth = (int) (measureWidth * mRightWeight / mWeightSum);
            ViewGroup.LayoutParams rlRightLp = mRlRight.getLayoutParams();
            if (rlRightLp != null) {
                if (rlRightLp.width != rlRightWidth) {
                    rlRightLp.width = rlRightWidth;
                    mRlRight.setLayoutParams(rlRightLp);
                }

                ViewGroup.LayoutParams llRightLp = mLlRight.getLayoutParams();
                if (llRightLp.width != ViewGroup.LayoutParams.MATCH_PARENT) {
                    llRightLp.width = ViewGroup.LayoutParams.MATCH_PARENT;
                    mLlRight.setLayoutParams(llRightLp);
                }
                LinearLayout.LayoutParams tvRightLp = (LinearLayout.LayoutParams) mTvRightOne.getLayoutParams();
                if (tvRightLp.weight != 1 || tvRightLp.width != 0) {
                    tvRightLp.weight = 1;
                    tvRightLp.width = 0;
                    mTvRightOne.setLayoutParams(tvRightLp);
                }
            }
        }
    }

    /**
     * 处理方向 目前支持：从左至右（默认）、从右至左
     *
     * @param layoutDirection
     */
    private void dealWithLayoutDirection(int layoutDirection) {
        RelativeLayout.LayoutParams lpLeft = (RelativeLayout.LayoutParams) mRlLeft.getLayoutParams();
        RelativeLayout.LayoutParams lpRight = (RelativeLayout.LayoutParams) mRlRight.getLayoutParams();
        switch (layoutDirection) {
            case LAYOUT_DERACTION_LTR:
                lpLeft.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
                lpLeft.removeRule(RelativeLayout.ALIGN_PARENT_RIGHT);
                mRlLeft.setLayoutParams(lpLeft);

                lpRight.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
                lpRight.removeRule(RelativeLayout.ALIGN_PARENT_LEFT);
                mRlRight.setLayoutParams(lpRight);
                break;
            case LAYOUT_DERACTION_RTL:
                lpLeft.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
                lpLeft.removeRule(RelativeLayout.ALIGN_PARENT_LEFT);
                mRlLeft.setLayoutParams(lpLeft);

                lpRight.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
                lpRight.removeRule(RelativeLayout.ALIGN_PARENT_RIGHT);
                mRlRight.setLayoutParams(lpRight);
                break;

            default:
                break;
        }
    }

    /**
     * 针对左右布局，需要根据布局中左右两部分的具体情况给控件设置约束 如果不设置可能会出现某一边太长把另一边完全挤出去的情况
     *
     * @param baseLine 以左（右）完全显示为基准设置右（左）的约束条件
     */
    private void dealWithBaseLine(int layoutDirection, int baseLine) {
        switch (baseLine) {
            case BASELINE_LEFT://以视图左侧为基准
                dealWithBaseLineLeft(layoutDirection);
                break;
            case BASELINE_RIGHT://以视图右侧为基准
                dealWithBaseLineRight(layoutDirection);
                break;
            default:
                break;
        }
    }

    /**
     * 以视图左侧为基准
     *
     * @param layoutDirection 当前视图的方向 目前只支持：从左至右或者从右至左
     */
    private void dealWithBaseLineLeft(int layoutDirection) {
        switch (layoutDirection) {
            case LAYOUT_DERACTION_LTR:
                RelativeLayout.LayoutParams lpRight = (RelativeLayout.LayoutParams) mRlRight.getLayoutParams();
                lpRight.width = LayoutParams.MATCH_PARENT;
                lpRight.addRule(RelativeLayout.RIGHT_OF, R.id.rl_left);
                mRlRight.setLayoutParams(lpRight);
                break;
            case LAYOUT_DERACTION_RTL:
                RelativeLayout.LayoutParams lpLeft = (RelativeLayout.LayoutParams) mRlLeft.getLayoutParams();
                lpLeft.width = LayoutParams.MATCH_PARENT;
                lpLeft.addRule(RelativeLayout.RIGHT_OF, R.id.rl_right);
                mRlLeft.setLayoutParams(lpLeft);
                break;
            default:
                break;
        }
    }

    /**
     * 以视图右侧为基准
     *
     * @param layoutDirection 当前视图的方向 目前只支持：从左至右或者从右至左
     */
    private void dealWithBaseLineRight(int layoutDirection) {
        switch (layoutDirection) {
            case LAYOUT_DERACTION_LTR:
                RelativeLayout.LayoutParams lpLeft = (RelativeLayout.LayoutParams) mRlLeft.getLayoutParams();
                lpLeft.width = LayoutParams.MATCH_PARENT;
                lpLeft.addRule(RelativeLayout.LEFT_OF, R.id.rl_right);
                mRlLeft.setLayoutParams(lpLeft);
                break;
            case LAYOUT_DERACTION_RTL:
                RelativeLayout.LayoutParams lpRight = (RelativeLayout.LayoutParams) mRlRight.getLayoutParams();
                lpRight.width = LayoutParams.MATCH_PARENT;
                lpRight.addRule(RelativeLayout.LEFT_OF, R.id.rl_left);
                mRlRight.setLayoutParams(lpRight);
                break;
            default:
                break;
        }
    }

    private void setLeftCenterVertical(boolean leftLayoutCenterVertival) {
        if (leftLayoutCenterVertival) {
            RelativeLayout.LayoutParams lpLeft = (RelativeLayout.LayoutParams) mRlLeft.getLayoutParams();
            lpLeft.addRule(RelativeLayout.CENTER_VERTICAL, RelativeLayout.TRUE);
            mRlLeft.setLayoutParams(lpLeft);
        }
    }

    /**
     * 设置当前控件的模式
     *
     * @param mode 模式
     */
    private void dealWithMode(int mode) {
        switch (mode) {
            case MODE_LEFT_ONE_TEXT:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                ViewUtil.setVisibility(mRlRight, View.GONE);
                break;
            case MODE_LEFT_ONE_TEXT_RIGHT_ICON:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                ViewUtil.setVisibility(mTvRightOne, View.GONE);
                ViewUtil.setVisibility(mTvTag, View.GONE);
                break;
            case MODE_LEFT_ONE_TEXT_RIGHT_TEXT:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                ViewUtil.setVisibility(mTvTag, View.GONE);
                ViewUtil.setVisibility(mIvIcon, View.GONE);
                break;
            case MODE_LEFT_ONE_TEXT_RIGHT_TAG:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                ViewUtil.setVisibility(mTvRightOne, View.GONE);
                ViewUtil.setVisibility(mIvIcon, View.GONE);
                break;
            case MODE_LEFT_ONE_TEXT_RIGHT_TEXT_ICON:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                ViewUtil.setVisibility(mTvTag, View.GONE);
                break;
            case MODE_LEFT_ONE_TEXT_RIGHT_TAG_ICON:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                ViewUtil.setVisibility(mTvRightOne, View.GONE);
                break;
            case MODE_LEFT_ONE_TEXT_RIGHT_TEXT_TAG:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                ViewUtil.setVisibility(mIvIcon, View.GONE);
                break;
            case MODE_LEFT_ONE_TEXT_RIGHT_TEXT_TAG_ICON:
                ViewUtil.setVisibility(mTvLeftTwo, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT:
                ViewUtil.setVisibility(mRlRight, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT_RIGHT_ICON:
                ViewUtil.setVisibility(mTvRightOne, View.GONE);
                ViewUtil.setVisibility(mTvTag, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT_RIGHT_TEXT:
                ViewUtil.setVisibility(mTvTag, View.GONE);
                ViewUtil.setVisibility(mIvIcon, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT_RIGHT_TAG:
                ViewUtil.setVisibility(mTvRightOne, View.GONE);
                ViewUtil.setVisibility(mIvIcon, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT_RIGHT_TEXT_ICON:
                ViewUtil.setVisibility(mTvTag, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT_RIGHT_TAG_ICON:
                ViewUtil.setVisibility(mTvRightOne, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT_RIGHT_TEXT_TAG:
                ViewUtil.setVisibility(mIvIcon, View.GONE);
                break;
            case MODE_LEFT_TWO_TEXT_RIGHT_TEXT_TAG_ICON:
                break;
            case MODE_RIGHT_TEXT:
                ViewUtil.setVisibility(mRlLeft, View.GONE);
                ViewUtil.setVisibility(mTvTag, View.GONE);
                ViewUtil.setVisibility(mIvIcon, View.GONE);
                break;
            default:
                throw new IllegalArgumentException("The mode of ItemComponentView is not supported in xml file");
        }
    }

    public void setScaleType(int itemType, ImageView.ScaleType scaleType) {
        View view = getView(itemType);
        if (view instanceof ImageView) {
            ((ImageView) view).setScaleType(scaleType);
        }
    }

    public void setScaleType(ImageView imageView, ImageView.ScaleType scaleType) {
        if (imageView == null) {
            return;
        }
        imageView.setScaleType(scaleType);
    }

    public void setVisibility(int itemType, int visibility) {
        View view = getView(itemType);
        if (view == null) {
            return;
        }
        ViewUtil.setVisibility(view, visibility);
    }

    public void setTextStyle(TextView textView, int style) {
        if (style == 0) {//与attr中定义的值相对应
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        } else if (style == 1) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        } else if (style == 2) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
        } else if (style == 3) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD_ITALIC));
        }
    }

    public void appendText(int itemType, CharSequence charSequence) {
        appendText(itemType, charSequence, "");
    }

    public void appendText(int itemType, @StringRes int stringRes) {
        String msg = mContext.getString(stringRes);
        appendText(itemType, msg, "");
    }

    public void appendText(int itemType, CharSequence charSequence, String defaultStr) {
        View view = getView(itemType);
        if (!(view instanceof TextView)) {
            return;
        }
        TextView tv = (TextView) view;
        ViewUtil.appendText(tv, charSequence, defaultStr);
    }


    public void setText(int itemType, CharSequence charSequence) {
        setText(itemType, charSequence, "");
    }

    public void setText(int itemType, @StringRes int stringRes) {
        String msg = mContext.getString(stringRes);
        setText(itemType, msg, "");
    }

    public void setText(int itemType, CharSequence charSequence, String defaultStr) {
        View view = getView(itemType);
        if (!(view instanceof TextView)) {
            return;
        }
        TextView tv = (TextView) view;
        ViewUtil.setText(tv, charSequence, defaultStr);
    }

    public void setTextHintColor(int itemType, @ColorInt int color) {
        View view = getView(itemType);
        if (!(view instanceof TextView)) {
            return;
        }
        TextView tv = (TextView) view;
        tv.setHintTextColor(color);
    }

    public void setTextColor(int itemType, @ColorInt int color) {
        View view = getView(itemType);
        if (!(view instanceof TextView)) {
            return;
        }
        TextView tv = (TextView) view;
        tv.setTextColor(color);
    }

    public void setBackgroundColor(int itemType, @ColorInt int color) {
        View view = getView(itemType);
        if (view == null) {
            return;
        }
        view.setBackgroundColor(color);
    }

    public void setBackground(int itemType, @DrawableRes int drawableRes) {
        Drawable drawable = mContext.getResources().getDrawable(drawableRes);
        setBackground(itemType, drawable);
    }

    public void setBackground(int itemType, Drawable drawable) {
        View view = getView(itemType);
        if (view == null) {
            return;
        }
        view.setBackground(drawable);
    }

    public void setIconSrc(@DrawableRes int drawableRes) {
        Drawable drawable = mContext.getResources().getDrawable(drawableRes);
        setIconSrc(drawable);
    }

    public void setIconSrc(Drawable drawable) {
        mIvIcon.setImageDrawable(drawable);
    }

    public void setOnClickListener(int itemType, OnClickListener listener) {
        View view = getView(itemType);
        if (view == null) {
            return;
        }
        view.setOnClickListener(listener);
    }

    public void setSingleLine(int itemType) {
        setSingleLine(itemType, true);
    }

    public void setSingleLine(int itemType, boolean singleLine) {
        View view = getView(itemType);
        if (!(view instanceof TextView)) {
            return;
        }
        ((TextView) view).setSingleLine(singleLine);
    }

    public void setEnabled(int itemType, boolean enabled) {
        View view = getView(itemType);
        ViewUtil.setEnabled(view, enabled);
    }

    public void setOnEditorActionListener(int itemType, TextView.OnEditorActionListener l) {
        View view = getView(itemType);
        if (!(view instanceof TextView)) {
            return;
        }
        ViewUtil.setOnEditorActionListener((TextView) view, l);
    }

    public String getText(int itemType) {
        View view = getView(itemType);
        if (!(view instanceof TextView)) {
            return null;
        }
        TextView textView = (TextView) view;
        return textView.getText().toString();
    }

    public View getView(int itemType) {
        View view = null;
        switch (itemType) {
            case ITEM_LEFT_ONE_TEXT:
                view = mTvLeftOne;
                break;
            case ITEM_LEFT_TWO_TEXT:
                view = mTvLeftTwo;
                break;
            case ITEM_RIGHT_ONE_TEXT:
                view = mTvRightOne;
                break;
            case ITEM_RIGHT_TAG:
                view = mTvTag;
                break;
            case ITEM_RIGHT_ICON:
                view = mIvIcon;
                break;
            case ITEM_RIGHT:
                view = mRlRight;
                break;
            default:
                break;
        }
        return view;
    }
}
