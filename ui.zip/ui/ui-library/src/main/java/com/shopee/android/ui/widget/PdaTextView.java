package com.shopee.android.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;

import androidx.appcompat.widget.AppCompatTextView;

import com.shopee.android.ui.drawable.RoundRefreshDrawable;
import com.shopee.android.ui_library.R;

/**
 * 在 AppCompatTextView 的基础上，添加粘性 drawableStart、内置refresh loading Drawable
 *
 * Created by honggang.xiong on 2019-10-18.
 */
public class PdaTextView extends AppCompatTextView {

    // TextView 在绘制 drawableStart 时，会调用 getHorizontalOffsetForDrawables() 进行 offset，
    // 重写该方法并在 onDraw() 时刷新该值，即可实现 drawableStart 和文字粘在一起。
    // 简单无侵入，即使后续 Android 更新移除该 api，也不影响正常流程。
    private int mOffsetForDrawableStart = 0;
    // 是否开启粘性 drawableStart，开启后，drawableStart 将紧靠文字，同时可响应 drawablePadding
    private boolean mDrawableStartSticky;
    private int mRefreshPosition;
    private boolean mRefreshing = false;
    // 代表刷新状态的简单 Drawable
    private RoundRefreshDrawable mCurrentRefreshDrawable;
    private RoundRefreshDrawable.Params mRefreshParams;

    public PdaTextView(Context context) {
        this(context, null);
    }

    public PdaTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.PdaTextView);
        mDrawableStartSticky = typedArray.getBoolean(R.styleable.PdaTextView_drawableStartSticky, true);
        mRefreshPosition = typedArray.getInt(R.styleable.PdaTextView_refreshPosition, Gravity.START);
        boolean refreshing = typedArray.getBoolean(R.styleable.PdaTextView_refreshing, false);
        typedArray.recycle();
        mRefreshParams = RoundRefreshDrawable.createParams(context, attrs);
        setRefreshing(refreshing);
    }

    public boolean isRefreshing() {
        return mRefreshing;
    }

    public void toggleRefresh() {
        setRefreshing(!mRefreshing);
    }

    public void setRefreshing(boolean refreshing) {
        if (mRefreshing != refreshing) {
            if (refreshing) {
                showRefresh();
            } else {
                hideRefresh();
            }
        }
    }

    public void showRefresh() {
        if (mCurrentRefreshDrawable == null) {
            mCurrentRefreshDrawable = mRefreshParams.newDrawable();
            switch (mRefreshPosition) {
                case Gravity.TOP:
                    setCompoundDrawablesRelative(null, mCurrentRefreshDrawable, null, null);
                    break;
                case Gravity.BOTTOM:
                    setCompoundDrawablesRelative(null, null, null, mCurrentRefreshDrawable);
                    break;
                case Gravity.START:
                default:
                    setCompoundDrawablesRelative(mCurrentRefreshDrawable, null, null, null);
                    break;
            }
        }
        mCurrentRefreshDrawable.startRefresh();
        mRefreshing = true;
    }

    public void hideRefresh() {
        if (mCurrentRefreshDrawable != null) {
            mCurrentRefreshDrawable.stopRefresh();
            setCompoundDrawablesRelative(null, null, null, null);
            mCurrentRefreshDrawable = null;
        }
        mRefreshing = false;
    }

    public void updateRefreshDrawableColor(int bgColor, int fgColor) {
        mRefreshParams.setBgColor(bgColor);
        mRefreshParams.setFgColor(fgColor);
        if (mCurrentRefreshDrawable != null) {
            mCurrentRefreshDrawable.updateDrawableColor(bgColor, fgColor);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        refreshOffsetForDrawables();
        super.onDraw(canvas);
    }

    private void refreshOffsetForDrawables() {
        int result = 0;
        if (mDrawableStartSticky) {
            Drawable[] drawables = getCompoundDrawablesRelative();
            if (drawables[0] != null) { // drawableStart not null
                int hoGravity = getGravity() & Gravity.RELATIVE_HORIZONTAL_GRAVITY_MASK;
                float textWidth = getPaint().measureText(getText().toString());
                switch (hoGravity) {
                    case Gravity.START:
                        result = 0;
                        break;
                    case Gravity.END:
                        result = Math.round(getWidth() - getCompoundPaddingLeft() - getCompoundPaddingRight() - textWidth);
                        break;
                    case Gravity.CENTER_HORIZONTAL:
                    default:
                        result = Math.round((getWidth() - getCompoundPaddingLeft() - getCompoundPaddingRight() - textWidth) / 2.0F);
                        break;
                }
            }
        }
        mOffsetForDrawableStart = result;
    }

    // Do not delete this method
    public int getHorizontalOffsetForDrawables() {
        return mOffsetForDrawableStart;
    }

}
