package com.shopee.android.ui.choice;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;

import com.shopee.android.ui_library.R;

/**
 * Created by honggang.xiong on 2019-11-20.
 */
public class ChoiceViewHolderFactoryHelper {

    public static ChoiceViewHolder.Factory newChooseEnvFactory() {
        return new ChoiceViewHolder.Factory() {
            @Override
            public ChoiceViewHolder generate(@NonNull ViewGroup parent, int viewType) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.ui_library_item_env_choice_radio, parent, false);
                CompoundButton compoundButton = itemView.findViewById(R.id.compound_button);
                View maskView = itemView.findViewById(R.id.view_mask);
                return new ChoiceViewHolder(itemView, compoundButton, compoundButton, maskView, null);
            }
        };
    }

}
