package com.shopee.android.ui.drawable;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.util.AttributeSet;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.android.ui.util.ContextUtils;
import com.shopee.android.ui_library.R;

/**
 * 通过不断绘制两段圆弧来代表刷新状态的简单 Drawable.
 *
 * Created by honggang.xiong on 2019-10-18.
 */
public class RoundRefreshDrawable extends Drawable {

    public static final int REFRESH_DEFAULT_DURATION_MILLIS = 900;
    public static final int REFRESH_DEFAULT_SWIPE_ANGEL = 50;

    private Paint mBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint mFgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RectF mRectF = new RectF();
    private int mStrokeWidth;
    private boolean mRefreshing = false;
    private long mRefreshStartTime;
    private int mRefreshDuration = REFRESH_DEFAULT_DURATION_MILLIS;
    private int mSwipeAngel = REFRESH_DEFAULT_SWIPE_ANGEL;

    public static Params createParams(Context context, AttributeSet attrs) {
        Params params = new Params();
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.RoundRefresh);
        params.mBgColor = ta.getColor(R.styleable.RoundRefresh_refreshBackgroundColor, Color.BLACK);
        params.mFgColor = ta.getColor(R.styleable.RoundRefresh_refreshForegroundColor, Color.WHITE);
        params.mRefreshDuration = fixInRange(ta.getInt(R.styleable.RoundRefresh_refreshDuration,
                REFRESH_DEFAULT_DURATION_MILLIS), 100, 100_000);
        params.mStrokeWidth = fixInRange(ta.getDimensionPixelSize(R.styleable.RoundRefresh_refreshStrokeWidth,
                ContextUtils.dp2px(context, 2)), 1, 10_000);
        params.mRadius = fixInRange(ta.getDimensionPixelSize(R.styleable.RoundRefresh_refreshRadius,
                ContextUtils.dp2px(context, 10)), 1, 10_000);
        params.mSwipeAngel = fixInRange(ta.getInt(R.styleable.RoundRefresh_refreshSwipeAngel,
                REFRESH_DEFAULT_SWIPE_ANGEL), 1, 360);
        ta.recycle();
        return params;
    }

    public RoundRefreshDrawable(int strokeWidth, @ColorInt int bgColor, @ColorInt int fgColor) {
        mStrokeWidth = strokeWidth;
        mBgPaint.setStyle(Paint.Style.STROKE);
        mBgPaint.setStrokeWidth(mStrokeWidth);
        mBgPaint.setColor(bgColor);
        mFgPaint.setStyle(Paint.Style.STROKE);
        mFgPaint.setStrokeWidth(mStrokeWidth);
        mFgPaint.setColor(fgColor);
    }

    public void setRefreshDuration(int refreshDuration) {
        mRefreshDuration = refreshDuration;
    }

    public void setSwipeAngel(int swipeAngel) {
        mSwipeAngel = swipeAngel;
    }

    public boolean isRefreshing() {
        return mRefreshing;
    }

    public void startRefresh() {
        mRefreshing = true;
        mRefreshStartTime = SystemClock.elapsedRealtime();
        invalidateSelf();
    }

    public void stopRefresh() {
        mRefreshing = false;
    }

    public void updateDrawableColor(int bgColor, int fgColor) {
        mBgPaint.setColor(bgColor);
        mFgPaint.setColor(fgColor);
        if (mRefreshing) {
            invalidateSelf();
        }
    }

    @Override
    public void draw(@NonNull Canvas canvas) {
        long startAngle = -90;
        if (mRefreshing) {
            startAngle = (-90 + (SystemClock.elapsedRealtime() - mRefreshStartTime) * 360 / mRefreshDuration) % 360;
        }
        canvas.drawArc(mRectF, (startAngle + mSwipeAngel) % 360, 360 - mSwipeAngel, false, mBgPaint);
        canvas.drawArc(mRectF, startAngle, mSwipeAngel, false, mFgPaint);
        if (mRefreshing) {
            invalidateSelf();
        }
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        int w = bounds.width();
        int h = bounds.height();
        float r = (Math.min(w, h) - mStrokeWidth) / 2.0F;
        float centerX = w / 2.0F;
        float centerY = h / 2.0F;
        mRectF.set(centerX - r, centerY - r, centerX + r, centerY + r);
    }

    @Override
    public void setAlpha(int alpha) {
        // ignore
    }

    @Override
    public void setColorFilter(@Nullable ColorFilter colorFilter) {
        // ignore
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    private static int fixInRange(int origin, int low, int high) {
        return Math.min(high, Math.max(origin, low));
    }


    public static class Params {
        // 圆环背景颜色
        int mBgColor;
        // 圆环背景颜色
        int mFgColor;
        // 循环一圈时间
        int mRefreshDuration;
        int mStrokeWidth;
        int mRadius;
        int mSwipeAngel;

        public RoundRefreshDrawable newDrawable() {
            RoundRefreshDrawable drawable = new RoundRefreshDrawable(mStrokeWidth, mBgColor, mFgColor);
            drawable.setRefreshDuration(mRefreshDuration);
            drawable.setSwipeAngel(mSwipeAngel);
            drawable.setBounds(0, 0, 2 * mRadius, 2 * mRadius);
            return drawable;
        }

        public int getBgColor() {
            return mBgColor;
        }

        public void setBgColor(int bgColor) {
            mBgColor = bgColor;
        }

        public int getFgColor() {
            return mFgColor;
        }

        public void setFgColor(int fgColor) {
            mFgColor = fgColor;
        }

        public int getRefreshDuration() {
            return mRefreshDuration;
        }

        public void setRefreshDuration(int refreshDuration) {
            mRefreshDuration = refreshDuration;
        }

        public int getStrokeWidth() {
            return mStrokeWidth;
        }

        public void setStrokeWidth(int strokeWidth) {
            mStrokeWidth = strokeWidth;
        }

        public int getRadius() {
            return mRadius;
        }

        public void setRadius(int radius) {
            mRadius = radius;
        }
    }

}
