package com.shopee.android.ui.widget;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;

import com.shopee.android.ui.util.ContextUtils;
import com.shopee.android.ui_library.R;

/**
 * Created by honggang.xiong on 2019-11-15.
 */
public class CommonTitle extends RelativeLayout {

    public static final int TITLE_ONLY = 0;
    public static final int COMMON_GO_BACK = 1;
    public static final int SHOW_ALL = 2;

    private int mStyle = COMMON_GO_BACK;
    private ImageView mIvBack;
    private TextView mTvCenterTitle;
    private TextView mTvRightTitle;
    private View mDividerView;

    public CommonTitle(Context context) {
        this(context, null);
    }

    public CommonTitle(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CommonTitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, R.layout.ui_library_layout_common_title, this);
        mIvBack = findViewById(R.id.iv_title_back);
        mTvCenterTitle = findViewById(R.id.tv_center_title);
        mTvRightTitle = findViewById(R.id.tv_right_title);
        mDividerView = findViewById(R.id.view_title_divider);

        TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.CommonTitle);
        String centerTitle = ta.getString(R.styleable.CommonTitle_centerTitle);
        String rightTitle = ta.getString(R.styleable.CommonTitle_rightTitle);
        int rightIcon = ta.getResourceId(R.styleable.CommonTitle_rightIcon, 0);
        boolean showDivider = ta.getBoolean(R.styleable.CommonTitle_showBottomDivider, false);
        int style = ta.getInt(R.styleable.CommonTitle_titleStyle, COMMON_GO_BACK);
        ta.recycle();

        setCenterTitle(centerTitle);
        setRightTitle(rightTitle);
        setRightIcon(rightIcon);
        setShowBottomDivider(showDivider);
        setStyle(style);
    }

    public ImageView getBackImageView() {
        return mIvBack;
    }

    public TextView getCenterTextView() {
        return mTvCenterTitle;
    }

    public TextView getRightTextView() {
        return mTvRightTitle;
    }

    public void setCenterTitle(CharSequence text) {
        mTvCenterTitle.setText(text);
    }

    public void setCenterTitle(@StringRes int resId) {
        mTvCenterTitle.setText(resId);
    }

    public void setRightTitle(CharSequence text) {
        mTvRightTitle.setText(text);
    }

    public void setRightTitle(@StringRes int resId) {
        mTvRightTitle.setText(resId);
    }

    public void setRightIcon(Drawable drawable) {
        mTvRightTitle.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, null, null, null);
    }

    public void setRightIcon(@DrawableRes int resId) {
        mTvRightTitle.setCompoundDrawablesRelativeWithIntrinsicBounds(resId, 0, 0, 0);
    }

    public void setShowBottomDivider(boolean showBottomDivider) {
        mDividerView.setVisibility(showBottomDivider ? View.VISIBLE : View.GONE);
    }

    public int getStyle() {
        return mStyle;
    }

    public void setStyle(int style) {
        if (style < 0 || style > 2) {
            return;
        }
        mStyle = style;
        switch (mStyle) {
            case TITLE_ONLY:
                mIvBack.setVisibility(View.GONE);
                mTvRightTitle.setVisibility(View.GONE);
                break;
            case COMMON_GO_BACK:
                mIvBack.setVisibility(View.VISIBLE);
                mTvRightTitle.setVisibility(View.GONE);
                mIvBack.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Activity activity = ContextUtils.getActivityFromView(v);
                        if (activity != null) {
                            activity.finish();
                        }
                    }
                });
                break;
            case SHOW_ALL:
                mIvBack.setVisibility(View.VISIBLE);
                mTvRightTitle.setVisibility(View.VISIBLE);
                mIvBack.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Activity activity = ContextUtils.getActivityFromView(v);
                        if (activity != null) {
                            activity.finish();
                        }
                    }
                });
                break;
        }
    }

    public void setOnBackClickListener(View.OnClickListener listener) {
        mIvBack.setOnClickListener(listener);
    }

    public void setOnRightClickListener(View.OnClickListener listener) {
        mTvRightTitle.setOnClickListener(listener);
    }

}
