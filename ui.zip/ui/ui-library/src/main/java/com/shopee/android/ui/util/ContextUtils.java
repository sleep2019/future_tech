package com.shopee.android.ui.util;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.util.TypedValue;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Created by honggang.xiong on 2019-09-25.
 */
public class ContextUtils {

    public static int dp2px(Context context, float dp) {
        if (context == null) {
            return (int) dp;
        }
        return (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics()) + 0.5F);
    }

    public static int sp2px(Context context, float sp) {
        if (context == null) {
            return (int) sp;
        }
        return (int) (TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, context.getResources().getDisplayMetrics()) + 0.5F);
    }

    @Nullable
    public static Activity getActivityFromView(View view) {
        if (view != null) {
            Context context = view.getContext();
            while (context instanceof ContextWrapper) {
                if (context instanceof Activity) {
                    return (Activity) context;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        return null;
    }

}
