package com.shopee.android.ui_library.widget.tablayout;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.shopee.android.ui_library.R;
import com.shopee.android.ui_library.widget.util.ViewUtil;

import java.util.List;

/**
 * @ClassName: CustomTabLayout
 * @Description: 自定义的TabLayout 里面使用Fragment填充
 * @Author: lanjingzeng
 * @CreateDate: 2020/7/28 4:40 PM
 * @Version: 1.0
 */
public class CustomTabLayout extends RelativeLayout implements ViewPager.OnPageChangeListener {
    private static final String TAG = CustomTabLayout.class.getSimpleName();
    private RelativeLayout mRlContainer;
    private HorizontalScrollView mScrollView;
    private ConstraintLayout mClTabLayout;
    private ViewPager mViewPager;
    private MyAdapter mAdapter;
    private Context mContext;
    private float mTabTextSize;
    private float mTabIndicatorHeight;
    private ColorStateList mTabTextColorStateList;
    private ColorStateList mTabTextSelectedColorStateList;
    private int mTabIndicatorColor;
    private int mTabIndicatorSelectedColor;
    private int mTabTextStyle;
    private int mTabSelectedTextStyle;
    private int mTabMode;
    private float mMargin, mLeftMargin, mTopMargin, mRightMargin, mBottomMargin;
    private float mPadding, mLeftPadding, mTopPadding, mRightPadding, mBottomPadding;
    private int mLastSelectPosition = -1;
    private int mSelectedPosition = -1;


    public CustomTabLayout(Context context) {
        super(context);
        init(context, null, 0, 0);
    }

    public CustomTabLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs, 0, 0);
    }

    public CustomTabLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr, 0);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public CustomTabLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs, defStyleAttr, defStyleRes);
    }

    private void init(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        mContext = context;
        RelativeLayout contentView = (RelativeLayout) LayoutInflater.from(context).inflate(R.layout.ui_library_custom_tablayout, this, true);
        mRlContainer = (RelativeLayout) contentView.findViewById(R.id.rl_container);
        mScrollView = (HorizontalScrollView) contentView.findViewById(R.id.scrollView);
        mClTabLayout = (ConstraintLayout) contentView.findViewById(R.id.cl_tab_container);
        mViewPager = (ViewPager) contentView.findViewById(R.id.view_pager);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomTabLayout, defStyleAttr, defStyleRes);
        mTabMode = typedArray.getInt(R.styleable.CustomTabLayout_tabMode, -1);
//        int tabHeight = getTabHeight(typedArray, R.styleable.CustomTabLayout_uiLibraryTabHeight);
        mMargin = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextMargin, 0);
        mLeftMargin = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextMarginLeft, 0);
        mTopMargin = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextMarginTop, 0);
        mRightMargin = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextMarginRight, 0);
        mBottomMargin = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextMarginBottom, 0);
        mPadding = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextPadding, 0);
        mLeftPadding = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextPaddingLeft, 0);
        mTopPadding = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextPaddingTop, getResources().getDimension(R.dimen.ui_library_custom_tablayout_tab_padding_top));
        mRightPadding = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextPaddingRight, 0);
        mBottomPadding = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextPaddingBottom, getResources().getDimension(R.dimen.ui_library_custom_tablayout_tab_padding_bottom));
        Drawable tabBackgroundDrawable = typedArray.getDrawable(R.styleable.CustomTabLayout_uiLibraryTabBackground);
        mTabTextSize = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabTextSize, getResources().getDimension(R.dimen.ui_library_custom_tablayout_tab_textSize));
        mTabTextStyle = typedArray.getInt(R.styleable.CustomTabLayout_uiLibraryTabTextStyle, Typeface.NORMAL);
        mTabSelectedTextStyle = typedArray.getInt(R.styleable.CustomTabLayout_uiLibraryTabSelectedTextStyle, Typeface.NORMAL);

        mTabTextColorStateList = typedArray.getColorStateList(R.styleable.CustomTabLayout_uiLibraryTabTextColor);
        if (mTabTextColorStateList == null) {
            mTabTextColorStateList = ColorStateList.valueOf(getResources().getColor(R.color.ui_library_custom_tablayout_txt_gray_8C9AAB));
        }

        mTabTextSelectedColorStateList = typedArray.getColorStateList(R.styleable.CustomTabLayout_uiLibraryTabSelectedTextColor);
        if (mTabTextSelectedColorStateList == null) {
            mTabTextSelectedColorStateList = ColorStateList.valueOf(getResources().getColor(R.color.ui_library_custom_tablayout_txt_orange_FF5722));
        }

        mTabIndicatorHeight = typedArray.getDimension(R.styleable.CustomTabLayout_uiLibraryTabIndicatorHeight, getResources().getDimension(R.dimen.ui_library_custom_tablayout_indicator_height));
        mTabIndicatorColor = typedArray.getColor(R.styleable.CustomTabLayout_uiLibraryTabIndicatorColor, getResources().getColor(R.color.ui_library_custom_tablayout_indicator_00000000));
        mTabIndicatorSelectedColor = typedArray.getColor(R.styleable.CustomTabLayout_uiLibraryTabIndicatorSelectedColor, getResources().getColor(R.color.ui_library_custom_tablayout_indicator_orange_FF5722));
        checkMode(mTabMode);
//        setTabLayoutHeight(tabHeight);
        if (tabBackgroundDrawable != null) {
            mClTabLayout.setBackground(tabBackgroundDrawable);
        }
        typedArray.recycle();
    }

    private void checkMode(int tabMode) {
        if (!(tabMode == TabLayout.MODE_FIXED || tabMode == TabLayout.MODE_SCROLLABLE)) {//TabLayout.MODE_FIXED:1  TabLayout.MODE_SCROLLABLE:0
            throw new IllegalArgumentException("tabMode only support fixed or scrollable");
        }
    }

    private int getTabHeight(TypedArray a, int heightAttr) {
        int height = a.getLayoutDimension(heightAttr, "uiLibraryTabHeight");
        return height;
    }

    private void setTabLayoutHeight(int tabHeight) {
        FrameLayout.LayoutParams tabLp = (FrameLayout.LayoutParams) mClTabLayout.getLayoutParams();
        if (tabLp == null) {
            tabLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        tabLp.height = tabHeight;
        mClTabLayout.setLayoutParams(tabLp);
    }

    public void initData(FragmentManager fm, List<? extends Fragment> fragments, List<String> titles, int defaultSelectPosition) {
        if (fragments == null) {
            throw new IllegalArgumentException("fragments is null");
        }
        if (titles == null) {
            throw new IllegalArgumentException("titles is null");
        }

        if (fragments.size() != titles.size()) {
            throw new IllegalArgumentException("the size of fragments is not equals size of titles");
        }
        mAdapter = new MyAdapter(fm);
        mViewPager.setAdapter(mAdapter);
        mAdapter.setData(fragments, titles);
        mAdapter.notifyDataSetChanged();
        int size = fragments.size();

        for (int index = 0; index < size; index++) {
            String title = titles.get(index);
            if (defaultSelectPosition == index) {
                mSelectedPosition = index;
                mLastSelectPosition = mSelectedPosition;
                setTabCustomView(index, title, true, index == size - 1);
                mViewPager.setCurrentItem(index);
            } else {
                setTabCustomView(index, title, false, index == size - 1);
            }
        }
        setTabTitleLayoutParams();
        mViewPager.addOnPageChangeListener(this);
    }

    public void setOffscreenPageLimit(int limit) {
        mViewPager.setOffscreenPageLimit(limit);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        //只有模式是scrollable的时候才需要处理tab的滑动(fixed模式所有的tab项都能显示在屏幕上，不需要处理滑动)
        if (mTabMode == TabLayout.MODE_FIXED) {
            return;
        }
        int x = calculateScrollXForTab(position, positionOffset);
//        Log.i(TAG, "移动的距离：" + x);
        mScrollView.scrollTo(x, 0);
    }

    @Override
    public void onPageSelected(int position) {
        mSelectedPosition = position;
        //将position位置的tab项置为选择状态
        selectTab(mSelectedPosition, true);
        //将上一个选中的tab项置为未选择状态
        if (mLastSelectPosition != mSelectedPosition) {
            selectTab(mLastSelectPosition, false);
        }
        mLastSelectPosition = mSelectedPosition;
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private void selectTab(int index, boolean selected) {
        if (index >= 0 && index < mClTabLayout.getChildCount()) {
            View tabView = mClTabLayout.getChildAt(index);
            setTab(tabView, selected);
        }
    }

    public int getSelectPos() {
        return mSelectedPosition;
    }

    private View getTabView(int selectIndex) {
        if (selectIndex >= 0 && selectIndex < mClTabLayout.getChildCount()) {
            View tabView = mClTabLayout.getChildAt(selectIndex);
            return tabView;
        }
        return null;
    }

    private int calculateScrollXForTab(int position, float positionOffset) {
        if (mTabMode == TabLayout.MODE_SCROLLABLE) {
            View selectedChild = getTabView(position);
            View nextChild = getTabView(position + 1);
            int selectedWidth = selectedChild != null ? selectedChild.getWidth() : 0;
            int nextWidth = nextChild != null ? nextChild.getWidth() : 0;
            int scrollBase = selectedChild.getLeft() + selectedWidth / 2 - mScrollView.getWidth() / 2;
            int scrollOffset = (int) ((float) (selectedWidth + nextWidth) * 0.5F * positionOffset);
            return ViewCompat.getLayoutDirection(this) == ViewCompat.LAYOUT_DIRECTION_LTR ? scrollBase + scrollOffset : scrollBase - scrollOffset;
        } else {
            return 0;
        }
    }

    public void setTabCustomView(int index, String title, boolean selected, boolean isLastTab) {
        final View tabView = LayoutInflater.from(mContext).inflate(R.layout.ui_library_custom_tablayout_tab_item, mClTabLayout, false);
        View vIndicator = (View) tabView.findViewById(R.id.v_tab_indicator);
        TextView tvTitle = (TextView) tabView.findViewById(R.id.tv_tab_title);
        setIndicatorHeight(vIndicator);
        ViewUtil.setPadding(tvTitle, (int) mPadding, (int) mLeftPadding, (int) mTopPadding, (int) mRightPadding, (int) mBottomPadding);
        ViewUtil.setMargin(tvTitle, (int) mMargin, (int) mLeftMargin, (int) mTopMargin, (int) mRightMargin, (int) mBottomMargin);
        ViewUtil.setTextSize(tvTitle, mTabTextSize);
        tvTitle.setText(title);
        tabView.setTag(index);
        tabView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tabView.getTag() instanceof Integer) {
                    int position = ((Integer) tabView.getTag()).intValue();
                    mViewPager.setCurrentItem(position);
                }
            }
        });
        setTab(tabView, selected);
        //将tab像加进mClTabLayout中
        mClTabLayout.addView(tabView, getTabLayoutParams(tabView, isLastTab));
    }

    public ConstraintLayout.LayoutParams getTabLayoutParams(View tabView, boolean isLast) {
        tabView.setId(tabView.hashCode());
        if (mTabMode == TabLayout.MODE_FIXED) {
            return getFixedTabLayoutParams(tabView, isLast);
        } else {
            return getScrollableTabLayoutParams(tabView, isLast);
        }
    }

    public ConstraintLayout.LayoutParams getScrollableTabLayoutParams(View tabView, boolean isLast) {
        ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        if (mClTabLayout.getChildCount() == 0) {
            lp.startToStart = mClTabLayout.getId();
            return lp;
        }
        View lastTabView = mClTabLayout.getChildAt(mClTabLayout.getChildCount() - 1);
        ConstraintLayout.LayoutParams lastViewLp = (ConstraintLayout.LayoutParams) lastTabView.getLayoutParams();
        if (lastViewLp == null) {
            return null;
        }
        lp.startToEnd = lastTabView.getId();
        return lp;
    }

    public ConstraintLayout.LayoutParams getFixedTabLayoutParams(View tabView, boolean isLast) {
        //将mClTabLayout的父布局HorizontalScrollView移除，否则在fixed模式下HorizontalScrollView高度计算有问题
        //（如果使用HorizontalScrollView+Linearlayout的方式实现，在fixed模式下Linearlayout的layout_weight属性失效，也是要通过移除HorizontalScrollView这个布局来解决）
        mRlContainer.removeView(mScrollView);
        ((ViewGroup) mClTabLayout.getParent()).removeView(mClTabLayout);
        mRlContainer.addView(mClTabLayout);

        ConstraintLayout.LayoutParams lp = new ConstraintLayout.LayoutParams(0, ConstraintLayout.LayoutParams.WRAP_CONTENT);
        lp.horizontalWeight = 1;
        lp.topToTop = mClTabLayout.getId();
        if (mClTabLayout.getChildCount() == 0) {
            lp.startToStart = mClTabLayout.getId();
            if (isLast) {
                lp.endToEnd = mClTabLayout.getId();
            }
            return lp;
        }
        lp.width = 0;
        lp.horizontalWeight = 1;

        View lastTabView = mClTabLayout.getChildAt(mClTabLayout.getChildCount() - 1);
        ConstraintLayout.LayoutParams lastViewLp = (ConstraintLayout.LayoutParams) lastTabView.getLayoutParams();
        if (lastViewLp == null) {
            return null;
        }
        lastViewLp.endToStart = tabView.getId();
        lp.startToEnd = lastTabView.getId();
        if (isLast) {
            lp.endToEnd = mClTabLayout.getId();
        }
        return lp;
    }

    /**
     * Scrollable模式：title的宽度和高度都为wrap_content即可
     * Fixed模式:需要将title的宽度设置成与其父容器的宽度一致，因为indicator的宽度和title的宽度是一致的，否则将会出现tab的indicator各不相；高度需要设置为计算出来的maxHeight，否则每个tab的高度不一致
     */
    private void setTabTitleLayoutParams() {
        if (mTabMode == TabLayout.MODE_SCROLLABLE) {
            return;
        }
        mClTabLayout.post(new Runnable() {
            @Override
            public void run() {
                int maxHeight = 0;
                for (int i = 0; i < mClTabLayout.getChildCount(); i++) {
                    int tabHeight = mClTabLayout.getChildAt(i).getHeight();
                    maxHeight = maxHeight > tabHeight ? maxHeight : tabHeight;
                }
                if (maxHeight > 0) {
                    for (int i = 0; i < mClTabLayout.getChildCount(); i++) {
                        View tabView = mClTabLayout.getChildAt(i);
                        View tvTitle = tabView.findViewById(R.id.tv_tab_title);
                        RelativeLayout.LayoutParams lp = getTitleLayoutParams(tvTitle);
                        lp.height = maxHeight;
                        tvTitle.setLayoutParams(lp);
                    }
                }
            }
        });
    }

    /**
     * Scrollable模式：title的宽度为wrap_content即可（xml文件中默认就是wrap_content,因此如果是Scrollable模式可不用处理宽度）
     * Fixed模式:需要将title的宽度设置成与其父容器的宽度一致，因为indicator的宽度和title的宽度是一致的，否则将会出现tab的indicator各不相同
     */
    public RelativeLayout.LayoutParams getTitleLayoutParams(View tvTitle) {
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) tvTitle.getLayoutParams();
        if (lp == null) {
            lp = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        }
        if (mTabMode == TabLayout.MODE_FIXED) {
            lp.width = LayoutParams.MATCH_PARENT;
        }
        return lp;
    }

    private void setIndicatorHeight(View indicator) {
        ViewGroup.LayoutParams indicatorLp = indicator.getLayoutParams();
        if (indicatorLp == null) {
            indicatorLp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        indicatorLp.height = (int) mTabIndicatorHeight;
        indicator.setLayoutParams(indicatorLp);
    }

    private void setTab(View tabView, boolean selected) {
        TextView tvTitle = getTabTextView(tabView);
        View vIndicator = getTabIndicatorView(tabView);
        if (tvTitle == null || vIndicator == null) {
            return;
        }
        if (selected) {
            setTextStyle(tvTitle, mTabSelectedTextStyle);
            tvTitle.setTextColor(mTabTextSelectedColorStateList);
            vIndicator.setBackgroundColor(mTabIndicatorSelectedColor);
        } else {
            setTextStyle(tvTitle, mTabTextStyle);
            tvTitle.setTextColor(mTabTextColorStateList);
            vIndicator.setBackgroundColor(mTabIndicatorColor);
        }
    }

    private TextView getTabTextView(View tabView) {
        if (tabView == null) {
            return null;
        }
        TextView tvTitle = (TextView) tabView.findViewById(R.id.tv_tab_title);
        return tvTitle;
    }

    private View getTabIndicatorView(View tabView) {
        if (tabView == null) {
            return null;
        }
        View vIndicator = (View) tabView.findViewById(R.id.v_tab_indicator);
        return vIndicator;
    }

    private void setTextStyle(TextView textView, int style) {
        if (style == 0) {//与attr中定义的值相对应
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        } else if (style == 1) {
            //字体加粗最好使用下面的方式，paint.setFakeBoldText()有时没生效。
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        } else if (style == 2) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
        } else if (style == 3) {
            textView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD_ITALIC));
        }
    }

    public ConstraintLayout getTabLayout() {
        return mClTabLayout;
    }

    public void setTabTitle(int index, CharSequence newText) {
        View tabView = getTabView(index);
        TextView tvTitle = getTabTextView(tabView);
        if (tvTitle == null) {
            return;
        }
        tvTitle.setText(newText);
    }

    private class MyAdapter<T extends Fragment> extends FragmentStatePagerAdapter {
        private List<T> fragments;
        private List<String> titles;

        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        public void setData(List<T> fragments, List<String> titles) {
            this.fragments = fragments;
            this.titles = titles;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            if (fragments == null) {
                return null;
            }
            if (position >= fragments.size()) {
                return null;
            }
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            if (fragments == null) {
                return 0;
            }
            return fragments.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            if (titles == null) {
                return null;
            }
            if (position >= titles.size()) {
                return null;
            }
            return titles.get(position);
        }
    }


}
