package com.shopee.android.ui.widget.picker;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.Dimension;
import androidx.annotation.IntDef;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.shopee.android.ui_library.R;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

/**
 * 时间选择器
 */
public class TimePickerView extends BasePickerView {

    private static final String TAG = "TimePickerView";

    public static final int PICKER_TYPE_YEAR = 1 << 5;
    public static final int PICKER_TYPE_MONTH = 1 << 4;
    public static final int PICKER_TYPE_DAY = 1 << 3;
    public static final int PICKER_TYPE_HOUR = 1 << 2;
    public static final int PICKER_TYPE_MINUTE = 1 << 1;
    public static final int PICKER_TYPE_SECOND = 1;

    // 年月
    public static final int PICKER_TYPE_YEAR_MONTH = PICKER_TYPE_YEAR | PICKER_TYPE_MONTH;
    // 年月日
    public static final int PICKER_TYPE_YEAR_MONTH_DAY = PICKER_TYPE_YEAR_MONTH | PICKER_TYPE_DAY;
    // 时分
    public static final int PICKER_TYPE_HOUR_MINUTE = PICKER_TYPE_HOUR | PICKER_TYPE_MINUTE;
    // 时分秒
    public static final int PICKER_TYPE_HOUR_MINUTE_SECOND = PICKER_TYPE_HOUR_MINUTE | PICKER_TYPE_SECOND;
    // 月日时分
    public static final int PICKER_TYPE_MONTH_DAY_HOUR_MIN = PICKER_TYPE_MONTH | PICKER_TYPE_DAY | PICKER_TYPE_HOUR_MINUTE;
    // 年月日时分秒
    public static final int PICKER_TYPE_ALL = PICKER_TYPE_YEAR_MONTH_DAY | PICKER_TYPE_HOUR_MINUTE_SECOND;

    @IntDef(flag = true, value = {
            PICKER_TYPE_YEAR,
            PICKER_TYPE_MONTH,
            PICKER_TYPE_DAY,
            PICKER_TYPE_HOUR,
            PICKER_TYPE_MINUTE,
            PICKER_TYPE_SECOND})
    @Retention(RetentionPolicy.SOURCE)
    public @interface PickerTypes {
    }

    private WheelTime mWheelTime;
    private OnTimeSelectListener mOnTimeSelectListener;

    @PickerTypes
    private int mPickerType;

    private Date mDate;
    private int mStartYear;
    private int mEndYear;
    private boolean mCyclic;
    private boolean mCancelable;

    private String mStrSubmit;
    private String mStrCancel;
    private String mStrTitle;

    private int mColorSubmit;
    private int mColorCancel;
    private int mColorTitle;

    private int mColorBackgroundWheel;
    private int mColorBackgroundTitle;

    private int mSizeSubmitCancel;
    private int mSizeTitle;
    private int mSizeContent;

    private int mDividerColor;
    private int mTextColorOut;
    private int mTextColorCenter;

    private int mWheelMaxItems;
    private int mWheelItemHeight;

    private String[] mTimePrefixArray;
    private String[] mTimeSuffixArray;

    private TimePickerView(Builder builder) {
        super(builder.mContext, builder.mIsDialog);
        this.mOnTimeSelectListener = builder.mOnTimeSelectListener;
        this.mPickerType = builder.mPickerType;
        this.mDate = builder.mDate;
        this.mStartYear = builder.mStartYear;
        this.mEndYear = builder.mEndYear;
        this.mCyclic = builder.mCyclic;
        this.mCancelable = builder.mCancelable;

        this.mStrSubmit = builder.mStrSubmit;
        this.mStrCancel = builder.mStrCancel;
        this.mStrTitle = builder.mStrTitle;
        this.mColorSubmit = builder.mColorSubmit;
        this.mColorCancel = builder.mColorCancel;
        this.mColorTitle = builder.mColorTitle;
        this.mColorBackgroundWheel = builder.mColorBackgroundWheel;
        this.mColorBackgroundTitle = builder.mColorBackgroundTitle;
        this.mSizeSubmitCancel = builder.mSizeSubmitCancel;
        this.mSizeTitle = builder.mSizeTitle;
        this.mSizeContent = builder.mSizeContent;
        this.mDividerColor = builder.mDividerColor;
        this.mTextColorCenter = builder.mTextColorCenter;
        this.mTextColorOut = builder.mTextColorOut;

        this.mWheelMaxItems = builder.mWheelMaxItems;
        this.mWheelItemHeight = builder.mWheelItemHeight;
        this.mTimePrefixArray = builder.mTimePrefixArray;
        this.mTimeSuffixArray = builder.mTimeSuffixArray;
        initView(builder.mContext);
    }

    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.ui_library_layout_picker_view_time, mContentContainer);

        // 顶部标题
        TextView tvTitle = findViewById(R.id.tv_title);
        // 确认和取消按钮
        TextView tvSubmit = findViewById(R.id.tv_submit);
        TextView tvCancel = findViewById(R.id.tv_cancel);

        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnTimeSelectListener != null) {
                    try {
                        Date selectDate = WheelTime.DATE_FORMAT.parse(mWheelTime.getTime());
                        mOnTimeSelectListener.onTimeSelect(selectDate, v);
                    } catch (ParseException e) {
                        Log.w(TAG, "parse error:" + e);
                    }
                }
                TimePickerView.this.dismiss();
            }
        });
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerView.this.dismiss();
            }
        });

        // 设置文字
        tvSubmit.setText(TextUtils.isEmpty(mStrSubmit)
                ? context.getString(R.string.ui_library_picker_text_complete) : mStrSubmit);
        tvCancel.setText(TextUtils.isEmpty(mStrCancel)
                ? context.getString(R.string.ui_library_picker_text_cancel) : mStrCancel);
        tvTitle.setText(mStrTitle);

        // 设置文字颜色
        int defaultSubmitColor = ContextCompat.getColor(context, R.color.ui_library_orange_brand);
        tvTitle.setTextColor(mColorTitle == 0 ? Color.BLACK : mColorTitle);
        tvSubmit.setTextColor(mColorSubmit == 0 ? defaultSubmitColor : mColorSubmit);
        tvCancel.setTextColor(mColorCancel == 0 ? defaultSubmitColor : mColorCancel);

        // 设置文字大小
        tvSubmit.setTextSize(mSizeSubmitCancel);
        tvCancel.setTextSize(mSizeSubmitCancel);
        tvTitle.setTextSize(mSizeTitle);

        findViewById(R.id.rv_header).setBackgroundColor(mColorBackgroundTitle == 0 ? Color.WHITE : mColorBackgroundTitle);
        // 时间转轮 自定义控件
        LinearLayout timePickerView = findViewById(R.id.ll_time_picker);
        timePickerView.setBackgroundColor(mColorBackgroundWheel == 0 ? Color.WHITE : mColorBackgroundWheel);

        mWheelTime = new WheelTime(timePickerView, mPickerType, mSizeContent);

        if (mStartYear != 0 && mEndYear != 0 && mStartYear <= mEndYear) {
            // 设置可以选择的时间范围, 要在setTime之前调用才有效果
            mWheelTime.setStartYear(mStartYear);
            mWheelTime.setEndYear(mEndYear);
        }
        setTime(mDate);
        setOutSideCancelable(mCancelable);
        mWheelTime.setCyclic(mCyclic);
        mWheelTime.setDividerColor(mDividerColor);
        mWheelTime.setTextColorCenter(mTextColorCenter);
        mWheelTime.setTextColorOut(mTextColorOut);
        mWheelTime.setWheelMaxItems(mWheelMaxItems);
        if (mWheelItemHeight > 0) {
            mWheelTime.setWheelItemHeight(mWheelItemHeight);
        }
    }

    /**
     * 设置选中时间,默认选中当前时间
     */
    public void setTime(Date date) {
        Calendar calendar = Calendar.getInstance();
        if (date == null) {
            calendar.setTimeInMillis(System.currentTimeMillis());
        } else {
            calendar.setTime(date);
        }

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hours = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int seconds = calendar.get(Calendar.SECOND);
        mWheelTime.setPicker(year, month, day, hours, minute, seconds, mTimePrefixArray, mTimeSuffixArray);
    }


    public interface OnTimeSelectListener {
        void onTimeSelect(Date date, View v);
    }

    public static class Builder {

        private Context mContext;
        private OnTimeSelectListener mOnTimeSelectListener;

        @PickerTypes
        private int mPickerType = PICKER_TYPE_ALL;
        private boolean mIsDialog;

        private Date mDate;
        private int mStartYear;
        private int mEndYear;
        private boolean mCyclic = false;
        private boolean mCancelable = true;

        private String mStrSubmit;
        private String mStrCancel;
        private String mStrTitle;

        private int mColorSubmit;
        private int mColorCancel;
        private int mColorTitle;

        private int mColorBackgroundWheel;
        private int mColorBackgroundTitle;

        private int mSizeSubmitCancel = 15;
        private int mSizeTitle = 15;
        private int mSizeContent = 16;

        private int mDividerColor;
        private int mTextColorOut;
        private int mTextColorCenter;

        private int mWheelMaxItems = 7;
        private int mWheelItemHeight;

        private String[] mTimePrefixArray;
        private String[] mTimeSuffixArray;

        // Required
        public Builder(@NonNull Context context) {
            mContext = context;
        }

        /**
         * 设置监听
         */
        public Builder setOnTimeSelectListener(OnTimeSelectListener onTimeSelectListener) {
            mOnTimeSelectListener = onTimeSelectListener;
            return this;
        }

        /**
         * 设置 PickerView 展示的时间类型，默认全部显示（年月日时分秒）
         */
        public Builder setPickerType(@PickerTypes int pickerType) {
            mPickerType = pickerType;
            return this;
        }

        /**
         * 设置是否以 Dialog 形式展示
         */
        public Builder isDialog(boolean isDialog) {
            mIsDialog = isDialog;
            return this;
        }

        /**
         * 设置初始选中时间
         */
        public Builder setDate(Date date) {
            mDate = date;
            return this;
        }

        /**
         * 设置年份区间
         */
        public Builder setRange(int startYear, int endYear) {
            mStartYear = startYear;
            mEndYear = endYear;
            return this;
        }

        /**
         * 设置是否循环，默认 false
         */
        public Builder isCyclic(boolean cyclic) {
            mCyclic = cyclic;
            return this;
        }

        /**
         * 设置是否能取消，默认 true
         */
        public Builder setCancelable(boolean cancelable) {
            mCancelable = cancelable;
            return this;
        }

        /**
         * 设置确认按钮字符串
         */
        public Builder setSubmitText(String strSubmit) {
            mStrSubmit = strSubmit;
            return this;
        }

        /**
         * 设置取消按钮字符串
         */
        public Builder setCancelText(String strCancel) {
            mStrCancel = strCancel;
            return this;
        }

        /**
         * 设置标题字符串
         */
        public Builder setTitleText(String strTitle) {
            mStrTitle = strTitle;
            return this;
        }

        /**
         * 设置确认按钮文本颜色，未设置或为 0 时默认橙色
         */
        public Builder setSubmitColor(@ColorInt int colorSubmit) {
            mColorSubmit = colorSubmit;
            return this;
        }

        /**
         * 设置取消按钮文本颜色，未设置或为 0 时默认橙色
         */
        public Builder setCancelColor(@ColorInt int colorCancel) {
            mColorCancel = colorCancel;
            return this;
        }

        /**
         * 设置标题文本颜色，未设置或为 0 时默认黑色
         */
        public Builder setTitleColor(@ColorInt int colorTitle) {
            mColorTitle = colorTitle;
            return this;
        }

        /**
         * 设置标题框背景颜色，未设置或为 0 时默认白色
         */
        public Builder setTitleBgColor(@ColorInt int colorBackgroundTitle) {
            mColorBackgroundTitle = colorBackgroundTitle;
            return this;
        }

        /**
         * 设置滚轮背景颜色，未设置或为 0 时默认白色
         */
        public Builder setBgColor(@ColorInt int colorBackgroundWheel) {
            mColorBackgroundWheel = colorBackgroundWheel;
            return this;
        }

        /**
         * 设置确认、取消按钮字体大小，默认 15sp
         */
        public Builder setSubmitTextSize(@Dimension(unit = Dimension.SP) int sizeSubmitCancel) {
            mSizeSubmitCancel = sizeSubmitCancel;
            return this;
        }

        /**
         * 设置标题字体大小，默认 15sp
         */
        public Builder setTitleSize(@Dimension(unit = Dimension.SP) int sizeTitle) {
            mSizeTitle = sizeTitle;
            return this;
        }

        /**
         * 设置滚轮内容字体大小，默认 16sp
         */
        public Builder setContentSize(@Dimension(unit = Dimension.SP) int sizeContent) {
            mSizeContent = sizeContent;
            return this;
        }

        /**
         * 设置滚轮分割线的颜色
         */
        public Builder setDividerColor(@ColorInt int dividerColor) {
            mDividerColor = dividerColor;
            return this;
        }

        /**
         * 设置滚轮分割线之间的文字的颜色
         */
        public Builder setTextColorCenter(@ColorInt int textColorCenter) {
            mTextColorCenter = textColorCenter;
            return this;
        }

        /**
         * 设置滚轮分割线以外文字的颜色
         */
        public Builder setTextColorOut(@ColorInt int textColorOut) {
            mTextColorOut = textColorOut;
            return this;
        }

        /**
         * 设置滚轮 item 数量，奇数效果更好
         */
        public Builder setWheelMaxItems(@IntRange(from = 0) int wheelMaxItems) {
            if (wheelMaxItems >= 0) {
                mWheelMaxItems = wheelMaxItems;
            }
            return this;
        }

        /**
         * 设置滚轮 item 高度
         */
        public Builder setWheelItemHeight(@Dimension @IntRange(from = 1) int wheelItemHeight) {
            if (wheelItemHeight > 0) {
                mWheelItemHeight = wheelItemHeight;
            }
            return this;
        }

        /**
         * 设置年月日时分秒的前缀
         */
        public Builder setTimePrefixArray(String[] timePrefixArray) {
            if (timePrefixArray == null || timePrefixArray.length == 6) {
                mTimePrefixArray = timePrefixArray;
            }
            return this;
        }

        /**
         * 设置年月日时分秒的后缀
         */
        public Builder setTimeSuffixArray(String[] timeSuffixArray) {
            if (timeSuffixArray == null || timeSuffixArray.length == 6) {
                mTimeSuffixArray = timeSuffixArray;
            }
            return this;
        }

        public TimePickerView build() {
            return new TimePickerView(this);
        }
    }

}

