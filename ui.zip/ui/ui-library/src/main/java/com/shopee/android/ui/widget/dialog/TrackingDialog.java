package com.shopee.android.ui.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;

/**
 * Created by honggang.xiong on 2021/12/22.
 */
public abstract class TrackingDialog<D extends TrackingDialog<?>> extends Dialog {

    // 全局的上报 pv 时使用的 pageName 前缀以及上报点击事件时使用的 pageName 前缀，根据设计需要可能不一样。
    // eg: pvPageName = "dialog_home_page_exit"，clickEvent = "btn_home_page_exit_cancel"，则 pageName
    // 设置为 "home_page_exit"，sPvPageNamePrefix 设置为 "dialog"，sClickPageNamePrefix 设置为 "btn"
    private static String sGlobalPvPageNamePrefix;
    private static String sGlobalClickPrefix;
    private static EventTrackListener sTrackListener;

    private long mPvStartTime;
    private String mReportPageName;
    private String mReportUserType;
    private String mPvPageNamePrefix;
    private String mClickPrefix;

    public TrackingDialog(@NonNull Context context) {
        this(context, 0);
    }

    public TrackingDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
        mPvPageNamePrefix = sGlobalPvPageNamePrefix;
        mClickPrefix = sGlobalClickPrefix;
    }

    // 静态实例，全局设置一次即可
    public static void setEventTrackListener(EventTrackListener listener) {
        sTrackListener = listener;
    }

    public static void setGlobalPageNamePrefix(String pvPrefix, String clickPrefix) {
        sGlobalPvPageNamePrefix = pvPrefix;
        sGlobalClickPrefix = clickPrefix;
    }

    @NonNull
    protected abstract D getSelf();

    public D setOnClickListener(@IdRes int viewId, View.OnClickListener listener) {
        return setOnClickListener(viewId, listener, null, true);
    }

    public D setOnClickListener(@IdRes int viewId, View.OnClickListener listener, boolean autoDismiss) {
        return setOnClickListener(viewId, listener, null, autoDismiss);
    }

    public D setOnClickListener(@IdRes int viewId, View.OnClickListener listener, String trackClickName) {
        return setOnClickListener(viewId, listener, trackClickName, true);
    }

    public D setOnClickListener(@IdRes int viewId, final View.OnClickListener listener, final String trackClickName,
                                final boolean autoDismiss) {
        findViewById(viewId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reportClick(trackClickName);
                if (listener != null) {
                    listener.onClick(v);
                }
                if (autoDismiss) {
                    dismiss();
                }
            }
        });
        return getSelf();
    }

    public D setReportPageName(String reportPageName) {
        mReportPageName = reportPageName;
        return getSelf();
    }

    public D setReportUserType(String reportUserType) {
        mReportUserType = reportUserType;
        return getSelf();
    }

    public D setPageNamePrefix(String pvPrefix, String clickPrefix) {
        mPvPageNamePrefix = pvPrefix;
        mClickPrefix = clickPrefix;
        return getSelf();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mPvStartTime = SystemClock.elapsedRealtime();
        reportPv();
    }

    @Override
    protected void onStop() {
        super.onStop();
        reportDuration();
    }

    private void reportPv() {
        String pvPageName = getPvPageName();
        if (sTrackListener != null && !TextUtils.isEmpty(pvPageName)) {
            sTrackListener.onTrackPv(pvPageName, mReportUserType);
        }
    }

    private void reportDuration() {
        String pvPageName = getPvPageName();
        if (sTrackListener != null && !TextUtils.isEmpty(pvPageName)) {
            sTrackListener.onTrackDuration(pvPageName, SystemClock.elapsedRealtime() - mPvStartTime, mReportUserType);
        }
    }

    protected void reportClick(String clickName) {
        String clickPageName = getClickName(clickName);
        if (sTrackListener != null && !TextUtils.isEmpty(clickPageName)) {
            sTrackListener.onTrackClick(clickPageName, mReportUserType);
        }
    }

    protected String getPvPageName() {
        if (TextUtils.isEmpty(mReportPageName)) {
            return null;
        }
        return TextUtils.isEmpty(mPvPageNamePrefix) ? mReportPageName : mPvPageNamePrefix + "_" + mReportPageName;
    }

    protected String getClickName(String clickName) {
        if (TextUtils.isEmpty(clickName)) {
            return null;
        }
        return TextUtils.isEmpty(mClickPrefix) ? clickName : mClickPrefix + "_" + clickName;
    }


    public interface EventTrackListener {
        void onTrackPv(String pageName, String userType);

        void onTrackDuration(String pageName, long stayMillis, String userType);

        void onTrackClick(String eventKey, String userType);
    }

}
