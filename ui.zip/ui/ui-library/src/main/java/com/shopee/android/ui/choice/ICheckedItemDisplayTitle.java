package com.shopee.android.ui.choice;

/**
 * 用于 {@link CheckedItem} 自动获取 display title
 *
 * Created by honggang.xiong on 2020/8/19.
 */
public interface ICheckedItemDisplayTitle {

    String getCheckedItemDisplayTitle();

}
