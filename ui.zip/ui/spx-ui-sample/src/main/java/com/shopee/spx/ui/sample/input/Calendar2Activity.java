package com.shopee.spx.ui.sample.input;

import android.view.View;

import androidx.annotation.IntRange;

import com.shopee.sc.ui.calendar.CalendarBean;

import java.util.Calendar;

public class Calendar2Activity extends CalendarActivity {

    @Override
    protected void initView() {
        super.initView();
        mTvClear.setVisibility(View.GONE);
        setDateRangeWithShift(0, 3, 0, 0, 0, 0);
    }

    public void setDateRangeWithShift(int preYear, int preMonth, int preDay, int afterYear, int afterMonth, int afterDay) {
        setDateRangeWithShift(System.currentTimeMillis(), preYear, preMonth, preDay, afterYear, afterMonth, afterDay);
    }

    public void setDateRangeWithShift(long timeMillis, @IntRange(from = 0) int preYear,
                                      @IntRange(from = 0) int preMonth,
                                      @IntRange(from = 0) int preDay,
                                      @IntRange(from = 0) int afterYear,
                                      @IntRange(from = 0) int afterMonth,
                                      @IntRange(from = 0) int afterDay) {
        Calendar start = java.util.Calendar.getInstance();
        start.setTimeInMillis(timeMillis);
        start.add(java.util.Calendar.YEAR, -preYear);
        start.add(java.util.Calendar.MONTH, -preMonth);
        start.add(java.util.Calendar.DAY_OF_MONTH, -preDay);

        Calendar end = java.util.Calendar.getInstance();
        end.setTimeInMillis(timeMillis);
        end.add(java.util.Calendar.YEAR, afterYear);
        end.add(java.util.Calendar.MONTH, afterMonth);
        end.add(java.util.Calendar.DAY_OF_MONTH, afterDay);
        mCalendarView.setRange(new CalendarBean(start), new CalendarBean(end));
        mCalendarView.scrollToCurrent();
        mCalendarView.postInvalidate();
    }

}