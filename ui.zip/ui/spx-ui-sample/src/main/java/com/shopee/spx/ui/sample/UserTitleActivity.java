package com.shopee.spx.ui.sample;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.HorizontalScrollView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.shopee.spx.ui.util.ContextUtils;
import com.shopee.spx.ui.widget.CustomExpandableTitle;
import com.shopee.spx.ui.widget.CustomTitle;
import com.shopee.spx.ui.widget.ScCommonTitle;
import com.shopee.spx.ui.widget.bean.TitleMenuItem;
import com.shopee.spx.ui.widget.tab.SlidingTabLayout;

import java.util.ArrayList;
import java.util.List;

public class UserTitleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_title);
        setCommonTitleBg();

        CustomTitle customTitle = findViewById(R.id.test_custom_title);
        ViewPager viewPager = findViewById(R.id.vp_express);
        FragmentStatePagerAdapter pagerAdapter;
        String[] mTabTitles = {"To-do","Done"};
        pagerAdapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return new Fragment();
            }

            @Override
            public int getCount() {
                return 2;
            }
        };
        viewPager.setAdapter(pagerAdapter);

        SlidingTabLayout mSlideTab = new SlidingTabLayout(this);
        HorizontalScrollView.LayoutParams lp = new HorizontalScrollView.LayoutParams(
                ContextUtils.dp2px(this, 200), ContextUtils.dp2px(this, 48));
        lp.gravity = Gravity.BOTTOM;
        mSlideTab.setLayoutParams(lp);
        mSlideTab.setBottomDividerVisible(false);
        mSlideTab.setTextSelectColor(getResources().getColor(R.color.black));
        mSlideTab.setTextUnselectColor(getResources().getColor(R.color.font_color_second));
        mSlideTab.setTextSize(18);
        mSlideTab.setViewPager(viewPager, mTabTitles);
        mSlideTab.setCurrentTab(0, true);
        mSlideTab.setIndicatorHeight(3);
        customTitle.addTabContainer(mSlideTab);
        multiItemMenu();
    }

    public void setCommonTitleBg() {
        ScCommonTitle commonTitle = findViewById(R.id.ct_change_bg);
        commonTitle.setBackgroundColor(ContextCompat.getColor(this, R.color.orange_brand));
        commonTitle.setCentTitleColor(Color.WHITE);
        commonTitle.setBackIconColor(Color.WHITE);
    }


    public void multiItemMenu() {
        CustomExpandableTitle multiCustomTitle = findViewById(R.id.multi_item_custom_title);
        List<TitleMenuItem> titleMenuItems = new ArrayList<>();
        titleMenuItems.add(new TitleMenuItem("label1", R.drawable.ic_back_24, "Test Item 2"));
        titleMenuItems.add(new TitleMenuItem("label2", R.drawable.ic_drop_up, "Test Item 3"));
        titleMenuItems.add(new TitleMenuItem("label3", R.drawable.ic_navigate, "Test Item 4"));
        multiCustomTitle.setBaseTitleItems(titleMenuItems);
        multiCustomTitle.addBaseTitleItemRightToLeft(1,
                new TitleMenuItem("label4", R.drawable.ic_avatar_default, "Test Item 6"));
        multiCustomTitle.notifyMenuChange();
        multiCustomTitle.setMenuReDotNumber("label4", 100);
    }
}