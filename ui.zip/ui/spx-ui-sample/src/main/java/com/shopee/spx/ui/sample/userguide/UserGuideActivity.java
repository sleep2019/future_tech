package com.shopee.spx.ui.sample.userguide;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.shopee.spx.ui.sample.R;
import com.shopee.userguide.UserGuide;
import com.shopee.userguide.bubble.RelativePos;
import com.shopee.userguide.core.Controller;
import com.shopee.userguide.listener.OnLayoutInflatedListener;
import com.shopee.userguide.model.GuideBubble;
import com.shopee.userguide.model.GuidePage;
import com.shopee.userguide.model.HighLight;
import com.shopee.userguide.model.RelativeBubble;

public class UserGuideActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_guide);
        final ImageView ivIcon = findViewById(R.id.iv_icon);
        final Button btnSimple = (Button) findViewById(R.id.btn_simple_guide);
        final Button btnDialog = (Button) findViewById(R.id.btn_dialog_guide);
        final Button btnBubble1 = (Button) findViewById(R.id.btn_bubble_guide1);
        final Button btnBubble2 = (Button) findViewById(R.id.btn_bubble_guide2);
        final Button btnBubble3 = (Button) findViewById(R.id.btn_bubble_guide3);

        //简单蒙板使用
        btnSimple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserGuide.with(UserGuideActivity.this) //可以传入新手指引所在的Activity或者Fragment
                        .setLabel("simpleguide") //设置引导页的标签，需要是唯一的，且必须设置否则报错
                        .alwaysShow(true)//总是显示，调试时可以打开
                        .addGuidePage(GuidePage.newInstance() //添加GuidePage
                                .addHighLight(ivIcon, HighLight.Shape.CIRCLE, 20, //添加高亮
                                        new RelativeBubble(R.layout.layout_simple_bubble, Gravity.START, 16, 8, R.id.tv_next))
                                .setEverywhereCancelable(false)
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        view.findViewById(R.id.iv_close).setVisibility(View.GONE); //隐藏布局中close图标
                                        view.findViewById(R.id.ll_sequence).setVisibility(View.VISIBLE); //显示sequence信息
                                        ((TextView) view.findViewById(R.id.tv_sequence)).setText("1/2");
                                    }
                                }))
                        .addGuidePage(GuidePage.newInstance()
                                .addHighLight(ivIcon, HighLight.Shape.CIRCLE, 20,
                                        new RelativeBubble(R.layout.layout_simple_bubble, Gravity.BOTTOM, 16, 8, R.id.tv_next))
                                .setEverywhereCancelable(false)
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        view.findViewById(R.id.iv_close).setVisibility(View.GONE); //隐藏布局中close图标
                                        view.findViewById(R.id.ll_sequence).setVisibility(View.VISIBLE); //显示sequence信息
                                        ((TextView) view.findViewById(R.id.tv_sequence)).setText("2/2");
                                    }
                                }))
                        .show(); //直接显示引导层
                //如果不想马上显示可以使用build方法返回一个Controller对象，完成构建。需要显示得时候再次调用Controller对象的show方法进行显示。
            }
        });

        //对话框形式(3页）
        ColorStateList lightColor = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.orange_brand));
        ColorStateList greyColor = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.font_color_second_50));
        btnDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserGuide.with(UserGuideActivity.this)
                        .setLabel("dialogguide")
                        .alwaysShow(true)//总是显示，调试时可以打开
                        .addGuidePage(GuidePage.newInstance()
                                .setEverywhereCancelable(false)
                                .setLayoutRes(R.layout.layout_guide_dialog, R.id.btn_next)
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        ((TextView) view.findViewById(R.id.tv_message)).setText("New guide dialog -- page 1");
                                        ((TextView) view.findViewById(R.id.btn_previous)).setTextColor(getResources().getColor(R.color.dialog_second_button_disable_color));
                                        view.findViewById(R.id.btn_previous).setOnClickListener(null);
                                        view.findViewById(R.id.iv_dot0).setBackgroundTintList(lightColor);
                                        view.findViewById(R.id.iv_dot1).setBackgroundTintList(greyColor);
                                        view.findViewById(R.id.iv_dot2).setBackgroundTintList(greyColor);
                                        view.findViewById(R.id.iv_close).setOnClickListener(v -> controller.removeAndSkip()); //中断引导，后面不再展示
                                    }
                                }))
                        .addGuidePage(GuidePage.newInstance()
                                .setEverywhereCancelable(false)
                                .setLayoutRes(R.layout.layout_guide_dialog, R.id.btn_next)
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        ((TextView) view.findViewById(R.id.tv_message)).setText("New guide dialog -- page 2");
                                        view.findViewById(R.id.iv_dot0).setBackgroundTintList(greyColor);
                                        view.findViewById(R.id.iv_dot1).setBackgroundTintList(lightColor);
                                        view.findViewById(R.id.iv_dot2).setBackgroundTintList(greyColor);
                                        view.findViewById(R.id.btn_previous).setOnClickListener(v -> controller.showPreviewContent()); //展示前一页
                                        view.findViewById(R.id.iv_close).setOnClickListener(v -> controller.removeAndSkip()); //中断引导，后面不再展示
                                    }
                                }))
                        .addGuidePage(GuidePage.newInstance()
                                .setEverywhereCancelable(false)
                                .setLayoutRes(R.layout.layout_guide_dialog, R.id.btn_next)
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        ((TextView) view.findViewById(R.id.tv_message)).setText("New guide dialog -- page 3");
                                        view.findViewById(R.id.iv_dot0).setBackgroundTintList(greyColor);
                                        view.findViewById(R.id.iv_dot1).setBackgroundTintList(greyColor);
                                        view.findViewById(R.id.iv_dot2).setBackgroundTintList(lightColor);
                                        view.findViewById(R.id.btn_previous).setOnClickListener(v -> controller.showPreviewContent()); //展示前一页
                                        view.findViewById(R.id.iv_close).setOnClickListener(v -> controller.removeAndSkip()); //中断引导，后面不再展示
                                    }
                                }))
                        .show();
            }
        });

        //简单气泡，会自动消失
        btnBubble1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserGuide.with(UserGuideActivity.this)
                        .setLabel("bubbleguide")
                        .alwaysShow(true)//总是显示，调试时可以打开
                        .addGuideBubble(GuideBubble.newInstance() //添加引导气泡对象
                                .setLayoutRes(R.layout.layout_simple_bubble, R.id.popup_bubble) //设置包含气泡控件的布局id 和 该布局中气泡控件的id（用于对气泡添加箭头）
                                .setCancelOnTouch(false) //点击气泡不消失
                                .setDismissMilliSecond(3000) //气泡消失时间
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        View ivClose = view.findViewById(R.id.iv_close); //隐藏布局中close图标
                                        ivClose.setVisibility(View.GONE);
                                    }
                                })
                                // 设置气泡指向的anchorView、箭头相对anchorView的位置、与anchorView的水平边距（dp）、与anchorView的垂直边距（dp）
                                .setArrowTo(btnBubble1, new RelativePos(RelativePos.CENTER_HORIZONTAL, RelativePos.ABOVE), 0, 8))
                        .show();
            }
        });

        //带关闭按钮气泡
        btnBubble2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserGuide.with(UserGuideActivity.this)
                        .setLabel("multibubble")
                        .alwaysShow(true)//总是显示，调试时可以打开
                        .addGuideBubble(GuideBubble.newInstance()
                                .setLayoutRes(R.layout.layout_simple_bubble, R.id.popup_bubble) //气泡图文样式布局，布局中气泡控件id
                                .setCancelOnTouch(false)
                                .setDismissId(R.id.iv_close) //点击使气泡消失的控件id
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        TextView tv = view.findViewById(R.id.tv_msg);
                                        tv.setText("Quick Pickup move to here. -- sequence 1");
                                    }
                                })
                                // 设置气泡指向的anchorView、箭头相对anchorView的位置、与anchorView的水平边距（dp）、与anchorView的垂直边距（dp）
                                .setArrowTo(ivIcon, new RelativePos(RelativePos.CENTER_HORIZONTAL, RelativePos.BELOW), 0, 8))
                        .addGuideBubble(GuideBubble.newInstance()
                                .setLayoutRes(R.layout.layout_simple_bubble, R.id.popup_bubble) //气泡图文样式布局，布局中气泡控件id
                                .setCancelOnTouch(false)
                                .setDismissId(R.id.iv_close) //点击使气泡消失的控件id
                                .setOnLayoutInflatedListener(new OnLayoutInflatedListener() {
                                    @Override
                                    public void onLayoutInflated(View view, Controller controller) {
                                        TextView tv = view.findViewById(R.id.tv_msg);
                                        tv.setText("Quick Pickup move to here. -- sequence 2");
                                    }
                                })
                                // 设置气泡指向的anchorView、箭头相对anchorView的位置、与anchorView的水平边距（dp）、与anchorView的垂直边距（dp）
                                .setArrowTo(ivIcon, new RelativePos(RelativePos.TO_LEFT_OF, RelativePos.CENTER_VERTICAL), 8, 0))
                        .show();
            }
        });

        //复杂图文气泡
        btnBubble3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserGuide.with(UserGuideActivity.this)
                        .setLabel("comlextbubble")
                        .alwaysShow(true)//总是显示，调试时可以打开
                        .addGuideBubble(GuideBubble.newInstance()
                                .setLayoutRes(R.layout.layout_complex_bubble, R.id.view_bubble)
                                .setCancelOnTouch(true)
                                .setArrowTo(btnBubble3, new RelativePos(RelativePos.CENTER_HORIZONTAL, RelativePos.ABOVE), 0, 8))
                        .show();
            }
        });

        // fragment 中使用
        findViewById(R.id.btn_fragment).setOnClickListener(v -> {
            startActivity(new Intent(this, UserGuideFragmentActivity.class));
        });
    }

}