package com.shopee.spx.ui.sample.util;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;

import com.shopee.spx.ui.sample.R;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Created by heroxiong on 2018/3/19.
 */

public class UiUtils {

    private static final int MAX_SINGLE_LINE_LENGTH = 40;

    public static DisplayMetrics getDisplayMetrics() {
        return Resources.getSystem().getDisplayMetrics();
    }

    public static int getScreenWidth() {
        return getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return getDisplayMetrics().heightPixels;
    }

    public static int getStatusBarHeight(Context context) {
        int statusBarHeight = -1;
        try {
            int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                statusBarHeight = context.getResources().getDimensionPixelSize(resourceId);
            }
        } catch (Exception e) {
        }
        return statusBarHeight;
    }

    /**
     * dp转换成px
     */
    public static int dp2px(Context context, float dpValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * px转换成dp
     */
    public static int px2dp(Context context, float pxValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    /**
     * sp转换成px
     */
    public static int sp2px(Context context, float spValue) {
        float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }

    /**
     * px转换成sp
     */
    public static int px2sp(Context context, float pxValue) {
        float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (pxValue / fontScale + 0.5f);
    }

    public static Activity getActivityFromView(View view) {
        if (view != null) {
            Context context = view.getContext();
            while (context instanceof ContextWrapper) {
                if (context instanceof Activity) {
                    return (Activity) context;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        return null;
    }

    public static void transparentStatusBar(Activity activity, boolean isLayoutFullscreen) {
        if (isLayoutFullscreen) {
            activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setStatusBarColor(activity, Color.TRANSPARENT);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    public static void setStatusBarColor(Activity activity, @ColorInt int color) {
        Window window = activity.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(color);
    }

    @RequiresApi(Build.VERSION_CODES.M)
    public static void setStatusBarLightModeCompat(Activity activity) {
        activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setStatusBarLightModeInMIUI(activity, true);
    }

    @RequiresApi(Build.VERSION_CODES.M)
    public static void setStatusBarLightModeCompatWithPreVisibility(Activity activity) {
        int visibility = activity.getWindow().getDecorView().getSystemUiVisibility();
        activity.getWindow().getDecorView().setSystemUiVisibility(visibility | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setStatusBarLightModeInMIUI(activity, true);
    }

    private static void setStatusBarLightModeInMIUI(Activity activity, boolean isLightMode) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O && "Xiaomi".equalsIgnoreCase(Build.BRAND)) {
            Window window = activity.getWindow();
            try {
                int lightModeFlag = 0;
                Class layoutParamsClass = Class.forName("android.view.MiuiWindowManager$LayoutParams");
                Field field = layoutParamsClass.getField("EXTRA_FLAG_STATUS_BAR_DARK_MODE");
                lightModeFlag = field.getInt(layoutParamsClass);
                Method setFlagMethod = window.getClass().getMethod("setExtraFlags", int.class, int.class);
                if (isLightMode) {
                    setFlagMethod.invoke(window, lightModeFlag, lightModeFlag);
                } else {
                    setFlagMethod.invoke(window, 0, lightModeFlag);
                }
            } catch (Exception e) {
                // ignore
            }
        }
    }

    public static void showKeyboard(@NonNull EditText editText) {
        InputMethodManager imm = (InputMethodManager) editText.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(editText, 0);
        }
    }

    public static void hideKeyboard(@NonNull EditText editText) {
        InputMethodManager imm = (InputMethodManager) editText.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
    }

    /**
     * 获取 {@link android.widget.PopupWindow#showAtLocation(View, int, int, int)} 时，PopupWindow
     * 需置于目标 View 正下方的 offsetY
     *
     * @param anchor 目标 View
     * @return offsetY
     */
    public static int getPopupOffsetYBelowAnchor(View anchor) {
        if (anchor == null) {
            return 0;
        }

        return getPopupAnchorY(anchor) + anchor.getHeight();
    }

    /**
     * 获取 {@link android.widget.PopupWindow#showAtLocation(View, int, int, int)} 时，PopupWindow
     * 需和目标 View 垂直中心对齐的 offsetY，PopupWindow 高度需已知
     *
     * @param anchor      目标 View
     * @param popupHeight PopupWindow 高度
     * @return offsetY
     */
    public static int getPopupOffsetYAlignAnchorCenter(View anchor, int popupHeight) {
        if (anchor == null) {
            return 0;
        }

        return getPopupAnchorY(anchor) + (anchor.getHeight() - popupHeight) / 2;
    }

    public static int getPopupAnchorY(@NonNull View anchor) {
        int[] temp = new int[2];
        anchor.getRootView().getLocationOnScreen(temp);
        int rootY = temp[1];
        anchor.getLocationOnScreen(temp);
        return temp[1] - rootY;
    }

    public static void showTextIfNotNull(@NonNull TextView textView, @Nullable String text) {
        if (TextUtils.isEmpty(text)) {
            textView.setVisibility(View.GONE);
        } else {
            textView.setVisibility(View.VISIBLE);
            textView.setText(text);
        }
    }

    public static void showTextIfNotZero(@NonNull TextView textView, @StringRes int stringRes) {
        if (stringRes == 0) {
            textView.setVisibility(View.GONE);
        } else {
            textView.setVisibility(View.VISIBLE);
            textView.setText(stringRes);
        }
    }

    public static void highlightTextView(TextView textView, String text, String searchKey) {
        highlightTextView(textView, text, searchKey, ContextCompat.getColor(textView.getContext(), R.color.orange_brand));
    }

    public static void highlightTextView(TextView textView, String text, String searchKey, @ColorInt int color) {
        int index;
        if (!TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(text) && (index = text.indexOf(searchKey)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            textView.setText(spannable);
        } else {
            textView.setText(text);
        }
    }

    // 高亮 TextView，原文本超长时做省略号处理
    public static void highlightTextViewWithEllipsis(@NonNull TextView textView, String text, String searchKey,
                                                     boolean highlightSearchKey) {
        int index;
        if (highlightSearchKey && !TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(text) && (index = text.toLowerCase().indexOf(searchKey.toLowerCase())) >= 0) {
            if (text.length() <= MAX_SINGLE_LINE_LENGTH) {
                SpannableString spannable = new SpannableString(text);
                int color = ContextCompat.getColor(textView.getContext(), R.color.orange_common);
                spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                textView.setText(spannable);
            } else {
                int startIndex = index;
                int tempIndex;
                String prefixString = text.substring(0, startIndex);
                if ((tempIndex = prefixString.lastIndexOf(" ")) >= 0) {
                    startIndex = tempIndex;
                    prefixString = text.substring(0, startIndex);
                    if ((tempIndex = prefixString.lastIndexOf(" ", startIndex)) >= 0) {
                        startIndex = tempIndex;
                    } else {
                        startIndex = 0;
                    }
                }
                String newText = text.substring(startIndex);
                if (startIndex > 0) {
                    newText = "…" + newText;
                }
                SpannableString spannable = new SpannableString(newText);
                index = newText.toLowerCase().indexOf(searchKey.toLowerCase());
                int color = ContextCompat.getColor(textView.getContext(), R.color.orange_common);
                spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                textView.setText(spannable);
            }
        } else {
            textView.setText(text);
        }
    }

    public static void boldTextView(TextView textView, String text, String... searchKey) {
        SpannableString spannable = new SpannableString(text);
        if (searchKey != null && searchKey.length > 0 && !TextUtils.isEmpty(text)) {
            for (String key : searchKey) {
                int index = text.indexOf(key);
                if (index >= 0) {
                    spannable.setSpan(new StyleSpan(Typeface.BOLD), index, index + key.length(),
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        }

        textView.setText(spannable);
    }

    /**
     * 对某段字体放大
     *
     * @param size 单位为dp
     */
    public static void scaleHighlightTextView(TextView textView, String text,
                                              String searchKey, int size, int color) {
        int index;
        if (!TextUtils.isEmpty(searchKey) && !TextUtils.isEmpty(text) && (index = text.indexOf(searchKey)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new AbsoluteSizeSpan(size, true), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannable.setSpan(new ForegroundColorSpan(color), index, index + searchKey.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            textView.setText(spannable);
        } else {
            textView.setText(text);
        }
    }

    public static CharSequence getHighlightText(String text, String subText, @ColorInt int color) {
        return getHighlightText(text, subText, color, null);
    }

    public static CharSequence getHighlightText(String text, String subText, @ColorInt int color,
                                                @Nullable Integer sizeInPx) {
        int index;
        if (!TextUtils.isEmpty(text) && !TextUtils.isEmpty(subText) && (index = text.indexOf(subText)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new ForegroundColorSpan(color), index, index + subText.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (sizeInPx != null) {
                spannable.setSpan(new AbsoluteSizeSpan(sizeInPx), index, index + subText.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            return spannable;
        } else {
            return text;
        }
    }

    public static CharSequence getHighlightAllText(final String text, final String subText, final @ColorInt int color) {
        int index;
        if (!TextUtils.isEmpty(text) && !TextUtils.isEmpty(subText) && (index = text.indexOf(subText)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            while (index >= 0) {
                spannable.setSpan(new ForegroundColorSpan(color), index, index + subText.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                index = text.indexOf(subText, index + subText.length());
            }
            return spannable;
        } else {
            return text;
        }
    }

    public static CharSequence getClickableText(String text, String subText, @ColorInt int color,
                                                boolean showUnderline, @Nullable View.OnClickListener onClickListener) {
        int index;
        if (!TextUtils.isEmpty(text) && !TextUtils.isEmpty(subText) && (index = text.indexOf(subText)) >= 0) {
            SpannableString spannable = new SpannableString(text);
            spannable.setSpan(new SimpleClickableSpan(color, showUnderline, onClickListener),
                    index, index + subText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            return spannable;
        } else {
            return text;
        }
    }


    public static class SimpleClickableSpan extends ClickableSpan {

        private final int mColorInt;
        private final boolean mShowUnderline;
        private final View.OnClickListener mOnClickListener;

        public SimpleClickableSpan(@ColorInt int colorInt, boolean showUnderline,
                                   @Nullable View.OnClickListener onClickListener) {
            mColorInt = colorInt;
            mShowUnderline = showUnderline;
            mOnClickListener = onClickListener;
        }

        @Override
        public void onClick(@NonNull View widget) {
            if (mOnClickListener != null) {
                mOnClickListener.onClick(widget);
            }
        }

        @Override
        public void updateDrawState(@NonNull TextPaint ds) {
            ds.setColor(mColorInt);
            ds.setUnderlineText(mShowUnderline);
        }
    }

    /**
     * 给imageView 的svg初始化颜色
     */
    public static Drawable initSvgColor(Context context, int imgRes, @ColorInt int tint) {
        //利用ContextCompat工具类获取drawable图片资源
        Drawable drawable = ContextCompat.getDrawable(context, imgRes);
        //简单的使用tint改变drawable颜色
        DrawableCompat.wrap(drawable).mutate();
        DrawableCompat.setTint(drawable, tint);
        return drawable;
    }

}
