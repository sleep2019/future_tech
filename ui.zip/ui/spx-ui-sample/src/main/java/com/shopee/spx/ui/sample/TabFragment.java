package com.shopee.spx.ui.sample;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class TabFragment extends Fragment {
    private String mTitle;

    public static TabFragment getInstance(String title) {
        TabFragment tf = new TabFragment();
        tf.mTitle = title;
        return tf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_tab, null);
        TextView card_title_tv = (TextView) v.findViewById(R.id.tv_title);
        card_title_tv.setText(mTitle);
        return v;
    }
}