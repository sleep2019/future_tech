package com.shopee.spx.ui.sample.input;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.shopee.sc.ui.calendar.CalendarBean;
import com.shopee.sc.ui.calendar.CalendarView;
import com.shopee.spx.ui.sample.R;
import com.shopee.spx.ui.sample.util.StringFormatUtil;
import com.shopee.spx.ui.sample.util.UiUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CalendarActivity extends FragmentActivity {

    private static final String TAG = "CalendarActivity";

    protected TextView mTvTitle;
    protected ImageView mIvClose;
    protected CalendarView mCalendarView;
    protected TextView mTvStartDate;
    protected TextView mTvEndDate;
    protected TextView mTvClear;
    protected TextView mTvConfirm;

    private SimpleDateFormat mFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    private CalendarBean mCalendarStart;
    private CalendarBean mCalendarEnd;
    private OnDateRangeConfirmListener mConfirmListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStatusBar();
        setContentView(R.layout.activity_test_calendar);
        initView();
    }

    @CallSuper
    protected void initView() {
        mTvTitle = findViewById(R.id.tv_title);
        mIvClose = findViewById(R.id.iv_close);
        mCalendarView = findViewById(R.id.calendar_view);
        mTvStartDate = findViewById(R.id.tv_start_date);
        mTvEndDate = findViewById(R.id.tv_end_date);
        mTvClear = findViewById(R.id.tv_clear);
        mTvConfirm = findViewById(R.id.tv_confirm);

        mIvClose.setOnClickListener(v -> finish());
        mCalendarView.setOnMonthChangeListener(this::setCurrentMonth);
        mCalendarView.setOnCalendarRangeSelectListener(new CalendarView.OnCalendarRangeSelectListener() {
            @Override
            public void onCalendarSelectOutOfRange(CalendarBean calendarBean) {

            }

            @Override
            public void onSelectOutOfRange(CalendarBean calendarBean, boolean isOutOfMinRange) {

            }

            @Override
            public void onCalendarRangeSelect(CalendarBean calendar, boolean isEnd) {
                if (!isEnd) {
                    mCalendarStart = calendar;
                }
                mCalendarEnd = calendar;
                handleRangeChanged();
            }
        });

        mTvClear.setOnClickListener(v -> {
            mCalendarView.clearRangeSelect();
            mCalendarStart = null;
            mCalendarEnd = null;
            handleRangeChanged();
        });

        mTvConfirm.setOnClickListener(v -> {
            if (mConfirmListener != null) {
                mConfirmListener.onDateRangeConfirmed(mCalendarStart, mCalendarEnd);
            }

            String text;
            if (mCalendarStart != null && mCalendarEnd != null) {
                if (mCalendarStart != mCalendarEnd) {
                    text = "Selected: " + formatDate(mCalendarStart) + " ~ " + formatDate(mCalendarEnd);
                } else {
                    text = "Selected: " + formatDate(mCalendarStart);
                }
            } else {
                text = "No Selected";
            }
            Toast.makeText(v.getContext(), text, Toast.LENGTH_SHORT).show();
        });

        handleRangeChanged();
    }

    private void setCurrentMonth(int year, int month) {
        Log.d(TAG, "setCurrentMonth: year=" + year + ", month=" + month);
    }

    @SuppressLint("SetTextI18n")
    private void handleRangeChanged() {
        updateSelectedDateViews(mTvStartDate, mTvEndDate, mCalendarStart, mCalendarEnd);
    }

    public static void updateSelectedDateViews(@NonNull TextView tvStartDate, @NonNull TextView tvEndDate,
                                               CalendarBean start, CalendarBean end) {
        if (start != null && end != null) {
            if (start == end) {
                setDateText(tvStartDate, R.string.selected, start);
                setDateText(tvEndDate, 0, null);
            } else {
                setDateText(tvStartDate, R.string.start, start);
                setDateText(tvEndDate, R.string.end, end);
            }
        } else {
            setDateText(tvStartDate, 0, null);
            setDateText(tvEndDate, 0, null);
        }
    }

    private static void setDateText(@NonNull TextView textView, @StringRes int prefixRes, CalendarBean bean) {
        if (prefixRes == 0 || bean == null) {
            textView.setVisibility(View.GONE);
            return;
        }

        textView.setVisibility(View.VISIBLE);
        String prefix = textView.getContext().getString(prefixRes);
        String content = StringFormatUtil.formatTime(bean.getTimeInMillis(), StringFormatUtil.YEAR_MONTH_DAY);
        textView.setText(UiUtils.getHighlightText(prefix + ": " + content, content,
                ContextCompat.getColor(textView.getContext(), R.color.font_color_main)));
    }


    public interface OnDateRangeConfirmListener {
        void onDateRangeConfirmed(@Nullable CalendarBean start, @Nullable CalendarBean end);
    }

    private String formatDate(CalendarBean bean) {
        return mFormat.format(new Date(bean.getTimeInMillis()));
    }

    protected void setStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // 设置状态栏与 App ActionBar 同色
            UiUtils.setStatusBarColor(this, ContextCompat.getColor(this, R.color.foreground_color));
            // 设置状态栏文字与图标为灰色
            UiUtils.setStatusBarLightModeCompat(this);
        }
    }

}