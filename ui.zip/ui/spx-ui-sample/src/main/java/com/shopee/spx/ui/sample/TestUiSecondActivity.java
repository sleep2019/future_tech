package com.shopee.spx.ui.sample;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.spx.ui.sample.input.Calendar2Activity;
import com.shopee.spx.ui.sample.input.CalendarActivity;
import com.shopee.spx.ui.sample.userguide.UserGuideActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-10-10.
 */
public class TestUiSecondActivity extends FragmentActivity {

    private static final String KEY_SECOND_TYPE = "key_second_type";
    public static final int TYPE_BASIC = 100;      // 基础
    public static final int TYPE_NAVIGATION = 200; // 导航
    public static final int TYPE_INPUT = 300;      // 数据录入
    public static final int TYPE_DISPLAY = 400;    // 数据展示
    public static final int TYPE_FEEDBACK = 500;   // 数据反馈
    public static final int TYPE_BUSINESS = 600;   // 业务组件

    public static boolean navigate(Context context, int type) {
        switch (type) {
//            case TYPE_BASIC:
            case TYPE_NAVIGATION:
            case TYPE_INPUT:
//            case TYPE_DISPLAY:
            case TYPE_FEEDBACK:
            case TYPE_BUSINESS:
                Intent intent = new Intent(context, TestUiSecondActivity.class);
                intent.putExtra(KEY_SECOND_TYPE, type);
                context.startActivity(intent);
                return true;
            default:
                return false;
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_ui_sub);
        int type = getIntent().getIntExtra(KEY_SECOND_TYPE, TYPE_BASIC);
        ((TextView) findViewById(R.id.tv_header)).setText(getTitleByType(type));
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setAdapter(new PdaUiSecondAdapter(getUiListByType(type)));
    }

    private String getTitleByType(int type) {
        switch (type) {
            case TYPE_INPUT:
                return "数据录入";
            case TYPE_FEEDBACK:
                return "数据反馈";
            case TYPE_NAVIGATION:
                return "导航 / Navigation";
            case TYPE_BUSINESS:
                return "业务控件";
            case TYPE_DISPLAY:
                return "数据展示";
            case TYPE_BASIC:
            default:
                return "通用";
        }
    }

    private List<Pair<String, Class<? extends Activity>>> getUiListByType(int type) {
        List<Pair<String, Class<? extends Activity>>> result = new ArrayList<>();
        switch (type) {
            case TYPE_INPUT:
                result.add(Pair.create("日历 Calendar", CalendarActivity.class));
                result.add(Pair.create("日历 Calendar(可选最近三个月)", Calendar2Activity.class));
                break;
            case TYPE_FEEDBACK:
                result.add(Pair.create("对话框 Dialog", DialogsActivity.class));
                break;
            case TYPE_BUSINESS:
                result.add(Pair.create("新手指引", UserGuideActivity.class));
                break;
            case TYPE_NAVIGATION:
                result.add(Pair.create("顶部栏", UserTitleActivity.class));
                result.add(Pair.create("页签", TabActivity.class));
                break;

            default:
                break;
        }
        return result;
    }


    static class PdaUiSecondAdapter extends BaseQuickAdapter<Pair<String, Class<? extends Activity>>, BaseViewHolder> {

        public PdaUiSecondAdapter(@Nullable List<Pair<String, Class<? extends Activity>>> data) {
            super(R.layout.item_debug_list, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, final Pair<String, Class<? extends Activity>> item) {
            helper.setText(R.id.tv_title, item.first);
            helper.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(), item.second);
                    v.getContext().startActivity(intent);
                }
            });
        }
    }
}
