package com.shopee.spx.ui.sample;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.spx.ui.sample.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-09-18.
 */
public class TestUIActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_ui);
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setAdapter(new PdaUiAdapter(getUiList()));
    }

    private List<PdaUiItem> getUiList() {
        List<PdaUiItem> result = new ArrayList<>();
        result.add(new PdaUiItem("通用", "按钮", TestUiSecondActivity.TYPE_BASIC));
        result.add(new PdaUiItem("导航", "包含顶部栏、页签等", TestUiSecondActivity.TYPE_NAVIGATION));
        result.add(new PdaUiItem("数据录入", "包含日历选择", TestUiSecondActivity.TYPE_INPUT));
        result.add(new PdaUiItem("数据展示", "包含列表、标签等", TestUiSecondActivity.TYPE_DISPLAY));
        result.add(new PdaUiItem("数据反馈", "包含对话框等", TestUiSecondActivity.TYPE_FEEDBACK));
        result.add(new PdaUiItem("公共工具", "教育引导", TestUiSecondActivity.TYPE_BUSINESS));
        return result;
    }


    static class PdaUiItem {
        String title;
        String content;
        int type;

        public PdaUiItem(String title, String content, int type) {
            this.title = title;
            this.content = content;
            this.type = type;
        }
    }

    static class PdaUiAdapter extends BaseQuickAdapter<PdaUiItem, BaseViewHolder> {

        public PdaUiAdapter(@Nullable List<PdaUiItem> data) {
            super(R.layout.item_pda_ui, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, final PdaUiItem item) {
            helper.setText(R.id.tv_title, item.title);
            helper.setText(R.id.tv_content, item.content);
            helper.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!TestUiSecondActivity.navigate(v.getContext(), item.type)) {
                        Toast.makeText(mContext, "To Be Continued", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

}
