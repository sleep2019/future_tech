package com.shopee.spx.ui.sample.userguide;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.shopee.spx.ui.sample.R;

public class UserGuideFragmentActivity extends AppCompatActivity {
    private String[] mSubTitles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_guide_tab);
        ViewPager viewPager = findViewById(R.id.view_pager);
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        mSubTitles = new String[]{"Fragment1", "Fragment2"};

        viewPager.setAdapter(new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @NonNull
            @Override
            public Fragment getItem(int position) {
                return UserGuideFragment.newInstance(position);
            }

            @Override
            public int getCount() {
                return mSubTitles.length;
            }

            @Override
            public int getItemPosition(@NonNull Object object) {
                return POSITION_NONE;
            }

            @Nullable
            @Override
            public CharSequence getPageTitle(int position) {
                return mSubTitles[position];
            }
        });
        viewPager.setOffscreenPageLimit(mSubTitles.length);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setCurrentItem(0, true);


    }
}