package com.shopee.spx.ui.sample.input;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;

import com.shopee.sc.ui.calendar.BaseMonthWeekPainter;
import com.shopee.sc.ui.calendar.CalendarBean;
import com.shopee.sc.ui.calendar.CalendarUtil;

/**
 * 范围选择月视图
 */
@Keep
public class CustomRangeMonthPainter extends BaseMonthWeekPainter {

    private final Paint mSelectedCenterBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int mPaddingVertical;
    private final int mRangeBgRadius;
    private final String mTextToday;
    private final String mRangeTextStart;
    private final String mRangeTextEnd;
    protected float mRangeTextBaseLine;

    public CustomRangeMonthPainter(Context context) {
        super(context);
        mSelectedCenterBgPaint.setColor(0xFFFFF5F0);
        mPaddingVertical = CalendarUtil.dp2px(context, 2);
        mRangeBgRadius = CalendarUtil.dp2px(context, 2);
        // TODO: change to string res
        mTextToday = "Today";
        mRangeTextStart = "Start";
        mRangeTextEnd = "End";
    }

    @Override
    protected void onPreviewHook(int itemHeight, int itemWidth, float textBaseLine) {
        super.onPreviewHook(itemHeight, itemWidth, textBaseLine);
        mRangeTextBaseLine = mPaddingVertical - mSelectedFestivalPaint.getFontMetrics().ascent;
    }

    @Override
    protected boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean calendar, int x, int y,
                                       boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {
        int cx = x + mItemWidth / 2;
        int top = y + mPaddingVertical;
        int bottom = y + mItemHeight - mPaddingVertical;
        if (isSelectedPre && isSelectedNext) { // 中间选中
            canvas.drawRect(x, top, x + mItemWidth, bottom, mSelectedCenterBgPaint);
            canvas.drawText(getDayText(calendar), cx, mTextBaseLine + y, mCurMonthTextPaint);
        } else { // 第一个/最后一个/单独选中
            canvas.drawRoundRect(x, top, x + mItemWidth, bottom, mRangeBgRadius, mRangeBgRadius, mSelectedBgPaint);
            canvas.drawText(getDayText(calendar), cx, mTextBaseLine + y, mSelectedTextPaint);

            // 绘制首尾提示
            if (isSelectedNext) { // 第一个
                canvas.drawText(mRangeTextStart, cx, mRangeTextBaseLine + top, mSelectedFestivalPaint);
            } else if (isSelectedPre) { // 最后一个
                canvas.drawText(mRangeTextEnd, cx, mRangeTextBaseLine + top, mSelectedFestivalPaint);
            }
        }
        return false;
    }

    @Override
    protected void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean calendar, int x, int y, boolean isSelected) {
    }

    @Override
    protected void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y,
                              boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected) {
        if (!isSelected) {
            int cx = x + mItemWidth / 2;
            Paint paint = isInRange(bean) ? mCurMonthTextPaint : mOtherMonthTextPaint;
            canvas.drawText(getDayText(bean), cx, mTextBaseLine + y, paint);
        }
    }

    private String getDayText(@NonNull CalendarBean bean) {
        return isCurrentDay(bean) ? mTextToday : String.valueOf(bean.getDay());
    }

}
