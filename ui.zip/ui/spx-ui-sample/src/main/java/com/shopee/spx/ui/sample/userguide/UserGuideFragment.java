package com.shopee.spx.ui.sample.userguide;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.shopee.spx.ui.sample.R;
import com.shopee.spx.ui.sample.base.BaseFragment;
import com.shopee.userguide.UserGuide;
import com.shopee.userguide.bubble.RelativePos;
import com.shopee.userguide.core.Controller;
import com.shopee.userguide.model.GuideBubble;


public class UserGuideFragment extends BaseFragment {

    private int no;
    Controller controller;
    TextView textView;
    ImageView ivIcon;

    public static UserGuideFragment newInstance(int no) {
        Bundle args = new Bundle();
        args.putInt("no", no);
        UserGuideFragment fragment = new UserGuideFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle arguments = getArguments();
        if (arguments != null) {
            no = arguments.getInt("no");
        }
    }


    @Override
    protected void initView() {
        super.initView();
        textView = (TextView) findViewById(R.id.tv);
        textView.setText("fragment:" + no);
        ivIcon = (ImageView) findViewById(R.id.iv_icon);
        controller = UserGuide.with(this)//传入fragment
                .setLabel("fragment")//设置引导层标示，必传！否则报错
//                .alwaysShow(true)
                .addGuideBubble(GuideBubble.newInstance()
                        .setLayoutRes(R.layout.layout_simple_bubble, R.id.popup_bubble)
                        .setCancelOnTouch(false)
                        .setDismissId(R.id.iv_close)
                        .setArrowTo(ivIcon, new RelativePos(RelativePos.CENTER_HORIZONTAL, RelativePos.ABOVE), 0, 8))
                .build();//直接显示引导层
    }

    @Override
    protected void onVisible() {
        super.onVisible();
        ivIcon.postDelayed(() -> {
            if (no == 1) {
                controller.show();
            }
        }, 200); //延迟一段时间等viewpager已经scroll到最终位置，避免气泡位置不准确
    }

    @Override
    protected void onInvisible() {
        super.onInvisible();
        if (no == 1 && controller.isShowing()) { //如果引导页没有在展示，不需要处理
            controller.removeOnly(); //此处调用removeOnly，下次该fragment onVisible时，会再次展示当前引导内容

            //controller.removeAndSkip(); //此处调用removeAndSkip，下次该fragment onVisible时，不会再展示任何内容
            //controller.resetLabel(); //此处调用resetLabel, 下次fragment onVisible时，会从引导内容的第一页开始展示
        }

    }

    @Override
    protected int contentViewId() {
        return R.layout.fragment_user_guide;
    }


}
