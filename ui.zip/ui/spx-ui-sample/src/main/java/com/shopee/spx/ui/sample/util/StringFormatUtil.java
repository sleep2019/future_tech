package com.shopee.spx.ui.sample.util;

import android.text.TextUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StringFormatUtil {

    public static final String DAY_MONTH_YEAR = "dd-MM-yyyy";
    public static final String DAY_MONTH_YEAR_SLASH = "dd/MM/yyyy";
    public static final String HOUR_DAY_MONTH_YEAR = "HH:mm dd-MM-yyyy";
    public static final String YEAR_MONTH_DAY_HOUR = "yyyy-MM-dd HH:mm:ss";
    public static final String YEAR_MONTH_DAY_HOUR_MINUTE = "yyyy-MM-dd HH:mm";
    public static final String HOUR_MINUTE_SECOND = "HH:mm:ss";
    public static final String YEAR_MONTH_DAY_HOUR_SHORT = "yyyyMMdd HH:mm:ss";
    public static final String YEAR_MONTH_DAY = "yyyy-MM-dd";
    public static final String YEAR_MONTH_DAY_WEEK = "yyyy-MM-dd EEE";
    public static final String MONTH_DAY_WEEK = "MM-dd EEE";
    public static final String MONTH_DAY = "MM-dd";
    public static final String HOUR_MINUTE = "HH:mm";
    public static final String YYYY_MMMM = "yyyy MMMM";
    public static final String MMM_YYYY = "MMM yyyy";


    public static String formatTime(long timeMillis, String formatPattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(formatPattern, Locale.getDefault());
        return sdf.format(new Date(timeMillis));
    }

    /**
     * 格式化时间
     *
     * @param timeSecond    时间戳，单位 s
     * @param formatPattern 格式
     * @return 格式化后的时间
     */
    public static String formatNetTime(long timeSecond, String formatPattern) {
        return formatTime(timeSecond * 1000, formatPattern);
    }

    public static int parseInt(String str, int defaultValue) {
        if (TextUtils.isEmpty(str)) {
            return defaultValue;
        }

        try {
            return Integer.parseInt(str);
        } catch (Exception ignore) {
            return defaultValue;
        }
    }

    public static double parseDouble(String str, double defaultValue) {
        if (TextUtils.isEmpty(str)) {
            return defaultValue;
        }

        try {
            return Double.parseDouble(str);
        } catch (Exception ignore) {
            return defaultValue;
        }
    }

}
