package com.shopee.spx.ui.sample;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.shopee.spx.ui.listener.OnPageSelectedListener;
import com.shopee.spx.ui.widget.tab.FixedTabLayout;
import com.shopee.spx.ui.widget.tab.SlidingTabLayout;

import java.util.ArrayList;

public class TabActivity extends AppCompatActivity {
    private static final String TAG = "TabActivity";

    private final String[] mTitles1 = {
            "All", "Wallet", "Compensation", "Announcement", "COD", "ShopeePay", "Others"
    };

    private final String[] mTitles2 = {"Todo", "Delivered"};
    private final String[] mTitles3 = {"Todo", "Delivered", "On-Hold"};
    private final String[] mTitles4 = {"Wallet", "COD", "ShopeePay", "Others"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);

        ViewPager vp1 = findViewById(R.id.vp1);
        MyPagerAdapter mAdapter1 = new MyPagerAdapter(getSupportFragmentManager(), mTitles1);
        vp1.setAdapter(mAdapter1);
        SlidingTabLayout tabLayout1 = findViewById(R.id.tl1);
        tabLayout1.setViewPager(vp1);
        tabLayout1.setOnPageSelectListener(new OnPageSelectedListener() {
            @Override
            public void onPageSelected(int position) {
                Log.d(TAG, "onPageSelected: tabLayout1 " + position);
            }
        });
        findViewById(R.id.button).setOnClickListener(v -> {
            ArrayList<String> numbers = new ArrayList<>();
            numbers.add("10");
            numbers.add("1");
            numbers.add("2");
            numbers.add("3");
            numbers.add("4");
            numbers.add("5");
            numbers.add("1");
            tabLayout1.updateTitles(mTitles1, numbers);
        });

        ViewPager vp2 = findViewById(R.id.vp2);
        MyPagerAdapter mAdapter2 = new MyPagerAdapter(getSupportFragmentManager(), mTitles2);
        vp2.setAdapter(mAdapter2);
        FixedTabLayout tabLayout2 = findViewById(R.id.tl2);
        tabLayout2.setViewPager(vp2);
        tabLayout2.setOnPageSelectListener(new OnPageSelectedListener() {
            @Override
            public void onPageSelected(int position) {
                Log.d(TAG, "onPageSelected: tabLayout2 " + position);
            }
        });

        ViewPager vp3 = findViewById(R.id.vp3);
        MyPagerAdapter mAdapter3 = new MyPagerAdapter(getSupportFragmentManager(), mTitles3);
        vp3.setAdapter(mAdapter3);
        FixedTabLayout tabLayout3 = findViewById(R.id.tl3);
        tabLayout3.setViewPager(vp3);
        tabLayout3.setOnPageSelectListener(new OnPageSelectedListener() {
            @Override
            public void onPageSelected(int position) {
                Log.d(TAG, "onPageSelected: tabLayout3 " + position);
            }
        });

        ViewPager vp4 = findViewById(R.id.vp4);
        MyPagerAdapter mAdapter4 = new MyPagerAdapter(getSupportFragmentManager(), mTitles4);
        vp4.setAdapter(mAdapter4);
        FixedTabLayout tabLayout4 = findViewById(R.id.tl4);
        tabLayout4.setViewPager(vp4);
        tabLayout4.setOnPageSelectListener(new OnPageSelectedListener() {
            @Override
            public void onPageSelected(int position) {
                Log.d(TAG, "onPageSelected: tabLayout4 " + position);
            }
        });

    }

    private class MyPagerAdapter extends FragmentPagerAdapter {
        String[] mTitles;

        public MyPagerAdapter(FragmentManager fm, String[] titles) {
            super(fm);
            mTitles = titles;
        }

        @Override
        public int getCount() {
            return mTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mTitles[position];
        }

        @Override
        public Fragment getItem(int position) {
            return TabFragment.getInstance(mTitles[position]);
        }
    }

}