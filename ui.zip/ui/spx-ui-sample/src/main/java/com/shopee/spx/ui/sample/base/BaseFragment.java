package com.shopee.spx.ui.sample.base;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.CallSuper;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * Created by chris on 2018/2/27.
 */
public abstract class BaseFragment extends Fragment {

    protected boolean mViewCreated = false;
    protected boolean mIsFirst = true; // Lazy load only once
    private View mContentView;
    /**
     * 当前 Fragment 是否可见，与父类的 {@link #getUserVisibleHint()} 不同，父类的 mUserVisibleHint 变量
     * 可在生命周期的任意时刻进行赋值，当 Fragment 未初始化时进行操作可能产生各种问题；
     * 所以本变量只能在生命周期的 onViewCreated <-> onDestroyView 之间进行赋值，当值发生变化时回调对应的
     * {@link #onVisible()} 及 {@link #onInvisible()} 方法，基本可替代 {@link #onResume()} 及 {@link #onPause()}
     */
    private boolean mFragmentVisible = false;

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        setUserVisibleHint(!hidden);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (mViewCreated) {
            switchVisible(isVisibleToUser);
        }
    }

    private void switchVisible(boolean isVisible) {
        if (mFragmentVisible != isVisible) {
            mFragmentVisible = isVisible;
            if (isVisible) {
                onVisible();
            } else {
                onInvisible();
            }
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(contentViewId(), container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContentView = view;
        mViewCreated = true;
        initView();
    }

    @Override
    public void onResume() {
        super.onResume();
        switchVisible(getUserVisibleHint());
    }

    @CallSuper
    protected void onVisible() {
        if (mIsFirst) {
            lazyLoad(); // initial load data
            mIsFirst = false;
        }
    }

    @CallSuper
    protected void onInvisible() {
    }

    @Override
    public void onPause() {
        switchVisible(false);
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mContentView = null;
        mViewCreated = false;
    }

    public boolean isFragmentVisible() {
        return mFragmentVisible;
    }

    /**
     * get fragment content view
     */
    protected View getContentView() {
        return mContentView;
    }

    /**
     * find out the relevant view
     *
     * @param id
     * @param <T>
     * @return
     */
    protected <T extends View> T findViewById(int id) {
        return mContentView.findViewById(id);
    }

    /**
     * return fragment layout id
     */
    @LayoutRes
    protected abstract int contentViewId();

    /**
     * Lazy load just once. If subclass don't need lazy load or want to perform custom lazy load,
     * just ignore this method and do it in {@link #onVisible()}.
     */
    protected void lazyLoad() {

    }

    protected void initView() {

    }

}
