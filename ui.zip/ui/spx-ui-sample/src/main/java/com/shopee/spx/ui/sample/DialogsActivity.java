package com.shopee.spx.ui.sample;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.shopee.spx.ui.widget.dialog.CustomizeDialog;
import com.shopee.spx.ui.widget.dialog.CustomizeInputDialog;

public class DialogsActivity extends AppCompatActivity {

    private static final String TAG = "DialogsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialogs);

        //基础对话框
        findViewById(R.id.btn_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomizeDialog dialog = new CustomizeDialog(DialogsActivity.this, R.layout.dialog_notify_normal)
                        .setText(R.id.tv_title, "Title")
                        .setText(R.id.tv_message, "Contentcontentcontentcontentcontentcontentcon" +
                                "tentcontentcontentcontentcontentcontentcontentcontentcontentContentconten" +
                                "tcontentcontentcontentcontentcontentcontentcontentcontentcontentcontentconten" +
                                "tentcontentcontentcontentcontentcontentcontentcontentcontentContentconten" +
                                "tcontentcontentcontentcontentcontentcontentcontentcontentcontentcontentconten" +
                                "tentcontentcontentcontentcontentcontentcontentcontentcontentContentconten" +
                                "tcontentcontentcontentcontentcontentcontentcontentcontentcontentcontentconten" +
                                "tcontentcontentContentcontentcontentcontentcontentcontentcontentcontentcontentco!!")
                        .setText(R.id.tv_cancel, "No")
                        .setText(R.id.tv_confirm, "Yes")
                        .setOnClickListener(R.id.tv_cancel, null)
                        .setOnClickListener(R.id.tv_confirm, null)
                        .setVisibility(R.id.divider_button, View.VISIBLE);
                dialog.show();

            }
        });

        //无标题对话框
        findViewById(R.id.btn_5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomizeDialog dialog = new CustomizeDialog(DialogsActivity.this, R.layout.dialog_notify_normal)
                        .setVisibility(R.id.tv_title, View.GONE)
                        .setText(R.id.tv_message, "Contentcontentcontentcontentcontentcontentcon" +
                                "tcontentcontentContentcontentcontentcontentcontentcontentcontentcontentcontentco!!")
                        .setTextColor(R.id.tv_message, R.color.dialog_title_color)
                        .setText(R.id.tv_cancel, "No")
                        .setText(R.id.tv_confirm, "Yes")
                        .setOnClickListener(R.id.tv_cancel, null)
                        .setOnClickListener(R.id.tv_confirm, null)
                        .setVisibility(R.id.divider_button, View.VISIBLE);
                dialog.show();

            }
        });

        //组合对话框
        findViewById(R.id.btn_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomizeDialog dialog = new CustomizeDialog(DialogsActivity.this, R.layout.dialog_notify_radio)
                        .setText(R.id.tv_title, "Title")
                        .setText(R.id.tv_message, "Contentcontentcontentcontentcontentcontentcontentcontentcontent!!")
                        .setText(R.id.tv_confirm, "Button")
                        .setOnClickListener(R.id.tv_confirm, null)
                        .setVisibility(R.id.tv_cancel, View.GONE);
                dialog.show();
            }
        });

        //多按钮对话框
        findViewById(R.id.btn_6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomizeDialog dialog = new CustomizeDialog(DialogsActivity.this, R.layout.dialog_notify_normal)
                        .setText(R.id.tv_title, "Title")
                        .setText(R.id.tv_message, "Contentcontentcontentcontentcontentcontentcon" +
                                "tcontentcontentContentcontentcontentcontentcontentcontentcontentcontentcontentco!!")
                        .setText(R.id.tv_confirm, "Yes")
                        .setText(R.id.tv_button2, "Button")
                        .setText(R.id.tv_button3, "Button")
                        .setVisibility(R.id.tv_button2, View.VISIBLE)
                        .setVisibility(R.id.divider2, View.VISIBLE)
                        .setVisibility(R.id.tv_button3, View.VISIBLE)
                        .setVisibility(R.id.divider3, View.VISIBLE)
                        .setOnClickListener(R.id.tv_confirm, null)
                        .setOnClickListener(R.id.tv_button2, null)
                        .setOnClickListener(R.id.tv_button3, null)
                        .setVisibility(R.id.tv_cancel, View.GONE)
                        .setVisibility(R.id.divider_button, View.GONE);
                dialog.show();

            }
        });

        //带图对话框
        findViewById(R.id.btn_3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomizeDialog dialog = new CustomizeDialog(DialogsActivity.this, R.layout.dialog_notify_normal)
                        .setText(R.id.tv_title, "Title")
                        .setText(R.id.tv_message, "Contentcontentcontentcontentcontentcontentcon!!")
                        .setText(R.id.tv_cancel, "No")
                        .setText(R.id.tv_confirm, "Yes")
                        .setOnClickListener(R.id.tv_cancel, null)
                        .setOnClickListener(R.id.tv_confirm, null)
                        .setVisibility(R.id.top_bg, View.VISIBLE)
                        .setVisibility(R.id.divider_button, View.VISIBLE);
                dialog.show();

            }
        });

        //输入对话框
        findViewById(R.id.btn_4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomizeDialog dialog = new CustomizeInputDialog(DialogsActivity.this, R.layout.dialog_notify_input)
                        //先设置CustomizeInputDialog专属接口
                        .setEditTextIds(R.id.edit_text1, R.id.edit_text2) //设置所有edit text的id，用于后续输入结果的回调
                        .setConfirmAndDismissListener(R.id.tv_confirm, new CustomizeInputDialog.OnInputResultListener() { //设置confirm按钮和回调监听
                            @Override
                            public void onInputResult(String... results) {
                                if (results.length > 1) {
                                    Log.d(TAG, "onInputResult: results " + results[0] + " " + results[1]);
                                }
                            }
                        })
                        //再设置CustomizeDialog通用接口
                        .setText(R.id.tv_title, "Title")
                        .setText(R.id.tv_message, "Please let us know why you rated us average, so we can improve.")
                        .setText(R.id.tv_input_hint, "Contentcontentcontentcontentcontentcontentcon" +
                                "tentcontentcontentcontentcontentcontentcontentcontentcontentContentconten" +
                                "tentcontentcontentcontentcontentcontentcontentcontentcontentContentconten" +
                                "tcontentcontentcontentcontentcontentcontentcontentcontentcontentcontentconten" +
                                "tcontentcontentcontentcontentcontentcontentcontentcontentcontentcontentconten" +
                                "tcontentcontentContentcontentcontentcontentcontentcontentcontentcontentcontentco!!")
                        .setText(R.id.tv_cancel, "No")
                        .setText(R.id.tv_confirm, "Yes")
                        .setOnClickListener(R.id.tv_cancel, null)
                        .setOnClickListener(R.id.tv_confirm, null)
                        .setVisibility(R.id.divider_button, View.VISIBLE);
                dialog.show();
            }
        });
    }

}