# wms-ui


## Release Version

## 1.0.0.4 (2022-03-10):
 - [feature] SuggestLocationItemView 添加库位倒计时结束响应事件

## 1.0.0.5 (2022-03-11):
 - [bugfix] 解决ConfirmSkuDialog弹出问题

## 1.0.0.6 (2022-03-23):
 - [bugfix] SuggestLocationItemView 倒计时listener事件NPE错误

   https://console.firebase.google.com/project/shopee-supply-chain/crashlytics/app/android:com.shopee.wms.pda/issues/2a9b0b22c2203b4f80e8250dc2d64d89?versions=1.36.0%20(100)&time=last-twenty-four-hours&sessionEventKey=623BDBDB024C000161CAFB1A7E63E637_1656955803909512353

## 1.0.1-test1 (2022-03-28):
- [feature] MultiLevelSkuItemAdapter 第一行支持显示 tag

## 1.0.1 (2022-04-26):
- [feature] MultiLevelSkuItemAdapter 第一行支持显示 tag

## 1.0.2-test1 (2022-06-08):
- [feature] CustomizeDialog 支持设置文字按钮颜色
- [feature] SuggestLocationItemView样式修改

## 1.0.2 (2022-06-27):
- [feature] CustomizeDialog 支持设置文字按钮颜色
- [feature] SuggestLocationItemView样式修改

## 1.0.3 (2022-08-22):
- [feature] CustomizeDialog 支持设置文字按钮颜色
- [feature] SuggestLocationItemView样式修改