package com.shopee.wms.ui.widget.multilevel.itemlist;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;

public class ItemTagInfo {
    private CharSequence mText;
    private @ColorRes int mTextColor;
    private @DrawableRes int mBgColor;

    public ItemTagInfo(CharSequence text, @ColorRes int textColor, @DrawableRes int bgColor) {
        mText = text;
        mTextColor = textColor;
        mBgColor = bgColor;
    }

    public CharSequence getText() {
        return mText;
    }

    public void setText(CharSequence text) {
        mText = text;
    }

    public int getTextColor() {
        return mTextColor;
    }

    public void setTextColor(@ColorRes int textColor) {
        mTextColor = textColor;
    }

    public int getBgColor() {
        return mBgColor;
    }

    public void setBgColor(@DrawableRes int bgColor) {
        mBgColor = bgColor;
    }
}
