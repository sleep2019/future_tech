package com.shopee.wms.ui.widget.multilevel.skulist;

import android.view.View;
import android.widget.RadioButton;

import androidx.annotation.IntDef;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.shopee.wms.ui.R;
import com.shopee.wms.ui.widget.multilevel.itemlist.ItemTagInfo;
import com.shopee.wms.ui.widget.multilevel.itemlist.TagAdapter;
import com.shopee.wms.ui.widget.sku.SkuItemView;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

/**
 * 实现多级菜单，即列表中的item存在列表的情况
 * 上层菜单还有单选框
 *
 * @author tao.yangyt
 */
public class MultiLevelSkuItemAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity,
        BaseViewHolder> {

    private int mSelectedPosition = -1;

    private final int mSelectType;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({SelectType.SINGLE_SELECT, SelectType.MULTI_SELECT})
    public @interface SelectType {
        int SINGLE_SELECT = 0; // 单选
        int MULTI_SELECT = 1; // 多选
    }

    public MultiLevelSkuItemAdapter() {
        // 默认单选
        this(SelectType.SINGLE_SELECT);
    }

    public MultiLevelSkuItemAdapter(@SelectType int selectType) {
        super(new ArrayList<>());
        mSelectType = selectType;
        addItemType(SkuListInfo.TYPE_TOP, R.layout.wmsui_item_multi_sku_list);
        addItemType(SkuSubInfo.TYPE_BOTTOM, R.layout.wmsui_item_multi_sku_info);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder helper,
                           @NonNull MultiItemEntity item) {
        if (helper.getItemViewType() == SkuListInfo.TYPE_TOP) {
            // 最外层菜单item设置
            if (item instanceof SkuListInfo) {
                SkuListInfo info = (SkuListInfo) item;

                // 单选RadioButton的设置
                RadioButton radioButton = helper.getView(R.id.rbtn_batch);
                if (mSelectType == SelectType.MULTI_SELECT) {
                    radioButton.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            0, 0, R.drawable.wmsui_selector_checkbox, 0);
                }
                radioButton.setClickable(false);
                radioButton.setChecked(info.isChecked());

                radioButton.setOnClickListener(v -> {
                    if (mSelectType == SelectType.MULTI_SELECT) { // 实现多选
                        int position = getParentPosition(item);
                        if (!info.isChecked()) {
                            info.setChecked(true);
                            notifyItemChanged(position);
                        } else {
                            info.setChecked(false);
                            notifyItemChanged(position);
                        }
                    } else { // 实现单选
                        int position = getParentPosition(item);
                        List<MultiItemEntity> multiItemEntities = getData();
                        for (int i = 0; i < multiItemEntities.size(); i++) {
                            MultiItemEntity selectableEntity = multiItemEntities.get(i);
                            if (selectableEntity instanceof SkuListInfo) {
                                SkuListInfo selectable = (SkuListInfo) selectableEntity;
                                if (i == position) {
                                    if (!selectable.isChecked()) {
                                        mSelectedPosition = position;
                                        selectable.setChecked(true);
                                        notifyItemChanged(i);
                                    }
                                } else {
                                    if (selectable.isChecked()) {
                                        selectable.setChecked(false);
                                        notifyItemChanged(i);
                                    }
                                }
                            }
                        }
                    }
                });

                helper.setText(R.id.tv_asn_id, info.getFirstLine())
                        .setText(R.id.tv_return_tn, info.getSecondLine());

                List<ItemTagInfo> tagInfoList = info.getFirstLineTagList();
                if (tagInfoList != null && !tagInfoList.isEmpty()) {
                    helper.setGone(R.id.rv_first_line_tags, true);
                    RecyclerView recyclerView = helper.getView(R.id.rv_first_line_tags);
                    TagAdapter tagAdapter = new TagAdapter();
                    recyclerView.setAdapter(tagAdapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext(),
                            LinearLayoutManager.HORIZONTAL, false));
                    tagAdapter.setNewData(tagInfoList);
                } else {
                    helper.setGone(R.id.rv_first_line_tags, false);
                }

                SkuItemView skuItemView = helper.getView(R.id.siv_sku_info);
                View vCollapse = helper.getView(R.id.fl_collapse);

                // 首个SKU信息的展示
                skuItemView.setSkuId(info.getSkuId());
                skuItemView.setSkuName(info.getSkuName());
                skuItemView.setThumbnail(info.getSkuImage());
                skuItemView.setQuantity(info.getQuantity());

                // 是否有二级菜单的item
                if (info.hasSubItem()) {
                    // 根据折叠/展开状态设置不同显示
                    if (info.isExpanded()) {
                        vCollapse.setVisibility(View.GONE);
                    } else {
                        vCollapse.setVisibility(View.VISIBLE);
                        vCollapse.setOnClickListener(v -> {
                            int pos = helper.getAdapterPosition();
                            expand(pos);
                        });
                    }
                } else {
                    // 只有一个SKU item，则无需显示二级菜单
                    vCollapse.setVisibility(View.GONE);
                }
            }
        } else if (helper.getItemViewType() == SkuSubInfo.TYPE_BOTTOM) {
            // 二级菜单item设置
            if (item instanceof SkuSubInfo) {
                SkuSubInfo info = (SkuSubInfo) item;

                // item SKU信息
                SkuItemView skuItemView = helper.getView(R.id.siv_sku_info);
                skuItemView.setSkuId(info.getSkuId());
                skuItemView.setSkuName(info.getSkuName());
                skuItemView.setThumbnail(info.getSkuImage());
                skuItemView.setQuantity(info.getQuantity());

                View vClose = helper.getView(R.id.fl_close);
                int p = getParentPosition(item);
                SkuListInfo parent = (SkuListInfo) getData().get(p);
                // 判断最后一个item要显示折叠按钮
                if (parent.getSubItemPosition(info) == parent.getSubItems().size() - 1) {
                    vClose.setVisibility(View.VISIBLE);
                    vClose.setOnClickListener(v -> {
                        int pos = getParentPosition(item);
                        collapse(pos);
                    });
                } else {
                    // 非最后一个item不需要展示折叠按钮
                    vClose.setVisibility(View.GONE);
                }
            }
        }
    }

    public SkuListInfo getSelectedData() {
        if (mSelectedPosition < 0) {
            return null;
        }
        MultiItemEntity e = getItem(mSelectedPosition);
        if (e instanceof SkuListInfo) {
            return (SkuListInfo) e;
        } else {
            return null;
        }
    }

    /**
     * 获取全部选中的Item列表，多选模式调用这个方法
     *
     * @return 选中的Item列表
     */
    @NonNull
    public List<SkuListInfo> getSelectedDatas() {
        List<SkuListInfo> skuListInfoList = new ArrayList<>();
        List<MultiItemEntity> multiItemEntities = getData();
        for (MultiItemEntity multiItemEntity : multiItemEntities) {
            if (multiItemEntity instanceof SkuListInfo) {
                SkuListInfo skuListInfo = (SkuListInfo) multiItemEntity;
                if (skuListInfo.isChecked()) {
                    skuListInfoList.add(skuListInfo);
                }
            }
        }
        return skuListInfoList;
    }
}
