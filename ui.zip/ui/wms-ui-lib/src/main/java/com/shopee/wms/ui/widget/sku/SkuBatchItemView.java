package com.shopee.wms.ui.widget.sku;

import android.content.Context;
import android.text.Html;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.shopee.android.ui_library.widget.item.ItemComponentView;
import com.shopee.sc.common.widget.ViewClickProxy;
import com.shopee.wms.ui.R;

import static com.shopee.wms.ui.constant.Constant.COLOR_FF4742;

public class SkuBatchItemView extends LinearLayout {

    private ItemComponentView mIcvProductionDate;
    private ItemComponentView mIcvExpiredDate;

    public SkuBatchItemView(Context context) {
        super(context);
        initView(context);
    }

    public SkuBatchItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public SkuBatchItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        View contentView = LayoutInflater.from(context).inflate(R.layout.wmsui_item_sku_batch, this, true);
        mIcvProductionDate = contentView.findViewById(R.id.icv_production_date);
        mIcvExpiredDate = contentView.findViewById(R.id.icv_expired_date);
    }

    public SkuBatchItemView setProductionDateTitle(CharSequence title, boolean required) {
        if (required) {
            String text = title + "<font color=" + COLOR_FF4742 + ">" + " * " + "</font>";
            title = Html.fromHtml(text);
        }
        mIcvProductionDate.setText(ItemComponentView.ITEM_LEFT_ONE_TEXT, title);
        return this;
    }

    public SkuBatchItemView setExpiredDateTitle(CharSequence title, boolean required) {
        if (required) {
            String text = title + "<font color=" + COLOR_FF4742 + ">" + " * " + "</font>";
            title = Html.fromHtml(text);
        }
        mIcvExpiredDate.setText(ItemComponentView.ITEM_LEFT_ONE_TEXT, title);
        return this;
    }

    public SkuBatchItemView setProductionDate(CharSequence date) {
        mIcvProductionDate.setText(ItemComponentView.ITEM_LEFT_TWO_TEXT, date);
        return this;
    }

    public SkuBatchItemView setExpiredDate(CharSequence date) {
        mIcvExpiredDate.setText(ItemComponentView.ITEM_LEFT_TWO_TEXT, date);
        return this;
    }

    public SkuBatchItemView setProductionDateClickListener(OnClickListener listener) {
        mIcvProductionDate.setOnClickListener(new ViewClickProxy(listener));
        return this;
    }

    public SkuBatchItemView setExpiredDateClickListener(OnClickListener listener) {
        mIcvExpiredDate.setOnClickListener(new ViewClickProxy(listener));
        return this;
    }
}
