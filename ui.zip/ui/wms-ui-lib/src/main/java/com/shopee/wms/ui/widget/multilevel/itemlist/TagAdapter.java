package com.shopee.wms.ui.widget.multilevel.itemlist;

import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.wms.ui.R;


public class TagAdapter extends BaseQuickAdapter<ItemTagInfo, BaseViewHolder> {

    public TagAdapter() {
        super(R.layout.wmsui_item_tag);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder helper, ItemTagInfo item) {
        TextView tag = helper.getView(R.id.tv_tag);
        tag.setText(item.getText());
        tag.setTextColor(ContextCompat.getColor(tag.getContext(), item.getTextColor()));
        tag.setBackgroundResource(item.getBgColor());
    }

}
