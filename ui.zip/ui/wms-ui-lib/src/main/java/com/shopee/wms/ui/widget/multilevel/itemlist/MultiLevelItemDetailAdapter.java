package com.shopee.wms.ui.widget.multilevel.itemlist;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.shopee.android.ui_library.widget.item.ItemComponentView;
import com.shopee.wms.ui.R;

import java.util.ArrayList;
import java.util.List;

/**
 * 实现多级菜单，即列表中的item存在列表的情况
 *
 * @author tao.yangyt
 */
public class MultiLevelItemDetailAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity,
        BaseViewHolder> {

    private OnMultiItemClickListener mMultiItemClickListener;

    public MultiLevelItemDetailAdapter() {
        super(null);
        addItemType(ItemListInfo.TYPE_TOP, R.layout.wmsui_item_info);
        addItemType(ItemSubInfo.TYPE_BOTTOM, R.layout.wmsui_item_item);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder helper, @NonNull MultiItemEntity item) {
        if (helper.getItemViewType() == ItemListInfo.TYPE_TOP) {
            // 最外层菜单item设置
            if (item instanceof ItemListInfo) {
                ItemListInfo listInfo = (ItemListInfo) item;

                helper.setText(R.id.tv_qty, listInfo.getItemQty())
                        .setText(R.id.tv_damage, listInfo.getSecondLine());

                if (listInfo.isClickable()) {
                    helper.setVisible(R.id.iv_enter, true);
                    helper.getView(R.id.root).setOnClickListener(v -> {
                        if (mMultiItemClickListener != null && listInfo.isClickable()) {
                            mMultiItemClickListener.onItemClick(this, v,
                                    getParentPosition(item), listInfo);
                        }
                    });
                } else {
                    helper.setVisible(R.id.iv_enter, false);
                }

                View vCollapse = helper.getView(R.id.fl_collapse);

                List<ItemTagInfo> tags = new ArrayList<>();
                ItemTagInfo tag2 = listInfo.getTag2Info();
                if (tag2 != null) {
                    tags.add(tag2);
                }
                if (listInfo.getItemTagInfos() != null && !listInfo.getItemTagInfos().isEmpty()) {
                    tags.addAll(listInfo.getItemTagInfos());
                }
                if (!tags.isEmpty()) {
                    // 有tag要展示
                    RecyclerView recyclerView = helper.getView(R.id.rv_tags);
                    TagAdapter tagAdapter = new TagAdapter();
                    recyclerView.setAdapter(tagAdapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext(),
                            LinearLayoutManager.HORIZONTAL, false));

                    tagAdapter.setNewData(tags);
                }

                // 是否有二级菜单的item
                if (listInfo.hasSubItem()) {
                    // 根据折叠/展开状态设置不同显示
                    if (listInfo.isExpanded()) {
                        vCollapse.setVisibility(View.GONE);
                        helper.getView(R.id.v_space).setVisibility(View.GONE);
                    } else {
                        vCollapse.setVisibility(View.VISIBLE);
                        vCollapse.setOnClickListener(v -> {
                            int pos = helper.getAdapterPosition();
                            expand(pos);
                        });
                        helper.getView(R.id.v_space).setVisibility(View.VISIBLE);
                    }
                } else {
                    // 只有一个SKU item，则无需显示二级菜单
                    vCollapse.setVisibility(View.GONE);
                    helper.getView(R.id.v_space).setVisibility(View.VISIBLE);
                }
            }
        } else if (helper.getItemViewType() == ItemSubInfo.TYPE_BOTTOM) {
            // 二级菜单item设置
            if (item instanceof ItemSubInfo) {
                ItemSubInfo info = (ItemSubInfo) item;

                // item SKU信息
                ItemComponentView itemComponentView = helper.getView(R.id.icv_item);
                itemComponentView.setText(ItemComponentView.ITEM_LEFT_ONE_TEXT, info.getLeftText());
                itemComponentView.setText(ItemComponentView.ITEM_RIGHT_ONE_TEXT, info.getRightText());


                View vClose = helper.getView(R.id.fl_close);
                int p = getParentPosition(item);
                ItemListInfo parent = (ItemListInfo) getData().get(p);

                helper.getView(R.id.root).setOnClickListener(v -> {
                    if (mMultiItemClickListener != null) {
                        mMultiItemClickListener.onItemClick(this, v, getParentPosition(item), parent);
                    }
                });
                // 判断最后一个item要显示折叠按钮
                if (parent.getSubItemPosition(info) == parent.getSubItems().size() - 1) {
                    vClose.setVisibility(View.VISIBLE);
                    vClose.setOnClickListener(v -> {
                        int pos = getParentPosition(item);
                        collapse(pos);
                    });
                } else {
                    // 非最后一个item不需要展示折叠按钮
                    vClose.setVisibility(View.GONE);
                }
            }
        }
    }

    public void setMultiItemClickListener(OnMultiItemClickListener multiItemClickListener) {
        mMultiItemClickListener = multiItemClickListener;
    }
}
