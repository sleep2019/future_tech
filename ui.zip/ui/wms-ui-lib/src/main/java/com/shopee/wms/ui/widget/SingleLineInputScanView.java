package com.shopee.wms.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputType;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import com.shopee.android.ui_library.widget.util.ViewUtil;
import com.shopee.sc.common.util.AppUtils;
import com.shopee.wms.ui.R;
import com.shopee.wms.ui.util.LetterUtils;


/**
 * @author 常亚浩
 * @date 2021-11-16
 */
public class SingleLineInputScanView extends ConstraintLayout {

    public final static int LEFTONE_RIGHTTWO = 1;
    public final static int LEFTNO_RIGHTTWO = 2;
    public final static int LEFTONE_RIGHTEDIT = 3;

    private TextView mTextView;
    private EditText mEditText;
    private ImageView mImageView;
    private ConstraintLayout mConstraintLayout;

    public SingleLineInputScanView(Context context) {
        super(context);
        initView(context, null, 0, 0);
    }

    public SingleLineInputScanView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context, attrs, 0, 0);
    }

    public SingleLineInputScanView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context, attrs, defStyleAttr, 0);
    }

    private void initView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        View contentView = LayoutInflater.from(context)
                .inflate(R.layout.wmsui_single_line_input_scan, this, true);
        mTextView = contentView.findViewById(R.id.tv_sku_id_title);
        mEditText = contentView.findViewById(R.id.et_scan_sku_id);
        mImageView = contentView.findViewById(R.id.iv_scan_sku_id);
        mConstraintLayout = contentView.findViewById(R.id.top_parent);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.SingleLineInputScanView, defStyleAttr, defStyleRes);
        String text = typedArray.getString(R.styleable.SingleLineInputScanView_wmsUiLeftText);
        String hint = typedArray.getString(R.styleable.SingleLineInputScanView_wmsUirightHintText);
        String rightTextInputType = typedArray.getString(R.styleable.SingleLineInputScanView_wmsUiRightTextInputType);
        if (!TextUtils.isEmpty(rightTextInputType) && "number".equals(rightTextInputType)) {
            mEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
        }


        if (!TextUtils.isEmpty(text)) {
            mTextView.setText(text);
        }

        if (!TextUtils.isEmpty(hint)) {
            mEditText.setHint(hint);
        }

        int mode = typedArray.getInt(R.styleable.SingleLineInputScanView_SingleLineInputScanViewUiMode, LEFTONE_RIGHTTWO);
        dealWithMode(mode);
    }

    private SingleLineInputScanView setLeftTextGone() {
        mTextView.setVisibility(GONE);
        ConstraintSet set = new ConstraintSet();
        set.clone(mConstraintLayout);
        set.connect(mEditText.getId(), ConstraintSet.START, R.id.top_parent, ConstraintSet.START);
        set.applyTo(mConstraintLayout);
        return this;
    }

    public SingleLineInputScanView setScanEnabled(boolean enabled) {
        mImageView.setEnabled(enabled);
        return this;
    }

    public ImageView getScanView() {
        return mImageView;
    }

    public boolean getScanIsEnabled() {
        return mImageView.isEnabled();
    }

    public SingleLineInputScanView setLeftText(@StringRes int resId) {
        mTextView.setText(resId);
        return this;
    }

    public SingleLineInputScanView setLeftText(String text) {
        mTextView.setText(text);
        return this;
    }

    public SingleLineInputScanView setInputValue(String value) {
        mEditText.setText(value);
        return this;
    }

    public SingleLineInputScanView setInputHint(@StringRes int resId) {
        mEditText.setHint(resId);
        return this;
    }

    public SingleLineInputScanView setInputHint(String hint) {
        mEditText.setHint(hint);
        return this;
    }

    public SingleLineInputScanView setInputType(int inputType) {
        mEditText.setInputType(inputType);
        return this;
    }

    public SingleLineInputScanView setInputEnabled(boolean enabled) {
        mEditText.setEnabled(enabled);
        return this;
    }

    public SingleLineInputScanView setImageViewVisibility(int isVisibility) {
        mImageView.setVisibility(isVisibility);
        return this;
    }

    //获得输入字符串
    public String getInputValue() {
        return mEditText.getText().toString();
    }

    //获得EditText
    public EditText getEditText() {
        return mEditText;
    }

    public SingleLineInputScanView setLeftViewGone() {
        mTextView.setVisibility(GONE);
        return this;
    }

    public TextView getTitle() {
        return mTextView;
    }

    //设置扫描监听事件
    public SingleLineInputScanView setScanClickListener(View.OnClickListener imageClickListener) {
        if (mImageView.isEnabled()) {
            mImageView.setOnClickListener(imageClickListener);
        }
        return this;
    }

    //设置输入框回车监听时间
    public SingleLineInputScanView setOnEditorActionListener(TextView.OnEditorActionListener onEditorActionListener) {
        mEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND
                    || actionId == EditorInfo.IME_ACTION_DONE
                    || actionId == EditorInfo.IME_ACTION_NEXT
                    || (event != null && KeyEvent.KEYCODE_ENTER == event.getKeyCode()
                    && KeyEvent.ACTION_DOWN == event.getAction())) {
                onEditorActionListener.onEditorAction(v, actionId, event);
                AppUtils.hideSystemInputWhenHasFocus(AppUtils.getActivity(v));
            }
            return false;
        });
        return this;
    }

    //小写字母变大写
    public SingleLineInputScanView setCapitalLetter() {
        LetterUtils.setCapitalLetter(mEditText);
        return this;
    }

    private void dealWithMode(int mode) {
        switch (mode) {
            case LEFTONE_RIGHTTWO:
                break;
            case LEFTNO_RIGHTTWO:
                setLeftTextGone();
                break;
            case LEFTONE_RIGHTEDIT:
                ViewUtil.setVisibility(mImageView, GONE);
                break;
            default:
                throw new IllegalArgumentException("The mode of BottomSummaryView is not supported in xml file");
        }
    }
}
