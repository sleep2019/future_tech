package com.shopee.wms.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.FragmentActivity;

import com.shopee.sc.common.misc.NumRangeInputFilter;
import com.shopee.sc.common.util.KeyBoradUtils;
import com.shopee.sc.common.util.NumberUtils;
import com.shopee.wms.ui.R;
import com.shopee.wms.ui.helper.InputNumberHelper;


public class SingleLineInputView extends LinearLayout {

    private TextView mTvInputTitle;
    private EditText mEtInput;
    private TextView mTvUnit;

    public SingleLineInputView(Context context) {
        super(context);
        initView(context);
    }

    public SingleLineInputView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public SingleLineInputView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        View contentView = LayoutInflater.from(context).inflate(R.layout.wmsui_item_single_line_input, this, true);
        mTvInputTitle = contentView.findViewById(R.id.tv_input_title);
        mEtInput = contentView.findViewById(R.id.et_input);
        mTvUnit = contentView.findViewById(R.id.tv_unit);

        mTvUnit.setOnClickListener(v -> {
            if (mEtInput.isEnabled() && !mEtInput.hasFocus() && mEtInput.getVisibility() == View.VISIBLE) {
                mEtInput.requestFocus();
                mEtInput.setSelection(mEtInput.length());
                KeyBoradUtils.showSoftKeyBoard(mEtInput);
            }
        });
    }

    public SingleLineInputView setInputTitle(@StringRes int resId) {
        mTvInputTitle.setText(resId);
        return this;
    }

    public SingleLineInputView setInputTitle(String title) {
        mTvInputTitle.setText(title);
        return this;
    }

    public SingleLineInputView setInputValue(String value) {
        mEtInput.setText(value);
        return this;
    }

    public SingleLineInputView setInputHint(@StringRes int resId) {
        mEtInput.setHint(resId);
        return this;
    }

    public SingleLineInputView setInputHint(String hint) {
        mEtInput.setHint(hint);
        return this;
    }

    public SingleLineInputView setInputType(int inputType) {
        mEtInput.setInputType(inputType);
        return this;
    }

    public SingleLineInputView setUnit(int resId) {
        mTvUnit.setText(resId);
        return this;
    }

    public SingleLineInputView setUnit(String unit) {
        mTvUnit.setText(unit);
        return this;
    }

    public SingleLineInputView setUnitVisibility(int visibility) {
        mTvUnit.setVisibility(visibility);
        return this;
    }

    public SingleLineInputView setInputEnabled(boolean enabled) {
        mEtInput.setEnabled(enabled);
        return this;
    }

    public EditText getEtInput() {
        return mEtInput;
    }

    public SingleLineInputView initInputNumberHelper(FragmentActivity activity, float inputMax,
                                                     InputNumberHelper.OnKeyBordInputCodeListener onKeyBordInputCodeListener) {
        new InputNumberHelper(activity).initInputQuantityByBoard(null,
                onKeyBordInputCodeListener, mEtInput, 0, inputMax);
        return this;
    }

    public SingleLineInputView initInputNumberHelper(FragmentActivity activity, OnFocusChangeListener onFocusChangeListener,
                                                     InputNumberHelper.OnKeyBordInputCodeListener onKeyBordInputCodeListener,
                                                     float inputMin, float inputMax, int maxPointerLength,
                                                     NumRangeInputFilter.OnNumRangInputListener listener) {
        new InputNumberHelper(activity).initInputQuantityByBoard(onFocusChangeListener,
                onKeyBordInputCodeListener, mEtInput, inputMin, inputMax, maxPointerLength, listener);
        return this;
    }

    public int getInputQty() {
        String inputText = mEtInput.getText().toString().trim();
        return NumberUtils.convertToInt(inputText, 0);
    }

    public float getInputQtyFloat() {
        String inputText = mEtInput.getText().toString().trim();
        return NumberUtils.convertToFloat(inputText, 0);
    }
}
