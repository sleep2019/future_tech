package com.shopee.wms.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.StringRes;

import com.shopee.android.ui_library.widget.util.ViewUtil;
import com.shopee.wms.ui.R;

/**
 * @author 常亚浩
 * @date 2021-11-17
 */
public class BottomSummaryView extends RelativeLayout {

    public final static int ITEM_CHECKBOX_TEXTLEFT_TEXTRIGHT = 1;
    public final static int ITEM_TEXTRIGHT = 2;
    public final static int ITEM_TEXTLEFT_TEXTRIGHT = 3;
    public final static int ITEM_TEXTLEFT = 4;


    private CheckBox mCheckbox;
    private TextView mTextViewLeft;
    private TextView mTextViewRight;
    private LinearLayout mLinearLayout;

    public BottomSummaryView(Context context) {
        super(context);
        initView(context, null, 0, 0);
    }

    public BottomSummaryView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView(context, attrs, 0, 0);
    }

    public BottomSummaryView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context, attrs, defStyleAttr, 0);
    }

    private void initView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        View contentView = LayoutInflater.from(context)
                .inflate(R.layout.wmsui_item_bottom_summary, this, true);
        mCheckbox = contentView.findViewById(R.id.cb_select_all);
        mTextViewLeft = contentView.findViewById(R.id.tv_text);
        mTextViewRight = contentView.findViewById(R.id.tv_quantity);
        mLinearLayout = contentView.findViewById(R.id.ll_select_all_layout);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.BottomSummaryView, defStyleAttr, defStyleRes);
        int mode = typedArray.getInt(R.styleable.BottomSummaryView_BottomSummaryViewMode, ITEM_CHECKBOX_TEXTLEFT_TEXTRIGHT);
        dealWithMode(mode);
    }

    public void setCheckboxstate(boolean isChecked) {
        if (mCheckbox == null) {
            return;
        }
        mCheckbox.setChecked(isChecked);
    }

    public BottomSummaryView setLeftText(@StringRes int resId) {
        mTextViewLeft.setText(resId);
        return this;
    }

    public BottomSummaryView setLeftText(String text) {
        mTextViewLeft.setText(text);
        return this;
    }

    public BottomSummaryView setRightText(@StringRes int resId) {
        mTextViewRight.setText(resId);
        return this;
    }

    public BottomSummaryView setRightText(String text) {
        mTextViewRight.setText(text);
        return this;
    }

    public void setCheckBoxEnabled(boolean enabled) {
        if (mLinearLayout == null) {
            return;
        }
        mLinearLayout.setClickable(enabled);
    }

    public boolean checkBoxIsChecked() {
        return mCheckbox.isChecked();
    }

    public BottomSummaryView setCheckBoxState(boolean isChecked) {
        mCheckbox.setChecked(isChecked);
        return this;
    }

    public void setBottomSectionListener(View.OnClickListener listener) {
        if (mLinearLayout != null && mCheckbox != null && mTextViewLeft != null) {
            mLinearLayout.setOnClickListener(v -> {
                boolean ischecked = !mCheckbox.isChecked();
                mCheckbox.setChecked(ischecked);
                listener.onClick(v);
            });
        }
    }

    private void dealWithMode(int mode) {
        switch (mode) {
            case ITEM_CHECKBOX_TEXTLEFT_TEXTRIGHT:
                break;
            case ITEM_TEXTRIGHT:
                ViewUtil.setVisibility(mLinearLayout, GONE);
                break;
            case ITEM_TEXTLEFT_TEXTRIGHT:
                ViewUtil.setVisibility(mCheckbox, GONE);
                break;
            case ITEM_TEXTLEFT:
                ViewUtil.setVisibility(mCheckbox, GONE);
                ViewUtil.setVisibility(mTextViewRight, GONE);
                break;
            default:
                throw new IllegalArgumentException("The mode of BottomSummaryView is not supported in xml file");
        }
    }
}
