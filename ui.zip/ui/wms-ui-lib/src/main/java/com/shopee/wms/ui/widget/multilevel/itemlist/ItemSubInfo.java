package com.shopee.wms.ui.widget.multilevel.itemlist;

import com.chad.library.adapter.base.entity.MultiItemEntity;

public class ItemSubInfo implements MultiItemEntity {
    public static final int TYPE_BOTTOM = 0;

    private String mLeftText;
    private String mRightText;

    public ItemSubInfo(String leftText, String rightText) {
        mLeftText = leftText;
        mRightText = rightText;
    }

    public String getLeftText() {
        return mLeftText;
    }

    public void setLeftText(String leftText) {
        mLeftText = leftText;
    }

    public String getRightText() {
        return mRightText;
    }

    public void setRightText(String rightText) {
        mRightText = rightText;
    }

    @Override
    public int getItemType() {
        return TYPE_BOTTOM;
    }
}
