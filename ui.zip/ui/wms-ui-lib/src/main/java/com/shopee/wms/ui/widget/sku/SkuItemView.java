package com.shopee.wms.ui.widget.sku;

import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.IdRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.Nullable;

import com.shopee.sc.common.util.CheckUtils;
import com.shopee.wms.ui.R;
import com.shopee.wms.ui.helper.ImageHelper;

import java.util.List;

public class SkuItemView extends LinearLayout {

    private ImageView mIvThumbnail;
    private TextView mTvSkuId;
    private TextView mTvSkuName;
    private LinearLayout mLlSkuExtraInfo;
    private TextView mTvFromLocation;
    private TextView mTvQuantityInfo;
    private LinearLayout mLlSkuIdMapping;
    private TextView mTvMapping;

    private SparseArray<TextView> mExtraInfoViews;

    public SkuItemView(Context context) {
        super(context);
        initView(context);
    }

    public SkuItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public SkuItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        View contentView = LayoutInflater.from(context).inflate(R.layout.wmsui_item_sku, this, true);
        mIvThumbnail = contentView.findViewById(R.id.iv_thumbnail);
        mTvSkuId = contentView.findViewById(R.id.tv_sku_id);
        mTvSkuName = contentView.findViewById(R.id.tv_sku_name);
        mLlSkuExtraInfo = contentView.findViewById(R.id.ll_extra_info);
        mTvFromLocation = contentView.findViewById(R.id.tv_from_location);
        mTvQuantityInfo = contentView.findViewById(R.id.tv_quantity);
        mLlSkuIdMapping = contentView.findViewById(R.id.ll_sku_id_mapping);
        mTvMapping = contentView.findViewById(R.id.tv_mapping);

        mExtraInfoViews = new SparseArray<>();
    }

    public SkuItemView setThumbnails(List<String> imageUrls) {
        if (!CheckUtils.isNullOrEmpty(imageUrls)) {
            setThumbnail(imageUrls.get(0));
        }
        return this;
    }

    public SkuItemView setThumbnail(String imageUrl) {
        ImageHelper.showThumbnail(mIvThumbnail, imageUrl);
        return this;
    }

    public SkuItemView setSkuId(String skuId) {
        mTvSkuId.setText(skuId);
        return this;
    }

    public SkuItemView setSkuName(CharSequence skuName) {
        mTvSkuName.setText(skuName);
        return this;
    }

    public SkuItemView setQuantity(CharSequence quantity) {
        mTvQuantityInfo.setVisibility(VISIBLE);
        mTvQuantityInfo.setText(quantity);
        return this;
    }

    public SkuItemView showQuantityArrowIcon(boolean showMoreIcon) {
        mTvQuantityInfo.setVisibility(VISIBLE);
        if (showMoreIcon) {
            mTvQuantityInfo.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wmsui_ic_arrow_right_14
                    , 0);
        } else {
            mTvQuantityInfo.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0);
        }
        return this;
    }

    public SkuItemView setMappingVisibility(boolean isShow) {
        mTvMapping.setVisibility(isShow ? VISIBLE : GONE);
        return this;
    }

    public SkuItemView setMappingListener(OnClickListener listener) {
        mLlSkuIdMapping.setOnClickListener(listener);
        return this;
    }

    public TextView getExtraInfoTextView(int viewId) {
        return getExtraInfoTextView(viewId, R.layout.wmsui_item_sku_extra_info);
    }

    @Nullable
    public TextView getExtraInfoTextView(@IdRes int viewId, @LayoutRes int textviewLayoutId) {
        TextView extraItemView = mExtraInfoViews.get(viewId);
        if (extraItemView == null) {
            View view = LayoutInflater.from(getContext()).inflate(textviewLayoutId, mLlSkuExtraInfo, false);
            if (view instanceof TextView) {
                extraItemView = (TextView) view;
                extraItemView.setId(viewId);
                mExtraInfoViews.put(viewId, extraItemView);
                mLlSkuExtraInfo.addView(extraItemView);
            }
        }
        return extraItemView;
    }

    public View addExtraView(@LayoutRes int layoutId) {
        View view = LayoutInflater.from(getContext()).inflate(layoutId, mLlSkuExtraInfo, false);
        mLlSkuExtraInfo.addView(view);
        return view;
    }

    public void setExtraView(View view) {
        mLlSkuExtraInfo.removeView(view);
        mLlSkuExtraInfo.addView(view);
    }

    /**
     * @param location
     * @return
     * @deprecated Use {@link SkuItemView#getExtraInfoTextView} replace
     */
    public SkuItemView setFromLocation(CharSequence location) {
        mTvFromLocation.setVisibility(VISIBLE);
        mTvFromLocation.setText(location);
        return this;
    }
}
