package com.shopee.wms.ui.widget.sku;

import android.content.Context;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.shopee.android.ui_library.widget.item.ItemComponentView;
import com.shopee.sc.common.misc.NumRangeInputFilter;
import com.shopee.sc.common.util.KeyBoradUtils;
import com.shopee.sc.common.util.NumberUtils;
import com.shopee.sc.common.util.UiUtils;
import com.shopee.wms.ui.R;
import com.shopee.wms.ui.helper.InputNumberHelper;


public class SkuQuantityItemView extends LinearLayout {

    private ItemComponentView mIcvReferenceQty;
    private LinearLayout mLlInput;
    private TextView mTvInputTitle;
    private EditText mEtInputQty;
    private ItemComponentView mIcvCounting;
    private View mViewDivider;

    private InputNumberHelper mInputNumberHelper;

    private boolean mIsCountingMode;
    private int mUidCount;

    public SkuQuantityItemView(Context context) {
        super(context);
        initView(context);
    }

    public SkuQuantityItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public SkuQuantityItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        View contentView = LayoutInflater.from(context).inflate(R.layout.wmsui_item_sku_quantity, this, true);
        mIcvReferenceQty = contentView.findViewById(R.id.icv_reference_qty);
        mLlInput = contentView.findViewById(R.id.ll_input);
        mTvInputTitle = contentView.findViewById(R.id.tv_input_title);
        mEtInputQty = contentView.findViewById(R.id.et_input_qty);
        mIcvCounting = contentView.findViewById(R.id.icv_counting);
        mViewDivider = contentView.findViewById(R.id.view_divider);

        mEtInputQty.setFilters(new InputFilter[]{new NumRangeInputFilter(InputNumberHelper.MAX_INPUT)});

        mLlInput.setOnClickListener(v -> {
            if (!mEtInputQty.hasFocus() && mEtInputQty.getVisibility() == View.VISIBLE) {
                mEtInputQty.requestFocus();
                mEtInputQty.setSelection(mEtInputQty.length());
                KeyBoradUtils.showSoftKeyBoard(mEtInputQty);
            }
        });
    }

    public SkuQuantityItemView setReferenceTitle(int resId) {
        mIcvReferenceQty.setText(ItemComponentView.ITEM_LEFT_ONE_TEXT, resId);
        return this;
    }

    public SkuQuantityItemView setReferenceTitle(String title) {
        mIcvReferenceQty.setText(ItemComponentView.ITEM_LEFT_ONE_TEXT, title);
        return this;
    }

    public SkuQuantityItemView setReferenceQty(int quantity) {
        mIcvReferenceQty.setText(ItemComponentView.ITEM_LEFT_TWO_TEXT, String.valueOf(quantity));
        return this;
    }

    public SkuQuantityItemView setReferenceQty(String quantityStr) {
        mIcvReferenceQty.setText(ItemComponentView.ITEM_LEFT_TWO_TEXT, quantityStr);
        return this;
    }

    public SkuQuantityItemView setInputTitle(int resId) {
        mTvInputTitle.setText(resId);
        return this;
    }

    public SkuQuantityItemView setInputTitle(String title) {
        mTvInputTitle.setText(title);
        return this;
    }

    public SkuQuantityItemView setInputQty(int quantity) {
        mEtInputQty.setText(String.valueOf(quantity));
        return this;
    }

    public SkuQuantityItemView setInputQty(String quantity) {
        mEtInputQty.setText(quantity);
        return this;
    }

    public SkuQuantityItemView setInputQtyHint(int resId) {
        mEtInputQty.setHint(resId);
        return this;
    }

    public SkuQuantityItemView setCountingMode(boolean isCountingMode) {
        mIsCountingMode = isCountingMode;
        if (isCountingMode) {
            mLlInput.setVisibility(GONE);
            mIcvCounting.setVisibility(VISIBLE);
        } else {
            mLlInput.setVisibility(VISIBLE);
            mIcvCounting.setVisibility(GONE);
        }
        return this;
    }

    public SkuQuantityItemView setCountingTitle(int resId) {
        mIcvCounting.setText(ItemComponentView.ITEM_LEFT_ONE_TEXT, resId);
        return this;
    }

    public SkuQuantityItemView setCountingTitle(String title) {
        mIcvCounting.setText(ItemComponentView.ITEM_LEFT_ONE_TEXT, title);
        return this;
    }

    public SkuQuantityItemView setCountingContent(int resId) {
        return setCountingContent(getContext().getResources().getString(resId));
    }

    public SkuQuantityItemView setCountingContent(String content) {
        mIcvCounting.setText(ItemComponentView.ITEM_LEFT_TWO_TEXT, content + " >");
        mIcvCounting.setVisibility(ItemComponentView.ITEM_RIGHT_TAG, View.GONE);
        mIcvCounting.setTextColor(ItemComponentView.ITEM_LEFT_TWO_TEXT, ContextCompat.getColor(getContext(),R.color.common_orange));
        return this;
    }

    public SkuQuantityItemView setCountingQty(int quantity) {
        mUidCount = quantity;
        mIcvCounting.setVisibility(ItemComponentView.ITEM_RIGHT_TAG, View.VISIBLE);
        mIcvCounting.setText(ItemComponentView.ITEM_LEFT_TWO_TEXT, String.valueOf(quantity));
        mIcvCounting.setTextColor(ItemComponentView.ITEM_LEFT_TWO_TEXT,
                ContextCompat.getColor(getContext(),R.color.common_font_A1AEBC));
        return this;
    }

    public SkuQuantityItemView setCountingTagText(int tagTextResId) {
        mIcvCounting.setText(ItemComponentView.ITEM_RIGHT_TAG, tagTextResId);
        return this;
    }

    public SkuQuantityItemView setCountingListener(View.OnClickListener listener) {
        mIcvCounting.setOnClickListener(listener);
        return this;
    }

    public SkuQuantityItemView setReferenceVisibility(boolean visibility) {
        if (visibility) {
            mIcvReferenceQty.setVisibility(VISIBLE);
            mViewDivider.setVisibility(VISIBLE);
        } else {
            mIcvReferenceQty.setVisibility(GONE);
            mViewDivider.setVisibility(GONE);
            ViewGroup.LayoutParams layoutParams = mLlInput.getLayoutParams();
            layoutParams.width = UiUtils.getScreenWidth() / 2;
            mLlInput.setLayoutParams(layoutParams);
        }
        return this;
    }

    public EditText getInputQtyEditText() {
        return mEtInputQty;
    }

    public SkuQuantityItemView setInputListener(FragmentActivity activity,
                                                View.OnFocusChangeListener onFocusChangeListener,
                                                InputNumberHelper.OnKeyBordInputCodeListener onKeyBordInputCodeListener) {
        return setInputListener(activity, onFocusChangeListener, onKeyBordInputCodeListener, InputNumberHelper.MAX_INPUT, null);
    }

    public SkuQuantityItemView setInputListener(FragmentActivity activity,
                                                View.OnFocusChangeListener onFocusChangeListener,
                                                InputNumberHelper.OnKeyBordInputCodeListener onKeyBordInputCodeListener,
                                                int maxInput, NumRangeInputFilter.OnNumRangInputListener numRangInputListener) {
        if (mInputNumberHelper == null) {
            mInputNumberHelper = new InputNumberHelper(activity);
        }
        mInputNumberHelper.initInputQuantityByBoard(onFocusChangeListener,
                onKeyBordInputCodeListener, mEtInputQty, 0, maxInput, 0, numRangInputListener);
        return this;
    }

    public SkuQuantityItemView updateMaxInput(int maxInput) {
        InputFilter[] inputFilters = mEtInputQty.getFilters();
        if (inputFilters == null) {
            return this;
        }
        for (InputFilter inputFilter : inputFilters) {
            if (inputFilter instanceof NumRangeInputFilter) {
                NumRangeInputFilter numRangeInputFilter = (NumRangeInputFilter) inputFilter;
                numRangeInputFilter.setMaxValue(maxInput);
                break;
            }
        }
        return this;
    }

    public int getInputQty() {
        return getInputQty(0);
    }

    public int getInputQty(int defaultValue) {
        if (mIsCountingMode) {
            return mUidCount;
        } else {
            String inputText = mEtInputQty.getText().toString().trim();
            return NumberUtils.convertToInt(inputText, defaultValue);
        }
    }
}
