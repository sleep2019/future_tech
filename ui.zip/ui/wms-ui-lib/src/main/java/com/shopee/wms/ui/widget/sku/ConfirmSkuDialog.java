package com.shopee.wms.ui.widget.sku;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;

import com.bumptech.glide.Glide;
import com.shopee.sc.common.base.BaseDialogFragment;
import com.shopee.sc.common.util.ImageUrlUtils;
import com.shopee.sc.common.util.UiUtils;
import com.shopee.wms.ui.R;

import java.util.List;


public class ConfirmSkuDialog extends BaseDialogFragment {
    private ImageView mIvGoods;
    private TextView mTvSkuId;
    private TextView mTvSkuName;
    private Switch mSwitch;

    private OnButtonClickListener mClickListener;
    private List<String> mImages;
    private String mSkuId;
    private String mSkuName;
    private boolean mNeedRemind;

    public static ConfirmSkuDialog newInstance() {
        return new ConfirmSkuDialog();
    }

    public ConfirmSkuDialog() {
        mNeedRemind = true;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = super.onCreateView(inflater, container, savedInstanceState);
        if (v == null) {
            v = inflater.inflate(R.layout.wmsui_dialog_fragment_confirm_sku, container, false);
        }
        mIvGoods = v.findViewById(R.id.iv_goods_thumbnail);
        mTvSkuId = v.findViewById(R.id.tv_sku_id);
        mTvSkuName = v.findViewById(R.id.tv_sku_name);
        mSwitch = v.findViewById(R.id.switch_skip);

        v.findViewById(R.id.tv_cancel).setOnClickListener(v1 -> onCancelClicked());

        v.findViewById(R.id.tv_confirm).setOnClickListener(v2 -> onConfirmClicked());
        return v;
    }

    @Override
    protected int contentViewId() {
        return R.layout.wmsui_dialog_fragment_confirm_sku;
    }

    @Override
    protected void setNoTitleStyle() {
    }

    private void bindData() {
        if (mImages != null && !mImages.isEmpty()) {
            Glide.with(this)
                    .load(ImageUrlUtils.alter2LD(mImages.get(0)))
                    .placeholder(R.drawable.wmsui_ic_blank_thumbnail)
                    .dontAnimate()
                    .error(R.drawable.wmsui_ic_blank_thumbnail_error)
                    .into(mIvGoods);
        }
        mTvSkuId.setText(mSkuId);
        mTvSkuName.setText(mSkuName);
    }

    /**
     * 设置是否默认提醒确认
     *
     * @param needRemind
     */
    public void setRemind(boolean needRemind) {
        mNeedRemind = needRemind;
    }

    public void setData(List<String> images, String skuId, String skuName) {
        mImages = images;
        mSkuId = skuId;
        mSkuName = skuName;

    }

    public boolean isShowing() {
        return getDialog() != null && getDialog().isShowing();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        bindData();
        // 隐藏导航栏
        if (getDialog() != null) {
            final Window window = getDialog().getWindow();
            if (window != null) {
                window.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
                getDialog().setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface dialog) {
                        window.getDecorView()
                                .setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                        window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
                    }
                });
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog;
        Window window;
        if ((dialog = getDialog()) != null && getContext()!=null) {
            if ((window = dialog.getWindow()) != null) {
                int width = UiUtils.getScreenWidth() - UiUtils.dp2px(getContext(),16);
                int height = UiUtils.dp2px(getContext(),500);
                window.setLayout(width, height);
            }
        }
    }

    @Override
    public void show(@NonNull FragmentManager manager, @Nullable String tag) {
        if (mNeedRemind) {
            super.show(manager, tag);
        } else {
            // 用户选择了跳过，直接confirm
            if (mClickListener != null) {
                mClickListener.onConfirmClick();
            }
        }
    }

    public void onCancelClicked() {
        if (mClickListener != null) {
            mClickListener.onCancelClick();
        }
        dismissAllowingStateLoss();
    }

    public void onConfirmClicked() {
        if (mClickListener != null) {
            mClickListener.onConfirmClick();
        }
        if (mSwitch.isChecked()) {
            setRemind(false);
        }
        dismissAllowingStateLoss();
    }

    public void setClickListener(OnButtonClickListener listener) {
        mClickListener = listener;
    }

    public interface OnButtonClickListener {
        void onCancelClick();

        void onConfirmClick();
    }
}
