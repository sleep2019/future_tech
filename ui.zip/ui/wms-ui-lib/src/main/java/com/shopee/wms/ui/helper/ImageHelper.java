package com.shopee.wms.ui.helper;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.shopee.wms.ui.R;

public class ImageHelper {

    /**
     * 显示缩略图
     */
    public static void showThumbnail(ImageView imageView, String imgUrl) {
        Glide.with(imageView)
                .load(imgUrl)
                .placeholder(R.drawable.wmsui_ic_thumbnail_placeholder)
                .dontAnimate()
                .error(R.drawable.wmsui_ic_thumbnail_error)
                .into(imageView);
    }
}
