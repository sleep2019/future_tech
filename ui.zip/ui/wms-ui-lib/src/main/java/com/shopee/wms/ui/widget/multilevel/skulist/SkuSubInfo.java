package com.shopee.wms.ui.widget.multilevel.skulist;

import com.chad.library.adapter.base.entity.MultiItemEntity;

public class SkuSubInfo implements MultiItemEntity {
    public static final int TYPE_BOTTOM = 0;

    private String mSkuId;
    private String mSkuName;
    private String mSkuImage;
    private String mQuantity;

    public SkuSubInfo(String skuId, String skuName, String skuImage, String quantity) {
        mSkuId = skuId;
        mSkuName = skuName;
        mSkuImage = skuImage;
        mQuantity = quantity;
    }

    public String getSkuId() {
        return mSkuId;
    }

    public void setSkuId(String skuId) {
        mSkuId = skuId;
    }

    public String getSkuName() {
        return mSkuName;
    }

    public void setSkuName(String skuName) {
        mSkuName = skuName;
    }

    public String getSkuImage() {
        return mSkuImage;
    }

    public void setSkuImage(String skuImage) {
        mSkuImage = skuImage;
    }

    public String getQuantity() {
        return mQuantity;
    }

    public void setQuantity(String quantity) {
        mQuantity = quantity;
    }

    @Override
    public int getItemType() {
        return TYPE_BOTTOM;
    }
}
