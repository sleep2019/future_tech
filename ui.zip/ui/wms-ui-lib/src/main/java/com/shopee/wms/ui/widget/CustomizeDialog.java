package com.shopee.wms.ui.widget;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.Nullable;
import androidx.annotation.StyleRes;

import com.shopee.wms.ui.R;

import java.lang.ref.WeakReference;

public class CustomizeDialog extends Dialog {
    private CharSequence mMsg;
    private String mLeft;
    private String mRight;
    private int mMsgTopDrawable;
    private View mView;
    private int mLeftVisibility = View.VISIBLE;
    private int mRightVisibility = View.VISIBLE;
    private int mExitVisibility = View.GONE;
    private View.OnClickListener mLeftClickListener;
    private View.OnClickListener mRightClickListener;
    private View.OnClickListener mExitClickListener;
    @ColorInt
    private int mLeftTextColor;
    @ColorInt
    private int mRightTextColor;

    public CustomizeDialog(Context context) {
        this(context, R.style.UiLibraryCustomDialog);
    }

    public CustomizeDialog(Context context, @StyleRes int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wmsui_dialog_2_buttons);
        Window window = getWindow();
        if (window != null) {
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(lp);
        }
        initView();
    }

    private void initView() {
        TextView tvTitle = findViewById(R.id.tv_title);
        TextView tvLeft = findViewById(R.id.tv_left);
        TextView tvRight = findViewById(R.id.tv_right);
        LinearLayout llContent = findViewById(R.id.ll_content);
        View divideLine = findViewById(R.id.divider_line);

        if (mView != null) {
            divideLine.setVisibility(View.VISIBLE);
            llContent.setVisibility(View.VISIBLE);
            llContent.addView(mView);
        }

        if (!TextUtils.isEmpty(mMsg)) {
            tvTitle.setText(mMsg);
        }

        if (mMsgTopDrawable != 0) {
            tvTitle.setCompoundDrawablesRelativeWithIntrinsicBounds(0, mMsgTopDrawable, 0, 0);
            tvLeft.setTextColor(getContext().getResources().getColor(R.color.common_orange));
        }

        if (!TextUtils.isEmpty(mLeft)) {
            tvLeft.setText(mLeft);
        }

        if (!TextUtils.isEmpty(mRight)) {
            tvRight.setText(mRight);
        }

        if (mLeftTextColor != 0) {
            tvLeft.setTextColor(mLeftTextColor);
        }

        if (mRightTextColor != 0) {
            tvRight.setTextColor(mRightTextColor);
        }

        findViewById(R.id.tv_left).setVisibility(mLeftVisibility);
        findViewById(R.id.tv_right).setVisibility(mRightVisibility);
        findViewById(R.id.iv_exit).setVisibility(mExitVisibility);

        findViewById(R.id.tv_left).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mLeftClickListener != null) {
                    mLeftClickListener.onClick(v);
                }
                CustomizeDialog.this.dismiss();
            }
        });
        findViewById(R.id.tv_right).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRightClickListener != null) {
                    mRightClickListener.onClick(v);
                }
                CustomizeDialog.this.dismiss();
            }
        });
        findViewById(R.id.iv_exit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mExitClickListener != null) {
                    mExitClickListener.onClick(v);
                }
                CustomizeDialog.this.dismiss();
            }
        });
    }


    @Override
    public void show() {
        if (!isDestroyedOrFinishing()) {
            super.show();
        }
    }

    protected boolean isDestroyedOrFinishing() {
        Activity activity = getActivityNoException();
        if (activity != null) {
            return activity.isDestroyed() || activity.isFinishing();
        }
        return false;
    }

    protected Activity getActivityNoException() {
        if (getContext() instanceof Activity) {
            return (Activity) getContext();
        } else if (getContext() instanceof ContextWrapper) {
            Context base = ((ContextWrapper) getContext()).getBaseContext();
            if (base instanceof Activity) {
                return (Activity) base;
            }
        }
        return null;
    }

    public CustomizeDialog setMsg(CharSequence title) {
        mMsg = title;
        return this;
    }

    public void setMsgTopDrawable(int msgTopDrawable) {
        mMsgTopDrawable = msgTopDrawable;
    }

    public CustomizeDialog setLeft(String left) {
        mLeft = left;
        return this;
    }

    public CustomizeDialog setRight(String right) {
        mRight = right;
        return this;
    }

    public CustomizeDialog setLeftTextColor(@ColorInt int leftTextColor) {
        mLeftTextColor = leftTextColor;
        return this;
    }

    public CustomizeDialog setRightTextColor(@ColorInt int rightTextColor) {
        mRightTextColor = rightTextColor;
        return this;
    }

    public CustomizeDialog setContentLayout(View view) {
        mView = view;
        return this;
    }

    public void setLeftVisibility(int leftVisibility) {
        mLeftVisibility = leftVisibility;
    }

    public void setRightVisibility(int rightVisibility) {
        mRightVisibility = rightVisibility;
    }

    public CustomizeDialog setExitVisibility(int exitVisibility) {
        mExitVisibility = exitVisibility;
        return this;
    }

    public CustomizeDialog setLeftClickListener(View.OnClickListener leftClickListener) {
        mLeftClickListener = leftClickListener;
        return this;
    }

    public CustomizeDialog setRightClickListener(View.OnClickListener rightClickListener) {
        mRightClickListener = rightClickListener;
        return this;
    }

    public void setExitClickListener(View.OnClickListener exitClickListener) {
        mExitClickListener = exitClickListener;
    }

    @Override
    public void setOnDismissListener(@Nullable OnDismissListener listener) {
        super.setOnDismissListener(listener == null ? null : new SafeOnDismissListener(listener));
    }


    static class SafeOnDismissListener implements OnDismissListener {

        private WeakReference<OnDismissListener> mWeakReference;

        public SafeOnDismissListener(OnDismissListener outOnDismissListener) {
            mWeakReference = new WeakReference<>(outOnDismissListener);
        }

        @Override
        public void onDismiss(DialogInterface dialog) {
            if (mWeakReference.get() != null) {
                mWeakReference.get().onDismiss(dialog);
            }
        }
    }
}
