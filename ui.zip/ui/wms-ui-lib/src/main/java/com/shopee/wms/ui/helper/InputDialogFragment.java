package com.shopee.wms.ui.helper;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ReplacementTransformationMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.shopee.wms.ui.R;


public class InputDialogFragment extends DialogFragment {
    private static final String HINT_TEXT = "hint_text";
    private static final String CONTENT_TEXT = "content_text";
    private static final String IS_UPPER_CASE = "is_upper_case";
    private String mHintText;
    private String mContentText;
    private boolean mIsUpperCase;

    private OnInputListener mOnInputListener;

    public static InputDialogFragment newInstance(boolean isUpperCase, String hintText, String contentText) {
        InputDialogFragment fragment = new InputDialogFragment();
        Bundle args = new Bundle();
        args.putBoolean(IS_UPPER_CASE, isUpperCase);
        args.putString(HINT_TEXT, hintText);
        args.putString(CONTENT_TEXT, contentText);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NO_TITLE, android.R.style.Theme_Dialog);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.wmsui_dialog_input, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();
        setAsBottomDialog();
        initView(view);
    }

    private void initData() {
        if (getArguments() == null) {
            return;
        }
        mIsUpperCase = getArguments().getBoolean(IS_UPPER_CASE);
        mHintText = getArguments().getString(HINT_TEXT);
        mContentText = getArguments().getString(CONTENT_TEXT);
    }

    private void initView(View view) {
        EditText etInput = view.findViewById(R.id.et_input_code);

        // DialogFragment 显示的时候，EditText 即使有焦点也不会自动弹出软键盘，需要手动调用一下弹出键盘
        toggleSoftInput(etInput);

        if (!TextUtils.isEmpty(mHintText)) {
            etInput.setHint(mHintText);
        }

        if (!TextUtils.isEmpty(mContentText)) {
            etInput.setText(mContentText);
            // 光标移动到字符串末尾
            etInput.setSelection(mContentText.length());
        }

        etInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        etInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND
                    || actionId == EditorInfo.IME_ACTION_DONE
                    || actionId == EditorInfo.IME_ACTION_NEXT
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {

                String content = etInput.getText().toString().trim();
                if (mIsUpperCase) {
                    content = content.toUpperCase();
                }
                if (!TextUtils.isEmpty(content)) {
                    if (mOnInputListener != null) {
                        mOnInputListener.onInput(content);
                    }
                    dismiss();
                }
                return true;
            }
            return false;
        });

        if (mIsUpperCase) {
            etInput.setTransformationMethod(new ReplacementTransformationMethod() {
                @Override
                protected char[] getOriginal() {
                    return new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g',
                            'h', 'i', 'j', 'k', 'l', 'm', 'n',
                            'o', 'p', 'q', 'r', 's', 't',
                            'u', 'v', 'w', 'x', 'y', 'z'};
                }

                @Override
                protected char[] getReplacement() {
                    return new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G',
                            'H', 'I', 'J', 'K', 'L', 'M', 'N',
                            'O', 'P', 'Q', 'R', 'S', 'T',
                            'U', 'V', 'W', 'X', 'Y', 'Z'};
                }
            });
        }
    }

    public void setOnInputListener(OnInputListener onInputListener) {
        mOnInputListener = onInputListener;
    }

    /**
     * 宽度占满整个屏幕，高度自适应，贴在底部的对话框
     */
    protected void setAsBottomDialog() {
        if (getDialog() == null) {
            return;
        }
        Window window = getDialog().getWindow();
        if (window == null) {
            return;
        }
        // 去掉Dialog默认的padding, 宽度占满整个屏幕,底部贴边
        window.getDecorView().setPadding(0, 0, 0, 0);
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        // 设置Dialog的位置在底部
        lp.gravity = Gravity.BOTTOM;
        window.setAttributes(lp);
    }

    private void toggleSoftInput(final View view) {
        try {
            InputMethodManager imm = (InputMethodManager) view.getContext()
                    .getSystemService(Context.INPUT_METHOD_SERVICE);
            // 1、需要加延迟才能弹出软键盘；
            // 2、InputMethodManager 的 showSoftInput 方法 在 Newland NLS-MT65 不能弹出软键盘，
            // 其它设备可以弹出但是Dismiss不能自动隐藏。
            view.postDelayed(() ->
                    imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS), 50);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface OnInputListener {
        void onInput(String content);
    }
}
