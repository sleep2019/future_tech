package com.shopee.wms.ui.widget.Grid;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.wms.ui.R;

/**
 * @author 常亚浩
 * @date 2021-11-18
 */
public class GridDataAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    public GridDataAdapter() {
        super(R.layout.wmsui_item_covered_zone);
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        helper.setText(R.id.tv_covered_zone, item);
    }

}
