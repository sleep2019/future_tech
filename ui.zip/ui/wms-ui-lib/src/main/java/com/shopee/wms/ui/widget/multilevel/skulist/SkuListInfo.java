package com.shopee.wms.ui.widget.multilevel.skulist;

import com.chad.library.adapter.base.entity.AbstractExpandableItem;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.shopee.wms.ui.widget.multilevel.itemlist.ItemTagInfo;

import java.util.List;


public class SkuListInfo extends AbstractExpandableItem<SkuSubInfo> implements MultiItemEntity {
    public static final int TYPE_TOP = 1;

    private String mFirstLine;
    private String mSecondLine;
    private boolean mIsChecked;

    /**
     * 第一个SKU需要在上层层级展示
     */
    private String mSkuId;
    private String mSkuName;
    private String mSkuImage;
    private String mQuantity;

    private Object mOrigin;
    private List<ItemTagInfo> mFirstLineTagList;

    public String getFirstLine() {
        return mFirstLine;
    }

    public void setFirstLine(String firstLine) {
        mFirstLine = firstLine;
    }

    public boolean isChecked() {
        return mIsChecked;
    }

    public void setChecked(boolean checked) {
        mIsChecked = checked;
    }

    public String getSecondLine() {
        return mSecondLine;
    }

    public void setSecondLine(String secondLine) {
        mSecondLine = secondLine;
    }

    public String getSkuId() {
        return mSkuId;
    }

    public void setSkuId(String skuId) {
        mSkuId = skuId;
    }

    public String getSkuName() {
        return mSkuName;
    }

    public void setSkuName(String skuName) {
        mSkuName = skuName;
    }

    public String getSkuImage() {
        return mSkuImage;
    }

    public void setSkuImage(String skuImage) {
        mSkuImage = skuImage;
    }

    public String getQuantity() {
        return mQuantity;
    }

    public void setQuantity(String quantity) {
        mQuantity = quantity;
    }

    public Object getOrigin() {
        return mOrigin;
    }

    public void setOrigin(Object origin) {
        mOrigin = origin;
    }

    public List<ItemTagInfo> getFirstLineTagList() {
        return mFirstLineTagList;
    }

    public void setFirstLineTagList(List<ItemTagInfo> firstLineTagList) {
        mFirstLineTagList = firstLineTagList;
    }

    @Override
    public int getLevel() {
        return 0;
    }

    @Override
    public int getItemType() {
        return TYPE_TOP;
    }
}
