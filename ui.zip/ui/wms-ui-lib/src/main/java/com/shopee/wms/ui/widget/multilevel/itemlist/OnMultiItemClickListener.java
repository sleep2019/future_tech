package com.shopee.wms.ui.widget.multilevel.itemlist;

import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;

public interface OnMultiItemClickListener {
    void onItemClick(BaseQuickAdapter adapter, View view, int position, ItemListInfo info);
}
