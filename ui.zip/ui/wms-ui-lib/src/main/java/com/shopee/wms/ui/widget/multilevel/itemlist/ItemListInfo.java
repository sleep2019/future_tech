package com.shopee.wms.ui.widget.multilevel.itemlist;

import com.chad.library.adapter.base.entity.AbstractExpandableItem;
import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

public class ItemListInfo extends AbstractExpandableItem<ItemSubInfo> implements MultiItemEntity {
    public static final int TYPE_TOP = 1;

    private String mItemQty;
    private String mItemDate;
    private String mSecondLine;

    private List<ItemTagInfo> mItemTagInfos;
    private ItemTagInfo mTag2Info;
    private boolean mClickable = true;

    private Object mOrigin;

    public String getItemQty() {
        return mItemQty;
    }

    public void setItemQty(String itemQty) {
        mItemQty = itemQty;
    }

    public String getItemDate() {
        return mItemDate;
    }

    public void setItemDate(String itemDate) {
        mItemDate = itemDate;
    }

    public String getSecondLine() {
        return mSecondLine;
    }

    public void setSecondLine(String secondLine) {
        mSecondLine = secondLine;
    }

    public List<ItemTagInfo> getItemTagInfos() {
        return mItemTagInfos;
    }

    public void setItemTagInfos(List<ItemTagInfo> itemTagInfos) {
        mItemTagInfos = itemTagInfos;
    }

    public ItemTagInfo getTag2Info() {
        return mTag2Info;
    }

    public void setTag2Info(ItemTagInfo tag2Info) {
        mTag2Info = tag2Info;
    }

    public boolean isClickable() {
        return mClickable;
    }

    public void setClickable(boolean clickable) {
        mClickable = clickable;
    }

    public Object getOrigin() {
        return mOrigin;
    }

    public void setOrigin(Object origin) {
        mOrigin = origin;
    }

    @Override
    public int getLevel() {
        return 0;
    }

    @Override
    public int getItemType() {
        return TYPE_TOP;
    }
}
