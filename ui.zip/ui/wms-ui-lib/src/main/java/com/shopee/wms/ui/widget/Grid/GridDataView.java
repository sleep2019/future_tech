package com.shopee.wms.ui.widget.Grid;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.shopee.wms.ui.R;

import java.util.List;

import static com.shopee.wms.ui.constant.Constant.GRID_COLUMN;

/**
 * @author 常亚浩
 * @date 2021-11-18
 */
public class GridDataView extends LinearLayout {

    private TextView mTextView;
    private RecyclerView mRecyclerView;
    private GridDataAdapter mGridAdapter;
    private View mDivider;
    private FrameLayout mFrameLayout;
    public GridDataView(Context context) {
        super(context);
        initView(context);
    }

    public GridDataView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);

    }

    public GridDataView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        View contentView = LayoutInflater.from(context)
                .inflate(R.layout.wmsui_grid, this, true);
        mTextView = contentView.findViewById(R.id.tv_zone_title);
        mRecyclerView = contentView.findViewById(R.id.rv_content);
        mDivider = contentView.findViewById(R.id.zone_divider);
        mFrameLayout = contentView.findViewById(R.id.fl_zones);

        mGridAdapter = new GridDataAdapter();
        GridLayoutManager gridLayoutManager = new GridLayoutManager(context, GRID_COLUMN,
                GridLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.setAdapter(mGridAdapter);
    }

    public void setDate(List<String> date) {
        if (date != null && date.size() != 0) {
            mGridAdapter.setNewData(date);
        }
    }

    public GridDataView setTitle(@StringRes int resId) {
        mTextView.setText(resId);
        return this;
    }

    public GridDataView setTitle(String text) {
        mTextView.setText(text);
        return this;
    }

    public void setDividerVisibility(int isVisibility){
        mDivider.setVisibility(isVisibility);
    }

    public void setFlZoneVisibility(int isVisibility){
        mFrameLayout.setVisibility(isVisibility);
    }
    public void setTitleVisibility(int isVisibility) {
        mTextView.setVisibility(isVisibility);
    }

    public void setDataVisibility(int isVisibility) {
        mRecyclerView.setVisibility(isVisibility);
    }

}
