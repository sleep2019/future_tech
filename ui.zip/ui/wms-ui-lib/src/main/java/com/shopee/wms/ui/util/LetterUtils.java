package com.shopee.wms.ui.util;

import android.content.Context;
import android.text.method.ReplacementTransformationMethod;
import android.widget.EditText;

import com.shopee.wms.ui.widget.SingleLineInputScanView;

/**
 * {类的功能描述}
 *
 * @author 常亚浩
 * @date 2021-11-25
 * @modified author
 */
public class LetterUtils {

    //小写字母变大写
    public static void setCapitalLetter(EditText editText) {
        editText.setTransformationMethod(new ReplacementTransformationMethod() {
            @Override
            protected char[] getOriginal() {
                return new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g',
                        'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
            }

            @Override
            protected char[] getReplacement() {
                return new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G',
                        'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
            }
        });
    }
}
