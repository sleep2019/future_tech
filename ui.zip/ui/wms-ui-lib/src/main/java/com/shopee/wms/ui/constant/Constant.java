package com.shopee.wms.ui.constant;

/**
 * @author 常亚浩
 * @date 2021-11-15
 */
public class Constant {
    public static final String COLOR_FF4742 = "#FF4742";
    public static final int GRID_COLUMN = 7;
}
