package com.shopee.wms.ui.helper;

import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.shopee.sc.common.misc.NumRangeInputFilter;
import com.shopee.sc.common.util.KeyBoradUtils;
import com.shopee.wms.ui.R;

/**
 * Created by chris on 2019/4/25.
 */
public class InputNumberHelper {

    private static final String POINTER = ".";
    public static final int MAX_INPUT = 9999999;

    private FragmentActivity mContext;
    private OnInputCodeListener mInputCodeListener;

    public InputNumberHelper(FragmentActivity ctx) {
        mContext = ctx;
    }

    public void initInputQuantityByBoard(final View.OnFocusChangeListener onFocusChangeListener,
                                         final OnKeyBordInputCodeListener onKeyBordInputCodeListener,
                                         final EditText etInput, final float inputMin, final float inputMax) {
        initInputQuantityByBoard(onFocusChangeListener, onKeyBordInputCodeListener, etInput, inputMin, inputMax, 0, null);
    }

    public void initInputQuantityByBoard(final View.OnFocusChangeListener onFocusChangeListener,
                                         final OnKeyBordInputCodeListener onKeyBordInputCodeListener,
                                         EditText inputText, final float inputMin, final float inputMax,
                                         final int maxPointerLength, final NumRangeInputFilter.OnNumRangInputListener listener) {
        if (inputText.getTag(R.id.wmsui_input_initial) instanceof Boolean) {
            return;
        }
        //设置只能输入数字
        int inputType = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_NORMAL;
        if (maxPointerLength > 0) {
            inputType = inputType | InputType.TYPE_NUMBER_FLAG_DECIMAL;
        }
        inputText.setInputType(inputType);

        //将键盘上的文字修改为"确认"
        inputText.setImeOptions(EditorInfo.IME_ACTION_DONE);
        inputText.setFilters(new InputFilter[]{new NumRangeInputFilter(inputMax, inputMin, maxPointerLength, listener)});
        inputText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND
                        || actionId == EditorInfo.IME_ACTION_NEXT
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    //让当前的输入框失去焦点，在OnFocusChangeListener的onFocusChange()中去处理输入的数量
                    inputText.clearFocus();
                    //输入完成隐藏软键盘
                    KeyBoradUtils.hideSoftKeyBoard(inputText);
                }
                return true;
            }
        });

        inputText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString();
                // 非小数点情况
                if (!text.contains(POINTER)) {
                    // 当长度 > 1 时再 replace
                    if (s.length() > 1 && text.startsWith("0")) {
                        s.replace(0, 1, "");
                    }
                }
            }
        });
        inputText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!(v instanceof TextView)) {
                    return;
                }
                TextView tv = (TextView) v;
                if (hasFocus) {//有焦点视为开始输入，此时将输入改变之前的内容设置为tag,这样可以在输入完成的时候监控本次输入是否有改变
                    String beforeInputText = ((TextView) v).getText().toString();
                    v.setTag(R.id.wmsui_before_input_data, beforeInputText);
                } else {
                    String currentInput = tv.getText().toString().trim();
                    //失去焦点时如果现在与之前的输入值一样，则视为本次没有改变该控件的文字
                    Object tag = v.getTag(R.id.wmsui_before_input_data);
                    if (tag instanceof String) {
                        String beforeInputText = (String) tag;
                        if (beforeInputText.equals(currentInput)) {
                            return;
                        }
                        if (onKeyBordInputCodeListener != null) {
                            onKeyBordInputCodeListener.setInputCode(inputText, currentInput);
                        }
                    }
                    //失去焦点时隐藏软键盘
                    KeyBoradUtils.hideSoftKeyBoard(tv);
                }
                if (onFocusChangeListener != null) {
                    onFocusChangeListener.onFocusChange(v, hasFocus);
                }
            }
        });
        inputText.setTag(R.id.wmsui_input_initial, true);
    }

    public void showInputCode(boolean matchCase) {
        showInputCode(matchCase, null);
    }

    public void showInputCode(boolean matchCase, String hint) {
        showInputCode(matchCase, null, hint);
    }

    public void showInputCode(boolean matchCase, String value, String hint) {
        if (mContext == null) {
            return;
        }
        InputDialogFragment dialogFragment = InputDialogFragment.newInstance(matchCase, hint, value);
        dialogFragment.setOnInputListener(content -> {
            if (mInputCodeListener != null) {
                mInputCodeListener.setInputCode(content);
            }
        });
        dialogFragment.show(mContext.getSupportFragmentManager(), InputDialogFragment.class.getSimpleName());
    }

    public void setInputCodeListener(OnInputCodeListener listener) {
        this.mInputCodeListener = listener;
    }

    public interface OnInputCodeListener {
        void setInputCode(String code);
    }

    public interface OnKeyBordInputCodeListener {
        void setInputCode(EditText inputText, String code);
    }
}
