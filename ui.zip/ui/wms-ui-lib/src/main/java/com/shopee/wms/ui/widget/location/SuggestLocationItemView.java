package com.shopee.wms.ui.widget.location;

import android.content.Context;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.android.ui_library.widget.item.ItemComponentView;
import com.shopee.sc.common.util.CheckUtils;
import com.shopee.wms.ui.R;

import java.util.List;

public class SuggestLocationItemView extends LinearLayout {

    private TextView mTvSuggestLocationId;
    private TextView mTvSuggestLocationType;
    private TextView mTvExpirationTime;
    private ItemComponentView mIcvSuggestQty;
    private TextView mTvNext;
    private RelativeLayout mLlNextLocationAndExpirationTime;
    private int mCurrentIndex;
    private OnChangeSuggestLocationListener mOnChangeSuggestLocationListener;
    private OnRetryGetSuggestLocationListener mOnRetryGetSuggestLocationListener;
    private OnSuggestTimeFinishListener mOnSuggestTimeFinishListener;
    private CountDownTimer mCountDownTimer;
    private boolean mIsShowSuggestQty = true;
    private boolean mStopNextActionInLastOne; // next 按钮点到最后一个 location 是否直接终止

    public SuggestLocationItemView(Context context) {
        super(context);
        initView(context);
    }

    public SuggestLocationItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public SuggestLocationItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        View contentView = LayoutInflater.from(context).inflate(R.layout.wmsui_item_suggest_location, this, true);
        mTvSuggestLocationId = contentView.findViewById(R.id.tv_suggest_location_id);
        mTvSuggestLocationType = contentView.findViewById(R.id.tv_suggest_location_type);
        mTvExpirationTime = contentView.findViewById(R.id.tv_expiration_time);
        mIcvSuggestQty = contentView.findViewById(R.id.icv_suggest_qty);
        mTvNext = contentView.findViewById(R.id.tv_next);
        mLlNextLocationAndExpirationTime = contentView.findViewById(R.id.rl_next_location_and_expiration_time);
    }

    public SuggestLocationItemView setSuggestLocations(List<Location> suggestLocations) {
        if (!CheckUtils.isNullOrEmpty(suggestLocations)) {
            showSuggestLocation(true);
            setSuggestLocation(suggestLocations.get(0));
            if (suggestLocations.size() > 1) {
                mCurrentIndex = 0;
                mTvNext.setVisibility(VISIBLE);
                mLlNextLocationAndExpirationTime.setVisibility(VISIBLE);
                mLlNextLocationAndExpirationTime.setOnClickListener(v -> {
                    if (mCurrentIndex >= suggestLocations.size() - 1) {
                        if (mOnChangeSuggestLocationListener != null) {
                            int lastIndex = suggestLocations.size() - 1;
                            mOnChangeSuggestLocationListener.onLastLocation(suggestLocations.get(lastIndex));
                        }
                        // 到了最后一个 Location 直接终止循环
                        if (mStopNextActionInLastOne) {
                            return;
                        }
                        mCurrentIndex = 0;
                    } else {
                        mCurrentIndex++;
                    }
                    Location suggestLocation = suggestLocations.get(mCurrentIndex);
                    if (mOnChangeSuggestLocationListener != null) {
                        mOnChangeSuggestLocationListener.onChangeSuggestLocation(suggestLocation);
                    }
                    setSuggestLocation(suggestLocation);
                });
            } else {
                mTvNext.setVisibility(GONE);
                checkNextLocationAndExpirationTimeLayoutVisibility();
            }
        } else {
            showSuggestLocation(false);
        }
        return this;
    }

    private void showSuggestLocation(boolean isShow) {
        int visibility = isShow ? View.VISIBLE : View.INVISIBLE;
        mTvSuggestLocationId.setVisibility(visibility);
        if (mIsShowSuggestQty) {
            mIcvSuggestQty.setVisibility(visibility);
        }
    }

    public SuggestLocationItemView setStopNextActionInLastOne(boolean stopNextActionInLastOne) {
        mStopNextActionInLastOne = stopNextActionInLastOne;
        return this;
    }

    public SuggestLocationItemView setSuggestQtyVisible(boolean isVisible) {
        mIsShowSuggestQty = isVisible;
        mIcvSuggestQty.setVisibility(isVisible ? VISIBLE : INVISIBLE);
        return this;
    }

    public SuggestLocationItemView setOnChangeSuggestLocationListener(OnChangeSuggestLocationListener listener) {
        mOnChangeSuggestLocationListener = listener;
        return this;
    }

    public SuggestLocationItemView setOnRetryGetSuggestLocationListener(OnRetryGetSuggestLocationListener listener) {
        mOnRetryGetSuggestLocationListener = listener;
        return this;
    }

    public SuggestLocationItemView setOnSuggestTimeFinishListener(OnSuggestTimeFinishListener listener) {
        mOnSuggestTimeFinishListener = listener;
        return this;
    }

    private void setSuggestLocation(Location suggestLocation) {
        if (suggestLocation == null) {
            return;
        }
        mTvSuggestLocationId.setText(suggestLocation.getLocationId());
        if (!TextUtils.isEmpty(suggestLocation.getLocationType())) {
            mTvSuggestLocationType.setVisibility(VISIBLE);
            mTvSuggestLocationType.setText(suggestLocation.getLocationType());
        } else {
            mTvSuggestLocationType.setVisibility(GONE);
        }
        mIcvSuggestQty.setText(ItemComponentView.ITEM_LEFT_TWO_TEXT, String.valueOf(suggestLocation.getQuantity()));

        long countDownTimeSec = suggestLocation.getExpirationDate() - System.currentTimeMillis() / 1000;
        if (countDownTimeSec > 0) {
            initCountDownTimer(countDownTimeSec);
        }
    }

    private void initCountDownTimer(long countDownTimeSec) {
        // 初始化之前先检查是否有之前在运行的CountDownTimer
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
        }
        mTvExpirationTime.setVisibility(VISIBLE);
        mLlNextLocationAndExpirationTime.setVisibility(VISIBLE);
        mCountDownTimer = new CountDownTimer(countDownTimeSec * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long totalSec = millisUntilFinished / 1000;
                int mm = (int) (totalSec / 60);
                int ss = (int) (totalSec % 60);
                String time = "( " + getContext().getResources().getString(R.string.wmsui_mm_ss, mm, ss) + " )";
                mTvExpirationTime.setText(time);
            }

            @Override
            public void onFinish() {
                mTvSuggestLocationType.setVisibility(GONE);
                // 不使用 GONE 为了占据空位，下次推荐继续显示该位置上
                mTvSuggestLocationId.setVisibility(INVISIBLE);
                mIcvSuggestQty.setVisibility(INVISIBLE);
                mTvNext.setVisibility(VISIBLE);
                mTvExpirationTime.setVisibility(GONE);
                mLlNextLocationAndExpirationTime.setVisibility(VISIBLE);
                mLlNextLocationAndExpirationTime.setOnClickListener(v -> {
                    if (mOnRetryGetSuggestLocationListener != null) {
                        mOnRetryGetSuggestLocationListener.onRetryGetSuggestLocation();
                    }
                });
                if (mOnSuggestTimeFinishListener != null) {
                    mOnSuggestTimeFinishListener.onSuggestTimeFinish();
                }
            }
        };
        mCountDownTimer.start();
    }

    private void checkNextLocationAndExpirationTimeLayoutVisibility() {
        if (mTvNext.getVisibility() == VISIBLE || mTvExpirationTime.getVisibility() == VISIBLE) {
            mLlNextLocationAndExpirationTime.setVisibility(VISIBLE);
        } else {
            mLlNextLocationAndExpirationTime.setVisibility(GONE);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
        }
    }

    public interface OnChangeSuggestLocationListener {
        void onChangeSuggestLocation(Location selectedSuggestLocation);

        /**
         * 最后一个 Location
         *
         * @param location 最后一个Location
         */
        default void onLastLocation(Location location) {
        }
    }

    public interface OnRetryGetSuggestLocationListener {
        void onRetryGetSuggestLocation();
    }

    public interface OnSuggestTimeFinishListener {
        void onSuggestTimeFinish();
    }

    public static class Location {
        private String locationId;
        private String locationType;
        private int quantity;
        private long expirationDate;

        public Location(@NonNull String locationId) {
            this.locationId = locationId;
        }

        public Location(String locationId, int quantity) {
            this.locationId = locationId;
            this.quantity = quantity;
        }

        public Location(String locationId, int quantity, long expirationDate) {
            this.locationId = locationId;
            this.quantity = quantity;
            this.expirationDate = expirationDate;
        }

        public Location(String locationId, String locationType, int quantity, long expirationDate) {
            this.locationId = locationId;
            this.locationType = locationType;
            this.quantity = quantity;
            this.expirationDate = expirationDate;
        }

        public String getLocationId() {
            return locationId;
        }

        public String getLocationType() {
            return locationType;
        }

        public int getQuantity() {
            return quantity;
        }

        public long getExpirationDate() {
            return expirationDate;
        }
    }
}
