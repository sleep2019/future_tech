# CalendarView

在 SPX 的早期开发过程中，由于时间原因，使用了 [huanghaibin-dev/CalendarView](https://github.com/huanghaibin-dev/CalendarView) 库来实现日历功能，该库在横向日历方面提供了非常丰富的功能，足以满足早期需求。但随着业务的复杂化，当设计同学提出竖向日历选择日期范围的需求时，该库就无能为力了。遂在该库的基础上，进行了较大的重构优化，新增支持竖向日历等功能。

## 整体设计

- 实体类 CalendarBean 保存常用日历属性，提供 BaseSubCalendarBean 供外部实现其他日历功能，如农历等。
- CalendarView 的所有日历逻辑提取至 ICalendarViewDelegate 接口，抽象类 BaseCalendarViewDelegate 实现公共逻辑，如日期设置、周起始设置、月视图显示模式设置、日期选择模式设置、多选范围选择逻辑、标记日期设置等，两个子类 CalendarViewDelegateHorizontal、CalendarViewDelegateVertical 分别实现横向、竖向日历的差异功能。
- 年/月/周视图的基础类分别为 SimpleYearView、SimpleMonthView、SimpleWeekView，逻辑内聚，无需外部继承。
- 横向日历为 YearViewPager + MonthViewPager + WeekViewPager 实现横向年/月/周视图的展示与切换。
- 竖向日历为 RecyclerView + SimpleMonthView 实现竖向月视图的展示与滑动。
- 将月/周视图的绘制逻辑抽离至 BaseMonthWeekPainter，提供默认实现。当需要自定义月/周视图时，最多只需一次反射即可。
- 将年视图的绘制逻辑抽离至 BaseYearViewPainter，提供默认实现。
- 星期栏 WeekBar 即为默认实现，也可继承实现自定义星期栏。


## 自定义功能及属性

### 日历显示模式

支持横向日历及竖向日历两种显示模式，xml设置值后不可修改

```xml
    <attr name="calendar_style">
        <enum name="horizontal_style" value="0" />
        <enum name="vertical_style" value="1" />
    </attr>
```

### 最小日期与最大日期

支持解析 "yyyyMMdd" 格式的字符串，解析错误时使用默认的最小日期（19000101）或最大日期（20991231）

```xml
    <!-- The minimal date shown by this calendar view in yyyyMMdd format. -->
    <attr name="min_date" format="string" />
    <!-- The maximal date shown by this calendar view in yyyyMMdd format. -->
    <attr name="max_date" format="string" />
```

### 自定义周起始

支持设置任意 week day 为周起始，取值与 java.util.Calendar 中的星期相同

```xml
    <attr name="week_start_with">
        <enum name="sunday" value="1" />
        <enum name="monday" value="2" />
        <enum name="tuesday" value="3" />
        <enum name="wednesday" value="4" />
        <enum name="thursday" value="5" />
        <enum name="friday" value="6" />
        <enum name="saturday" value="7" />
    </attr>
```

### 月视图显示模式

支持 3 种常见的月视图显示模式自由切换：
- mode_all：显示 6*7 中的所有日期
- mode_only_current：仅显示当月日期
- mode_fix：当月日期 + 填充首尾日期

```xml
    <attr name="month_view_show_mode">
        <enum name="mode_all" value="0" />
        <enum name="mode_only_current" value="1" />
        <enum name="mode_fix" value="2" />
    </attr>
```

### 日期选择模式

支持 4 种日期选择模式：
- auto_mode：默认模式，横向日历切换月份时根据选中规则自动选择日期
- single_mode：单选模式
- range_mode：范围选择模式
- multi_mode：多选模式

```xml
    <attr name="select_mode">
        <enum name="auto_mode" value="0" />
        <enum name="single_mode" value="1" />
        <enum name="range_mode" value="2" />
        <enum name="multi_mode" value="3" />
    </attr>
```

*auto_mode 自动选择模式时，切换月份时的选中日期模式*
- first_day_of_month：月份第一天
- last_select_day：最后一个选中日期横移，切回当月时选中当天
- last_select_day_ignore_current：最后一个选中日期横移，切回当月时也一致

```xml
    <attr name="auto_focus_mode">
        <enum name="first_day_of_month" value="0" />
        <enum name="last_select_day" value="1" />
        <enum name="last_select_day_ignore_current" value="2" />
    </attr>
```

*多选模式最大选择天数*

```xml
    <attr name="multi_select_max_size" format="integer" />
```

*范围选择模式最小/最大选择天数*

```xml
    <attr name="range_select_min_size" format="integer" />
    <attr name="range_select_max_size" format="integer" />
```

### 月/周视图绘制器

最常用的自定义部分，支持 xml 定义类名(反射构建)或运行时动态设值两种设置方式

```xml
    <attr name="month_week_painter" format="string" />
```

### 年视图绘制器

支持 xml 定义类名(反射构建)或运行时动态设值两种设置方式

```xml
    <attr name="year_view_painter" format="string" />
```

### 自定义星期栏

支持 xml 定义类名(反射构建)或运行时动态设值两种设置方式

```xml
    <attr name="week_bar_view" format="string" />
```

### 自定义月/年视图字体属性

支持定义月/年视图 selected/current day/scheme/current month/other month 等状态日历卡的字体颜色等，该部分属性较多且较简单，不一一列举

```xml
    <attr name="selected_text_color" format="color" />
    <attr name="scheme_text_color" format="color" />
    <attr name="current_day_text_color" format="color" />
    <attr name="current_month_text_color" format="color" />
    <attr name="other_month_text_color" format="color" />
    ...
```

### 当前横向/竖向日历支持的功能对比

|       功能        | 横向日历 | 竖向日历 |
| :---------------- | :------- | :------- |
| 年视图            | yes      | no       |
| 月视图            | yes      | yes      |
| 周视图            | yes      | no       |
| 3种月视图显示模式 | yes      | yes      |
| 自定义周起始      | yes      | yes      |
| 默认选择模式      | yes      | no       |
| 单选/多选模式     | yes      | yes      |
| 范围选择模式      | yes      | yes      |
| 月/周视图绘制器   | yes      | yes      |
| 年视图绘制器      | yes      | no       |
| 自定义星期栏      | yes      | yes      |

