package com.shopee.sc.ui.calendar;

import org.junit.Test;

import java.util.Calendar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test {@link CalendarUtil}
 */
public class CalendarUnitTest {

    @Test
    public void test_isWeekend() {
        // 周四
        assertFalse(CalendarUtil.isWeekend(new CalendarBean(2020, 3, 12)));
        // 周日
        assertTrue(CalendarUtil.isWeekend(new CalendarBean(2020, 3, 15)));
    }

    @Test
    public void test_getMonthDaysCount() {
        assertEquals(29, CalendarUtil.getMonthDaysCount(2020, 2));
        assertEquals(31, CalendarUtil.getMonthDaysCount(2020, 3));
        assertEquals(30, CalendarUtil.getMonthDaysCount(2020, 4));
        assertEquals(28, CalendarUtil.getMonthDaysCount(2019, 2));
        assertEquals(28, CalendarUtil.getMonthDaysCount(2100, 2));
    }

    @Test
    public void test_getMonthViewLineCount() {
        assertEquals(6, CalendarUtil.getMonthViewLineCount(2020, 3, Calendar.SUNDAY, CalendarConstants.MONTH_SHOW_MODE_ALL));
        assertEquals(6, CalendarUtil.getMonthViewLineCount(2020, 3, Calendar.MONDAY, CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT));
        assertEquals(5, CalendarUtil.getMonthViewLineCount(2020, 3, Calendar.SUNDAY, CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT));
    }

    @Test
    public void test_getWeekFromDayInMonth() {
        assertEquals(2, CalendarUtil.getWeekFromDayInMonth(new CalendarBean(2020, 3, 12), Calendar.SUNDAY));
        assertEquals(3, CalendarUtil.getWeekFromDayInMonth(new CalendarBean(2020, 3, 12), Calendar.MONDAY));
        assertEquals(2, CalendarUtil.getWeekFromDayInMonth(new CalendarBean(2020, 3, 12), Calendar.SATURDAY));
    }

    @Test
    public void test_getMonthViewStartOffset() {
        assertEquals(0, CalendarUtil.getMonthViewStartOffset(2020, 3, Calendar.SUNDAY));
        assertEquals(6, CalendarUtil.getMonthViewStartOffset(2020, 3, Calendar.MONDAY));
        assertEquals(1, CalendarUtil.getMonthViewStartOffset(2020, 3, Calendar.SATURDAY));
    }

    @Test
    public void test_getMonthEndOffset() {
        assertEquals(4, CalendarUtil.getMonthEndOffset(2020, 3, Calendar.SUNDAY));
        assertEquals(5, CalendarUtil.getMonthEndOffset(2020, 3, Calendar.MONDAY));
        assertEquals(3, CalendarUtil.getMonthEndOffset(2020, 3, Calendar.SATURDAY));
    }

    @Test
    public void test_getWeekFormCalendar() {
        assertEquals(Calendar.THURSDAY, CalendarUtil.getWeekFormCalendar(new CalendarBean(2020, 3, 12)));
    }

    @Test
    public void test_getWeekCountBetweenBothCalendar() {
        assertEquals(2, CalendarUtil.getWeekCountBetweenBothCalendar(2020, 3, 1,
                2020, 3, 12, Calendar.SUNDAY));
        assertEquals(3, CalendarUtil.getWeekCountBetweenBothCalendar(2020, 3, 1,
                2020, 3, 12, Calendar.MONDAY));
    }

    @Test
    public void test_getFirstCalendarStartWithMinCalendar() {
        assertEquals(new CalendarBean(2020, 3, 9), CalendarUtil.getFirstCalendarStartWithMinCalendar(2020, 3, 1, 3, Calendar.MONDAY));
        assertEquals(new CalendarBean(2020, 3, 15), CalendarUtil.getFirstCalendarStartWithMinCalendar(2020, 3, 1, 3, Calendar.SUNDAY));
    }

    @Test
    public void test_differ() {
        assertEquals(3, CalendarUtil.differ(new CalendarBean(2020, 3, 15), new CalendarBean(2020, 3, 12)));
        assertEquals(71, CalendarUtil.differ(new CalendarBean(2020, 3, 12), new CalendarBean(2020, 1, 1)));
    }

}