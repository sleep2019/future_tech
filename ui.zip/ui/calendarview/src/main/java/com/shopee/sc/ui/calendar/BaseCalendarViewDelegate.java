package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;

import androidx.annotation.Nullable;

import java.lang.reflect.Constructor;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Google规范化的属性委托
 * <p>
 * Created by honggang.xiong on 2020-03-12.
 */
public abstract class BaseCalendarViewDelegate implements CalendarView.ICalendarViewDelegate {

    static final String TAG = "CalendarViewDelegate";
    /**
     * String for parsing dates.
     */
    private static final String DATE_FORMAT = "yyyyMMdd";

    /**
     * Date format for parsing dates.
     */
    private final DateFormat DATE_FORMATTER = new SimpleDateFormat(DATE_FORMAT, Locale.US);

    /* 通用属性 */
    protected CalendarView mDelegator;
    protected Context mContext;

    /**
     * 最小日历和最大日历
     */
    protected CalendarBean mMinDate = new CalendarBean(CalendarConstants.MIN_YEAR, 1, 1);
    protected CalendarBean mMaxDate = new CalendarBean(CalendarConstants.MAX_YEAR, 12, 31);

    /**
     * The first day of the week (ex. Calendar.SUNDAY) indexed from one.
     */
    @CalendarConstants.WeekStart
    protected int mWeekStart;
    @CalendarConstants.MonthShowMode
    protected int mMonthViewShowMode;
    @CalendarConstants.SelectMode
    protected int mSelectMode;
    @CalendarConstants.AutoFocusMode
    protected int mCalendarAutoSelectMode;

    protected int mMultiSelectMaxSize;
    protected int mRangeSelectMinSize = -1;
    protected int mRangeSelectMaxSize = -1;

    /**
     * 是否是全屏日历
     */
    private boolean mIsFullScreenCalendar;

    /**
     * 星期栏
     */
    WeekBar mWeekBar;

    /**
     * 星期栏的背景、线的背景
     */
    private int mWeekBackground, mWeekLineBackground;

    /**
     * 星期栏Line margin
     */
    private int mWeekLineMargin;

    /**
     * 星期栏字体大小
     */
    private int mWeekTextSize;

    /**
     * 星期栏的高度
     */
    private int mWeekBarHeight;


    /**
     * 标记文本
     */
    private String mSchemeText;

    /**
     * 日历卡的项高度
     */
    private int mCalendarItemHeight;

    /**
     * 日历 Month/Week View padding
     */
    private int mMonthWeekPaddingStart,
            mMonthWeekPaddingTop,
            mMonthWeekPaddingEnd,
            mMonthWeekPaddingBottom;

    /**
     * 日期和节日文本大小
     */
    private int mDayTextSize, mFestivalTextSize;

    /**
     * 各种字体颜色，看名字知道对应的地方
     */
    private int mWeekTextColor,
            mSelectedTextColor,
            mSelectedFestivalTextColor,
            mCurDayTextColor,
            mCurDayFestivalTextColor,
            mSchemeTextColor,
            mSchemeFestivalTextColor,
            mCurMonthTextColor,
            mCurMonthFestivalTextColor,
            mOtherMonthTextColor,
            mOtherMonthFestivalTextColor;

    /**
     * 标记的主题色和选中的主题色
     */
    private int mSchemeThemeColor, mSelectedThemeColor;

    private boolean mPreventLongPressedSelected;


    /**
     * 年视图背景
     */
    private int mYearViewBackground;

    /**
     * 年视图月份高度和周的高度
     */
    private int mYearViewMonthHeight,
            mYearViewWeekHeight;

    /**
     * 年视图一些margin和padding
     */
    private int mYearViewPadding,
            mYearViewMonthMarginTop,
            mYearViewMonthMarginBottom;

    /**
     * 年视图字体大小
     */
    private int mYearViewMonthTextSize, mYearViewWeekTextSize, mYearViewDayTextSize;

    /**
     * 年视图字体和标记颜色
     */
    private int mYearViewMonthTextColor,
            mYearViewWeekTextColor,
            mYearViewSelectTextColor,
            mYearViewCurDayTextColor,
            mYearViewSchemeTextColor,
            mYearViewDayTextColor;

    /**
     * 日期拦截事件
     */
    CalendarView.OnCalendarInterceptListener mCalendarInterceptListener;

    /**
     * 日期选中监听
     */
    CalendarView.OnCalendarSelectListener mCalendarSelectListener;

    /**
     * 范围选择
     */
    private CalendarView.OnCalendarRangeSelectListener mCalendarRangeSelectListener;

    /**
     * 多选选择事件
     */
    private CalendarView.OnCalendarMultiSelectListener mCalendarMultiSelectListener;

    /**
     * 外部日期长按事件
     */
    CalendarView.OnCalendarLongClickListener mCalendarLongClickListener;

    /**
     * 内部日期切换监听，用于内部更新计算
     */
    CalendarView.OnInnerDateSelectedListener mInnerListener;

    /**
     * 快速年份切换
     */
    CalendarView.OnYearChangeListener mYearChangeListener;

    /**
     * 月份切换事件
     */
    CalendarView.OnMonthChangeListener mMonthChangeListener;

    /**
     * 周视图改变事件
     */
    CalendarView.OnWeekChangeListener mWeekChangeListener;

    /**
     * 视图改变事件
     */
    CalendarView.OnViewChangeListener mViewChangeListener;

    /**
     * 年视图改变事件
     */
    CalendarView.OnYearViewChangeListener mYearViewChangeListener;


    /**
     * 今天的日期
     */
    private CalendarBean mCurrentDate;

    /**
     * 保存选中的日期
     */
    CalendarBean mSelectedCalendar;

    /**
     * 保存标记位置
     */
    CalendarBean mIndexCalendar;

    /**
     * 当前月份视图的 item 位置
     */
    int mCurrentMonthViewItem;

    /**
     * 标记的日期,数量巨大，请使用这个
     */
    final Map<String, CalendarBean> mSchemeDatesMap = new HashMap<>();

    /**
     * 多选日历
     */
    final Map<String, CalendarBean> mMultiSelectCalendars = new HashMap<>();

    /**
     * 选择范围日历
     */
    CalendarBean mRangeSelectStartCalendar, mRangeSelectEndCalendar;

    BaseMonthWeekPainter mMonthWeekPainter;
    BaseYearViewPainter mYearViewPainter;

    public BaseCalendarViewDelegate(CalendarView delegator, Context context, @Nullable AttributeSet attrs) {
        CalendarUtil.initIfNeeded(context);

        mDelegator = delegator;
        mContext = context;
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.CalendarView);

        mWeekStart = array.getInt(R.styleable.CalendarView_week_start_with, CalendarConstants.WEEK_START_SUN);
        mMonthViewShowMode = array.getInt(R.styleable.CalendarView_month_view_show_mode, CalendarConstants.MONTH_SHOW_MODE_ALL);
        int selectMode = array.getInt(R.styleable.CalendarView_select_mode, CalendarConstants.SELECT_MODE_AUTO);
        mCalendarAutoSelectMode = array.getInt(R.styleable.CalendarView_auto_focus_mode, CalendarConstants.AUTO_FOCUS_MODE_FIRST_DAY_OF_MONTH);
        mMultiSelectMaxSize = array.getInt(R.styleable.CalendarView_multi_select_max_size, Integer.MAX_VALUE);
        setSelectMode(selectMode);
        int rangeSelectMinSize = array.getInt(R.styleable.CalendarView_range_select_min_size, -1);
        int rangeSelectMaxSize = array.getInt(R.styleable.CalendarView_range_select_max_size, -1);
        setRangeSelectSize(rangeSelectMinSize, rangeSelectMaxSize);

        mIsFullScreenCalendar = array.getBoolean(R.styleable.CalendarView_calendar_match_parent, false);

        mWeekBackground = array.getColor(R.styleable.CalendarView_week_background, Color.WHITE);
        mWeekLineBackground = array.getColor(R.styleable.CalendarView_week_line_background, Color.TRANSPARENT);
        mWeekTextColor = array.getColor(R.styleable.CalendarView_week_text_color, 0xFF333333);
        mWeekTextSize = array.getDimensionPixelSize(R.styleable.CalendarView_week_text_size,
                CalendarUtil.dp2px(context, 12));
        mWeekBarHeight = (int) array.getDimension(R.styleable.CalendarView_week_bar_height,
                CalendarUtil.dp2px(context, 40));
        mWeekLineMargin = (int) array.getDimension(R.styleable.CalendarView_week_line_margin, 0);

        mSchemeText = array.getString(R.styleable.CalendarView_scheme_text);
        if (TextUtils.isEmpty(mSchemeText)) {
            mSchemeText = "-";
        }
        mCalendarItemHeight = array.getDimensionPixelSize(R.styleable.CalendarView_calendar_item_height,
                CalendarUtil.dp2px(context, 56));
        int defaultMonthWeekPadding = 0;
        mMonthWeekPaddingStart = array.getDimensionPixelSize(R.styleable.CalendarView_month_week_padding_start, defaultMonthWeekPadding);
        mMonthWeekPaddingTop = array.getDimensionPixelSize(R.styleable.CalendarView_month_week_padding_top, defaultMonthWeekPadding);
        mMonthWeekPaddingEnd = array.getDimensionPixelSize(R.styleable.CalendarView_month_week_padding_end, defaultMonthWeekPadding);
        mMonthWeekPaddingBottom = array.getDimensionPixelSize(R.styleable.CalendarView_month_week_padding_bottom, defaultMonthWeekPadding);
        mDayTextSize = array.getDimensionPixelSize(R.styleable.CalendarView_day_text_size,
                CalendarUtil.dp2px(context, 16));
        mFestivalTextSize = array.getDimensionPixelSize(R.styleable.CalendarView_festival_text_size,
                CalendarUtil.dp2px(context, 10));

        mSelectedThemeColor = array.getColor(R.styleable.CalendarView_selected_theme_color, 0x50CFCFCF);
        mSelectedTextColor = array.getColor(R.styleable.CalendarView_selected_text_color, 0xFF111111);
        mSelectedFestivalTextColor = array.getColor(R.styleable.CalendarView_selected_festival_text_color, 0xFF111111);
        mSchemeTextColor = array.getColor(R.styleable.CalendarView_scheme_text_color, 0xFFFFFFFF);
        mSchemeFestivalTextColor = array.getColor(R.styleable.CalendarView_scheme_festival_text_color, 0xFFe1e1e1);
        mSchemeThemeColor = array.getColor(R.styleable.CalendarView_scheme_theme_color, 0x50CFCFCF);
        mCurDayTextColor = array.getColor(R.styleable.CalendarView_current_day_text_color, Color.RED);
        mCurDayFestivalTextColor = array.getColor(R.styleable.CalendarView_current_day_festival_text_color, Color.RED);
        mCurMonthTextColor = array.getColor(R.styleable.CalendarView_current_month_text_color, 0xFF111111);
        mCurMonthFestivalTextColor = array.getColor(R.styleable.CalendarView_current_month_festival_text_color, 0xffe1e1e1);
        mOtherMonthTextColor = array.getColor(R.styleable.CalendarView_other_month_text_color, 0xFFe1e1e1);
        mOtherMonthFestivalTextColor = array.getColor(R.styleable.CalendarView_other_month_festival_text_color, 0xffe1e1e1);

        // 年视图相关
        mYearViewBackground = array.getColor(R.styleable.CalendarView_year_view_background, Color.WHITE);
        mYearViewMonthHeight = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_month_height,
                CalendarUtil.dp2px(context, 32));
        mYearViewWeekHeight = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_week_height,
                CalendarUtil.dp2px(context, 0));
        mYearViewPadding = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_padding,
                CalendarUtil.dp2px(context, 6));
        mYearViewMonthMarginTop = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_month_margin_top,
                CalendarUtil.dp2px(context, 4));
        mYearViewMonthMarginBottom = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_month_margin_bottom,
                CalendarUtil.dp2px(context, 4));
        mYearViewMonthTextSize = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_month_text_size,
                CalendarUtil.sp2px(context, 18));
        mYearViewWeekTextSize = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_week_text_size,
                CalendarUtil.sp2px(context, 8));
        mYearViewDayTextSize = array.getDimensionPixelSize(R.styleable.CalendarView_year_view_day_text_size,
                CalendarUtil.sp2px(context, 7));
        mYearViewMonthTextColor = array.getColor(R.styleable.CalendarView_year_view_month_text_color, 0xFF111111);
        mYearViewWeekTextColor = array.getColor(R.styleable.CalendarView_year_view_week_text_color, 0xFF333333);
        mYearViewSelectTextColor = array.getColor(R.styleable.CalendarView_year_view_select_text_color, 0xFF333333);
        mYearViewCurDayTextColor = array.getColor(R.styleable.CalendarView_year_view_current_day_text_color, getCurDayTextColor());
        mYearViewSchemeTextColor = array.getColor(R.styleable.CalendarView_year_view_scheme_color, getSchemeThemeColor());
        mYearViewDayTextColor = array.getColor(R.styleable.CalendarView_year_view_day_text_color, 0xFF111111);

        final String minDate = array.getString(R.styleable.CalendarView_min_date);
        final String maxDate = array.getString(R.styleable.CalendarView_max_date);
        array.recycle();

        mCurrentDate = new CalendarBean(Calendar.getInstance());
        mCurrentDate.setupCalendar();

        final Calendar tempDate = Calendar.getInstance();
        if (!parseDate(minDate, tempDate)) {
            tempDate.set(CalendarConstants.MIN_YEAR, Calendar.JANUARY, 1);
        }
        CalendarBean min = new CalendarBean(tempDate);
        if (!parseDate(maxDate, tempDate)) {
            tempDate.set(CalendarConstants.MAX_YEAR, Calendar.DECEMBER, 31);
        }
        CalendarBean max = new CalendarBean(tempDate);
        if (min.getYear() < CalendarConstants.MIN_YEAR) {
            min = new CalendarBean(CalendarConstants.MIN_YEAR, 1, 1);
        }
        if (max.getYear() > CalendarConstants.MAX_YEAR) {
            max = new CalendarBean(CalendarConstants.MAX_YEAR, 12, 31);
        }
        setRange(min, max);

        initCustomObjects(context, attrs);
    }

    private void initCustomObjects(Context context, @Nullable AttributeSet attrs) {
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.CalendarView);
        String weekBarClassPath = array.getString(R.styleable.CalendarView_week_bar_view);
        String monthWeekPainterClassPath = array.getString(R.styleable.CalendarView_month_week_painter);
        String yearViewPainterClassPath = array.getString(R.styleable.CalendarView_year_view_painter);
        array.recycle();

        try {
            final Class<?> clazz = TextUtils.isEmpty(weekBarClassPath)
                    ? WeekBar.class : Class.forName(weekBarClassPath);
            Constructor<?> constructor = clazz.getConstructor(Context.class);
            mWeekBar = (WeekBar) constructor.newInstance(context);
        } catch (Exception e) {
            Log.w(TAG, "init mWeekBar error: ", e);
            mWeekBar = new WeekBar(context);
        }

        try {
            final Class<?> clazz = TextUtils.isEmpty(monthWeekPainterClassPath)
                    ? DefaultMonthWeekPainter.class : Class.forName(monthWeekPainterClassPath);
            Constructor<?> constructor = clazz.getConstructor(Context.class);
            constructor.setAccessible(true);
            mMonthWeekPainter = (BaseMonthWeekPainter) constructor.newInstance(context);
        } catch (Exception e) {
            Log.w(TAG, "init mMonthWeekPainter error: ", e);
            mMonthWeekPainter = new DefaultMonthWeekPainter(context);
        }
        mMonthWeekPainter.setDelegate(this);

        try {
            final Class<?> clazz = TextUtils.isEmpty(yearViewPainterClassPath)
                    ? DefaultYearViewPainter.class : Class.forName(yearViewPainterClassPath);
            Constructor<?> constructor = clazz.getConstructor(Context.class);
            constructor.setAccessible(true);
            mYearViewPainter = (BaseYearViewPainter) constructor.newInstance(context);
        } catch (Exception e) {
            Log.w(TAG, "init mYearViewPainter error: ", e);
            mYearViewPainter = new DefaultYearViewPainter(context);
        }
        mYearViewPainter.setDelegate(this);
    }

    /**
     * 设置颜色，多选变化时调用该方法
     */
    protected abstract void updateStyle();

    /**
     * 更新scheme时调用该方法
     */
    protected abstract void updateScheme();

    /**
     * 更新界面，重新创建 View
     */
    protected abstract void clearAndRefreshView();

    @Override
    public CalendarBean getMinDate() {
        return mMinDate;
    }

    @Override
    public CalendarBean getMaxDate() {
        return mMaxDate;
    }

    int getMinYear() {
        return mMinDate.getYear();
    }

    int getMaxYear() {
        return mMaxDate.getYear();
    }

    int getMinYearMonth() {
        return mMinDate.getMonth();
    }

    int getMaxYearMonth() {
        return mMaxDate.getMonth();
    }

    int getMinYearDay() {
        return mMinDate.getDay();
    }

    int getMaxYearDay() {
        return mMaxDate.getDay();
    }

    @Override
    public void setRange(CalendarBean minDate, CalendarBean maxDate) {
        if (!minDate.isValid() || !maxDate.isValid() || minDate.compareTo(maxDate) > 0) {
            Log.w(TAG, "setRange get wrong date min=" + minDate + ", max=" + maxDate);
            return;
        }

        mMinDate = minDate;
        mMinDate.setupCalendar();
        mMaxDate = maxDate;
        mMaxDate.setupCalendar();
        int y = mCurrentDate.getYear() - mMinDate.getYear();
        mCurrentMonthViewItem = 12 * y + mCurrentDate.getMonth() - mMinDate.getMonth();
    }

    @Override
    public int getWeekStart() {
        return mWeekStart;
    }

    @Override
    public void setWeekStart(@CalendarConstants.WeekStart int weekStart) {
        if (weekStart == mWeekStart) {
            return;
        }
        if (!CalendarUtil.isValidDayOfWeek(weekStart)) {
            return;
        }
        mWeekStart = weekStart;
    }

    @Override
    public int getMonthViewShowMode() {
        return mMonthViewShowMode;
    }

    @Override
    public void setMonthShowMode(@CalendarConstants.MonthShowMode int monthViewShowMode) {
        if (mMonthViewShowMode == monthViewShowMode) {
            return;
        }
        if (monthViewShowMode != CalendarConstants.MONTH_SHOW_MODE_ALL &&
                monthViewShowMode != CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT &&
                monthViewShowMode != CalendarConstants.MONTH_SHOW_MODE_AUTO_FIT) {
            return;
        }
        mMonthViewShowMode = monthViewShowMode;
    }

    @CalendarConstants.SelectMode
    @Override
    public int getSelectMode() {
        return mSelectMode;
    }

    @Override
    public void setSelectMode(@CalendarConstants.SelectMode int selectMode) {
        if (mSelectMode == selectMode) {
            return;
        }
        mSelectMode = selectMode;
        if (mSelectMode == CalendarConstants.SELECT_MODE_AUTO) {
            mSelectedCalendar = mIndexCalendar;
        } else if (mSelectMode == CalendarConstants.SELECT_MODE_RANGE) {
            clearRangeSelect();
        } else if (mSelectMode == CalendarConstants.SELECT_MODE_MULTI) {
            clearMultiSelect();
        }
        clearAndRefreshView();
    }

    @CalendarConstants.AutoFocusMode
    @Override
    public int getCalendarAutoSelectMode() {
        return mCalendarAutoSelectMode;
    }

    @Override
    public void setCalendarAutoSelectMode(@CalendarConstants.AutoFocusMode int defaultCalendarSelect) {
        mCalendarAutoSelectMode = defaultCalendarSelect;
    }

    public int getMultiSelectMaxSize() {
        return mMultiSelectMaxSize;
    }

    public void setMultiSelectMaxSize(int multiSelectMaxSize) {
        mMultiSelectMaxSize = multiSelectMaxSize;
    }

    @Override
    public void putMultiSelect(CalendarBean... calendarBeans) {
        if (calendarBeans == null || calendarBeans.length == 0) {
            return;
        }
        for (CalendarBean bean : calendarBeans) {
            if (bean != null) {
                mMultiSelectCalendars.put(bean.toString(), bean);
            }
        }
        updateStyle();
    }

    @Override
    public void removeMultiSelect(CalendarBean... calendarBeans) {
        if (calendarBeans == null || calendarBeans.length == 0) {
            return;
        }
        for (CalendarBean bean : calendarBeans) {
            if (bean != null) {
                mMultiSelectCalendars.remove(bean.toString());
            }
        }
        updateStyle();
    }

    @Override
    public List<CalendarBean> getMultiSelectCalendars() {
        List<CalendarBean> calendars = new ArrayList<>();
        if (mMultiSelectCalendars.size() == 0) {
            return calendars;
        }
        calendars.addAll(mMultiSelectCalendars.values());
        Collections.sort(calendars);
        return calendars;
    }

    public int getRangeSelectMinSize() {
        return mRangeSelectMinSize;
    }

    public int getRangeSelectMaxSize() {
        return mRangeSelectMaxSize;
    }

    public final void setRangeSelectSize(int minSize, int maxSize) {
        if (minSize > maxSize && maxSize > 0) {
            mRangeSelectMaxSize = minSize;
            mRangeSelectMinSize = minSize;
            return;
        }
        if (minSize <= 0) {
            mRangeSelectMinSize = -1;
        } else {
            mRangeSelectMinSize = minSize;
        }
        if (maxSize <= 0) {
            mRangeSelectMaxSize = -1;
        } else {
            mRangeSelectMaxSize = maxSize;
        }
    }

    @Override
    public void setRangeSelectStartCalendar(CalendarBean startCalendar) {
        if (mSelectMode != CalendarConstants.SELECT_MODE_RANGE) {
            return;
        }
        if (startCalendar == null) {
            return;
        }
        if (!isInRange(startCalendar)) {
            if (mCalendarRangeSelectListener != null) {
                mCalendarRangeSelectListener.onSelectOutOfRange(startCalendar, true);
            }
            return;
        }
        if (isCalendarIntercepted(startCalendar)) {
            mCalendarInterceptListener.onCalendarInterceptClick(startCalendar, false);
            return;
        }
        mRangeSelectEndCalendar = null;
        mRangeSelectStartCalendar = startCalendar;
        scrollToCalendar(startCalendar.getYear(), startCalendar.getMonth(), startCalendar.getDay(), false, true);
    }

    @Override
    public void setRangeSelectEndCalendar(CalendarBean endCalendar) {
        if (mSelectMode != CalendarConstants.SELECT_MODE_RANGE) {
            return;
        }
        if (mRangeSelectStartCalendar == null) {
            return;
        }
        setRangeSelectCalendar(mRangeSelectStartCalendar, endCalendar);
    }

    @Override
    public void setRangeSelectCalendar(CalendarBean startCalendar, CalendarBean endCalendar) {
        if (mSelectMode != CalendarConstants.SELECT_MODE_RANGE) {
            return;
        }
        if (startCalendar == null || endCalendar == null) {
            return;
        }
        if (isCalendarIntercepted(startCalendar)) {
            mCalendarInterceptListener.onCalendarInterceptClick(startCalendar, false);
            return;
        }
        if (isCalendarIntercepted(endCalendar)) {
            mCalendarInterceptListener.onCalendarInterceptClick(endCalendar, false);
            return;
        }
        int minDiffer = endCalendar.differ(startCalendar);
        if (minDiffer < 0) {
            return;
        }
        if (!isInRange(startCalendar) || !isInRange(endCalendar)) {
            return;
        }

        //优先判断各种直接return的情况，减少代码深度
        if (getRangeSelectMinSize() != -1 && getRangeSelectMinSize() > minDiffer + 1) {
            if (mCalendarRangeSelectListener != null) {
                mCalendarRangeSelectListener.onSelectOutOfRange(endCalendar, true);
            }
            return;
        } else if (getRangeSelectMaxSize() != -1 && getRangeSelectMaxSize() <
                minDiffer + 1) {
            if (mCalendarRangeSelectListener != null) {
                mCalendarRangeSelectListener.onSelectOutOfRange(endCalendar, false);
            }
            return;
        }
        if (getRangeSelectMinSize() == -1 && minDiffer == 0) {
            mRangeSelectStartCalendar = startCalendar;
            mRangeSelectEndCalendar = null;
            if (mCalendarRangeSelectListener != null) {
                mCalendarRangeSelectListener.onCalendarRangeSelect(startCalendar, false);
            }
            scrollToCalendar(startCalendar.getYear(), startCalendar.getMonth(), startCalendar.getDay(), false, true);
            return;
        }

        mRangeSelectStartCalendar = startCalendar;
        mRangeSelectEndCalendar = endCalendar;
        if (mCalendarRangeSelectListener != null) {
            mCalendarRangeSelectListener.onCalendarRangeSelect(startCalendar, false);
            mCalendarRangeSelectListener.onCalendarRangeSelect(endCalendar, true);
        }
        scrollToCalendar(startCalendar.getYear(), startCalendar.getMonth(), startCalendar.getDay(), false, true);
    }

    public final List<CalendarBean> getRangeSelectCalendars() {
        List<CalendarBean> result = new ArrayList<>();
        if (mSelectMode != CalendarConstants.SELECT_MODE_RANGE) {
            return result;
        }
        if (mRangeSelectStartCalendar == null || mRangeSelectEndCalendar == null) {
            return result;
        }

        Calendar calendar = mRangeSelectStartCalendar.newCalendar();
        long startTimeMills = calendar.getTimeInMillis();//获得起始时间戳
        calendar.set(mRangeSelectEndCalendar.getYear(),
                mRangeSelectEndCalendar.getMonth() - 1,
                mRangeSelectEndCalendar.getDay());
        long endTimeMills = calendar.getTimeInMillis();

        for (long timeMills = startTimeMills; timeMills <= endTimeMills; timeMills += CalendarConstants.ONE_DAY_MILLIS) {
            calendar.setTimeInMillis(timeMills);
            CalendarBean calendarBean = new CalendarBean(calendar);
            if (isCalendarIntercepted(calendarBean)) {
                continue;
            }

            calendarBean.setupCalendar();
            updateCalendarScheme(calendarBean);
            result.add(calendarBean);
        }
        addSchemesFromMap(result);
        return result;
    }

    /**
     * 日历是否被选中
     */
    protected boolean isCalendarSelected(CalendarBean bean) {
        switch (mSelectMode) {
            case CalendarConstants.SELECT_MODE_MULTI:
                return !isCalendarIntercepted(bean) && mMultiSelectCalendars.containsKey(bean.toString());
            case CalendarConstants.SELECT_MODE_RANGE:
                if (isCalendarIntercepted(bean)) {
                    return false;
                }
                if (mRangeSelectStartCalendar == null) {
                    return false;
                }
                if (mRangeSelectEndCalendar == null) {
                    return bean.compareTo(mRangeSelectStartCalendar) == 0;
                }
                return bean.compareTo(mRangeSelectStartCalendar) >= 0 && bean.compareTo(mRangeSelectEndCalendar) <= 0;
            case CalendarConstants.SELECT_MODE_AUTO:
            case CalendarConstants.SELECT_MODE_SINGLE:
                return bean.equals(mSelectedCalendar);
        }
        return false;
    }

    protected void notifyClickOutOfRange(CalendarBean bean) {
        switch (mSelectMode) {
            case CalendarConstants.SELECT_MODE_MULTI:
                if (mCalendarMultiSelectListener != null) {
                    mCalendarMultiSelectListener.onCalendarMultiSelectOutOfRange(bean);
                }
                break;
            case CalendarConstants.SELECT_MODE_RANGE:
                if (mCalendarRangeSelectListener != null) {
                    mCalendarRangeSelectListener.onCalendarSelectOutOfRange(bean);
                }
                break;
            case CalendarConstants.SELECT_MODE_AUTO:
            case CalendarConstants.SELECT_MODE_SINGLE:
                if (mCalendarSelectListener != null) {
                    mCalendarSelectListener.onCalendarOutOfRange(bean);
                }
                break;
        }
    }

    // return false if put failed
    protected boolean toggleSelectFromClick(CalendarBean bean) {
        switch (mSelectMode) {
            case CalendarConstants.SELECT_MODE_MULTI:
                String key = bean.toString();
                if (mMultiSelectCalendars.containsKey(key)) {
                    mMultiSelectCalendars.remove(key);
                } else {
                    if (mMultiSelectCalendars.size() >= getMultiSelectMaxSize()) {
                        if (mCalendarMultiSelectListener != null) {
                            mCalendarMultiSelectListener.onMultiSelectOutOfSize(bean, getMultiSelectMaxSize());
                        }
                        return false;
                    }
                    mMultiSelectCalendars.put(key, bean);
                }
                return true;
            case CalendarConstants.SELECT_MODE_RANGE:
                if (mRangeSelectStartCalendar != null && mRangeSelectEndCalendar == null) {
                    int minDiffer = CalendarUtil.differ(bean, mRangeSelectStartCalendar);
                    if (minDiffer >= 0 && getRangeSelectMinSize() != -1 && getRangeSelectMinSize() > minDiffer + 1) {
                        if (mCalendarRangeSelectListener != null) {
                            mCalendarRangeSelectListener.onSelectOutOfRange(bean, true);
                        }
                        return false;
                    } else if (getRangeSelectMaxSize() != -1 && getRangeSelectMaxSize() < minDiffer + 1) {
                        if (mCalendarRangeSelectListener != null) {
                            mCalendarRangeSelectListener.onSelectOutOfRange(bean, false);
                        }
                        return false;
                    }
                }

                if (mRangeSelectStartCalendar == null || mRangeSelectEndCalendar != null) {
                    mRangeSelectStartCalendar = bean;
                    mRangeSelectEndCalendar = null;
                } else {
                    int compare = bean.compareTo(mRangeSelectStartCalendar);
                    if (getRangeSelectMinSize() == -1 && compare <= 0) {
                        mRangeSelectStartCalendar = bean;
                        mRangeSelectEndCalendar = null;
                    } else if (compare < 0) {
                        mRangeSelectStartCalendar = bean;
                        mRangeSelectEndCalendar = null;
                    } else if (compare == 0 && getRangeSelectMinSize() == 1) {
                        mRangeSelectEndCalendar = bean;
                    } else {
                        mRangeSelectEndCalendar = bean;
                    }
                }
                return true;
            case CalendarConstants.SELECT_MODE_AUTO:
            case CalendarConstants.SELECT_MODE_SINGLE:
            default:
                return true;
        }
    }

    protected void notifyNewSelectFromClick(CalendarBean bean) {
        switch (mSelectMode) {
            case CalendarConstants.SELECT_MODE_MULTI:
                if (mCalendarMultiSelectListener != null) {
                    mCalendarMultiSelectListener.onCalendarMultiSelect(bean,
                            mMultiSelectCalendars.size(),
                            getMultiSelectMaxSize());
                }
                break;
            case CalendarConstants.SELECT_MODE_RANGE:
                if (mCalendarRangeSelectListener != null) {
                    mCalendarRangeSelectListener.onCalendarRangeSelect(bean, mRangeSelectEndCalendar != null);
                }
                break;
            case CalendarConstants.SELECT_MODE_AUTO:
            case CalendarConstants.SELECT_MODE_SINGLE:
                if (mCalendarSelectListener != null) {
                    mCalendarSelectListener.onCalendarSelect(bean, true);
                }
                break;
        }
    }

    public CalendarBean getCurrentDay() {
        return mCurrentDate;
    }

    public void updateCurrentDay() {
        CalendarBean curDay = new CalendarBean(Calendar.getInstance());
        if (curDay.equals(mCurrentDate)) {
            return;
        }
        mCurrentDate = curDay;
        mCurrentDate.setupCalendar();
        updateStyle();
    }

    @Override
    public CalendarBean getSelectedCalendar() {
        return mSelectedCalendar;
    }

    @Override
    public CalendarBean getIndexCalendar() {
        return mIndexCalendar;
    }

    @Override
    public void restoreCalendarBean(CalendarBean selectedBean, CalendarBean indexBean) {
        mSelectedCalendar = selectedBean;
        mIndexCalendar = indexBean;
        if (mSelectedCalendar != null && mCalendarSelectListener != null) {
            mCalendarSelectListener.onCalendarSelect(mSelectedCalendar, false);
        }
        if (mIndexCalendar != null) {
            scrollToCalendar(mIndexCalendar.getYear(),
                    mIndexCalendar.getMonth(),
                    mIndexCalendar.getDay(), false, true);
        }
        clearAndRefreshView();
    }

    public boolean isFullScreenCalendar() {
        return mIsFullScreenCalendar;
    }

    @Override
    public String getSchemeText() {
        return mSchemeText;
    }

    @Override
    public void setSchemeText(String text) {
        mSchemeText = text;
        updateStyle();
    }

    @Override
    public void setSchemeDate(Map<String, CalendarBean> schemeMap) {
        mSchemeDatesMap.clear();
        addSchemeDate(schemeMap);
    }

    @Override
    public void clearSchemeDate() {
        mSchemeDatesMap.clear();
        clearSelectedScheme();
        updateScheme();
    }

    @Override
    public void addSchemeDate(CalendarBean bean) {
        if (bean == null || !bean.isAvailable()) {
            return;
        }
        mSchemeDatesMap.put(bean.toString(), bean);
        updateSelectCalendarScheme();
        updateScheme();
    }

    @Override
    public void addSchemeDate(Map<String, CalendarBean> schemeMap) {
        if (schemeMap == null || schemeMap.size() == 0) {
            return;
        }
        mSchemeDatesMap.putAll(schemeMap);
        updateSelectCalendarScheme();
        updateScheme();
    }

    @Override
    public void removeSchemeDate(CalendarBean bean) {
        if (bean == null) {
            return;
        }
        mSchemeDatesMap.remove(bean.toString());
        if (mSelectedCalendar.equals(bean)) {
            clearSelectedScheme();
        }
        updateScheme();
    }

    final void updateSelectCalendarScheme() {
        updateCalendarScheme(mSelectedCalendar);
    }

    @Override
    public final void updateCalendarScheme(CalendarBean targetCalendar) {
        if (targetCalendar == null) {
            return;
        }
        CalendarBean schemeBean = mSchemeDatesMap.get(targetCalendar.toString());
        if (schemeBean != null) {
            targetCalendar.mergeScheme(schemeBean, getSchemeText());
        } else {
            targetCalendar.clearScheme();
        }
    }

    public void clearSelectedScheme() {
        mSelectedCalendar.clearScheme();
    }

    public int getMonthWeekPaddingStart() {
        return mMonthWeekPaddingStart;
    }

    public int getMonthWeekPaddingTop() {
        return mMonthWeekPaddingTop;
    }

    public int getMonthWeekPaddingEnd() {
        return mMonthWeekPaddingEnd;
    }

    public int getMonthWeekPaddingBottom() {
        return mMonthWeekPaddingBottom;
    }

    public void setPreventLongPressedSelected(boolean preventLongPressedSelected) {
        mPreventLongPressedSelected = preventLongPressedSelected;
    }

    public boolean isPreventLongPressedSelected() {
        return mPreventLongPressedSelected;
    }

    @Override
    public BaseMonthWeekPainter getMonthWeekPainter() {
        return mMonthWeekPainter;
    }

    @Override
    public void setMonthWeekPainter(BaseMonthWeekPainter monthWeekPainter) {
        if (monthWeekPainter == null) {
            return;
        }
        mMonthWeekPainter = monthWeekPainter;
        mMonthWeekPainter.setDelegate(this);
        clearAndRefreshView();
    }

    @Override
    public BaseYearViewPainter getYearViewPainter() {
        return mYearViewPainter;
    }

    @Override
    public void setYearViewPainter(BaseYearViewPainter yearViewPainter) {
        if (yearViewPainter == null) {
            return;
        }
        mYearViewPainter = yearViewPainter;
        mYearViewPainter.setDelegate(this);
        clearAndRefreshView();
    }

    public int getCalendarItemHeight() {
        return mCalendarItemHeight;
    }

    public void setCalendarItemHeight(int height) {
        mCalendarItemHeight = height;
    }

    public int getWeekBackground() {
        return mWeekBackground;
    }

    public int getWeekLineBackground() {
        return mWeekLineBackground;
    }

    public int getWeekLineMargin() {
        return mWeekLineMargin;
    }

    public int getWeekBarHeight() {
        return mWeekBarHeight;
    }


    @Override
    public int getWeekTextColor() {
        return mWeekTextColor;
    }

    @Override
    public int getSelectedTextColor() {
        return mSelectedTextColor;
    }

    @Override
    public int getSelectedFestivalTextColor() {
        return mSelectedFestivalTextColor;
    }

    @Override
    public int getCurDayTextColor() {
        return mCurDayTextColor;
    }

    @Override
    public int getCurDayFestivalTextColor() {
        return mCurDayFestivalTextColor;
    }

    @Override
    public int getSchemeTextColor() {
        return mSchemeTextColor;
    }

    @Override
    public int getSchemeFestivalTextColor() {
        return mSchemeFestivalTextColor;
    }

    @Override
    public int getCurMonthTextColor() {
        return mCurMonthTextColor;
    }

    @Override
    public int getCurMonthFestivalTextColor() {
        return mCurMonthFestivalTextColor;
    }

    @Override
    public int getOtherMonthTextColor() {
        return mOtherMonthTextColor;
    }

    @Override
    public int getOtherMonthFestivalTextColor() {
        return mOtherMonthFestivalTextColor;
    }

    @Override
    public int getSelectedThemeColor() {
        return mSelectedThemeColor;
    }

    @Override
    public int getSchemeThemeColor() {
        return mSchemeThemeColor;
    }

    @Override
    public void setTextColor(Integer selectedColor, Integer curDayColor, Integer schemeColor,
                             Integer curMonthColor, Integer otherMonthColor) {
        mSelectedTextColor = selectedColor != null ? selectedColor : mSelectedTextColor;
        mCurDayTextColor = curDayColor != null ? curDayColor : mCurDayTextColor;
        mSchemeTextColor = schemeColor != null ? schemeColor : mSchemeTextColor;
        mCurMonthTextColor = curMonthColor != null ? curMonthColor : mCurMonthTextColor;
        mOtherMonthTextColor = otherMonthColor != null ? otherMonthColor : mOtherMonthTextColor;
        mMonthWeekPainter.updateStyle();
        updateStyle();
    }

    @Override
    public void setFestivalTextColor(Integer selectedColor, Integer curDayColor, Integer schemeColor, Integer curMonthColor, Integer otherMonthColor) {
        mSelectedFestivalTextColor = selectedColor != null ? selectedColor : mSelectedFestivalTextColor;
        mCurDayFestivalTextColor = curDayColor != null ? curDayColor : mCurDayFestivalTextColor;
        mSchemeFestivalTextColor = schemeColor != null ? schemeColor : mSchemeFestivalTextColor;
        mCurMonthFestivalTextColor = curMonthColor != null ? curMonthColor : mCurMonthFestivalTextColor;
        mOtherMonthFestivalTextColor = otherMonthColor != null ? otherMonthColor : mOtherMonthFestivalTextColor;
        mMonthWeekPainter.updateStyle();
        updateStyle();
    }

    @Override
    public void setThemeColor(Integer selectedThemeColor, Integer schemeThemeColor) {
        mSelectedThemeColor = selectedThemeColor != null ? selectedThemeColor : mSelectedThemeColor;
        mSchemeThemeColor = schemeThemeColor != null ? schemeThemeColor : mSchemeThemeColor;
        mMonthWeekPainter.updateStyle();
        updateStyle();
    }

    @Override
    public int getDayTextSize() {
        return mDayTextSize;
    }

    @Override
    public void setDayTextSize(int sizeInPx) {
        mDayTextSize = sizeInPx;
        mMonthWeekPainter.updateStyle();
        updateStyle();
    }

    @Override
    public int getFestivalTextSize() {
        return mFestivalTextSize;
    }

    @Override
    public void setFestivalTextSize(int sizeInPx) {
        mFestivalTextSize = sizeInPx;
        mMonthWeekPainter.updateStyle();
        updateStyle();
    }

    @Override
    public int getWeekTextSize() {
        return mWeekTextSize;
    }

    /**
     * 是否拦截日期，true 代表日期不可选择
     *
     * @param bean CalendarBean
     * @return 是否拦截日期
     */
    protected final boolean isCalendarIntercepted(CalendarBean bean) {
        return mCalendarInterceptListener != null && mCalendarInterceptListener.isCalendarIntercepted(bean);
    }

    /**
     * 添加事件标记，来自Map
     */
    public final void addSchemesFromMap(List<CalendarBean> beanList) {
        if (mSchemeDatesMap.size() == 0 || beanList == null) {
            return;
        }
        for (CalendarBean bean : beanList) {
            updateCalendarScheme(bean);
        }
    }

    @Override
    public void setOnCalendarInterceptListener(CalendarView.OnCalendarInterceptListener listener) {
        if (listener == null) {
            mCalendarInterceptListener = null;
        }
        if (listener == null || mSelectMode == CalendarConstants.SELECT_MODE_AUTO) {
            return;
        }
        mCalendarInterceptListener = listener;
        if (listener.isCalendarIntercepted(mSelectedCalendar)) {
            mSelectedCalendar = new CalendarBean(0, 0, 0);
        }
    }

    /**
     * 是否在日期范围内
     *
     * @param bean CalendarBean
     * @return 是否在日期范围内
     */
    protected final boolean isInRange(CalendarBean bean) {
        return CalendarUtil.isCalendarInRange(bean, this);
    }

    @Override
    public void setOnCalendarSelectListener(CalendarView.OnCalendarSelectListener listener) {
        mCalendarSelectListener = listener;
        if (mCalendarSelectListener == null) {
            return;
        }
        if (mSelectMode != CalendarConstants.SELECT_MODE_AUTO) {
            return;
        }
        if (!isInRange(mSelectedCalendar)) {
            return;
        }
        updateSelectCalendarScheme();
    }

    @Override
    public void setOnCalendarRangeSelectListener(CalendarView.OnCalendarRangeSelectListener listener) {
        mCalendarRangeSelectListener = listener;
    }

    @Override
    public void setOnCalendarMultiSelectListener(CalendarView.OnCalendarMultiSelectListener listener) {
        mCalendarMultiSelectListener = listener;
    }

    @Override
    public void setOnCalendarLongClickListener(CalendarView.OnCalendarLongClickListener listener) {
        mCalendarLongClickListener = listener;
    }

    @Override
    public void setOnYearChangeListener(CalendarView.OnYearChangeListener listener) {
        mYearChangeListener = listener;
    }

    @Override
    public void setOnMonthChangeListener(CalendarView.OnMonthChangeListener listener) {
        mMonthChangeListener = listener;
    }

    @Override
    public void setOnWeekChangeListener(CalendarView.OnWeekChangeListener listener) {
        mWeekChangeListener = listener;
    }

    @Override
    public void setOnViewChangeListener(CalendarView.OnViewChangeListener listener) {
        mViewChangeListener = listener;
    }

    @Override
    public void setOnYearViewChangeListener(CalendarView.OnYearViewChangeListener listener) {
        mYearViewChangeListener = listener;
    }


    @Override
    public boolean isShowYearSelectedLayout() {
        return false;
    }

    @Override
    public int getYearViewBackground() {
        return mYearViewBackground;
    }

    @Override
    public int getYearViewMonthHeight() {
        return mYearViewMonthHeight;
    }

    @Override
    public int getYearViewWeekHeight() {
        return mYearViewWeekHeight;
    }

    @Override
    public int getYearViewPadding() {
        return mYearViewPadding;
    }

    @Override
    public int getYearViewMonthMarginTop() {
        return mYearViewMonthMarginTop;
    }

    @Override
    public int getYearViewMonthMarginBottom() {
        return mYearViewMonthMarginBottom;
    }

    @Override
    public int getYearViewMonthTextSize() {
        return mYearViewMonthTextSize;
    }

    @Override
    public int getYearViewWeekTextSize() {
        return mYearViewWeekTextSize;
    }

    @Override
    public int getYearViewDayTextSize() {
        return mYearViewDayTextSize;
    }

    @Override
    public int getYearViewMonthTextColor() {
        return mYearViewMonthTextColor;
    }

    @Override
    public int getYearViewWeekTextColor() {
        return mYearViewWeekTextColor;
    }

    @Override
    public int getYearViewSelectTextColor() {
        return mYearViewSelectTextColor;
    }

    @Override
    public int getYearViewCurDayTextColor() {
        return mYearViewCurDayTextColor;
    }

    @Override
    public int getYearViewSchemeTextColor() {
        return mYearViewSchemeTextColor;
    }

    @Override
    public int getYearViewDayTextColor() {
        return mYearViewDayTextColor;
    }

    @Override
    public void setYearViewTextColor(int yearViewMonthTextColor, int yearViewDayTextColor, int yarViewSchemeTextColor) {
        mYearViewMonthTextColor = yearViewMonthTextColor;
        mYearViewDayTextColor = yearViewDayTextColor;
        mYearViewSchemeTextColor = yarViewSchemeTextColor;
        updateStyle();
    }


    /**
     * Utility method for the date format used by CalendarView's min/max date.
     */
    boolean parseDate(String date, Calendar outDate) {
        if (date == null || date.isEmpty()) {
            return false;
        }

        try {
            final Date parsedDate = DATE_FORMATTER.parse(date);
            if (parsedDate == null) {
                return false;
            }
            outDate.setTime(parsedDate);
            return true;
        } catch (ParseException e) {
            Log.w(TAG, "Date: " + date + " not in format: " + DATE_FORMAT);
            return false;
        }
    }
}
