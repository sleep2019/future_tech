package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @ClassName: CompatibleRecyclerView
 * @Description: 该RecyclerView同时适用于原生和RN场景中
 * @Author: Lanjing Zeng
 * @CreateDate: 2021/11/25 4:00 PM
 * @Version: 1.0
 */
public class CompatibleRecyclerView extends RecyclerView {
    private boolean useInRn;
    private boolean mRequestedLayout;

    public CompatibleRecyclerView(@NonNull Context context) {
        this(context, null);
    }

    public CompatibleRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CompatibleRecyclerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setUseInRn(boolean useInRn) {
        this.useInRn = useInRn;
    }

    @Override
    public void requestLayout() {
        super.requestLayout();
        if (!useInRn) {
            return;
        }
        // We need to intercept this method because if we don't our children will never update
        // Check https://stackoverflow.com/questions/49371866/recyclerview-wont-update-child-until-i-scroll
        if (mRequestedLayout) {
            return;
        }
        mRequestedLayout = true;
        post(new Runnable() {
            @Override
            public void run() {
                mRequestedLayout = false;
                layout(getLeft(), getTop(), getRight(), getBottom());
                onLayout(false, getLeft(), getTop(), getRight(), getBottom());
            }
        });
    }
}
