package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Created by honggang.xiong on 2020-03-25.
 */
public abstract class BaseYearViewPainter extends BaseMonthWeekPainter {

    /**
     * 月份画笔
     */
    protected Paint mMonthTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 周栏画笔
     */
    protected Paint mWeekTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * Text的基线
     */
    protected float mMonthTextBaseLine;

    /**
     * Text的基线
     */
    protected float mWeekTextBaseLine;


    public BaseYearViewPainter(Context context) {
        super(context);
        mMonthTextPaint.setFakeBoldText(true);
        mWeekTextPaint.setFakeBoldText(true);
        mWeekTextPaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected int getDefaultTextSizeInSp() {
        return 7;
    }

    @Override
    protected void updateStyle() {
        if (mDelegate == null) {
            return;
        }
        mSelectedTextPaint.setColor(mDelegate.getYearViewSelectTextColor());
        mCurDayTextPaint.setColor(mDelegate.getYearViewCurDayTextColor());
        mSchemeTextPaint.setColor(mDelegate.getYearViewSchemeTextColor());
        mCurMonthTextPaint.setColor(mDelegate.getYearViewDayTextColor());
        mOtherMonthTextPaint.setColor(mDelegate.getYearViewDayTextColor());

        mSelectedTextPaint.setTextSize(mDelegate.getYearViewDayTextSize());
        mCurDayTextPaint.setTextSize(mDelegate.getYearViewDayTextSize());
        mSchemeTextPaint.setTextSize(mDelegate.getYearViewDayTextSize());
        mCurMonthTextPaint.setTextSize(mDelegate.getYearViewDayTextSize());
        mOtherMonthTextPaint.setTextSize(mDelegate.getYearViewDayTextSize());

        mMonthTextPaint.setColor(mDelegate.getYearViewMonthTextColor());
        mWeekTextPaint.setColor(mDelegate.getYearViewWeekTextColor());
        mMonthTextPaint.setTextSize(mDelegate.getYearViewMonthTextSize());
        mWeekTextPaint.setTextSize(mDelegate.getYearViewWeekTextSize());

        Paint.FontMetrics monthMetrics = mMonthTextPaint.getFontMetrics();
        mMonthTextBaseLine = mDelegate.getYearViewMonthHeight() / 2F - monthMetrics.descent
                + (monthMetrics.bottom - monthMetrics.top) / 2;

        Paint.FontMetrics weekMetrics = mWeekTextPaint.getFontMetrics();
        mWeekTextBaseLine = mDelegate.getYearViewWeekHeight() / 2F - weekMetrics.descent
                + (weekMetrics.bottom - weekMetrics.top) / 2;
    }

    @Override
    protected void onPreviewHook(int itemHeight, int itemWidth, float textBaseLine) {
        super.onPreviewHook(itemHeight, itemWidth, textBaseLine);
        Paint.FontMetrics metrics = mCurMonthTextPaint.getFontMetrics();
        mTextBaseLine = mItemHeight / 2F - metrics.descent + (metrics.bottom - metrics.top) / 2;
    }


    /**
     * 绘制月份
     *
     * @param canvas canvas
     * @param year   year
     * @param month  month
     * @param x      x
     * @param y      y
     * @param width  width
     * @param height height
     */
    protected abstract void onDrawMonth(Canvas canvas, int year, int month, int x, int y, int width, int height);


    /**
     * 绘制年视图的周栏
     *
     * @param canvas canvas
     * @param week   week
     * @param x      x
     * @param y      y
     * @param width  width
     * @param height height
     */
    protected abstract void onDrawWeek(Canvas canvas, int week, int x, int y, int width, int height);


}
