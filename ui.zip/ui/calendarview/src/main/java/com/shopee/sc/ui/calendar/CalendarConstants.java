package com.shopee.sc.ui.calendar;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/**
 * Created by honggang.xiong on 2020-03-12.
 */
public class CalendarConstants {

    /**
     * 支持的最小日历年份
     */
    public static final int MIN_YEAR = 1900;

    /**
     * 支持的最大日历年份
     */
    public static final int MAX_YEAR = 2099;

    public static final long ONE_DAY_MILLIS = TimeUnit.DAYS.toMillis(1);

    /**
     * 一周起始日
     */
    public static final int WEEK_START_SUN = Calendar.SUNDAY;    // 1 : 周日
    public static final int WEEK_START_MON = Calendar.MONDAY;    // 2 : 周一
    public static final int WEEK_START_TUE = Calendar.TUESDAY;   // 3 : 周二
    public static final int WEEK_START_WED = Calendar.WEDNESDAY; // 4 : 周三
    public static final int WEEK_START_THU = Calendar.THURSDAY;  // 5 : 周四
    public static final int WEEK_START_FRI = Calendar.FRIDAY;    // 6 : 周五
    public static final int WEEK_START_SAT = Calendar.SATURDAY;  // 7 : 周六

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({WEEK_START_SUN, WEEK_START_MON, WEEK_START_TUE, WEEK_START_WED, WEEK_START_THU, WEEK_START_FRI, WEEK_START_SAT})
    public @interface WeekStart {
    }

    /**
     * 日期选择模式
     */
    public static final int SELECT_MODE_AUTO = 0;   // 默认自动选择模式，切换月份时根据 mCalendarAutoSelectMode 重新选择日期
    public static final int SELECT_MODE_SINGLE = 1; // 单选模式，切换月份后不改变
    public static final int SELECT_MODE_RANGE = 2;  // 范围选择模式，切换月份后不改变
    public static final int SELECT_MODE_MULTI = 3;  // 多选模式，切换月份后不改变

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({SELECT_MODE_AUTO, SELECT_MODE_SINGLE, SELECT_MODE_RANGE, SELECT_MODE_MULTI})
    public @interface SelectMode {
    }

    /**
     * 当 SelectMode 为 SELECT_MODE_AUTO 时，切换月份聚焦日期策略
     */
    public static final int AUTO_FOCUS_MODE_FIRST_DAY_OF_MONTH = 0; // 默认选择日期1号 first_day_of_month
    public static final int AUTO_FOCUS_MODE_LAST_MONTH_SELECT_DAY = 1; // 跟随上个月，切回当月时选择当天 last_select_day
    public static final int AUTO_FOCUS_MODE_LAST_MONTH_SELECT_DAY_IGNORE_CURRENT = 2; // 跟随上个月，忽视当天 last_select_day_ignore_current

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({AUTO_FOCUS_MODE_FIRST_DAY_OF_MONTH,
            AUTO_FOCUS_MODE_LAST_MONTH_SELECT_DAY,
            AUTO_FOCUS_MODE_LAST_MONTH_SELECT_DAY_IGNORE_CURRENT})
    public @interface AutoFocusMode {
    }

    /**
     * 月份显示模式
     */
    public static final int MONTH_SHOW_MODE_ALL = 0;          // 全部显示
    public static final int MONTH_SHOW_MODE_ONLY_CURRENT = 1; // 仅显示当前月份
    public static final int MONTH_SHOW_MODE_AUTO_FIT = 2;     // 自适应，不会多出一行，但是会自动填充满 7 的倍数格

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({MONTH_SHOW_MODE_ALL, MONTH_SHOW_MODE_ONLY_CURRENT, MONTH_SHOW_MODE_AUTO_FIT})
    public @interface MonthShowMode {
    }

}
