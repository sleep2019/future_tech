package com.shopee.sc.ui.calendar;

import java.io.Serializable;

/**
 * 其他历法扩展接口，可自定义实现农历等
 *
 * Created by honggang.xiong on 2020-03-11.
 */
public abstract class BaseSubCalendarBean implements Serializable {

    /**
     * 公历年
     */
    protected final int solarYear;

    /**
     * 公历月
     */
    protected final int solarMonth;

    /**
     * 公历日
     */
    protected final int solarDay;

    /**
     * 其他历法年
     */
    protected int subYear;

    /**
     * 其他历法月
     */
    protected int subMonth;

    /**
     * 其他历法日
     */
    protected int subDay;

    public BaseSubCalendarBean(int solarYear, int solarMonth, int solarDay) {
        this.solarYear = solarYear;
        this.solarMonth = solarMonth;
        this.solarDay = solarDay;
    }

    public abstract void setupCalendar();

    public int getSolarYear() {
        return solarYear;
    }

    public int getSolarMonth() {
        return solarMonth;
    }

    public int getSolarDay() {
        return solarDay;
    }

    public int getSubYear() {
        return subYear;
    }

    public int getSubMonth() {
        return subMonth;
    }

    public int getSubDay() {
        return subDay;
    }

    public abstract String getYearText();

    public abstract String getMonthText();

    public abstract String getDayText();

    public abstract String getFestival();

}
