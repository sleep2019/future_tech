package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.NonNull;

/**
 * Created by honggang.xiong on 2020-03-12.
 */
public class DefaultMonthWeekPainter extends BaseMonthWeekPainter {

    private Paint mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint mSchemeBasicPaint = new Paint();
    private float mRadio;
    private int mPadding;
    private float mSchemeBaseLine;

    public DefaultMonthWeekPainter(Context context) {
        super(context);
        mTextPaint.setTextSize(CalendarUtil.dp2px(context, 8));
        mTextPaint.setColor(0xFFFFFFFF);
        mTextPaint.setFakeBoldText(true);

        mSchemeBasicPaint.setAntiAlias(true);
        mSchemeBasicPaint.setStyle(Paint.Style.FILL);
        mSchemeBasicPaint.setTextAlign(Paint.Align.CENTER);
        mSchemeBasicPaint.setColor(0xFFED5353);
        mSchemeBasicPaint.setFakeBoldText(true);
        mRadio = CalendarUtil.dp2px(context, 7);
        mPadding = CalendarUtil.dp2px(context, 4);
        Paint.FontMetrics metrics = mSchemeBasicPaint.getFontMetrics();
        mSchemeBaseLine = mRadio - metrics.descent + (metrics.bottom - metrics.top) / 2 + CalendarUtil.dp2px(context, 1);
    }

    @Override
    protected boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y,
                                       boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {
        canvas.drawRect(x + mPadding, y + mPadding, x + mItemWidth - mPadding, y + mItemHeight - mPadding, mSelectedBgPaint);
        return true;
    }

    @Override
    protected void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean isSelected) {
        mSchemeBasicPaint.setColor(bean.getSchemeColor());
        canvas.drawCircle(x + mItemWidth - mPadding - mRadio / 2, y + mPadding + mRadio, mRadio, mSchemeBasicPaint);
        canvas.drawText(bean.getScheme(),
                x + mItemWidth - mPadding - mRadio / 2 - getTextWidth(bean.getScheme()) / 2,
                y + mPadding + mSchemeBaseLine, mTextPaint);
    }

    /**
     * 获取字体的宽
     *
     * @param text text
     * @return return
     */
    private float getTextWidth(String text) {
        return mTextPaint.measureText(text);
    }

    @Override
    protected void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y,
                              boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected) {
        int cx = x + mItemWidth / 2;
        int top = y - mItemHeight / 6;

        final boolean isCurrentDay = isCurrentDay(bean);
        Paint textPaint;
        Paint festivalPaint;
        if (isSelected) {
            textPaint = mSelectedTextPaint;
            festivalPaint = mSelectedFestivalPaint;
        } else if (isCurrentDay) {
            textPaint = mCurDayTextPaint;
            festivalPaint = mCurDayFestivalPaint;
        } else if (hasScheme) {
            textPaint = isInCurrentMonthCard ? mSchemeTextPaint : mOtherMonthTextPaint;
            festivalPaint = isInCurrentMonthCard ? mSchemeFestivalPaint : mOtherMonthFestivalPaint;
        } else {
            textPaint = isInCurrentMonthCard ? mCurMonthTextPaint : mOtherMonthTextPaint;
            festivalPaint = isInCurrentMonthCard ? mCurMonthFestivalPaint : mOtherMonthFestivalPaint;
        }
        canvas.drawText(String.valueOf(bean.getDay()), cx, mTextBaseLine + top, textPaint);
        canvas.drawText(bean.getFestival(), cx, mTextBaseLine + y + mItemHeight / 10F, festivalPaint);
    }

}
