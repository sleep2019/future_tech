package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

/**
 * 星期栏
 */
public class WeekBar extends LinearLayout {

    private BaseCalendarViewDelegate mDelegate;

    protected String[] mWeekLabels = new String[7];
    protected TextView[] mTvWeeks;

    public WeekBar(Context context) {
        this(context, null);
    }

    public WeekBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    /**
     * 初始化 View，子类需自定义布局时可重写该方法
     */
    protected void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.cv_week_bar, this, true);
        mTvWeeks = new TextView[7];
        for (int i = 0; i < 7; i++) {
            mTvWeeks[i] = (TextView) getChildAt(i);
        }
    }

    /**
     * 传递属性
     *
     * @param delegate delegate
     */
    void setDelegate(BaseCalendarViewDelegate delegate) {
        mDelegate = delegate;
        setTextSize(delegate.getWeekTextSize());
        setTextColor(delegate.getWeekTextColor());
        setBackgroundColor(delegate.getWeekBackground());
        setPadding(delegate.getMonthWeekPaddingStart(), 0, delegate.getMonthWeekPaddingEnd(), 0);
    }

    /**
     * 设置文本颜色
     *
     * @param color color
     */
    protected void setTextColor(int color) {
        if (mTvWeeks != null) {
            for (TextView textView : mTvWeeks) {
                textView.setTextColor(color);
            }
        }
    }

    /**
     * 设置文本大小
     *
     * @param size Size in px
     */
    protected void setTextSize(int size) {
        if (mTvWeeks != null) {
            for (TextView textView : mTvWeeks) {
                textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, size);
            }
        }
    }

    /**
     * 当周起始发生变化，使用自定义布局需要重写这个方法，避免出问题
     *
     * @param weekStart 周起始
     */
    protected void onWeekStartChange(int weekStart) {
        updateWeekLabels(weekStart);
        if (mTvWeeks != null) {
            for (int i = 0; i < mTvWeeks.length; i++) {
                mTvWeeks[i].setText(mWeekLabels[i]);
            }
        }
    }

    /**
     * 根据 weekStart 更新 {@link #mWeekLabels}，子类可重写该方式使用自定义的 label
     *
     * @param weekStart From 1 to 7
     */
    protected void updateWeekLabels(int weekStart) {
        String[] weeks = getContext().getResources().getStringArray(R.array.week_string_array);
        for (int i = 0; i < 7; i++) {
            mWeekLabels[i] = weeks[(weekStart + i - 1) % 7];
        }
    }

    /**
     * 通过View的位置和周起始获取星期的对应坐标
     *
     * @param bean      CalendarBean
     * @param weekStart weekStart
     * @return 通过View的位置和周起始获取星期的对应坐标
     */
    protected int getViewIndexByCalendar(CalendarBean bean, int weekStart) {
        int week = bean.getWeek();
        return (week - weekStart + 7) % 7;
    }

    /**
     * 日期选择事件，这里提供这个回调，可以方便定制WeekBar需要
     *
     * @param bean      选择的日期
     * @param weekStart 周起始
     * @param isClick   isClick 点击
     */
    protected void onDateSelected(CalendarBean bean, int weekStart, boolean isClick) {

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mDelegate != null) {
            heightMeasureSpec = MeasureSpec.makeMeasureSpec(mDelegate.getWeekBarHeight(), MeasureSpec.EXACTLY);
        } else {
            heightMeasureSpec = MeasureSpec.makeMeasureSpec(CalendarUtil.dp2px(getContext(), 40), MeasureSpec.EXACTLY);
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

}
