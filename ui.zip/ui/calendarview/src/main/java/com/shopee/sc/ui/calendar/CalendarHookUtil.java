package com.shopee.sc.ui.calendar;

import android.content.Context;

import androidx.annotation.Nullable;

/**
 * Created by honggang.xiong on 2020-03-11.
 */
public class CalendarHookUtil {

    private static SubCalendarInitializer sSubCalendarInitializer = null;
    private static SubCalendarGenerator sSubCalendarGenerator = null;

    public static void setSubCalendarInitializer(SubCalendarInitializer subCalendarInitializer) {
        sSubCalendarInitializer = subCalendarInitializer;
    }

    public static void setSubCalendarGenerator(SubCalendarGenerator subCalendarGenerator) {
        sSubCalendarGenerator = subCalendarGenerator;
    }


    static void initSubCalendar(Context context) {
        if (sSubCalendarInitializer != null) {
            sSubCalendarInitializer.onInit(context);
        }
    }

    @Nullable
    static BaseSubCalendarBean generate(int year, int month, int day) {
        if (sSubCalendarGenerator != null) {
            BaseSubCalendarBean subCalendarBean = sSubCalendarGenerator.generate(year, month, day);
            if (subCalendarBean != null) {
                subCalendarBean.setupCalendar();
            }
            return subCalendarBean;
        }
        return null;
    }


    public interface SubCalendarInitializer {
        void onInit(Context context);
    }

    public interface SubCalendarGenerator {
        BaseSubCalendarBean generate(int year, int month, int day);
    }

}
