package com.shopee.sc.ui.calendar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import java.util.List;

/**
 * 水平日历，支持 年/月/周 视图水平滑动
 *
 * Created by honggang.xiong on 2020-03-12.
 */
public final class CalendarViewDelegateHorizontal extends BaseCalendarViewDelegate {

    /**
     * 自定义自适应高度的 ViewPager
     */
    private MonthViewPager mMonthPager;

    /**
     * 日历周视图
     */
    private WeekViewPager mWeekPager;

    /**
     * 月份快速选取
     */
    private YearViewPager mYearViewPager;

    /**
     * 星期栏的线
     */
    private View mWeekLine;

    /**
     * 日历外部收缩布局
     */
    CalendarLayout mParentLayout;

    /**
     * 年月视图是否打开
     */
    private boolean mIsShowYearSelectedLayout;

    private boolean mMonthViewScrollable,
            mWeekViewScrollable,
            mYearViewScrollable;

    CalendarViewDelegateHorizontal(CalendarView delegator, Context context, @Nullable AttributeSet attrs) {
        super(delegator, context, attrs);
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.CalendarView);
        mMonthViewScrollable = array.getBoolean(R.styleable.CalendarView_month_view_scrollable, true);
        mWeekViewScrollable = array.getBoolean(R.styleable.CalendarView_week_view_scrollable, true);
        mYearViewScrollable = array.getBoolean(R.styleable.CalendarView_year_view_scrollable, true);
        array.recycle();
        initView(context);
    }

    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.cv_layout_calendar_view, mDelegator, true);
        FrameLayout frameContent = mDelegator.findViewById(R.id.frameContent);
        mWeekPager = mDelegator.findViewById(R.id.vp_week);
        mWeekPager.setDelegate(this);

        frameContent.addView(mWeekBar, 2);
        mWeekBar.setDelegate(this);
        mWeekBar.onWeekStartChange(getWeekStart());

        mWeekLine = mDelegator.findViewById(R.id.line);
        mWeekLine.setBackgroundColor(getWeekLineBackground());
        FrameLayout.LayoutParams lineParams = (FrameLayout.LayoutParams) mWeekLine.getLayoutParams();
        lineParams.setMargins(getWeekLineMargin(), getWeekBarHeight(), getWeekLineMargin(), 0);
        mWeekLine.setLayoutParams(lineParams);

        mMonthPager = mDelegator.findViewById(R.id.vp_month);
        mMonthPager.mWeekPager = mWeekPager;
        mMonthPager.mWeekBar = mWeekBar;
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) mMonthPager.getLayoutParams();
        params.setMargins(0, getWeekBarHeight() + CalendarUtil.dp2px(context, 1), 0, 0);
        mWeekPager.setLayoutParams(params);


        mYearViewPager = mDelegator.findViewById(R.id.selectLayout);
        mYearViewPager.setBackgroundColor(getYearViewBackground());
        mYearViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (mWeekPager.getVisibility() == View.VISIBLE) {
                    return;
                }
                if (mYearChangeListener != null) {
                    mYearChangeListener.onYearChange(position + getMinYear());
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        mInnerListener = new CalendarView.OnInnerDateSelectedListener() {

            @Override
            public void onMonthDateSelected(CalendarBean calendarBean, boolean isClick) {
                if (calendarBean.getYear() == getCurrentDay().getYear()
                        && calendarBean.getMonth() == getCurrentDay().getMonth()
                        && mMonthPager.getCurrentItem() != mCurrentMonthViewItem) {
                    return;
                }
                mIndexCalendar = calendarBean;
                if (getSelectMode() == CalendarConstants.SELECT_MODE_AUTO || isClick) {
                    mSelectedCalendar = calendarBean;
                    if (mWeekBar != null) {
                        mWeekBar.onDateSelected(calendarBean, getWeekStart(), isClick);
                    }
                }
                mWeekPager.updateSelected(mIndexCalendar, false);
                mMonthPager.updateSelected();
            }

            @Override
            public void onWeekDateSelected(CalendarBean calendarBean, boolean isClick) {
                mIndexCalendar = calendarBean;
                if (getSelectMode() == CalendarConstants.SELECT_MODE_AUTO || isClick
                        || mIndexCalendar.equals(mSelectedCalendar)) {
                    mSelectedCalendar = calendarBean;
                    if (mWeekBar != null) {
                        mWeekBar.onDateSelected(calendarBean, getWeekStart(), isClick);
                    }
                }
                int y = calendarBean.getYear() - getMinYear();
                int position = 12 * y + mIndexCalendar.getMonth() - getMinYearMonth();
                mWeekPager.updateSingleSelect();
                mMonthPager.setCurrentItem(position, false);
                mMonthPager.updateSelected();
            }
        };

        if (getSelectMode() == CalendarConstants.SELECT_MODE_AUTO) {
            if (CalendarUtil.isCalendarInRange(getCurrentDay(), this)) {
                mSelectedCalendar = getCurrentDay();
            } else {
                mSelectedCalendar = getMinDate();
            }
        } else {
            mSelectedCalendar = new CalendarBean(0, 0, 0);
        }

        mIndexCalendar = mSelectedCalendar;

        mWeekBar.onDateSelected(mSelectedCalendar, getWeekStart(), false);

        mMonthPager.setDelegate(this);
        mMonthPager.setCurrentItem(mCurrentMonthViewItem);
        mYearViewPager.setOnMonthSelectedListener(new YearRecyclerView.OnMonthSelectedListener() {
            @Override
            public void onMonthSelected(int year, int month) {
                int position = 12 * (year - getMinYear()) + month - getMinYearMonth();
                closeSelectLayout(position);
                mIsShowYearSelectedLayout = false;
            }
        });
        mYearViewPager.setDelegate(this);
        mWeekPager.updateSelected(getCurrentDay(), false);
    }

    @Override
    protected void updateStyle() {
        mMonthPager.updateStyle();
        mWeekPager.updateStyle();
        if (isYearSelectLayoutVisible()) {
            mYearViewPager.updateStyle();
        }
    }

    @Override
    protected void updateScheme() {
        mWeekBar.onWeekStartChange(getWeekStart());
        mYearViewPager.update();
        mMonthPager.updateScheme();
        mWeekPager.updateScheme();
    }

    @Override
    protected void clearAndRefreshView() {
        if (mMonthPager == null) {
            return;
        }
        mWeekBar.onWeekStartChange(getWeekStart());
        mYearViewPager.update();
        mMonthPager.updateMonthViewClass();
        mWeekPager.updateWeekViewClass();
    }

    @Override
    public void setRange(CalendarBean minDate, CalendarBean maxDate) {
        super.setRange(minDate, maxDate);
        if (mMonthPager == null) {
            return;
        }
        mWeekPager.notifyDataSetChanged();
        mYearViewPager.notifyDataSetChanged();
        mMonthPager.notifyDataSetChanged();
        if (!CalendarUtil.isCalendarInRange(mSelectedCalendar, this)) {
            mSelectedCalendar = getMinDate();
            updateSelectCalendarScheme();
            mIndexCalendar = mSelectedCalendar;
        }
        mWeekPager.updateRange();
        mMonthPager.updateRange();
        mYearViewPager.updateRange();
    }

    @Override
    public void setWeekStart(int weekStart) {
        super.setWeekStart(weekStart);
        mWeekBar.onWeekStartChange(weekStart);
        mWeekBar.onDateSelected(mSelectedCalendar, weekStart, false);
        mWeekPager.handleWeekStartChanged();
        mMonthPager.handleWeekStartChanged();
        mYearViewPager.handleWeekStartChanged();
    }

    @Override
    public void setMonthShowMode(int monthViewShowMode) {
        super.setMonthShowMode(monthViewShowMode);
        mWeekPager.handleMonthShowModeChanged();
        mMonthPager.handleMonthShowModeChanged();
        mYearViewPager.notifyDataSetChanged();
    }

    @Override
    public void setSelectMode(int selectMode) {
        super.setSelectMode(selectMode);
        if (selectMode == CalendarConstants.SELECT_MODE_AUTO && mWeekBar != null) {
            mWeekBar.onDateSelected(mSelectedCalendar, getWeekStart(), false);
        }
    }

    @Override
    public List<CalendarBean> getCurrentWeekCalendars() {
        return mWeekPager.getCurrentWeekCalendars();
    }

    @Override
    public List<CalendarBean> getCurrentMonthCalendars() {
        return mMonthPager.getCurrentMonthCalendars();
    }

    @Override
    public void setCalendarItemHeight(int height) {
        if (getCalendarItemHeight() == height) {
            return;
        }
        super.setCalendarItemHeight(height);
        mMonthPager.handleCalendarItemHeightChanged();
        mWeekPager.handleCalendarItemHeightChanged();
        if (mParentLayout != null) {
            mParentLayout.handleCalendarItemHeightChanged();
        }
    }

    /**
     * 年月份选择视图是否打开
     */
    @Override
    public boolean isYearSelectLayoutVisible() {
        return mYearViewPager.getVisibility() == View.VISIBLE;
    }

    @Override
    public void closeYearSelectLayout() {
        if (mYearViewPager.getVisibility() == View.GONE) {
            return;
        }
        int position = 12 * (mSelectedCalendar.getYear() - getMinYear()) + mSelectedCalendar.getMonth() - getMinYearMonth();
        closeSelectLayout(position);
        mIsShowYearSelectedLayout = false;
    }

    @Override
    public void showYearSelectLayout(final int year) {
        if (mParentLayout != null && mParentLayout.mContentView != null) {
            if (!mParentLayout.isExpand()) {
                mParentLayout.expand();
            }
        }
        mWeekPager.setVisibility(View.GONE);
        mIsShowYearSelectedLayout = true;
        if (mParentLayout != null) {
            mParentLayout.hideContentView();
        }
        mWeekBar.animate()
                .translationY(-mWeekBar.getHeight())
                .setInterpolator(new LinearInterpolator())
                .setDuration(260)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        mWeekBar.setVisibility(View.GONE);
                        mYearViewPager.setVisibility(View.VISIBLE);
                        mYearViewPager.scrollToYear(year, false);
                        if (mParentLayout != null && mParentLayout.mContentView != null) {
                            mParentLayout.expand();
                        }
                    }
                });

        mMonthPager.animate()
                .scaleX(0)
                .scaleY(0)
                .setDuration(260)
                .setInterpolator(new LinearInterpolator())
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        if (mYearViewChangeListener != null) {
                            mYearViewChangeListener.onYearViewChange(false);
                        }
                    }
                });
    }

    @Override
    public boolean isShowYearSelectedLayout() {
        return mIsShowYearSelectedLayout;
    }

    @Override
    public void scrollToCurrent(boolean smoothScroll) {
        if (!CalendarUtil.isCalendarInRange(getCurrentDay(), this)) {
            return;
        }
        CalendarBean calendarBean = getCurrentDay();
        if (isCalendarIntercepted(calendarBean)) {
            mCalendarInterceptListener.onCalendarInterceptClick(calendarBean, false);
            return;
        }
        mSelectedCalendar = getCurrentDay();
        mIndexCalendar = mSelectedCalendar;
        updateSelectCalendarScheme();
        mWeekBar.onDateSelected(mSelectedCalendar, getWeekStart(), false);
        if (mMonthPager.getVisibility() == View.VISIBLE) {
            mMonthPager.scrollToCurrent(smoothScroll);
            mWeekPager.updateSelected(mIndexCalendar, false);
        } else {
            mWeekPager.scrollToCurrent(smoothScroll);
        }
        mYearViewPager.scrollToYear(getCurrentDay().getYear(), smoothScroll);
    }

    @Override
    public void scrollToNext(boolean smoothScroll) {
        if (isYearSelectLayoutVisible()) {
            mYearViewPager.setCurrentItem(mYearViewPager.getCurrentItem() + 1, smoothScroll);
        } else if (mWeekPager.getVisibility() == View.VISIBLE) {
            mWeekPager.setCurrentItem(mWeekPager.getCurrentItem() + 1, smoothScroll);
        } else {
            mMonthPager.setCurrentItem(mMonthPager.getCurrentItem() + 1, smoothScroll);
        }
    }

    @Override
    public void scrollToPre(boolean smoothScroll) {
        if (isYearSelectLayoutVisible()) {
            mYearViewPager.setCurrentItem(mYearViewPager.getCurrentItem() - 1, smoothScroll);
        } else if (mWeekPager.getVisibility() == View.VISIBLE) {
            mWeekPager.setCurrentItem(mWeekPager.getCurrentItem() - 1, smoothScroll);
        } else {
            mMonthPager.setCurrentItem(mMonthPager.getCurrentItem() - 1, smoothScroll);
        }
    }

    @Override
    public void scrollToSelectCalendar(boolean smoothScroll, boolean invokeListener) {
        if (!mSelectedCalendar.isAvailable()) {
            return;
        }
        scrollToCalendar(mSelectedCalendar.getYear(), mSelectedCalendar.getMonth(), mSelectedCalendar.getDay(),
                smoothScroll, invokeListener);
    }

    @Override
    public void scrollToCalendar(int year, int month, int day, boolean smoothScroll, boolean invokeListener) {
        CalendarBean calendarBean = new CalendarBean(year, month, day);
        if (!calendarBean.isAvailable()) {
            return;
        }
        if (!CalendarUtil.isCalendarInRange(calendarBean, this)) {
            return;
        }
        if (isCalendarIntercepted(calendarBean)) {
            mCalendarInterceptListener.onCalendarInterceptClick(calendarBean, false);
            return;
        }

        if (mWeekPager.getVisibility() == View.VISIBLE) {
            mWeekPager.scrollToCalendar(year, month, day, smoothScroll, invokeListener);
        } else {
            mMonthPager.scrollToCalendar(year, month, day, smoothScroll, invokeListener);
        }
    }

    @Override
    public void scrollToYear(int year, boolean smoothScroll) {
        if (mYearViewPager.getVisibility() != View.VISIBLE) {
            return;
        }
        mYearViewPager.scrollToYear(year, smoothScroll);
    }

    /**
     * 关闭日历布局，同时会滚动到指定的位置
     *
     * @param position 某一年
     */
    private void closeSelectLayout(final int position) {
        mYearViewPager.setVisibility(View.GONE);
        mWeekBar.setVisibility(View.VISIBLE);
        if (position == mMonthPager.getCurrentItem()) {
            if (mCalendarSelectListener != null &&
                    getSelectMode() != CalendarConstants.SELECT_MODE_SINGLE) {
                mCalendarSelectListener.onCalendarSelect(mSelectedCalendar, false);
            }
        } else {
            mMonthPager.setCurrentItem(position, false);
        }
        mWeekBar.animate()
                .translationY(0)
                .setInterpolator(new LinearInterpolator())
                .setDuration(280)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        mWeekBar.setVisibility(View.VISIBLE);
                    }
                });
        mMonthPager.animate()
                .scaleX(1)
                .scaleY(1)
                .setDuration(180)
                .setInterpolator(new LinearInterpolator())
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        if (mYearViewChangeListener != null) {
                            mYearViewChangeListener.onYearViewChange(true);
                        }
                        if (mParentLayout != null) {
                            mParentLayout.showContentView();
                            if (mParentLayout.isExpand()) {
                                mMonthPager.setVisibility(View.VISIBLE);
                            } else {
                                mWeekPager.setVisibility(View.VISIBLE);
                                mParentLayout.collapse();
                            }
                        } else {
                            mMonthPager.setVisibility(View.VISIBLE);
                        }
                        mMonthPager.clearAnimation();
                    }
                });
    }

    public boolean isMonthViewScrollable() {
        return mMonthViewScrollable;
    }

    public void setMonthViewScrollable(boolean monthViewScrollable) {
        mMonthViewScrollable = monthViewScrollable;
    }

    public boolean isWeekViewScrollable() {
        return mWeekViewScrollable;
    }

    public void setWeekViewScrollable(boolean weekViewScrollable) {
        mWeekViewScrollable = weekViewScrollable;
    }

    public boolean isYearViewScrollable() {
        return mYearViewScrollable;
    }

    public void setYearViewScrollable(boolean yearViewScrollable) {
        mYearViewScrollable = yearViewScrollable;
    }

    @Override
    public void clearRangeSelect() {
        mRangeSelectStartCalendar = null;
        mRangeSelectEndCalendar = null;
        if (mMonthPager != null) {
            mMonthPager.clearSelectRange();
            mWeekPager.clearSelectRange();
        }
    }

    @Override
    public void clearSingleSelect() {
        mSelectedCalendar = new CalendarBean(0, 0, 0);
        if (mMonthPager != null) {
            mMonthPager.clearSingleSelect();
            mWeekPager.clearSingleSelect();
        }
    }

    @Override
    public void clearMultiSelect() {
        mMultiSelectCalendars.clear();
        if (mMonthPager != null) {
            mMonthPager.clearMultiSelect();
            mWeekPager.clearMultiSelect();
        }
    }

    @Override
    public void setCalendarLayout(CalendarLayout calendarLayout) {
        mParentLayout = calendarLayout;
        mMonthPager.mParentLayout = mParentLayout;
        mWeekPager.mParentLayout = mParentLayout;
        mParentLayout.mWeekBar = mWeekBar;
        mParentLayout.setDelegate(this);
        mParentLayout.initStatus();
    }

    @Override
    public void setBackground(int yearViewBackground, int weekBackground, int lineBg) {
        mWeekBar.setBackgroundColor(weekBackground);
        mYearViewPager.setBackgroundColor(yearViewBackground);
        mWeekLine.setBackgroundColor(lineBg);
    }

    @Override
    public WeekBar getWeekBar() {
        return mWeekBar;
    }

    @Override
    public void setWeekBar(WeekBar weekBar) {
        if (weekBar == null) {
            return;
        }

        FrameLayout frameContent = mDelegator.findViewById(R.id.frameContent);
        frameContent.removeView(mWeekBar);
        mWeekBar = weekBar;
        frameContent.addView(mWeekBar, 2);
        mWeekBar.setDelegate(this);
        mWeekBar.onWeekStartChange(getWeekStart());
        mMonthPager.mWeekBar = mWeekBar;
        mWeekBar.onDateSelected(mSelectedCalendar, getWeekStart(), false);
    }

}
