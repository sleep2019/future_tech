package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.List;

/**
 * 年视图
 */
public class SimpleYearView extends View {

    BaseCalendarViewDelegate mDelegate;

    /**
     * 日历项
     */
    List<CalendarBean> mItems;

    /**
     * 每一项的高度
     */
    protected int mItemHeight;

    /**
     * 每一项的宽度
     */
    protected int mItemWidth;

    /**
     * 当前日历卡年份
     */
    protected int mYear;

    /**
     * 当前日历卡月份
     */
    protected int mMonth;

    /**
     * 下个月偏移的数量
     */
    protected int mNextDiff;

    /**
     * 周起始
     */
    protected int mWeekStart;

    /**
     * 日历单月行数，年视图固定为 6
     */
    protected int mLineCount = 6;

    public SimpleYearView(Context context) {
        this(context, null);
    }

    public SimpleYearView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    /**
     * 设置 delegate
     */
    final void setDelegate(BaseCalendarViewDelegate delegate) {
        mDelegate = delegate;
    }

    /**
     * 初始化年视图
     *
     * @param year  year
     * @param month month
     */
    final void setYearViewDate(int year, int month) {
        mYear = year;
        mMonth = month;
        mNextDiff = CalendarUtil.getMonthEndOffset(mYear, mMonth, mDelegate.getWeekStart());
        mItems = CalendarUtil.initCalendarForMonthView(mYear, mMonth, mDelegate.getWeekStart());
        mDelegate.addSchemesFromMap(mItems);
    }

    /**
     * 测量大小
     *
     * @param width  width
     * @param height height
     */
    final void resetSize(int width, int height) {
        Rect rect = new Rect();
        mDelegate.getYearViewPainter().mCurMonthTextPaint.getTextBounds("1", 0, 1, rect);
        int textHeight = rect.height();
        int minHeight = 12 * textHeight + getMonthViewTop();
        int h = height >= minHeight ? height : minHeight;

        mItemHeight = (h - getMonthViewTop()) / 6;
        getLayoutParams().width = width;
        getLayoutParams().height = h;
        invalidate();
    }

    private int getMonthViewTop() {
        return mDelegate.getYearViewMonthMarginTop() + mDelegate.getYearViewMonthHeight()
                + mDelegate.getYearViewMonthMarginBottom() + mDelegate.getYearViewWeekHeight();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        mItemWidth = (getWidth() - 2 * mDelegate.getYearViewPadding()) / 7;
        mDelegate.getYearViewPainter().onPreviewHook(mItemHeight, mItemWidth, 0);
        drawMonthLabel(canvas);
        drawWeekLabel(canvas);
        drawMonthView(canvas);
    }

    /**
     * 绘制月份栏
     */
    private void drawMonthLabel(Canvas canvas) {
        mDelegate.getYearViewPainter().onDrawMonth(canvas, mYear, mMonth,
                mDelegate.getYearViewPadding(),
                mDelegate.getYearViewMonthMarginTop(),
                getWidth() - 2 * mDelegate.getYearViewPadding(),
                mDelegate.getYearViewMonthHeight() + mDelegate.getYearViewMonthMarginTop());
    }

    /**
     * 绘制星期栏
     */
    private void drawWeekLabel(Canvas canvas) {
        if (mDelegate.getYearViewWeekHeight() <= 0) {
            return;
        }
        int week = mDelegate.getWeekStart();
        if (week > 0) {
            week -= 1;
        }
        int width = (getWidth() - 2 * mDelegate.getYearViewPadding()) / 7;
        for (int i = 0; i < 7; i++) {
            mDelegate.getYearViewPainter().onDrawWeek(canvas, week,
                    mDelegate.getYearViewPadding() + i * width,
                    mDelegate.getYearViewMonthHeight() + mDelegate.getYearViewMonthMarginTop()
                            + mDelegate.getYearViewMonthMarginBottom(),
                    width,
                    mDelegate.getYearViewWeekHeight());
            week += 1;
            if (week >= 7) {
                week = 0;
            }
        }
    }

    /**
     * 绘制月份日期数据
     */
    private void drawMonthView(Canvas canvas) {
        int d = 0;
        for (int row = 0; row < mLineCount; row++) {
            for (int col = 0; col < 7; col++) {
                CalendarBean bean = mItems.get(d);
                if (d > mItems.size() - mNextDiff) {
                    return;
                }
                if (!bean.isSameMonth(mYear, mMonth)) {
                    ++d;
                    continue;
                }
                draw(canvas, bean, row, col);
                ++d;
            }
        }
    }


    /**
     * 开始绘制
     *
     * @param canvas canvas
     * @param bean   对应日历
     * @param row    行
     * @param col    列
     */
    private void draw(Canvas canvas, CalendarBean bean, int row, int col) {
        int x = col * mItemWidth + mDelegate.getYearViewPadding();
        int y = row * mItemHeight + getMonthViewTop();

        boolean isSelected = bean.equals(mDelegate.mSelectedCalendar);
        boolean hasScheme = bean.hasScheme();

        boolean drawScheme = true;
        if (isSelected) {
            drawScheme = mDelegate.getYearViewPainter().onDrawSelectedBg(canvas, bean, x, y, hasScheme, false, false);
        }
        if (hasScheme && drawScheme) {
            // 将画笔设置为标记颜色
            mDelegate.getYearViewPainter().mSchemeBgPaint.setColor(bean.getSchemeColor() != 0 ? bean.getSchemeColor() : mDelegate.getSchemeThemeColor());
            mDelegate.getYearViewPainter().onDrawSchemeBg(canvas, bean, x, y, isSelected);
        }
        mDelegate.getYearViewPainter().onDrawText(canvas, bean, x, y, true, hasScheme, isSelected);
    }

}
