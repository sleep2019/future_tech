package com.shopee.sc.ui.calendar;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.shopee.sc.ui.calendar.CalendarConstants.ONE_DAY_MILLIS;

/**
 * 一些日期辅助计算工具
 */
public final class CalendarUtil {

    /**
     * 特殊节日、母亲节和父亲节,感恩节等
     */
    @SuppressLint("UseSparseArrays")
    private static final Map<Integer, String[]> sSpecialFestival = new HashMap<>();

    /**
     * 特殊节日的数组
     */
    private static String[] sSpecialFestivalStr = null;

    /**
     * 公历节日
     */
    private static final Map<String, String> sSolarFestival = new HashMap<>();

    private static String sLastLocaleTag;

    static void initIfNeeded(@NonNull Context context) {
        if (!sSolarFestival.isEmpty() && Objects.equals(sLastLocaleTag, getLocaleTag(context))) {
            return;
        }

        CalendarHookUtil.initSubCalendar(context);
        sSpecialFestival.clear();
        sSpecialFestivalStr = context.getResources().getStringArray(R.array.special_festivals);
        sSolarFestival.clear();
        String[] festivalArray = context.getResources().getStringArray(R.array.solar_festival);
        for (String festival : festivalArray) {
            if (festival.length() > 4) {
                sSolarFestival.put(festival.substring(0, 4), festival.substring(4));
            }
        }
        sLastLocaleTag = getLocaleTag(context);
    }

    private static String getLocaleTag(Context context) {
        Locale locale = context.getResources().getConfiguration().locale;
        return locale == null ? null : locale.toLanguageTag();
    }

    /**
     * 获取公历节日
     *
     * @param month 公历月份
     * @param day   公历日期
     * @return 公历节日
     */
    public static String getSolarFestival(@IntRange(from = 1, to = 12) int month, int day) {
        return sSolarFestival.get(getString(month, day));
    }

    private static String getString(int month, int day) {
        return (month >= 10 ? String.valueOf(month) : "0" + month) + (day >= 10 ? day : "0" + day);
    }

    /**
     * 获取特殊计算方式的节日
     * 如：每年五月的第二个星期日为母亲节，六月的第三个星期日为父亲节
     * 每年 11 月第四个星期四定为"感恩节"
     *
     * @param year  year
     * @param month month
     * @param day   day
     * @return 获取西方节日
     */
    static String getSpecialFestival(int year, int month, int day) {
        if (!sSpecialFestival.containsKey(year)) {
            sSpecialFestival.put(year, getSpecialFestivals(year));
        }
        String[] specialFestivals = sSpecialFestival.get(year);
        String text = year + getString(month, day);
        String solar = "";
        assert specialFestivals != null;
        for (String special : specialFestivals) {
            if (special.contains(text)) {
                solar = special.replace(text, "");
                break;
            }
        }
        return solar;
    }

    /**
     * 获取每年的母亲节和父亲节和感恩节
     * 特殊计算方式的节日
     *
     * @param year 年
     * @return 获取每年的母亲节和父亲节、感恩节
     */
    private static String[] getSpecialFestivals(int year) {
        String[] festivals = new String[3];
        Calendar date = Calendar.getInstance();
        date.set(year, 4, 1);
        int week = date.get(Calendar.DAY_OF_WEEK);
        int startDiff = 7 - week + 1;
        if (startDiff == 7) {
            festivals[0] = dateToString(year, 5, startDiff + 1) + sSpecialFestivalStr[0];
        } else {
            festivals[0] = dateToString(year, 5, startDiff + 7 + 1) + sSpecialFestivalStr[0];
        }
        date.set(year, 5, 1);
        week = date.get(Calendar.DAY_OF_WEEK);
        startDiff = 7 - week + 1;
        if (startDiff == 7) {
            festivals[1] = dateToString(year, 6, startDiff + 7 + 1) + sSpecialFestivalStr[1];
        } else {
            festivals[1] = dateToString(year, 6, startDiff + 7 + 7 + 1) + sSpecialFestivalStr[1];
        }

        date.set(year, 10, 1);
        week = date.get(Calendar.DAY_OF_WEEK);
        startDiff = 7 - week + 1;
        if (startDiff <= 2) {
            festivals[2] = dateToString(year, 11, startDiff + 21 + 5) + sSpecialFestivalStr[2];
        } else {
            festivals[2] = dateToString(year, 11, startDiff + 14 + 5) + sSpecialFestivalStr[2];
        }
        return festivals;
    }

    private static String dateToString(int year, int month, int day) {
        return year + getString(month, day);
    }

    /**
     * 判断一个日期是否是周末，即周六日
     *
     * @param calendarBean calendarBean
     * @return 判断一个日期是否是周末，即周六日
     */
    public static boolean isWeekend(CalendarBean calendarBean) {
        int week = getWeekFormCalendar(calendarBean);
        return week == Calendar.SUNDAY || week == Calendar.SATURDAY;
    }

    private static final int[] MONTH_DAYS = {31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    /**
     * 获取某月的天数
     *
     * @param year  年
     * @param month 月
     * @return 某月的天数
     */
    public static int getMonthDaysCount(int year, int month) {
        if (month == 2) {
            return isLeapYear(year) ? 29 : 28;
        }
        if (1 <= month && month <= 12) {
            return MONTH_DAYS[month - 1];
        }
        return 0;
    }

    /**
     * 是否是闰年
     *
     * @param year year
     * @return 是否是闰年
     */
    public static boolean isLeapYear(int year) {
        return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
    }

    static int getMonthViewLineCount(int year, int month, BaseCalendarViewDelegate delegate) {
        return getMonthViewLineCount(year, month, delegate.getWeekStart(), delegate.getMonthViewShowMode());
    }

    static int getMonthViewLineCount(int year, int month, @CalendarConstants.WeekStart int weekStart,
                                     @CalendarConstants.MonthShowMode int mode) {
        if (mode == CalendarConstants.MONTH_SHOW_MODE_ALL) {
            return 6;
        }
        int startOffset = getMonthViewStartOffset(year, month, weekStart);
        int monthDayCount = getMonthDaysCount(year, month);
        return (startOffset + monthDayCount - 1) / 7 + 1;
    }

    static int getAllModeMonthViewHeight(BaseCalendarViewDelegate delegate) {
        return 6 * delegate.getCalendarItemHeight() + delegate.getMonthWeekPaddingTop() + delegate.getMonthWeekPaddingBottom();
    }

    /**
     * 获取月视图的确切高度
     *
     * @param year     年
     * @param month    月
     * @param delegate delegate
     * @return 月视图的确切高度
     */
    static int getMonthViewHeight(int year, int month, BaseCalendarViewDelegate delegate) {
        return getMonthViewLineCount(year, month, delegate) * delegate.getCalendarItemHeight()
                + delegate.getMonthWeekPaddingTop() + delegate.getMonthWeekPaddingBottom();
    }

    /**
     * 获取月视图的确切高度
     * 该方法并不支持 padding，建议使用 {@link #getMonthViewHeight(int, int, BaseCalendarViewDelegate)}
     * Test pass
     *
     * @param year       年
     * @param month      月
     * @param itemHeight 每项的高度
     * @param weekStart  一周起始日
     * @param mode       月份显示模式
     * @return 月视图的确切高度
     */
    @Deprecated
    static int getMonthViewHeight(int year, int month, int itemHeight, @CalendarConstants.WeekStart int weekStart,
                                  @CalendarConstants.MonthShowMode int mode) {
        return getMonthViewLineCount(year, month, weekStart, mode) * itemHeight;
    }

    /**
     * 获取某天在该月的第几周,换言之就是获取这一天在该月视图的第几行,第几周，根据周起始动态获取
     * Test pass，单元测试通过
     *
     * @param calendarBean calendarBean
     * @param weekStart    一周起始日
     * @return 获取某天在该月的第几周 the week line in MonthView
     */
    static int getWeekFromDayInMonth(CalendarBean calendarBean, @CalendarConstants.WeekStart int weekStart) {
        int startOffset = getMonthViewStartOffset(calendarBean, weekStart);
        return (calendarBean.getDay() + startOffset - 1) / 7 + 1;
    }

    /**
     * 获取上一个日子
     *
     * @param calendarBean calendarBean
     * @return 获取上一个日子
     */
    static CalendarBean getPreCalendar(CalendarBean calendarBean) {
        Calendar calendar = calendarBean.newCalendar();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        return new CalendarBean(calendar);
    }

    static CalendarBean getNextCalendar(CalendarBean calendarBean) {
        Calendar calendar = calendarBean.newCalendar();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        return new CalendarBean(calendar);
    }

    /**
     * 获取日期所在月视图对应的起始偏移量
     * Test pass
     *
     * @param calendarBean calendarBean
     * @param weekStart    weekStart 一周起始日
     * @return 获取日期所在月视图对应的起始偏移量 the start diff with MonthView
     */
    static int getMonthViewStartOffset(CalendarBean calendarBean, @CalendarConstants.WeekStart int weekStart) {
        return getMonthViewStartOffset(calendarBean.getYear(), calendarBean.getMonth(), weekStart);
    }

    /**
     * 获取日期所在月视图对应的起始偏移量
     * Test pass
     *
     * @param year      年
     * @param month     月
     * @param weekStart 一周起始日
     * @return 获取日期所在月视图对应的起始偏移量 the start diff with MonthView
     */
    static int getMonthViewStartOffset(int year, int month, @CalendarConstants.WeekStart int weekStart) {
        int week = getWeekForDay(year, month, 1);
        return (week - weekStart + 7) % 7;
    }

    /**
     * 获取具体日期对应的星期
     *
     * @param year  年
     * @param month 月，1-12
     * @param day   日
     * @return 星期 1-7
     */
    private static int getWeekForDay(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, day);
        return calendar.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * 获取日期月份对应的结束偏移量,用于计算两个年份之间总共有多少周，不用于MonthView
     * Test pass
     *
     * @param year      年
     * @param month     月
     * @param weekStart 一周起始日
     * @return 获取日期月份对应的结束偏移量 the end diff in Month not MonthView
     */
    static int getMonthEndOffset(int year, int month, @CalendarConstants.WeekStart int weekStart) {
        return getMonthEndOffset(year, month, getMonthDaysCount(year, month), weekStart);
    }

    /**
     * 获取日期月份对应的结束偏移量,用于计算两个年份之间总共有多少周，不用于MonthView
     * Test pass
     *
     * @param year      年
     * @param month     月
     * @param weekStart 一周起始日
     * @return 获取日期月份对应的结束偏移量 the end diff in Month not MonthView
     */
    private static int getMonthEndOffset(int year, int month, int day, @CalendarConstants.WeekStart int weekStart) {
        int week = getWeekForDay(year, month, day);
        return 6 - (week - weekStart + 7) % 7;
    }

    /**
     * 获取某个日期是星期几
     * 测试通过
     *
     * @param calendarBean 某个日期
     * @return 返回某个日期是星期几
     */
    public static int getWeekFormCalendar(CalendarBean calendarBean) {
        return getWeekForDay(calendarBean.getYear(), calendarBean.getMonth(), calendarBean.getDay());
    }

    /**
     * 获取周视图的切换默认选项位置 WeekView index
     * 测试通过 test pass
     *
     * @param calendarBean calendarBean
     * @param weekStart    weekStart
     * @return 获取周视图的切换默认选项位置
     */
    static int getWeekViewIndexFromCalendar(CalendarBean calendarBean, @CalendarConstants.WeekStart int weekStart) {
        return getWeekViewStartOffset(calendarBean.getYear(), calendarBean.getMonth(), calendarBean.getDay(), weekStart);
    }

    /**
     * 是否在日期范围內
     * 测试通过 test pass
     *
     * @param calendarBean calendarBean
     * @param minYear      minYear
     * @param minYearDay   最小年份天
     * @param minYearMonth minYearMonth
     * @param maxYear      maxYear
     * @param maxYearMonth maxYearMonth
     * @param maxYearDay   最大年份天
     * @return 是否在日期范围內
     */
    static boolean isCalendarInRange(CalendarBean calendarBean,
                                     int minYear, int minYearMonth, int minYearDay,
                                     int maxYear, int maxYearMonth, int maxYearDay) {
        Calendar c = Calendar.getInstance();
        c.set(minYear, minYearMonth - 1, minYearDay);
        long minTime = c.getTimeInMillis();
        c.set(maxYear, maxYearMonth - 1, maxYearDay);
        long maxTime = c.getTimeInMillis();
        c.set(calendarBean.getYear(), calendarBean.getMonth() - 1, calendarBean.getDay());
        long curTime = c.getTimeInMillis();
        return curTime >= minTime && curTime <= maxTime;
    }

    /**
     * 获取两个日期之间一共有多少周，注意周起始周一、周日、周六
     * 测试通过 test pass
     *
     * @param minYear      minYear 最小年份
     * @param minYearMonth maxYear 最小年份月份
     * @param minYearDay   最小年份天
     * @param maxYear      maxYear 最大年份
     * @param maxYearMonth maxYear 最大年份月份
     * @param maxYearDay   最大年份天
     * @param weekStart    周起始
     * @return 周数用于WeekViewPager itemCount
     */
    static int getWeekCountBetweenBothCalendar(int minYear, int minYearMonth, int minYearDay,
                                               int maxYear, int maxYearMonth, int maxYearDay,
                                               @CalendarConstants.WeekStart int weekStart) {
        Calendar date = Calendar.getInstance();
        date.set(minYear, minYearMonth - 1, minYearDay);
        long minTimeMills = date.getTimeInMillis(); // 最小时间戳
        date.set(maxYear, maxYearMonth - 1, maxYearDay);
        long maxTimeMills = date.getTimeInMillis(); // 最大时间戳

        int dayCount = (int) ((maxTimeMills - minTimeMills) / ONE_DAY_MILLIS) + 1;
        int startOffset = getWeekViewStartOffset(minYear, minYearMonth, minYearDay, weekStart);
        return (startOffset + dayCount - 1) / 7 + 1;
    }

    /**
     * 根据日期获取距离最小日期在第几周
     * 用来设置 WeekView currentItem
     * 测试通过 test pass
     *
     * @param bean         CalendarBean
     * @param minYear      minYear 最小年份
     * @param minYearMonth maxYear 最小年份月份
     * @param minYearDay   最小年份天
     * @param weekStart    周起始
     * @return 返回两个年份中第几周 the WeekView currentItem
     */
    static int getWeekFromCalendarStartWithMinCalendar(CalendarBean bean,
                                                       int minYear, int minYearMonth, int minYearDay,
                                                       @CalendarConstants.WeekStart int weekStart) {
        return getWeekCountBetweenBothCalendar(minYear, minYearMonth, minYearDay,
                bean.getYear(), bean.getMonth(), bean.getDay(), weekStart);
    }

    /**
     * 根据星期数和最小日期推算出该星期的第一天
     * 测试通过 Test pass
     *
     * @param minYear      最小年份如2017
     * @param minYearMonth maxYear 最小年份月份，like : 2017-07
     * @param minYearDay   最小年份天
     * @param week         从最小年份minYear月minYearMonth 日1 开始的第几周 week > 0
     * @return 该星期的第一天日期
     */
    static CalendarBean getFirstCalendarStartWithMinCalendar(int minYear, int minYearMonth, int minYearDay, int week,
                                                             @CalendarConstants.WeekStart int weekStart) {
        Calendar date = Calendar.getInstance();
        date.set(minYear, minYearMonth - 1, minYearDay);
        long firstTimeMills = date.getTimeInMillis(); // 获得起始时间戳
        long weekTimeMills = (week - 1) * 7 * ONE_DAY_MILLIS;
        int startOffset = getWeekViewStartOffset(minYear, minYearMonth, minYearDay, weekStart);

        long timeCountMills = firstTimeMills + weekTimeMills - startOffset * ONE_DAY_MILLIS;
        date.setTimeInMillis(timeCountMills);
        return new CalendarBean(date);
    }

    /**
     * 是否在日期范围内
     *
     * @param calendarBean calendarBean
     * @param delegate     delegate
     * @return 是否在日期范围内
     */
    static boolean isCalendarInRange(CalendarBean calendarBean, CalendarView.ICalendarViewDelegate delegate) {
        return isCalendarInRange(calendarBean,
                delegate.getMinDate().getYear(), delegate.getMinDate().getMonth(), delegate.getMinDate().getDay(),
                delegate.getMaxDate().getYear(), delegate.getMaxDate().getMonth(), delegate.getMaxDate().getDay());
    }

    /**
     * 是否在日期范围內
     *
     * @param year         year
     * @param month        month
     * @param minYear      minYear
     * @param minYearMonth minYearMonth
     * @param maxYear      maxYear
     * @param maxYearMonth maxYearMonth
     * @return 是否在日期范围內
     */
    static boolean isMonthInRange(int year, int month, int minYear, int minYearMonth, int maxYear, int maxYearMonth) {
        return !(year < minYear || year > maxYear) &&
                !(year == minYear && month < minYearMonth) &&
                !(year == maxYear && month > maxYearMonth);
    }

    /**
     * 运算 maxBean - minBean 间隔天数
     * test Pass
     *
     * @param maxBean maxBean
     * @param minBean minBean
     * @return maxBean - minBean 间隔天数
     */
    static int differ(CalendarBean maxBean, CalendarBean minBean) {
        if (maxBean == null) {
            return Integer.MIN_VALUE;
        }
        if (minBean == null) {
            return Integer.MAX_VALUE;
        }

        Calendar calendar = maxBean.newCalendar();
        long maxTimeMills = calendar.getTimeInMillis(); // 获得起始时间戳
        calendar.set(minBean.getYear(), minBean.getMonth() - 1, minBean.getDay());
        long minTimeMills = calendar.getTimeInMillis(); // 获得结束时间戳
        return (int) ((maxTimeMills - minTimeMills) / ONE_DAY_MILLIS);
    }

    /**
     * 比较日期大小
     *
     * @param minYear      minYear
     * @param minYearMonth minYearMonth
     * @param minYearDay   minYearDay
     * @param maxYear      maxYear
     * @param maxYearMonth maxYearMonth
     * @param maxYearDay   maxYearDay
     * @return -1 0 1
     */
    static int compareTo(int minYear, int minYearMonth, int minYearDay,
                         int maxYear, int maxYearMonth, int maxYearDay) {
        CalendarBean first = new CalendarBean(minYear, minYearMonth, minYearDay);
        CalendarBean second = new CalendarBean(maxYear, maxYearMonth, maxYearDay);
        return first.compareTo(second);
    }

    /**
     * 为月视图初始化日历
     *
     * @param year     year
     * @param month    month
     * @param weekStar weekStar
     * @return 为月视图初始化日历项
     */
    static List<CalendarBean> initCalendarForMonthView(int year, int month, @CalendarConstants.WeekStart int weekStar) {
        int startOffset = getMonthViewStartOffset(year, month, weekStar); // 获取月视图起始偏移量
        int monthDayCount = getMonthDaysCount(year, month); // 获取月份真实天数

        int preYear, preMonth;
        int nextYear, nextMonth;
        if (month == 1) { // 如果是1月
            preYear = year - 1;
            preMonth = 12;
            nextYear = year;
            nextMonth = month + 1;
        } else if (month == 12) { // 如果是12月
            preYear = year;
            preMonth = month - 1;
            nextYear = year + 1;
            nextMonth = 1;
        } else { // 正常中间月份
            preYear = year;
            preMonth = month - 1;
            nextYear = year;
            nextMonth = month + 1;
        }
        // startOffset 为 0 时不需要使用该值
        int preMonthDaysCount = startOffset == 0 ? 0 : getMonthDaysCount(preYear, preMonth);

        List<CalendarBean> itemList = new ArrayList<>();
        int nextDay = 1;
        for (int i = 0; i < 42; i++) {
            CalendarBean bean;
            if (i < startOffset) {
                bean = new CalendarBean(preYear, preMonth, preMonthDaysCount - startOffset + i + 1);
            } else if (i >= monthDayCount + startOffset) {
                bean = new CalendarBean(nextYear, nextMonth, nextDay++);
            } else {
                bean = new CalendarBean(year, month, i - startOffset + 1);
            }
            bean.setupCalendar();
            itemList.add(bean);
        }
        return itemList;
    }

    static List<CalendarBean> getWeekCalendars(CalendarBean bean, CalendarViewDelegateHorizontal delegate) {
        long curTime = bean.getTimeInMillis();
        int startDiff = getWeekViewStartOffset(bean.getYear(), bean.getMonth(), bean.getDay(), delegate.getWeekStart());
        curTime -= startDiff * ONE_DAY_MILLIS;
        Calendar minCalendar = Calendar.getInstance();
        minCalendar.setTimeInMillis(curTime);
        CalendarBean startCalendar = new CalendarBean(minCalendar);
        return initCalendarForWeekView(startCalendar, delegate, delegate.getWeekStart());
    }

    /**
     * 生成周视图的7个item
     *
     * @param calendarBean calendarBean
     * @param delegate     delegate
     * @param weekStart    weekStart
     * @return 生成周视图的7个item
     */
    static List<CalendarBean> initCalendarForWeekView(CalendarBean calendarBean, CalendarView.ICalendarViewDelegate delegate,
                                                      @CalendarConstants.WeekStart int weekStart) {
        int weekEndOffset = getWeekViewEndOffset(calendarBean.getYear(), calendarBean.getMonth(), calendarBean.getDay(), weekStart);
        List<CalendarBean> items = new ArrayList<>();

        Calendar calendar = calendarBean.newCalendar();
        CalendarBean selectCalendar = new CalendarBean(calendar);
        selectCalendar.setupCalendar();
        items.add(selectCalendar);

        long curDateMills = calendar.getTimeInMillis(); // 生成选择的日期时间戳
        for (int i = 1; i <= weekEndOffset; i++) {
            calendar.setTimeInMillis(curDateMills + i * ONE_DAY_MILLIS);
            CalendarBean calendarDate = new CalendarBean(calendar);
            calendarDate.setupCalendar();
            items.add(calendarDate);
        }
        return items;
    }

    /**
     * 从选定的日期，获取周视图起始偏移量，用来生成周视图布局
     *
     * @param year      year
     * @param month     month
     * @param day       day
     * @param weekStart 周起始，1，2，7 日 一 六
     * @return 获取周视图起始偏移量，用来生成周视图布局
     */
    private static int getWeekViewStartOffset(int year, int month, int day, @CalendarConstants.WeekStart int weekStart) {
        int week = getWeekForDay(year, month, day);
        return (week - weekStart + 7) % 7;
    }

    /**
     * 从选定的日期，获取周视图结束偏移量，用来生成周视图布局
     *
     * @param year      year
     * @param month     month
     * @param day       day
     * @param weekStart 周起始，1，2，7 日 一 六
     * @return 获取周视图结束偏移量，用来生成周视图布局
     */
    private static int getWeekViewEndOffset(int year, int month, int day, @CalendarConstants.WeekStart int weekStart) {
        int week = getWeekForDay(year, month, day);
        return 6 - (week - weekStart + 7) % 7;
    }

    /**
     * 从月视图切换获得第一天的日期
     *
     * @param position position
     * @param delegate position
     * @return 从月视图切换获得第一天的日期
     */
    static CalendarBean getFirstCalendarFromMonthViewPager(int position, BaseCalendarViewDelegate delegate) {
        int year = (position + delegate.getMinYearMonth() - 1) / 12 + delegate.getMinYear();
        int month = (position + delegate.getMinYearMonth() - 1) % 12 + 1;
        int day;
        if (delegate.getCalendarAutoSelectMode() != CalendarConstants.AUTO_FOCUS_MODE_FIRST_DAY_OF_MONTH) {
            CalendarBean calendarBean = delegate.mIndexCalendar;
            day = calendarBean == null || calendarBean.getDay() == 0
                    ? 1
                    : Math.min(getMonthDaysCount(year, month), calendarBean.getDay());
        } else {
            day = 1;
        }
        CalendarBean calendarBean = new CalendarBean(year, month, day);
        if (!isCalendarInRange(calendarBean, delegate)) {
            if (isMinRangeEdge(calendarBean, delegate)) {
                calendarBean = delegate.getMinDate();
            } else {
                calendarBean = delegate.getMaxDate();
            }
        }
        calendarBean.setupCalendar();
        return calendarBean;
    }

    /**
     * 根据传入的日期获取边界访问日期，要么最大，要么最小
     *
     * @param calendarBean calendarBean
     * @param delegate     delegate
     * @return 获取边界访问日期
     */
    static CalendarBean getRangeEdgeCalendar(CalendarBean calendarBean, BaseCalendarViewDelegate delegate) {
        if (isCalendarInRange(delegate.getCurrentDay(), delegate)
                && delegate.getCalendarAutoSelectMode() != CalendarConstants.AUTO_FOCUS_MODE_LAST_MONTH_SELECT_DAY_IGNORE_CURRENT) {
            return delegate.getCurrentDay();
        }
        if (isCalendarInRange(calendarBean, delegate)) {
            return calendarBean;
        }
        if (delegate.getMinDate().isSameMonth(calendarBean)) {
            return delegate.getMinDate();
        }
        return delegate.getMaxDate();
    }

    /**
     * 是否是最小访问边界了
     *
     * @param calendarBean calendarBean
     * @return 是否是最小访问边界了
     */
    private static boolean isMinRangeEdge(CalendarBean calendarBean, BaseCalendarViewDelegate delegate) {
        Calendar c = calendarBean.newCalendar();
        long curTime = c.getTimeInMillis();
        c.set(delegate.getMinYear(), delegate.getMinYearMonth() - 1, delegate.getMinYearDay());
        long minTime = c.getTimeInMillis();
        return curTime < minTime;
    }

    /**
     * dp转px
     *
     * @param context context
     * @param dpValue dp
     * @return px
     */
    public static int dp2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * sp转px
     *
     * @param context context
     * @param spValue sp
     * @return px
     */
    public static int sp2px(Context context, float spValue) {
        float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }

    static Locale getLocaleFromContext(Context context) {
        Locale locale;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            locale = context.getResources().getConfiguration().getLocales().get(0);
        } else {
            locale = context.getResources().getConfiguration().locale;
        }
        return locale != null ? locale : Locale.getDefault();
    }

    static boolean isValidDayOfWeek(int day) {
        return day >= Calendar.SUNDAY && day <= Calendar.SATURDAY;
    }

}
