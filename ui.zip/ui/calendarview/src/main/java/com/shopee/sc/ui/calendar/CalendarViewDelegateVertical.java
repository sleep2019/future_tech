package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 垂直日历，只支持月视图垂直滑动
 * <p>
 * Created by honggang.xiong on 2020-03-16.
 */
public class CalendarViewDelegateVertical extends BaseCalendarViewDelegate {
    private final boolean mUseInRn;
    private CompatibleRecyclerView mRvVerticalCalendar;
    private VerticalCalendarAdapter mVerticalAdapter;
    private LinearLayoutManager mLayoutManager;
    private int mCurrentMonthIndex = 0;

    int mMonthNameHeight;
    int mMonthNamePaddingHorizontal;
    int mMonthNamePaddingVertical;
    int mMonthNameTextSize;
    int mMonthNameTextColor;
    Drawable mMonthNameBackgroundDrawable;
    String mMonthNameFormat;

    public CalendarViewDelegateVertical(CalendarView delegator, Context context, @Nullable AttributeSet attrs) {
        super(delegator, context, attrs);
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.CalendarView);
        mUseInRn = array.getBoolean(R.styleable.CalendarView_use_in_react_native,false);
        mMonthNameHeight = array.getDimensionPixelSize(R.styleable.CalendarView_vertical_style_month_name_height,
                CalendarUtil.dp2px(context, 38));
        mMonthNamePaddingHorizontal = array.getDimensionPixelSize(R.styleable.CalendarView_vertical_style_month_name_padding_horizontal,
                CalendarUtil.dp2px(context, 16));
        mMonthNamePaddingVertical = array.getDimensionPixelSize(R.styleable.CalendarView_vertical_style_month_name_padding_vertical, 0);
        mMonthNameTextSize = array.getDimensionPixelSize(R.styleable.CalendarView_vertical_style_month_name_text_size,
                CalendarUtil.sp2px(context, 16));
        mMonthNameTextColor = array.getColor(R.styleable.CalendarView_vertical_style_month_name_text_color, 0xFF303844);
        mMonthNameBackgroundDrawable = array.getDrawable(R.styleable.CalendarView_vertical_style_month_name_background);
        mMonthNameFormat = array.getString(R.styleable.CalendarView_vertical_style_month_name_format);
        array.recycle();
        initView(context);
    }

    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.cv_layout_calendar_view_vertical, mDelegator, true);
        ViewGroup frameContent = mDelegator.findViewById(R.id.frameContent);
        frameContent.addView(mWeekBar, 0);
        mWeekBar.setDelegate(this);
        mWeekBar.onWeekStartChange(getWeekStart());

        mInnerListener = new CalendarView.OnInnerDateSelectedListener() {

            @Override
            public void onMonthDateSelected(CalendarBean calendarBean, boolean isClick) {
                mIndexCalendar = calendarBean;
                if (isClick) {
                    mSelectedCalendar = calendarBean;
                    mWeekBar.onDateSelected(calendarBean, getWeekStart(), isClick);
                }
                mVerticalAdapter.notifyDataSetChanged();
            }

            @Override
            public void onWeekDateSelected(CalendarBean calendarBean, boolean isClick) {

            }
        };

        mIndexCalendar = mSelectedCalendar = new CalendarBean(0, 0, 0);
        mWeekBar.onDateSelected(mSelectedCalendar, getWeekStart(), false);

        mRvVerticalCalendar = mDelegator.findViewById(R.id.rv_vertical_calendar);
        mRvVerticalCalendar.setUseInRn(mUseInRn);
        mLayoutManager = new LinearLayoutManager(context);
        mRvVerticalCalendar.setLayoutManager(mLayoutManager);
        mVerticalAdapter = new VerticalCalendarAdapter(context);
        mRvVerticalCalendar.setAdapter(mVerticalAdapter);
        mVerticalAdapter.setDelegate(this);
        mRvVerticalCalendar.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                if (Math.abs(dy) > 0) {
                    int position = mLayoutManager.findFirstCompletelyVisibleItemPosition();
                    if (position == RecyclerView.NO_POSITION) {
                        position = mLayoutManager.findFirstVisibleItemPosition();
                    }
                    int monthIndex = position / 2;
                    onMonthIndexChanged(monthIndex);
                }
            }
        });

        if (mVerticalAdapter.getCurDayMonthIndex() >= 0) {
            scrollToCurrent(false);
        }
    }

    private void onMonthIndexChanged(int index) {
        Log.i(TAG, "onMonthIndexChanged: " + index);
        if (mCurrentMonthIndex == index) {
            return;
        }

        mCurrentMonthIndex = index;
        CalendarBean bean = CalendarUtil.getFirstCalendarFromMonthViewPager(index, this);
        if (mIndexCalendar != null && bean.getYear() != mIndexCalendar.getYear()
                && mYearChangeListener != null) {
            mYearChangeListener.onYearChange(bean.getYear());
        }
        mIndexCalendar = bean;

        // 月份改变事件
        if (mMonthChangeListener != null) {
            mMonthChangeListener.onMonthChange(bean.getYear(), bean.getMonth());
        }

        if (mRangeSelectStartCalendar != null && mRangeSelectStartCalendar.isSameMonth(mIndexCalendar)) {
            mIndexCalendar = mRangeSelectStartCalendar;
        } else {
            if (bean.isSameMonth(mSelectedCalendar)) {
                mIndexCalendar = mSelectedCalendar;
            }
        }

        updateSelectCalendarScheme();
    }


    @Override
    protected void updateStyle() {
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void updateScheme() {
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void clearAndRefreshView() {
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void setRange(CalendarBean minDate, CalendarBean maxDate) {
        super.setRange(minDate, maxDate);
        if (mVerticalAdapter != null) {
            mVerticalAdapter.setDelegate(this);
        }
    }

    @Override
    public void setSelectMode(int selectMode) {
        // 不支持自动选择模式
        if (selectMode == CalendarConstants.SELECT_MODE_AUTO) {
            selectMode = CalendarConstants.SELECT_MODE_SINGLE;
        }
        super.setSelectMode(selectMode);
    }

    @Override
    public List<CalendarBean> getCurrentWeekCalendars() {
        return Collections.emptyList();
    }

    @Override
    public List<CalendarBean> getCurrentMonthCalendars() {
        CalendarBean currentMonth = mVerticalAdapter.getMonth(mCurrentMonthIndex);
        List<CalendarBean> result = new ArrayList<>();
        for (int i = 1; i <= CalendarUtil.getMonthDaysCount(currentMonth.getYear(), currentMonth.getMonth()); i++) {
            result.add(new CalendarBean(currentMonth.getYear(), currentMonth.getMonth(), i));
        }
        return result;
    }

    @Override
    public void setBackground(int yearViewBackground, int weekBackground, int lineBg) {
        mWeekBar.setBackgroundColor(weekBackground);
    }

    @Override
    public void scrollToCurrent(boolean smoothScroll) {
        scrollToCalendar(getCurrentDay().getYear(), getCurrentDay().getMonth(), getCurrentDay().getDay(),
                smoothScroll, false);
        if (CalendarUtil.isCalendarInRange(getCurrentDay(), this)) {
            mIndexCalendar = mSelectedCalendar = getCurrentDay();
            updateSelectCalendarScheme();
        }
    }

    private void scrollToPosition(int monthIndex, boolean smoothScroll) {
        int adapterPos = monthIndex * 2;
        if (adapterPos < 0) {
            adapterPos = 0;
        } else if (adapterPos >= mVerticalAdapter.getItemCount()) {
            adapterPos = mVerticalAdapter.getItemCount() - 1;
        }
        if (smoothScroll) {
            mRvVerticalCalendar.smoothScrollToPosition(adapterPos);
        } else {
            mRvVerticalCalendar.scrollToPosition(adapterPos);
        }
        onMonthIndexChanged(monthIndex);
    }

    @Override
    public void scrollToNext(boolean smoothScroll) {
        scrollToPosition(mCurrentMonthIndex + 1, false);
    }

    @Override
    public void scrollToPre(boolean smoothScroll) {
        scrollToPosition(mCurrentMonthIndex - 1, false);
    }

    @Override
    public void scrollToSelectCalendar(boolean smoothScroll, boolean invokeListener) {
        if (!mSelectedCalendar.isAvailable()) {
            return;
        }
        scrollToCalendar(mSelectedCalendar.getYear(), mSelectedCalendar.getMonth(), mSelectedCalendar.getDay(),
                smoothScroll, invokeListener);
    }

    @Override
    public void scrollToCalendar(int year, int month, int day, boolean smoothScroll, boolean invokeListener) {
        CalendarBean calendarBean = new CalendarBean(year, month, day);
        if (!calendarBean.isAvailable()) {
            return;
        }
        if (!CalendarUtil.isCalendarInRange(calendarBean, this)) {
            return;
        }
        if (isCalendarIntercepted(calendarBean)) {
            mCalendarInterceptListener.onCalendarInterceptClick(calendarBean, false);
            return;
        }

        int position = 12 * (calendarBean.getYear() - getMinYear()) + calendarBean.getMonth() - getMinYearMonth();
        scrollToPosition(position, smoothScroll);
    }

    @Override
    public void scrollToYear(int year, boolean smoothScroll) {
        scrollToCalendar(year, 1, 1, smoothScroll, false);
    }

    @Override
    public WeekBar getWeekBar() {
        return mWeekBar;
    }

    @Override
    public void setWeekBar(WeekBar weekBar) {
        if (weekBar == null || mWeekBar == weekBar) {
            return;
        }
        ViewGroup frameContent = mDelegator.findViewById(R.id.frameContent);
        frameContent.removeView(mWeekBar);
        mWeekBar = weekBar;
        frameContent.addView(mWeekBar, 0);
        mWeekBar.setDelegate(this);
        mWeekBar.onWeekStartChange(getWeekStart());
        mWeekBar.onDateSelected(mSelectedCalendar, getWeekStart(), false);
    }

    @Override
    public void clearRangeSelect() {
        mRangeSelectStartCalendar = null;
        mRangeSelectEndCalendar = null;
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void clearSingleSelect() {
        mSelectedCalendar = new CalendarBean(0, 0, 0);
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void clearMultiSelect() {
        mMultiSelectCalendars.clear();
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void setWeekStart(int weekStart) {
        super.setWeekStart(weekStart);
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void setMonthShowMode(int monthViewShowMode) {
        super.setMonthShowMode(monthViewShowMode);
        if (mVerticalAdapter != null) {
            mVerticalAdapter.notifyDataSetChanged();
        }
    }

    // not support the operations below
    @Override
    public void setCalendarLayout(CalendarLayout calendarLayout) {

    }

    @Override
    public boolean isMonthViewScrollable() {
        return false;
    }

    @Override
    public void setMonthViewScrollable(boolean monthViewScrollable) {

    }

    @Override
    public boolean isWeekViewScrollable() {
        return false;
    }

    @Override
    public void setWeekViewScrollable(boolean weekViewScrollable) {

    }

    @Override
    public boolean isYearViewScrollable() {
        return false;
    }

    @Override
    public void setYearViewScrollable(boolean yearViewScrollable) {

    }

    @Override
    public boolean isYearSelectLayoutVisible() {
        return false;
    }

    @Override
    public void showYearSelectLayout(int year) {

    }

    @Override
    public void closeYearSelectLayout() {

    }

}
