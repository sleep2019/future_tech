package com.shopee.sc.ui.calendar;

import android.graphics.Color;
import android.text.TextUtils;

import androidx.annotation.ColorInt;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * 日历对象
 */
public class CalendarBean implements Serializable, Comparable<CalendarBean> {

    private static final long serialVersionUID = 141315161718191143L;

    @IntRange(from = CalendarConstants.MIN_YEAR, to = CalendarConstants.MAX_YEAR)
    private final int year;  // 年份

    @IntRange(from = 1, to = 12)
    private final int month; // 月份 1-12

    @IntRange(from = 1, to = 31)
    private final int day;   // 日期 1-31

    private final int snapshot; // yyyyMMdd 形式的整数

    /**
     * 星期, 取值 {@link Calendar#DAY_OF_WEEK} (1-7) 对应周日到周六
     */
    private int week;

    /**
     * 公历节日
     */
    private String solarFestival;

    /**
     * 默认事件标记，用来标记当天是否有任务。
     * <p>
     * 如需使用多标记，可调用 {@link #addScheme(int, String)}
     */
    private String scheme;

    /**
     * 默认事件标记颜色，没有则选择默认颜色。
     * <p>
     * 如需使用多标记，可调用 {@link #addScheme(int, String)}
     */
    private int schemeColor;

    /**
     * 多标记
     */
    private List<SchemeBean> schemeList;

    /**
     * 其他历法日历对象，默认为空
     */
    private BaseSubCalendarBean subCalendarBean;

    public CalendarBean(@NonNull Calendar calendar) {
        this(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH));
    }

    public CalendarBean(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
        snapshot = year * 10000 + month * 100 + day;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public int getSchemeColor() {
        return schemeColor;
    }

    public void setSchemeColor(int schemeColor) {
        this.schemeColor = schemeColor;
    }

    @Nullable
    public List<SchemeBean> getSchemeList() {
        return schemeList;
    }

    public void setSchemeList(@Nullable List<SchemeBean> schemeList) {
        this.schemeList = schemeList;
    }

    public void addScheme(@NonNull SchemeBean schemeBean) {
        if (schemeList == null) {
            schemeList = new ArrayList<>();
        }
        schemeList.add(schemeBean);
    }

    public void addScheme(@ColorInt int schemeColor, String scheme) {
        if (schemeList == null) {
            schemeList = new ArrayList<>();
        }
        schemeList.add(new SchemeBean(schemeColor, scheme));
    }

    /**
     * 获取星期，延迟初始化。取值 {@link Calendar#DAY_OF_WEEK} (1-7) 对应周日到周六
     */
    public int getWeek() {
        if (week == 0) {
            week = CalendarUtil.getWeekFormCalendar(this);
        }
        return week;
    }

    // 快速批量设置星期，内部使用
    void setWeek(int week) {
        this.week = week;
    }

    public boolean isWeekend() {
        int week = getWeek();
        return week == Calendar.SATURDAY || week == Calendar.SUNDAY;
    }

    /**
     * 公历节日
     */
    public String getSolarFestival() {
        return solarFestival;
    }

    public void setSolarFestival(String solarFestival) {
        this.solarFestival = solarFestival;
    }

    public boolean hasScheme() {
        if (schemeList != null && schemeList.size() != 0) {
            return true;
        }
        return !TextUtils.isEmpty(scheme);
    }

    /**
     * 是否是相同月份
     *
     * @param other 日期
     * @return 是否是相同月份
     */
    public boolean isSameMonth(@NonNull CalendarBean other) {
        return year == other.getYear() && month == other.getMonth();
    }

    public boolean isSameMonth(int year, int month) {
        return this.year == year && this.month == month;
    }

    /**
     * 比较日期
     *
     * @param other 日期
     * @return -1 0 1
     */
    public int compareTo(CalendarBean other) {
        if (other == null) {
            return 1;
        }
        return Integer.compare(snapshot, other.snapshot);
    }

    /**
     * 运算差距多少天，正数代表 other 为本日期之前的日期，负数则为之后的日期。
     *
     * @param other CalendarBean
     * @return 运算差距多少天
     */
    public final int differ(CalendarBean other) {
        return CalendarUtil.differ(this, other);
    }

    /**
     * 日期是否可用
     *
     * @return 日期是否可用
     */
    public boolean isAvailable() {
        return year > 0 & month > 0 & day > 0
                & day <= 31 & month <= 12
                & year >= CalendarConstants.MIN_YEAR & year <= CalendarConstants.MAX_YEAR;
    }

    /**
     * 日期是否有效
     */
    public boolean isValid() {
        if (day <= 0) return false;
        int dayCount = CalendarUtil.getMonthDaysCount(year, month);
        return dayCount > 0 && dayCount >= day;
    }

    public BaseSubCalendarBean getSubCalendarBean() {
        return subCalendarBean;
    }

    /**
     * 获取当前日历对应的 Calendar
     */
    public Calendar newCalendar() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        return calendar;
    }

    /**
     * 获取当前日历对应时间戳
     *
     * @return getTimeInMillis
     */
    public long getTimeInMillis() {
        return newCalendar().getTimeInMillis();
    }

    // 年月日确定后，通过该方法设置其他属性，也可通过 CalendarHookUtil 生成副日历，如农历等
    protected void setupCalendar() {
        String solarFestival = CalendarUtil.getSolarFestival(month, day);
        if (TextUtils.isEmpty(solarFestival)) {
            solarFestival = CalendarUtil.getSpecialFestival(year, month, day);
        }
        setSolarFestival(solarFestival);
        subCalendarBean = CalendarHookUtil.generate(year, month, day);
    }

    // 返回节日。如有其他历法，优先返回其他历法的节日，如农历信息等
    public String getFestival() {
        if (subCalendarBean != null) {
            if (!TextUtils.isEmpty(subCalendarBean.getFestival())) {
                return subCalendarBean.getFestival();
            }
            if (!TextUtils.isEmpty(getSolarFestival())) {
                return getSolarFestival();
            }
            if (!TextUtils.isEmpty(subCalendarBean.getDayText())) {
                return subCalendarBean.getDayText();
            }
        }
        return getSolarFestival();
    }

    @Override
    public int hashCode() {
        return snapshot;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof CalendarBean) {
            CalendarBean another = (CalendarBean) obj;
            return another.getYear() == year && another.getMonth() == month && another.getDay() == day;
        }
        return false;
    }

    @NonNull
    @Override
    public String toString() {
        return year + "" + (month < 10 ? "0" + month : month) + "" + (day < 10 ? "0" + day : day);
    }

    final void mergeScheme(CalendarBean bean, String defaultScheme) {
        if (bean == null) {
            return;
        }
        setScheme(TextUtils.isEmpty(bean.getScheme()) ? defaultScheme : bean.getScheme());
        setSchemeColor(bean.getSchemeColor());
        setSchemeList(bean.getSchemeList());
    }

    final void clearScheme() {
        setScheme("");
        setSchemeColor(0);
        setSchemeList(null);
    }

    /**
     * 事件标记对象，现在多类型的事务标记建议使用这个
     */
    public final static class SchemeBean implements Serializable {
        public static final int SCHEME_TYPE_DEFAULT = 0;
        @ColorInt
        private int schemeColor;
        private String scheme;
        private int type;
        private String other;
        private Object obj;

        public SchemeBean() {
            this(Color.TRANSPARENT, null, SCHEME_TYPE_DEFAULT);
        }

        public SchemeBean(@ColorInt int schemeColor, String scheme) {
            this(schemeColor, scheme, SCHEME_TYPE_DEFAULT);
        }

        public SchemeBean(@ColorInt int schemeColor, String scheme, int type) {
            this(schemeColor, scheme, type, null, null);
        }

        public SchemeBean(@ColorInt int schemeColor, String scheme, int type, String other, Object obj) {
            this.schemeColor = schemeColor;
            this.scheme = scheme;
            this.type = type;
            this.other = other;
            this.obj = obj;
        }

        @ColorInt
        public int getSchemeColor() {
            return schemeColor;
        }

        public void setSchemeColor(@ColorInt int schemeColor) {
            this.schemeColor = schemeColor;
        }

        public String getScheme() {
            return scheme;
        }

        public void setScheme(String scheme) {
            this.scheme = scheme;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public String getOther() {
            return other;
        }

        public void setOther(String other) {
            this.other = other;
        }

        public Object getObj() {
            return obj;
        }

        public void setObj(Object obj) {
            this.obj = obj;
        }
    }

}
