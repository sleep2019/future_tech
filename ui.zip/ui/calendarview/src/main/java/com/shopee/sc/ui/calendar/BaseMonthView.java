package com.shopee.sc.ui.calendar;

import android.content.Context;

import java.util.Objects;

/**
 * 月视图基础控件
 */
public abstract class BaseMonthView extends BaseView {

    MonthViewPager mMonthViewPager;

    /**
     * 当前日历卡年份
     */
    protected int mYear;

    /**
     * 当前日历卡月份
     */
    protected int mMonth;

    /**
     * 日历的行数
     */
    protected int mLineCount;

    /**
     * 日历总高度
     */
    protected int mTotalHeight;

    /**
     * 下个月偏移的数量
     */
    protected int mNextOffset;

    public BaseMonthView(Context context) {
        super(context);
    }

    /**
     * 初始化日期
     *
     * @param year  year
     * @param month month
     */
    final void setMonthViewDate(int year, int month) {
        if (mYear == year && mMonth == month) {
            return;
        }
        mYear = year;
        mMonth = month;
        resetCalendars();
    }

    /**
     * 初始化日历
     */
    private void resetCalendars() {
        mItemList = CalendarUtil.initCalendarForMonthView(mYear, mMonth, mDelegate.getWeekStart());
        if (mItemList.contains(mDelegate.getCurrentDay())) {
            mSelectedBean = mDelegate.getCurrentDay();
        } else {
            mSelectedBean = mDelegate.mSelectedCalendar;
        }

        if (mDelegate.isCalendarIntercepted(mSelectedBean)) {
            mSelectedBean = null;
        }

        mNextOffset = CalendarUtil.getMonthEndOffset(mYear, mMonth, mDelegate.getWeekStart());
        calculateLineCountAndHeight();
        mDelegate.addSchemesFromMap(mItemList);

        requestLayout();
        invalidate();
    }

    /**
     * 记录已经选择的日期
     */
    final void setSelectedCalendar(CalendarBean bean) {
        if (!Objects.equals(mSelectedBean, bean)) {
            mSelectedBean = bean;
            invalidate();
        }
    }

    /**
     * 更新月显示模式
     */
    final void handleMonthShowModeChanged() {
        calculateLineCountAndHeight();
        requestLayout();
        invalidate();
    }

    /**
     * 更新周起始
     */
    final void handleWeekStartChanged() {
        resetCalendars();
    }

    @Override
    void updateItemHeight() {
        super.updateItemHeight();
        calculateLineCountAndHeight();
        requestLayout();
        invalidate();
    }

    private void calculateLineCountAndHeight() {
        if (mYear == 0 || mMonth == 0) {
            return;
        }

        mLineCount = CalendarUtil.getMonthViewLineCount(mYear, mMonth, mDelegate);
        mTotalHeight = mItemHeight * mLineCount + mDelegate.getMonthWeekPaddingTop() + mDelegate.getMonthWeekPaddingBottom();
    }

    /**
     * 获取选中的下标
     *
     * @param bean CalendarBean
     * @return 获取选中的下标
     */
    protected final int getSelectedIndex(CalendarBean bean) {
        return mItemList.indexOf(bean);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mLineCount != 0) {
            heightMeasureSpec = MeasureSpec.makeMeasureSpec(mTotalHeight, MeasureSpec.EXACTLY);
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

}
