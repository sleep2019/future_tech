package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;

/**
 * Base painter for normal month/week view, also can be extended for year view.
 * <p>
 * Created by honggang.xiong on 2020-03-12.
 */
public abstract class BaseMonthWeekPainter {

    BaseCalendarViewDelegate mDelegate;

    // 建议画笔使用顺序：选中 > 当天 > 标记 > 当月 > 其他月
    /**
     * 选中日期文本画笔
     */
    protected final Paint mSelectedTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 当前日期文本画笔
     */
    protected final Paint mCurDayTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 标记日期文本画笔
     */
    protected final Paint mSchemeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 当前月份日期文本画笔
     */
    protected final Paint mCurMonthTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 其它月份日期文本画笔
     */
    protected final Paint mOtherMonthTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 选中日期背景画笔
     */
    protected final Paint mSelectedBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 标记日期背景画笔
     */
    protected final Paint mSchemeBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);


    /**
     * 选中日期节日文本画笔
     */
    protected final Paint mSelectedFestivalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 当前日期节日文本画笔
     */
    protected final Paint mCurDayFestivalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 标记日期节日文本颜色
     */
    protected final Paint mSchemeFestivalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 当前月份节日文本画笔
     */
    protected final Paint mCurMonthFestivalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 其它月份节日文本画笔
     */
    protected final Paint mOtherMonthFestivalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * 每一项的高度
     */
    protected int mItemHeight;

    /**
     * 每一项的宽度
     */
    protected int mItemWidth;

    /**
     * Text的基线
     */
    protected float mTextBaseLine;

    protected BaseMonthWeekPainter(Context context) {
        initPaint(context);
        initCustomPaint(context);
    }

    /**
     * 初始化配置
     *
     * @param context context
     */
    private void initPaint(Context context) {
        final int defaultTextSize = CalendarUtil.sp2px(context, getDefaultTextSizeInSp());
        mSelectedTextPaint.setStyle(Paint.Style.FILL);
        mSelectedTextPaint.setTextAlign(Paint.Align.CENTER);
        mSelectedTextPaint.setColor(0xFFED5353);
        mSelectedTextPaint.setTextSize(defaultTextSize);

        mCurDayTextPaint.setTextAlign(Paint.Align.CENTER);
        mCurDayTextPaint.setColor(Color.RED);
        mCurDayTextPaint.setTextSize(defaultTextSize);

        mSchemeTextPaint.setStyle(Paint.Style.FILL);
        mSchemeTextPaint.setTextAlign(Paint.Align.CENTER);
        mSchemeTextPaint.setColor(0xFFED5353);
        mSchemeTextPaint.setTextSize(defaultTextSize);

        mCurMonthTextPaint.setTextAlign(Paint.Align.CENTER);
        mCurMonthTextPaint.setColor(0xFF111111);
        mCurMonthTextPaint.setTextSize(defaultTextSize);

        mOtherMonthTextPaint.setTextAlign(Paint.Align.CENTER);
        mOtherMonthTextPaint.setColor(0xFFE1E1E1);
        mOtherMonthTextPaint.setTextSize(defaultTextSize);

        mSelectedBgPaint.setStyle(Paint.Style.FILL);
        mSelectedBgPaint.setStrokeWidth(2);

        mSchemeBgPaint.setStyle(Paint.Style.FILL);
        mSchemeBgPaint.setStrokeWidth(2);
        mSchemeBgPaint.setColor(0xFFEFEFEF);

        mCurDayFestivalPaint.setTextAlign(Paint.Align.CENTER);
        mCurDayFestivalPaint.setColor(Color.RED);
        mCurDayFestivalPaint.setTextSize(defaultTextSize);

        mSelectedFestivalPaint.setTextAlign(Paint.Align.CENTER);
        mSchemeFestivalPaint.setTextAlign(Paint.Align.CENTER);
        mCurMonthFestivalPaint.setTextAlign(Paint.Align.CENTER);
        mOtherMonthFestivalPaint.setTextAlign(Paint.Align.CENTER);
    }

    protected int getDefaultTextSizeInSp() {
        return 14;
    }

    final void setDelegate(BaseCalendarViewDelegate delegate) {
        mDelegate = delegate;
        updateStyle();
    }

    protected void updateStyle() {
        if (mDelegate == null) {
            return;
        }
        mSelectedTextPaint.setColor(mDelegate.getSelectedTextColor());
        mCurDayTextPaint.setColor(mDelegate.getCurDayTextColor());
        mSchemeTextPaint.setColor(mDelegate.getSchemeTextColor());
        mCurMonthTextPaint.setColor(mDelegate.getCurMonthTextColor());
        mOtherMonthTextPaint.setColor(mDelegate.getOtherMonthTextColor());

        mSelectedFestivalPaint.setColor(mDelegate.getSelectedFestivalTextColor());
        mCurDayFestivalPaint.setColor(mDelegate.getCurDayFestivalTextColor());
        mSchemeFestivalPaint.setColor(mDelegate.getSchemeFestivalTextColor());
        mCurMonthFestivalPaint.setColor(mDelegate.getCurMonthFestivalTextColor());
        mOtherMonthFestivalPaint.setColor(mDelegate.getOtherMonthFestivalTextColor());

        mSelectedTextPaint.setTextSize(mDelegate.getDayTextSize());
        mCurDayTextPaint.setTextSize(mDelegate.getDayTextSize());
        mSchemeTextPaint.setTextSize(mDelegate.getDayTextSize());
        mCurMonthTextPaint.setTextSize(mDelegate.getDayTextSize());
        mOtherMonthTextPaint.setTextSize(mDelegate.getDayTextSize());

        mSelectedFestivalPaint.setTextSize(mDelegate.getFestivalTextSize());
        mCurDayFestivalPaint.setTextSize(mDelegate.getFestivalTextSize());
        mSchemeFestivalPaint.setTextSize(mDelegate.getFestivalTextSize());
        mCurMonthFestivalPaint.setTextSize(mDelegate.getFestivalTextSize());
        mOtherMonthFestivalPaint.setTextSize(mDelegate.getFestivalTextSize());

        mSelectedBgPaint.setStyle(Paint.Style.FILL);
        mSelectedBgPaint.setColor(mDelegate.getSelectedThemeColor());
        mSchemeBgPaint.setColor(mDelegate.getSchemeThemeColor());
    }

    /**
     * 是否在日期范围内
     *
     * @param bean CalendarBean
     * @return 是否在日期范围内
     */
    protected final boolean isInRange(CalendarBean bean) {
        return mDelegate != null && CalendarUtil.isCalendarInRange(bean, mDelegate);
    }

    protected final boolean isCurrentDay(CalendarBean bean) {
        return mDelegate != null && mDelegate.getCurrentDay().equals(bean);
    }

    protected final boolean isCalendarIntercepted(CalendarBean bean) {
        return mDelegate != null && mDelegate.isCalendarIntercepted(bean);
    }

    /**
     * 初始化自定义画笔
     */
    protected void initCustomPaint(@NonNull Context context) {

    }

    /**
     * 开始绘制前的钩子，这里做一些初始化的操作，每次绘制只调用一次，性能高效
     * 没有需要可忽略不实现
     * 例如：
     * 1、需要绘制圆形标记事件背景，可以在这里计算半径
     * 2、绘制矩形选中效果，也可以在这里计算矩形宽和高
     */
    @CallSuper
    protected void onPreviewHook(int itemHeight, int itemWidth, float textBaseLine) {
        mItemHeight = itemHeight;
        mItemWidth = itemWidth;
        mTextBaseLine = textBaseLine;
    }

    /**
     * 循环绘制开始的回调，不需要可忽略
     * 绘制每个日历项的循环，用来计算 baseLine、圆心坐标等都可以在这里实现
     *
     * @param x 日历 Card x 起点坐标
     * @param y 日历 Card y 起点坐标
     */
    protected void onLoopStart(int x, int y) {

    }

    /**
     * 绘制选中日期背景，需要支持多选模式时重写该方法
     *
     * @param canvas         canvas
     * @param bean           日历 CalendarBean
     * @param x              日历 Card x 起点坐标
     * @param y              日历 Card y 起点坐标，周视图时恒为 0
     * @param hasScheme      hasScheme 非标记的日期
     * @param isSelectedPre  上一个日期是否选中, 默认及单选模式下恒为 false，多选或者范围选择时可能为 true
     * @param isSelectedNext 下一个日期是否选中, 默认及单选模式下恒为 false，多选或者范围选择时可能为 true
     * @return 是否继续绘制 onDrawScheme，true or false
     */
    protected abstract boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y,
                                                boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext);

    /**
     * 绘制标记的日期,这里可以是背景色，标记色什么的
     *
     * @param canvas     canvas
     * @param bean       日历 CalendarBean
     * @param x          日历 Card x 起点坐标
     * @param y          日历 Card y 起点坐标
     * @param isSelected 是否选中
     */
    protected abstract void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean isSelected);

    /**
     * 绘制日历文本
     *
     * @param canvas               canvas
     * @param bean                 日历 CalendarBean
     * @param x                    日历 Card x 起点坐标
     * @param y                    日历 Card y 起点坐标
     * @param isInCurrentMonthCard 当前 bean 是否属于当前月份 Card
     * @param hasScheme            是否是标记的日期
     * @param isSelected           是否选中
     */
    protected abstract void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y,
                                       boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected);

}
