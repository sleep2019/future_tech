package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.shopee.sc.ui.calendar.sticky.IStickyAdapter;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * 注意：支持吸顶后，一个月份实体对应两个 Adapter Item。需注意区分以下下标及其对应关系：
 * 1、monthIndex，月份实体下标，用 Index 为后缀作区分；
 * 2、monthNamePosition，Adapter 中 month name View 的下标，值为 2 * monthIndex；
 * 3、monthContentPosition，Adapter 中 month content View 的下标，值为 2 * monthIndex + 1；
 * <p>
 * Created by honggang.xiong on 2020-03-16.
 */
public class VerticalCalendarAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
        implements IStickyAdapter {

    private static final int ITEM_TYPE_MONTH_NAME_HEADER = 0x11;
    private static final int ITEM_TYPE_MONTH_VIEW = 0;

    private CalendarViewDelegateVertical mDelegate;
    private final String[] mMonthName;
    private Calendar mFormatCalendar;
    private SimpleDateFormat mDateFormat;
    // 保存最小年月即可
    private int mMinYear;
    private int mMinMonth;
    private int mMonthCount = 0;
    // 当天月份在月份列表中的下标
    private int mCurDayMonthIndex;

    public VerticalCalendarAdapter(Context context) {
        super();
        mMonthName = context.getResources().getStringArray(R.array.month_string_array);
    }

    public int getCurDayMonthIndex() {
        return mCurDayMonthIndex;
    }

    /**
     * Set Delegate
     */
    void setDelegate(CalendarViewDelegateVertical delegate) {
        mDelegate = delegate;
        updateMonthRange(delegate.getMinYear(), delegate.getMinYearMonth(), delegate.getMaxYear(), delegate.getMaxYearMonth());
        mCurDayMonthIndex = getMonthIndex(delegate.getCurrentDay());
    }

    private void updateMonthRange(int minYear, int minMonth, int maxYear, int maxMonth) {
        int monthCount = 12 * (maxYear - minYear) + maxMonth - minMonth + 1;
        if (monthCount < 0) {
            return;
        }

        mMinYear = minYear;
        mMinMonth = minMonth;
        mMonthCount = monthCount;
        notifyDataSetChanged();
    }

    int getMonthIndex(CalendarBean bean) {
        return getMonthIndex(bean.getYear(), bean.getMonth());
    }

    int getMonthIndex(int year, int month) {
        return 12 * (year - mMinYear) + month - mMinMonth;
    }

    CalendarBean getMonth(int monthIndex) {
        int year = (monthIndex + mMinMonth - 1) / 12 + mMinYear;
        int month = (monthIndex + mMinMonth - 1) % 12 + 1;
        return new CalendarBean(year, month, 1);
    }

    @Override
    public int getPreStickyIndexByPosition(int position) {
        if (position < 0 || position >= getItemCount()) {
            return -1;
        }

        for (int i = position; i >= 0; i--) {
            if (isStickyPos(i)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int getStickyPositionFromIndex(int stickyIndex) {
        return stickyIndex;
    }

    @Override
    public int getNextStickyIndexFromCurrent(int currentStickyIndex) {
        if (currentStickyIndex < 0 || currentStickyIndex >= getItemCount()) {
            return -1;
        }

        for (int i = currentStickyIndex + 1; i < getItemCount(); i++) {
            if (isStickyPos(i)) {
                return i;
            }
        }
        return -1;
    }

    private boolean isStickyPos(int position) {
        return position % 2 == 0;
    }

    /**
     * 支持吸顶，month name 提取为单独 item，则 item 数为月数的两倍
     */
    @Override
    public int getItemCount() {
        return mMonthCount * 2;
    }

    @Override
    public int getItemViewType(int position) {
        if (position % 2 == 0) {
            return ITEM_TYPE_MONTH_NAME_HEADER;
        }
        return ITEM_TYPE_MONTH_VIEW;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        if (viewType == ITEM_TYPE_MONTH_NAME_HEADER) {
            TextView tvMonth = new TextView(context);
            tvMonth.setTextSize(TypedValue.COMPLEX_UNIT_PX, mDelegate.mMonthNameTextSize);
            tvMonth.setTextColor(mDelegate.mMonthNameTextColor);
            tvMonth.setBackground(mDelegate.mMonthNameBackgroundDrawable);
            tvMonth.setGravity(Gravity.CENTER_VERTICAL);
            tvMonth.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            tvMonth.setPadding(mDelegate.mMonthNamePaddingHorizontal, mDelegate.mMonthNamePaddingVertical,
                    mDelegate.mMonthNamePaddingHorizontal, mDelegate.mMonthNamePaddingVertical);
            RecyclerView.LayoutParams lpForTv = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, mDelegate.mMonthNameHeight);
            tvMonth.setLayoutParams(lpForTv);
            return new MonthNameHolder(tvMonth, tvMonth);
        }

        BaseMonthView monthView = new SimpleMonthView(context);
        monthView.setDelegate(mDelegate);
        return new MonthContentHolder(monthView, monthView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        int monthIndex = position / 2;
        int year = (monthIndex + mMinMonth - 1) / 12 + mMinYear;
        int month = (monthIndex + mMinMonth - 1) % 12 + 1;
        if (holder instanceof MonthNameHolder) {
            MonthNameHolder nameHolder = (MonthNameHolder) holder;
            nameHolder.mTvMonth.setText(getMonthStr(holder.itemView.getContext(), year, month));
        } else if (holder instanceof MonthContentHolder) {
            MonthContentHolder contentHolder = (MonthContentHolder) holder;
            contentHolder.mBaseMonthView.setTag(monthIndex);
            contentHolder.mBaseMonthView.setMonthViewDate(year, month);
            contentHolder.mBaseMonthView.setSelectedCalendar(mDelegate.getSelectedCalendar());
        }
    }

    private String getMonthStr(Context context, int year, int month) {
        if (!TextUtils.isEmpty(mDelegate.mMonthNameFormat)) {
            if (mDateFormat == null) {
                try {
                    mDateFormat = new SimpleDateFormat(mDelegate.mMonthNameFormat, CalendarUtil.getLocaleFromContext(context));
                } catch (Exception e) {
                    e.printStackTrace();
                    // wrong format, reset mDelegate.mMonthFormat to null
                    mDelegate.mMonthNameFormat = null;
                    return mMonthName[month - 1] + " " + year;
                }
            }

            if (mFormatCalendar == null) {
                mFormatCalendar = Calendar.getInstance();
                mFormatCalendar.set(Calendar.DAY_OF_MONTH, 1);
            }
            mFormatCalendar.set(Calendar.YEAR, year);
            mFormatCalendar.set(Calendar.MONTH, month - 1);
            return mDateFormat.format(mFormatCalendar.getTime());
        }
        return mMonthName[month - 1] + " " + year;
    }


    static class MonthNameHolder extends RecyclerView.ViewHolder {
        TextView mTvMonth;

        public MonthNameHolder(@NonNull View itemView, TextView mTvMonth) {
            super(itemView);
            this.mTvMonth = mTvMonth;
        }
    }

    static class MonthContentHolder extends RecyclerView.ViewHolder {
        BaseMonthView mBaseMonthView;

        MonthContentHolder(View itemView, BaseMonthView monthView) {
            super(itemView);
            mBaseMonthView = monthView;
        }
    }

}
