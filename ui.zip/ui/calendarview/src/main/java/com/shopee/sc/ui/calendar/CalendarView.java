package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import androidx.annotation.ColorInt;
import androidx.annotation.Dimension;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import java.util.Map;

/**
 * 日历布局
 */
public class CalendarView extends FrameLayout {

    /**
     * 抽取自定义属性
     */
    private final ICalendarViewDelegate mDelegate;

    public static final int CALENDAR_STYLE_HORIZONTAL = 0;
    public static final int CALENDAR_STYLE_VERTICAL = 1;

    public CalendarView(@NonNull Context context) {
        this(context, null);
    }

    public CalendarView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.CalendarView);
        int style = ta.getInteger(R.styleable.CalendarView_calendar_style, CALENDAR_STYLE_HORIZONTAL);
        ta.recycle();

        if (style == CALENDAR_STYLE_HORIZONTAL) {
            mDelegate = new CalendarViewDelegateHorizontal(this, context, attrs);
        } else if (style == CALENDAR_STYLE_VERTICAL) {
            mDelegate = new CalendarViewDelegateVertical(this, context, attrs);
        } else {
            throw new IllegalArgumentException("illegal calendar style: " + style);
        }
    }

    /**
     * 设置日期范围
     *
     * @param minDate 最小日期
     * @param maxDate 最大日期
     */
    public void setRange(CalendarBean minDate, CalendarBean maxDate) {
        mDelegate.setRange(minDate, maxDate);
    }

    /**
     * 获取当天
     */
    public CalendarBean getCurrentDay() {
        return mDelegate.getCurrentDay();
    }

    /**
     * 获取当天
     */
    public int getCurDay() {
        return mDelegate.getCurrentDay().getDay();
    }

    /**
     * 获取本月
     */
    public int getCurMonth() {
        return mDelegate.getCurrentDay().getMonth();
    }

    /**
     * 获取本年
     */
    public int getCurYear() {
        return mDelegate.getCurrentDay().getYear();
    }


    /**
     * 年月份选择视图是否打开
     */
    public boolean isYearSelectLayoutVisible() {
        return mDelegate.isYearSelectLayoutVisible();
    }

    /**
     * 打开日历年视图快速选择月份
     */
    public void showYearSelectLayout(final int year) {
        mDelegate.showYearSelectLayout(year);
    }

    /**
     * 关闭年月视图选择布局
     */
    public void closeYearSelectLayout() {
        mDelegate.closeYearSelectLayout();
    }

    public void scrollToCurrent() {
        scrollToCurrent(false);
    }

    /**
     * 滚动到当前
     *
     * @param smoothScroll smoothScroll
     */
    public void scrollToCurrent(boolean smoothScroll) {
        mDelegate.scrollToCurrent(smoothScroll);
    }

    public void scrollToNext() {
        scrollToNext(false);
    }

    /**
     * 滚动到下一个月
     *
     * @param smoothScroll smoothScroll
     */
    public void scrollToNext(boolean smoothScroll) {
        mDelegate.scrollToNext(smoothScroll);
    }

    public void scrollToPre() {
        scrollToPre(false);
    }

    /**
     * 滚动到上一个月
     *
     * @param smoothScroll smoothScroll
     */
    public void scrollToPre(boolean smoothScroll) {
        mDelegate.scrollToPre(smoothScroll);
    }

    public void scrollToSelectCalendar() {
        scrollToSelectCalendar(false, true);
    }

    /**
     * 滚动到选择的日历
     *
     * @param smoothScroll   smoothScroll
     * @param invokeListener 调用日期事件
     */
    public void scrollToSelectCalendar(boolean smoothScroll, boolean invokeListener) {
        mDelegate.scrollToSelectCalendar(smoothScroll, invokeListener);
    }

    public void scrollToCalendar(int year, int month, int day) {
        scrollToCalendar(year, month, day, false);
    }

    public void scrollToCalendar(int year, int month, int day, boolean smoothScroll) {
        scrollToCalendar(year, month, day, smoothScroll, true);
    }

    /**
     * 滚动到指定日期
     *
     * @param year           year
     * @param month          month
     * @param day            day
     * @param smoothScroll   smoothScroll
     * @param invokeListener 调用日期事件
     */
    public void scrollToCalendar(int year, int month, int day, boolean smoothScroll, boolean invokeListener) {
        mDelegate.scrollToCalendar(year, month, day, smoothScroll, invokeListener);
    }

    public void scrollToYear(int year) {
        scrollToYear(year, false);
    }

    /**
     * 滚动到某一年
     *
     * @param year         快速滚动的年份
     * @param smoothScroll smoothScroll
     */
    public void scrollToYear(int year, boolean smoothScroll) {
        mDelegate.scrollToYear(year, smoothScroll);
    }

    /**
     * 设置月视图是否可滚动
     */
    public final void setMonthViewScrollable(boolean monthViewScrollable) {
        mDelegate.setMonthViewScrollable(monthViewScrollable);
    }

    /**
     * 设置周视图是否可滚动
     */
    public final void setWeekViewScrollable(boolean weekViewScrollable) {
        mDelegate.setWeekViewScrollable(weekViewScrollable);
    }

    /**
     * 设置年视图是否可滚动
     */
    public final void setYearViewScrollable(boolean yearViewScrollable) {
        mDelegate.setYearViewScrollable(yearViewScrollable);
    }

    public void setCalendarAutoSelectMode(@CalendarConstants.AutoFocusMode int autoSelectMode) {
        if (autoSelectMode == CalendarConstants.AUTO_FOCUS_MODE_FIRST_DAY_OF_MONTH
                || autoSelectMode == CalendarConstants.AUTO_FOCUS_MODE_LAST_MONTH_SELECT_DAY
                || autoSelectMode == CalendarConstants.AUTO_FOCUS_MODE_LAST_MONTH_SELECT_DAY_IGNORE_CURRENT) {
            mDelegate.setCalendarAutoSelectMode(autoSelectMode);
        }
    }

    /**
     * 清除选择范围
     */
    public final void clearRangeSelect() {
        mDelegate.clearRangeSelect();
    }

    /**
     * 清除单选
     */
    public final void clearSingleSelect() {
        mDelegate.clearSingleSelect();
    }

    /**
     * 清除多选
     */
    public final void clearMultiSelect() {
        mDelegate.clearMultiSelect();
    }

    /**
     * 添加选择
     *
     * @param calendarBeans CalendarBean array
     */
    public final void putMultiSelect(CalendarBean... calendarBeans) {
        mDelegate.putMultiSelect(calendarBeans);
    }

    /**
     * 清楚一些多选日期
     *
     * @param calendarBeans calendarBean array
     */
    public final void removeMultiSelect(CalendarBean... calendarBeans) {
        mDelegate.removeMultiSelect(calendarBeans);
    }

    /**
     * 获取多选模式选中日期
     */
    public final List<CalendarBean> getMultiSelectCalendars() {
        return mDelegate.getMultiSelectCalendars();
    }

    /**
     * 获取范围选择选中日期
     */
    public final List<CalendarBean> getRangeSelectCalendars() {
        return mDelegate.getRangeSelectCalendars();
    }

    /**
     * 设置月视图项高度
     *
     * @param calendarItemHeight MonthView item height
     */
    public final void setCalendarItemHeight(int calendarItemHeight) {
        mDelegate.setCalendarItemHeight(calendarItemHeight);
    }

    /**
     * 设置月周视图绘制器
     *
     * @param painter Painter for month and week view
     */
    public final void setMonthWeekPainter(BaseMonthWeekPainter painter) {
        mDelegate.setMonthWeekPainter(painter);
    }

    /**
     * 设置年视图绘制器
     *
     * @param painter Painter for year view
     */
    public final void setYearViewPainter(BaseYearViewPainter painter) {
        mDelegate.setYearViewPainter(painter);
    }

    /**
     * 设置自定义星期栏
     *
     * @param weekBar WeekBar
     */
    public final void setWeekBar(WeekBar weekBar) {
        mDelegate.setWeekBar(weekBar);
    }

    /**
     * 添加日期拦截事件
     * 使用此方法，只能基于select_mode = single_mode
     * 否则的话，如果标记全部日期为不可点击，那是没有意义的，
     * 框架本身也不可能在滑动的过程中全部去判断每个日期的可点击性
     *
     * @param listener listener
     */
    public final void setOnCalendarInterceptListener(OnCalendarInterceptListener listener) {
        mDelegate.setOnCalendarInterceptListener(listener);
    }

    /**
     * 设置年份改变事件监听
     *
     * @param listener listener
     */
    public void setOnYearChangeListener(OnYearChangeListener listener) {
        mDelegate.setOnYearChangeListener(listener);
    }

    /**
     * 设置月份改变事件监听
     *
     * @param listener listener
     */
    public void setOnMonthChangeListener(OnMonthChangeListener listener) {
        mDelegate.setOnMonthChangeListener(listener);
    }

    /**
     * 设置周视图切换监听监听
     *
     * @param listener listener
     */
    public void setOnWeekChangeListener(OnWeekChangeListener listener) {
        mDelegate.setOnWeekChangeListener(listener);
    }

    /**
     * 日期选择事件
     *
     * @param listener listener
     */
    public void setOnCalendarSelectListener(OnCalendarSelectListener listener) {
        mDelegate.setOnCalendarSelectListener(listener);
    }

    /**
     * 日期选择事件
     *
     * @param listener listener
     */
    public final void setOnCalendarRangeSelectListener(OnCalendarRangeSelectListener listener) {
        mDelegate.setOnCalendarRangeSelectListener(listener);
    }

    /**
     * 日期多选事件
     *
     * @param listener listener
     */
    public final void setOnCalendarMultiSelectListener(OnCalendarMultiSelectListener listener) {
        mDelegate.setOnCalendarMultiSelectListener(listener);
    }

    /**
     * 设置范围选择最小值及最大值，default：minSize = -1，maxSize = -1 表示没有限制
     *
     * @param minSize minSize
     * @param maxSize maxSize
     */
    public final void setRangeSelectSize(int minSize, int maxSize) {
        mDelegate.setRangeSelectSize(minSize, maxSize);
    }

    public final void setRangeSelectStartCalendar(int startYear, int startMonth, int startDay) {
        setRangeSelectStartCalendar(new CalendarBean(startYear, startMonth, startDay));
    }

    public final void setRangeSelectStartCalendar(CalendarBean startCalendar) {
        mDelegate.setRangeSelectStartCalendar(startCalendar);
    }

    public final void setRangeSelectEndCalendar(int endYear, int endMonth, int endDay) {
        setRangeSelectEndCalendar(new CalendarBean(endYear, endMonth, endDay));
    }

    public final void setRangeSelectEndCalendar(CalendarBean endCalendar) {
        mDelegate.setRangeSelectEndCalendar(endCalendar);
    }

    /**
     * 直接指定范围选择日期
     *
     * @param startYear  startYear
     * @param startMonth startMonth
     * @param startDay   startDay
     * @param endYear    endYear
     * @param endMonth   endMonth
     * @param endDay     endDay
     */
    public final void setRangeSelectCalendar(int startYear, int startMonth, int startDay, int endYear, int endMonth, int endDay) {
        setRangeSelectCalendar(new CalendarBean(startYear, startMonth, startDay), new CalendarBean(endYear, endMonth, endDay));
    }

    /**
     * 设置范围选择日期
     *
     * @param startCalendar startCalendar
     * @param endCalendar   endCalendar
     */
    public final void setRangeSelectCalendar(CalendarBean startCalendar, CalendarBean endCalendar) {
        mDelegate.setRangeSelectCalendar(startCalendar, endCalendar);
    }

    /**
     * 获得最大多选数量
     */
    public final int getMultiSelectMaxSize() {
        return mDelegate.getMultiSelectMaxSize();
    }

    /**
     * 设置最大多选数量
     */
    public final void setMultiSelectMaxSize(int multiSelectMaxSize) {
        mDelegate.setMultiSelectMaxSize(multiSelectMaxSize);
    }

    /**
     * 最小选择范围
     *
     * @return 最小选择范围
     */
    public final int getMinSelectRange() {
        return mDelegate.getRangeSelectMinSize();
    }

    /**
     * 最大选择范围
     *
     * @return 最大选择范围
     */
    public final int getMaxSelectRange() {
        return mDelegate.getRangeSelectMaxSize();
    }

    /**
     * 日期长按事件
     *
     * @param listener listener
     */
    public void setOnCalendarLongClickListener(OnCalendarLongClickListener listener) {
        mDelegate.setOnCalendarLongClickListener(listener);
    }

    /**
     * 日期长按事件
     *
     * @param preventLongPressedSelect 防止长按选择日期
     * @param listener                 listener
     */
    public void setOnCalendarLongClickListener(OnCalendarLongClickListener listener, boolean preventLongPressedSelect) {
        mDelegate.setOnCalendarLongClickListener(listener);
        mDelegate.setPreventLongPressedSelected(preventLongPressedSelect);
    }

    /**
     * 视图改变事件
     *
     * @param listener listener
     */
    public void setOnViewChangeListener(OnViewChangeListener listener) {
        mDelegate.setOnViewChangeListener(listener);
    }


    public void setOnYearViewChangeListener(OnYearViewChangeListener listener) {
        mDelegate.setOnYearViewChangeListener(listener);
    }

    /**
     * 保持状态
     *
     * @return 状态
     */
    @Nullable
    @Override
    protected Parcelable onSaveInstanceState() {
        if (mDelegate == null) {
            return super.onSaveInstanceState();
        }
        Bundle bundle = new Bundle();
        Parcelable parcelable = super.onSaveInstanceState();
        bundle.putParcelable("super", parcelable);
        bundle.putSerializable("selected_calendar", mDelegate.getSelectedCalendar());
        bundle.putSerializable("index_calendar", mDelegate.getIndexCalendar());
        return bundle;
    }

    /**
     * 恢复状态
     *
     * @param state 状态
     */
    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        Bundle bundle = (Bundle) state;
        Parcelable superData = bundle.getParcelable("super");
        CalendarBean selectedCalendar = (CalendarBean) bundle.getSerializable("selected_calendar");
        CalendarBean indexCalendar = (CalendarBean) bundle.getSerializable("index_calendar");
        mDelegate.restoreCalendarBean(selectedCalendar, indexCalendar);
        super.onRestoreInstanceState(superData);
    }

    /**
     * 初始化时初始化日历卡默认选择位置
     */
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (getParent() != null && getParent() instanceof CalendarLayout) {
            mDelegate.setCalendarLayout((CalendarLayout) getParent());
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int height = MeasureSpec.getSize(heightMeasureSpec);
        if (!mDelegate.isFullScreenCalendar()) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            return;
        }

        setCalendarItemHeight((height - mDelegate.getWeekBarHeight()) / 6);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * 标记哪些日期有事件
     *
     * @param mSchemeDates mSchemeDatesMap 通过自己的需求转换即可
     */
    public final void setSchemeDate(Map<String, CalendarBean> mSchemeDates) {
        mDelegate.setSchemeDate(mSchemeDates);
    }

    /**
     * 清空日期标记
     */
    public final void clearSchemeDate() {
        mDelegate.clearSchemeDate();
    }

    /**
     * 添加事物标记
     *
     * @param bean CalendarBean
     */
    public final void addSchemeDate(CalendarBean bean) {
        mDelegate.addSchemeDate(bean);
    }

    /**
     * 添加事物标记
     *
     * @param mSchemeDates mSchemeDates
     */
    public final void addSchemeDate(Map<String, CalendarBean> mSchemeDates) {
        mDelegate.addSchemeDate(mSchemeDates);
    }

    /**
     * 移除某天的标记
     * 这个API是安全的
     *
     * @param bean CalendarBean
     */
    public final void removeSchemeDate(CalendarBean bean) {
        mDelegate.removeSchemeDate(bean);
    }

    /**
     * 设置背景色
     *
     * @param yearViewBackground 年份卡片的背景色
     * @param weekBackground     星期栏背景色
     * @param lineBg             线的颜色
     */
    public void setBackground(int yearViewBackground, int weekBackground, int lineBg) {
        mDelegate.setBackground(yearViewBackground, weekBackground, lineBg);
    }

    /**
     * 设置日历文本各状态颜色，为 null 则不改变原有值
     *
     * @param selectedColor   选中日期字体颜色
     * @param curDayColor     当天字体颜色
     * @param schemeColor     标记字体颜色
     * @param curMonthColor   当前月份字体颜色
     * @param otherMonthColor 其它月份字体颜色
     */
    public void setTextColor(Integer selectedColor, Integer curDayColor, Integer schemeColor,
                             Integer curMonthColor, Integer otherMonthColor) {
        mDelegate.setTextColor(selectedColor, curDayColor, schemeColor, curMonthColor, otherMonthColor);
    }

    /**
     * 设置日历节日文本各状态颜色，为 null 则不改变原有值
     *
     * @param selectedColor   选中日期农历字体颜色
     * @param curDayColor     当天农历字体颜色
     * @param schemeColor     标记农历字体颜色
     * @param curMonthColor   当前月份农历字体颜色
     * @param otherMonthColor 其它月份农历字体颜色
     */
    public void setFestivalTextColor(@ColorInt Integer selectedColor, @ColorInt Integer curDayColor, @ColorInt Integer schemeColor,
                                     @ColorInt Integer curMonthColor, @ColorInt Integer otherMonthColor) {
        mDelegate.setFestivalTextColor(selectedColor, curDayColor, schemeColor, curMonthColor, otherMonthColor);
    }

    /**
     * 设置日历标记颜色，为 null 则不改变原有值
     */
    public void setThemeColor(@ColorInt Integer selectedThemeColor, @ColorInt Integer schemeThemeColor) {
        mDelegate.setThemeColor(selectedThemeColor, schemeThemeColor);
    }

    /**
     * 设置年视图的颜色
     *
     * @param yearViewMonthTextColor 年视图月份颜色
     * @param yearViewDayTextColor   年视图天的颜色
     * @param yarViewSchemeTextColor 年视图标记颜色
     */
    public void setYearViewTextColor(int yearViewMonthTextColor, int yearViewDayTextColor, int yarViewSchemeTextColor) {
        mDelegate.setYearViewTextColor(yearViewMonthTextColor, yearViewDayTextColor, yarViewSchemeTextColor);
    }

    /**
     * 设置星期栏的背景和字体颜色
     *
     * @param weekBackground 背景色
     * @param weekTextColor  字体颜色
     */
    public void setWeekColor(int weekBackground, int weekTextColor) {
        WeekBar weekBar = mDelegate.getWeekBar();
        if (weekBar == null) {
            return;
        }
        weekBar.setBackgroundColor(weekBackground);
        weekBar.setTextColor(weekTextColor);
    }

    /**
     * 默认选择模式
     */
    public final void setSelectDefaultMode() {
        mDelegate.setSelectMode(CalendarConstants.SELECT_MODE_AUTO);
    }

    /**
     * 范围模式
     */
    public void setSelectRangeMode() {
        mDelegate.setSelectMode(CalendarConstants.SELECT_MODE_RANGE);
    }

    /**
     * 多选模式
     */
    public void setSelectMultiMode() {
        mDelegate.setSelectMode(CalendarConstants.SELECT_MODE_MULTI);
    }

    /**
     * 单选模式
     */
    public void setSelectSingleMode() {
        mDelegate.setSelectMode(CalendarConstants.SELECT_MODE_SINGLE);
    }

    /**
     * 设置一周起始日，1-7 代表 周日-周六
     *
     * @param weekStart 一周起始日
     */
    public void setWeekStart(@CalendarConstants.WeekStart int weekStart) {
        mDelegate.setWeekStart(weekStart);
    }

    /**
     * 是否是单选模式
     */
    public boolean isSingleSelectMode() {
        return mDelegate.getSelectMode() == CalendarConstants.SELECT_MODE_SINGLE;
    }

    /**
     * 设置显示模式为全部
     */
    public void setMonthAllMode() {
        setMonthShowMode(CalendarConstants.MONTH_SHOW_MODE_ALL);
    }

    /**
     * 设置显示模式为仅当前月份
     */
    public void setMonthOnlyCurrentMode() {
        setMonthShowMode(CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT);
    }

    /**
     * 设置显示模式为填充
     */
    public void setMonthAutoFitMode() {
        setMonthShowMode(CalendarConstants.MONTH_SHOW_MODE_AUTO_FIT);
    }

    /**
     * 设置显示模式
     * CalendarConstants.MONTH_SHOW_MODE_ALL
     * CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT
     * CalendarConstants.MONTH_SHOW_MODE_AUTO_FIT
     *
     * @param mode 月视图显示模式
     */
    private void setMonthShowMode(@CalendarConstants.MonthShowMode int mode) {
        mDelegate.setMonthShowMode(mode);
    }

    /**
     * 更新当前日期
     */
    public final void updateCurrentDate() {
        mDelegate.updateCurrentDay();
    }

    /**
     * 获取当前周数据
     */
    public List<CalendarBean> getCurrentWeekCalendars() {
        return mDelegate.getCurrentWeekCalendars();
    }

    /**
     * 获取当前月份日期
     */
    public List<CalendarBean> getCurrentMonthCalendars() {
        return mDelegate.getCurrentMonthCalendars();
    }

    /**
     * 获取选择的日期
     */
    public CalendarBean getSelectedCalendar() {
        return mDelegate.getSelectedCalendar();
    }

    /**
     * 获得最小范围日期
     */
    public CalendarBean getMinRangeCalendar() {
        return mDelegate.getMinDate();
    }

    /**
     * 获得最大范围日期
     */
    public CalendarBean getMaxRangeCalendar() {
        return mDelegate.getMaxDate();
    }


    /**
     * 年份视图切换事件，快速年份切换
     */
    public interface OnYearChangeListener {
        void onYearChange(int year);
    }

    /**
     * 月份切换事件
     */
    public interface OnMonthChangeListener {
        void onMonthChange(int year, int month);
    }


    /**
     * 周视图切换事件
     */
    public interface OnWeekChangeListener {
        void onWeekChange(List<CalendarBean> weekCalendars);
    }

    /**
     * 内部日期选择，不暴露外部使用
     * 主要是用于更新日历CalendarLayout位置
     */
    interface OnInnerDateSelectedListener {
        /**
         * 月视图点击
         *
         * @param calendarBean CalendarBean
         * @param isClick      是否来自点击
         */
        void onMonthDateSelected(CalendarBean calendarBean, boolean isClick);

        /**
         * 周视图点击
         *
         * @param calendarBean CalendarBean
         * @param isClick      是否来自点击
         */
        void onWeekDateSelected(CalendarBean calendarBean, boolean isClick);
    }


    /**
     * 日历范围选择事件
     */
    public interface OnCalendarRangeSelectListener {

        /**
         * 范围选择超出范围越界
         *
         * @param calendarBean calendarBean
         */
        void onCalendarSelectOutOfRange(CalendarBean calendarBean);

        /**
         * 选择范围超出范围
         *
         * @param calendarBean    calendarBean
         * @param isOutOfMinRange 是否小于最小范围，否则为最大范围
         */
        void onSelectOutOfRange(CalendarBean calendarBean, boolean isOutOfMinRange);

        /**
         * 日期选择事件
         *
         * @param calendarBean calendarBean
         * @param isEnd        是否结束
         */
        void onCalendarRangeSelect(CalendarBean calendarBean, boolean isEnd);
    }


    /**
     * 日历多选事件
     */
    public interface OnCalendarMultiSelectListener {

        /**
         * 多选超出范围越界
         *
         * @param calendarBean calendarBean
         */
        void onCalendarMultiSelectOutOfRange(CalendarBean calendarBean);

        /**
         * 多选超出大小
         *
         * @param maxSize      最大大小
         * @param calendarBean calendarBean
         */
        void onMultiSelectOutOfSize(CalendarBean calendarBean, int maxSize);

        /**
         * 多选事件
         *
         * @param calendarBean calendarBean
         * @param curSize      curSize
         * @param maxSize      maxSize
         */
        void onCalendarMultiSelect(CalendarBean calendarBean, int curSize, int maxSize);
    }

    /**
     * 日历选择事件
     */
    public interface OnCalendarSelectListener {

        /**
         * 超出范围越界
         *
         * @param calendarBean calendarBean
         */
        void onCalendarOutOfRange(CalendarBean calendarBean);

        /**
         * 日期选择事件
         *
         * @param calendarBean calendarBean
         * @param isClick      isClick
         */
        void onCalendarSelect(CalendarBean calendarBean, boolean isClick);
    }

    public interface OnCalendarLongClickListener {

        /**
         * 超出范围越界
         *
         * @param calendarBean calendarBean
         */
        void onCalendarLongClickOutOfRange(CalendarBean calendarBean);

        /**
         * 日期长按事件
         *
         * @param calendarBean calendarBean
         */
        void onCalendarLongClick(CalendarBean calendarBean);
    }

    /**
     * 视图改变事件
     */
    public interface OnViewChangeListener {
        /**
         * 视图改变事件
         *
         * @param isMonthView isMonthView是否是月视图
         */
        void onViewChange(boolean isMonthView);
    }

    /**
     * 年视图改变事件
     */
    public interface OnYearViewChangeListener {
        /**
         * 年视图变化
         *
         * @param isClose 是否关闭
         */
        void onYearViewChange(boolean isClose);
    }

    /**
     * 拦截日期是否可用事件
     */
    public interface OnCalendarInterceptListener {
        boolean isCalendarIntercepted(CalendarBean calendarBean);

        void onCalendarInterceptClick(CalendarBean calendarBean, boolean isClick);
    }


    interface ICalendarViewDelegate {

        CalendarBean getMinDate();

        CalendarBean getMaxDate();

        void setRange(CalendarBean minDate, CalendarBean maxDate);

        @CalendarConstants.WeekStart
        int getWeekStart();

        void setWeekStart(@CalendarConstants.WeekStart int weekStart);

        @CalendarConstants.MonthShowMode
        int getMonthViewShowMode();

        void setMonthShowMode(@CalendarConstants.MonthShowMode int monthViewShowMode);

        @CalendarConstants.SelectMode
        int getSelectMode();

        void setSelectMode(@CalendarConstants.SelectMode int selectMode);

        @CalendarConstants.AutoFocusMode
        int getCalendarAutoSelectMode();

        void setCalendarAutoSelectMode(@CalendarConstants.AutoFocusMode int defaultCalendarSelect);

        int getMultiSelectMaxSize();

        void setMultiSelectMaxSize(int multiSelectMaxSize);

        void putMultiSelect(CalendarBean... calendarBeans);

        void removeMultiSelect(CalendarBean... calendarBeans);

        List<CalendarBean> getMultiSelectCalendars();

        int getRangeSelectMinSize();

        int getRangeSelectMaxSize();

        void setRangeSelectSize(int minRange, int maxRange);

        void setRangeSelectStartCalendar(CalendarBean startCalendar);

        void setRangeSelectEndCalendar(CalendarBean endCalendar);

        void setRangeSelectCalendar(CalendarBean startCalendar, CalendarBean endCalendar);

        List<CalendarBean> getRangeSelectCalendars();

        void clearRangeSelect();

        void clearSingleSelect();

        void clearMultiSelect();

        CalendarBean getCurrentDay();

        void updateCurrentDay();

        CalendarBean getSelectedCalendar();

        CalendarBean getIndexCalendar();

        List<CalendarBean> getCurrentMonthCalendars();

        List<CalendarBean> getCurrentWeekCalendars();

        void restoreCalendarBean(CalendarBean selectedBean, CalendarBean indexBean);

        void setCalendarLayout(CalendarLayout calendarLayout);

        boolean isFullScreenCalendar();

        String getSchemeText();

        void setSchemeText(String text);

        void setSchemeDate(Map<String, CalendarBean> schemeMap);

        void clearSchemeDate();

        void addSchemeDate(CalendarBean bean);

        void addSchemeDate(Map<String, CalendarBean> schemeMap);

        void removeSchemeDate(CalendarBean bean);

        void updateCalendarScheme(CalendarBean targetCalendar);

        void clearSelectedScheme();

        boolean isPreventLongPressedSelected();

        void setPreventLongPressedSelected(boolean preventLongPressedSelected);

        BaseMonthWeekPainter getMonthWeekPainter();

        void setMonthWeekPainter(BaseMonthWeekPainter monthWeekPainter);

        BaseYearViewPainter getYearViewPainter();

        void setYearViewPainter(BaseYearViewPainter yearViewPainter);

        WeekBar getWeekBar();

        void setWeekBar(WeekBar weekBar);


        void scrollToCurrent(boolean smoothScroll);

        void scrollToNext(boolean smoothScroll);

        void scrollToPre(boolean smoothScroll);

        void scrollToSelectCalendar(boolean smoothScroll, boolean invokeListener);

        void scrollToCalendar(int year, int month, int day, boolean smoothScroll, boolean invokeListener);

        void scrollToYear(int year, boolean smoothScroll);


        int getCalendarItemHeight();

        void setCalendarItemHeight(int height);


        @ColorInt
        int getWeekBackground();

        @ColorInt
        int getWeekLineBackground();

        @Dimension
        int getWeekLineMargin();

        @Dimension
        int getWeekBarHeight();

        void setBackground(int yearViewBackground, int weekBackground, int lineBg);

        @ColorInt
        int getWeekTextColor();

        @ColorInt
        int getSelectedTextColor();

        @ColorInt
        int getSelectedFestivalTextColor();

        @ColorInt
        int getCurDayTextColor();

        @ColorInt
        int getCurDayFestivalTextColor();

        @ColorInt
        int getSchemeTextColor();

        @ColorInt
        int getSchemeFestivalTextColor();

        @ColorInt
        int getCurMonthTextColor();

        @ColorInt
        int getCurMonthFestivalTextColor();

        @ColorInt
        int getOtherMonthTextColor();

        @ColorInt
        int getOtherMonthFestivalTextColor();

        @ColorInt
        int getSelectedThemeColor();

        @ColorInt
        int getSchemeThemeColor();

        void setTextColor(@ColorInt Integer selectedColor, @ColorInt Integer curDayColor, @ColorInt Integer schemeColor,
                          @ColorInt Integer curMonthColor, @ColorInt Integer otherMonthColor);

        void setFestivalTextColor(@ColorInt Integer selectedColor, @ColorInt Integer curDayColor, @ColorInt Integer schemeColor,
                                  @ColorInt Integer curMonthColor, @ColorInt Integer otherMonthColor);

        /**
         * 设置日历 scheme 颜色，为 null 则不改变原有值
         */
        void setThemeColor(@ColorInt Integer selectedThemeColor, @ColorInt Integer schemeThemeColor);


        int getDayTextSize();

        void setDayTextSize(int sizeInPx);

        int getFestivalTextSize();

        void setFestivalTextSize(int sizeInPx);

        int getWeekTextSize();

        boolean isMonthViewScrollable();

        void setMonthViewScrollable(boolean monthViewScrollable);

        boolean isWeekViewScrollable();

        void setWeekViewScrollable(boolean weekViewScrollable);

        boolean isYearViewScrollable();

        void setYearViewScrollable(boolean yearViewScrollable);


        void setOnCalendarInterceptListener(OnCalendarInterceptListener listener);

        void setOnCalendarSelectListener(OnCalendarSelectListener listener);

        void setOnCalendarRangeSelectListener(OnCalendarRangeSelectListener listener);

        void setOnCalendarMultiSelectListener(OnCalendarMultiSelectListener listener);

        void setOnCalendarLongClickListener(OnCalendarLongClickListener listener);

        void setOnYearChangeListener(OnYearChangeListener listener);

        void setOnMonthChangeListener(OnMonthChangeListener listener);

        void setOnWeekChangeListener(OnWeekChangeListener listener);

        void setOnViewChangeListener(OnViewChangeListener listener);

        void setOnYearViewChangeListener(OnYearViewChangeListener listener);

        /* 年相关属性 */
        boolean isShowYearSelectedLayout();

        boolean isYearSelectLayoutVisible();

        void closeYearSelectLayout();

        void showYearSelectLayout(int year);

        int getYearViewBackground();

        int getYearViewMonthHeight();

        int getYearViewWeekHeight();

        int getYearViewPadding();

        int getYearViewMonthMarginTop();

        int getYearViewMonthMarginBottom();

        int getYearViewMonthTextSize();

        int getYearViewWeekTextSize();

        int getYearViewDayTextSize();

        int getYearViewMonthTextColor();

        int getYearViewWeekTextColor();

        int getYearViewSelectTextColor();

        int getYearViewCurDayTextColor();

        int getYearViewSchemeTextColor();

        int getYearViewDayTextColor();

        void setYearViewTextColor(int yearViewMonthTextColor, int yearViewDayTextColor, int yarViewSchemeTextColor);

    }

}
