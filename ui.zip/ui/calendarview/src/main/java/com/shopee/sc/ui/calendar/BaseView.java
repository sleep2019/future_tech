package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.CallSuper;
import androidx.annotation.Nullable;

import java.util.List;

/**
 * 基本的日历View，派生出 MonthView 和 WeekView
 */
public abstract class BaseView extends View implements View.OnClickListener, View.OnLongClickListener {

    BaseCalendarViewDelegate mDelegate;

    /**
     * 日历布局，需要在日历下方放自己的布局
     */
    CalendarLayout mParentLayout;

    /**
     * 日历项
     */
    List<CalendarBean> mItemList;

    /**
     * 每一项的高度
     */
    protected int mItemHeight;

    /**
     * 每一项的宽度
     */
    protected int mItemWidth;

    /**
     * Text的基线
     */
    protected float mTextBaseLine;

    /**
     * 点击的x、y坐标
     */
    int mLastX, mLastY;

    /**
     * 是否点击
     */
    boolean mIsValidClick = true;

    /**
     * 当前选择项
     */
    CalendarBean mSelectedBean = null;

    public BaseView(Context context) {
        this(context, null);
    }

    public BaseView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setOnClickListener(this);
        setOnLongClickListener(this);
    }

    /**
     * 初始化所有UI配置
     *
     * @param delegate delegate
     */
    final void setDelegate(BaseCalendarViewDelegate delegate) {
        mDelegate = delegate;
        updateItemHeight();
    }

    @CallSuper
    void updateItemHeight() {
        mItemHeight = mDelegate.getCalendarItemHeight();
        Paint.FontMetrics metrics = mDelegate.getMonthWeekPainter().mCurMonthTextPaint.getFontMetrics();
        mTextBaseLine = mItemHeight / 2F - (metrics.descent + metrics.ascent) / 2;
    }

    /**
     * 移除事件
     */
    final void removeSchemes() {
        if (mItemList == null) {
            return;
        }
        for (CalendarBean bean : mItemList) {
            bean.clearScheme();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getPointerCount() > 1) {
            return false;
        }
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mLastX = (int) event.getX();
                mLastY = (int) event.getY();
                mIsValidClick = true;
                break;
            case MotionEvent.ACTION_MOVE:
                float diffY;
                if (mIsValidClick) {
                    diffY = event.getY() - mLastY;
                    mIsValidClick = Math.abs(diffY) <= 50;
                }
                break;
            case MotionEvent.ACTION_UP:
                mLastX = (int) event.getX();
                mLastY = (int) event.getY();
                break;
        }
        return super.onTouchEvent(event);
    }

    /**
     * 日历是否被选中
     */
    protected boolean isCalendarSelected(CalendarBean bean) {
        return mDelegate != null && mDelegate.isCalendarSelected(bean);
    }

    /**
     * 上一个日期是否选中
     *
     * @param bean 当前日期
     */
    protected boolean isSelectPreCalendar(CalendarBean bean) {
        // 单选时不关心前后是否选中，这里直接返回 false
        if (isSingleOrAutoMode()) {
            return false;
        }

        CalendarBean preCalendar = CalendarUtil.getPreCalendar(bean);
        mDelegate.updateCalendarScheme(preCalendar);
        return isCalendarSelected(preCalendar);
    }

    /**
     * 下一个日期是否选中
     *
     * @param bean 当前日期
     */
    protected boolean isSelectNextCalendar(CalendarBean bean) {
        // 单选时不关心前后是否选中，这里直接返回 false
        if (isSingleOrAutoMode()) {
            return false;
        }

        CalendarBean nextCalendar = CalendarUtil.getNextCalendar(bean);
        mDelegate.updateCalendarScheme(nextCalendar);
        return isCalendarSelected(nextCalendar);
    }

    protected boolean isSingleOrAutoMode() {
        return mDelegate.getSelectMode() == CalendarConstants.SELECT_MODE_AUTO
                || mDelegate.getSelectMode() == CalendarConstants.SELECT_MODE_SINGLE;
    }

    /**
     * 更新事件
     */
    final void updateScheme() {
        if (mDelegate.mSchemeDatesMap.size() == 0) {//清空操作
            removeSchemes();
        } else {
            mDelegate.addSchemesFromMap(mItemList);
        }
        invalidate();
    }

    /**
     * 是否拦截日期
     *
     * @param bean CalendarBean
     * @return 是否拦截日期
     */
    protected final boolean onCalendarIntercept(CalendarBean bean) {
        return mDelegate.isCalendarIntercepted(bean);
    }

    /**
     * 是否在日期范围内
     *
     * @param bean CalendarBean
     * @return 是否在日期范围内
     */
    protected final boolean isInRange(CalendarBean bean) {
        return mDelegate != null && CalendarUtil.isCalendarInRange(bean, mDelegate);
    }

    /**
     * 获取点击选中的日期
     */
    protected CalendarBean getPointerCalendarBean() {
        if (mItemWidth == 0 || mItemHeight == 0) {
            return null;
        }
        int indexX = (mLastX - mDelegate.getMonthWeekPaddingStart()) / mItemWidth;
        if (indexX < 0 || indexX > 6) {
            return null;
        }

        int indexY = (mLastY - mDelegate.getMonthWeekPaddingTop()) / mItemHeight;
        int position = indexY * 7 + indexX; // 选择项
        if (position >= 0 && position < mItemList.size()) {
            return mItemList.get(position);
        }
        return null;
    }

    /**
     * 销毁
     */
    protected void onDestroy() {

    }

}
