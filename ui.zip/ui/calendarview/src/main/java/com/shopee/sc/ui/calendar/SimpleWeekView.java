package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/**
 * 周视图
 */
public class SimpleWeekView extends BaseWeekView {

    public SimpleWeekView(Context context) {
        super(context);
    }

    /**
     * 绘制日历文本
     *
     * @param canvas canvas
     */
    @Override
    protected void onDraw(Canvas canvas) {
        if (mItemList.size() == 0) {
            return;
        }

        mItemWidth = (getWidth() - mDelegate.getMonthWeekPaddingStart() - mDelegate.getMonthWeekPaddingEnd()) / 7;
        mDelegate.getMonthWeekPainter().onPreviewHook(mItemHeight, mItemWidth, mTextBaseLine);
        int y = mDelegate.getMonthWeekPaddingTop();
        for (int col = 0; col < mItemList.size(); col++) {
            int x = col * mItemWidth + mDelegate.getMonthWeekPaddingStart();
            mDelegate.getMonthWeekPainter().onLoopStart(x, y);
            CalendarBean bean = mItemList.get(col);
            boolean isSelected = isCalendarSelected(bean);
            boolean hasScheme = bean.hasScheme();

            boolean drawScheme = true;
            if (isSelected) {
                boolean isPreSelected = isSelectPreCalendar(bean);
                boolean isNextSelected = isSelectNextCalendar(bean);
                drawScheme = mDelegate.getMonthWeekPainter().onDrawSelectedBg(canvas, bean, x, y, hasScheme, isPreSelected, isNextSelected);
            }
            if (hasScheme && drawScheme) {
                // 将画笔设置为标记颜色
                mDelegate.getMonthWeekPainter().mSchemeBgPaint.setColor(bean.getSchemeColor() != 0 ? bean.getSchemeColor() : mDelegate.getSchemeThemeColor());
                mDelegate.getMonthWeekPainter().onDrawSchemeBg(canvas, bean, x, y, isSelected);
            }

            mDelegate.getMonthWeekPainter().onDrawText(canvas, bean, x, y, bean.isSameMonth(mYear, mMonth), hasScheme, isSelected);
        }
    }

    @Override
    public void onClick(View v) {
        if (!mIsValidClick) {
            return;
        }
        CalendarBean bean = getPointerCalendarBean();
        if (bean == null) {
            return;
        }
        if (onCalendarIntercept(bean)) {
            mDelegate.mCalendarInterceptListener.onCalendarInterceptClick(bean, true);
            return;
        }
        if (!isInRange(bean)) {
            mDelegate.notifyClickOutOfRange(bean);
            return;
        }

        if (!mDelegate.toggleSelectFromClick(bean)) {
            return;
        }

        if (mDelegate.mInnerListener != null) {
            mDelegate.mInnerListener.onWeekDateSelected(bean, true);
        }
        if (mParentLayout != null) {
            int i = CalendarUtil.getWeekFromDayInMonth(bean, mDelegate.getWeekStart());
            mParentLayout.updateSelectWeek(i);
        }

        mDelegate.notifyNewSelectFromClick(bean);
        invalidate();
    }

    @Override
    public boolean onLongClick(View v) {
        if (!isSingleOrAutoMode()) {
            return false;
        }

        if (mDelegate.mCalendarLongClickListener == null) {
            return false;
        }
        if (!mIsValidClick) {
            return false;
        }
        CalendarBean bean = getPointerCalendarBean();
        if (bean == null) {
            return false;
        }
        if (onCalendarIntercept(bean)) {
            mDelegate.mCalendarInterceptListener.onCalendarInterceptClick(bean, true);
            return true;
        }
        boolean isCalendarInRange = isInRange(bean);

        if (!isCalendarInRange) {
            if (mDelegate.mCalendarLongClickListener != null) {
                mDelegate.mCalendarLongClickListener.onCalendarLongClickOutOfRange(bean);
            }
            return true;
        }

        if (mDelegate.isPreventLongPressedSelected()) {//如果启用拦截长按事件不选择日期
            if (mDelegate.mCalendarLongClickListener != null) {
                mDelegate.mCalendarLongClickListener.onCalendarLongClick(bean);
            }
            return true;
        }

        mDelegate.mIndexCalendar = mDelegate.mSelectedCalendar;

        if (mDelegate.mInnerListener != null) {
            mDelegate.mInnerListener.onWeekDateSelected(bean, true);
        }
        if (mParentLayout != null) {
            int i = CalendarUtil.getWeekFromDayInMonth(bean, mDelegate.getWeekStart());
            mParentLayout.updateSelectWeek(i);
        }

        if (mDelegate.mCalendarSelectListener != null) {
            mDelegate.mCalendarSelectListener.onCalendarSelect(bean, true);
        }

        if (mDelegate.mCalendarLongClickListener != null) {
            mDelegate.mCalendarLongClickListener.onCalendarLongClick(bean);
        }

        invalidate();
        return true;
    }

}
