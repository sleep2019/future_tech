package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/**
 * 月视图控件
 */
public class SimpleMonthView extends BaseMonthView {

    public SimpleMonthView(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (mLineCount == 0) {
            return;
        }

        mItemWidth = (getWidth() - mDelegate.getMonthWeekPaddingStart() - mDelegate.getMonthWeekPaddingEnd()) / 7;
        mDelegate.getMonthWeekPainter().onPreviewHook(mItemHeight, mItemWidth, mTextBaseLine);
        int count = mLineCount * 7;
        int index = 0;
        for (int row = 0; row < mLineCount; row++) {
            for (int col = 0; col < 7; col++) {
                CalendarBean bean = mItemList.get(index);
                if (mDelegate.getMonthViewShowMode() == CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT) {
                    if (index > mItemList.size() - mNextOffset) {
                        return;
                    }
                    if (!bean.isSameMonth(mYear, mMonth)) {
                        ++index;
                        continue;
                    }
                } else if (mDelegate.getMonthViewShowMode() == CalendarConstants.MONTH_SHOW_MODE_AUTO_FIT) {
                    if (index >= count) {
                        return;
                    }
                }
                draw(canvas, bean, row, col);
                ++index;
            }
        }
    }

    /**
     * 开始绘制
     *
     * @param canvas canvas
     * @param bean   对应日历
     * @param row    行
     * @param col    列
     */
    private void draw(Canvas canvas, CalendarBean bean, int row, int col) {
        int x = col * mItemWidth + mDelegate.getMonthWeekPaddingStart();
        int y = row * mItemHeight + mDelegate.getMonthWeekPaddingTop();
        mDelegate.getMonthWeekPainter().onLoopStart(x, y);
        boolean isSelected = isCalendarSelected(bean);
        boolean hasScheme = bean.hasScheme();

        boolean drawScheme = true;
        if (isSelected) {
            boolean isPreSelected = isSelectPreCalendar(bean);
            boolean isNextSelected = isSelectNextCalendar(bean);
            drawScheme = mDelegate.getMonthWeekPainter().onDrawSelectedBg(canvas, bean, x, y, hasScheme, isPreSelected, isNextSelected);
        }
        if (hasScheme && drawScheme) {
            // 将画笔设置为标记颜色
            mDelegate.getMonthWeekPainter().mSchemeBgPaint.setColor(bean.getSchemeColor() != 0 ? bean.getSchemeColor() : mDelegate.getSchemeThemeColor());
            mDelegate.getMonthWeekPainter().onDrawSchemeBg(canvas, bean, x, y, isSelected);
        }

        mDelegate.getMonthWeekPainter().onDrawText(canvas, bean, x, y, bean.isSameMonth(mYear, mMonth), hasScheme, isSelected);
    }

    @Override
    public void onClick(View v) {
        if (!mIsValidClick) {
            return;
        }
        CalendarBean bean = getPointerCalendarBean();
        if (bean == null) {
            return;
        }

        if (mDelegate.getMonthViewShowMode() == CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT
                && !bean.isSameMonth(mYear, mMonth)) {
            return;
        }

        if (onCalendarIntercept(bean)) {
            mDelegate.mCalendarInterceptListener.onCalendarInterceptClick(bean, true);
            return;
        }

        if (!isInRange(bean)) {
            mDelegate.notifyClickOutOfRange(bean);
            return;
        }

        if (!mDelegate.toggleSelectFromClick(bean)) {
            return;
        }

        int clickPos = mItemList.indexOf(bean);

        if (!bean.isSameMonth(mYear, mMonth) && mMonthViewPager != null) {
            int cur = mMonthViewPager.getCurrentItem();
            int position = clickPos < 7 ? cur - 1 : cur + 1;
            mMonthViewPager.setCurrentItem(position);
        }

        if (mDelegate.mInnerListener != null) {
            mDelegate.mInnerListener.onMonthDateSelected(bean, true);
        }

        if (mParentLayout != null) {
            if (bean.isSameMonth(mYear, mMonth)) {
                mParentLayout.updateSelectPosition(mItemList.indexOf(bean));
            } else {
                mParentLayout.updateSelectWeek(CalendarUtil.getWeekFromDayInMonth(bean, mDelegate.getWeekStart()));
            }
        }

        mDelegate.notifyNewSelectFromClick(bean);
    }

    @Override
    public boolean onLongClick(View v) {
        if (!isSingleOrAutoMode()) {
            return false;
        }

        if (mDelegate.mCalendarLongClickListener == null) {
            return false;
        }
        if (!mIsValidClick) {
            return false;
        }
        CalendarBean bean = getPointerCalendarBean();
        if (bean == null) {
            return false;
        }

        if (mDelegate.getMonthViewShowMode() == CalendarConstants.MONTH_SHOW_MODE_ONLY_CURRENT
                && !bean.isSameMonth(mYear, mMonth)) {
            return false;
        }

        if (onCalendarIntercept(bean)) {
            mDelegate.mCalendarInterceptListener.onCalendarInterceptClick(bean, true);
            return false;
        }

        boolean isCalendarInRange = isInRange(bean);
        if (!isCalendarInRange) {
            if (mDelegate.mCalendarLongClickListener != null) {
                mDelegate.mCalendarLongClickListener.onCalendarLongClickOutOfRange(bean);
            }
            return true;
        }

        if (mDelegate.isPreventLongPressedSelected()) {
            if (mDelegate.mCalendarLongClickListener != null) {
                mDelegate.mCalendarLongClickListener.onCalendarLongClick(bean);
            }
            return true;
        }

        int clickPos = mItemList.indexOf(bean);
        if (!bean.isSameMonth(mYear, mMonth) && mMonthViewPager != null) {
            int cur = mMonthViewPager.getCurrentItem();
            int position = clickPos < 7 ? cur - 1 : cur + 1;
            mMonthViewPager.setCurrentItem(position);
        }

        if (mDelegate.mInnerListener != null) {
            mDelegate.mInnerListener.onMonthDateSelected(bean, true);
        }

        if (mParentLayout != null) {
            if (bean.isSameMonth(mYear, mMonth)) {
                mParentLayout.updateSelectPosition(mItemList.indexOf(bean));
            } else {
                mParentLayout.updateSelectWeek(CalendarUtil.getWeekFromDayInMonth(bean, mDelegate.getWeekStart()));
            }
        }

        if (mDelegate.mCalendarSelectListener != null) {
            mDelegate.mCalendarSelectListener.onCalendarSelect(bean, true);
        }

        if (mDelegate.mCalendarLongClickListener != null) {
            mDelegate.mCalendarLongClickListener.onCalendarLongClick(bean);
        }
        invalidate();
        return true;
    }

}
