package com.shopee.sc.ui.calendar;

import android.content.Context;

import java.util.Calendar;
import java.util.Objects;

/**
 * 最基础周视图
 */
public abstract class BaseWeekView extends BaseView {

    protected int mYear;
    protected int mMonth;

    public BaseWeekView(Context context) {
        super(context);
    }

    /**
     * 初始化周视图控件
     *
     * @param bean CalendarBean
     */
    final void setup(CalendarBean bean) {
        mYear = bean.getYear();
        mMonth = bean.getMonth();
        mItemList = CalendarUtil.initCalendarForWeekView(bean, mDelegate, mDelegate.getWeekStart());
        mDelegate.addSchemesFromMap(mItemList);
        invalidate();
    }

    /**
     * 记录已经选择的日期
     */
    final void setSelectedCalendar(CalendarBean bean) {
        if (!Objects.equals(mSelectedBean, bean)) {
            mSelectedBean = bean;
            invalidate();
        }
    }

    /**
     * 周视图切换点击默认位置
     *
     * @param bean     CalendarBean
     * @param isNotice isNotice
     */
    final void performClickCalendar(CalendarBean bean, boolean isNotice) {
        if (mParentLayout == null || mDelegate.mInnerListener == null
                || mItemList == null || mItemList.size() == 0) {
            return;
        }

        int week = CalendarUtil.getWeekViewIndexFromCalendar(bean, mDelegate.getWeekStart());
        if (mItemList.contains(mDelegate.getCurrentDay())) {
            week = CalendarUtil.getWeekViewIndexFromCalendar(mDelegate.getCurrentDay(), mDelegate.getWeekStart());
        }

        CalendarBean currentCalendar = mItemList.get(week);
        if (mDelegate.getSelectMode() != CalendarConstants.SELECT_MODE_AUTO) {
            if (mItemList.contains(mDelegate.mSelectedCalendar)) {
                currentCalendar = mDelegate.mSelectedCalendar;
            } else {
                mSelectedBean = null;
            }
        }

        if (!isInRange(currentCalendar)) {
            int curIndex = getEdgeIndex(isMinRangeEdge(currentCalendar));
            currentCalendar = mItemList.get(curIndex);
        }

        mDelegate.mInnerListener.onWeekDateSelected(currentCalendar, false);
        int i = CalendarUtil.getWeekFromDayInMonth(currentCalendar, mDelegate.getWeekStart());
        mParentLayout.updateSelectWeek(i);

        if (mDelegate.mCalendarSelectListener != null && isNotice
                && mDelegate.getSelectMode() == CalendarConstants.SELECT_MODE_AUTO) {
            mDelegate.mCalendarSelectListener.onCalendarSelect(currentCalendar, false);
        }

        mParentLayout.updateContentViewTranslateY();
        if (mDelegate.getSelectMode() == CalendarConstants.SELECT_MODE_AUTO) {
            mSelectedBean = currentCalendar;
        }

        if (!mDelegate.isShowYearSelectedLayout()
                && mDelegate.mIndexCalendar != null
                && bean.getYear() != mDelegate.mIndexCalendar.getYear()
                && mDelegate.mYearChangeListener != null) {
            mDelegate.mYearChangeListener.onYearChange(mDelegate.mIndexCalendar.getYear());
        }

        mDelegate.mIndexCalendar = currentCalendar;
        invalidate();
    }

    /**
     * 是否是最小访问边界了
     *
     * @param bean CalendarBean
     * @return 是否是最小访问边界了
     */
    final boolean isMinRangeEdge(CalendarBean bean) {
        Calendar c = mDelegate.getMinDate().newCalendar();
        long minTime = c.getTimeInMillis();
        c.set(bean.getYear(), bean.getMonth() - 1, bean.getDay());
        long curTime = c.getTimeInMillis();
        return curTime < minTime;
    }

    /**
     * 获得边界范围内下标
     *
     * @param isMinEdge isMinEdge
     * @return 获得边界范围内下标
     */
    final int getEdgeIndex(boolean isMinEdge) {
        for (int i = 0; i < mItemList.size(); i++) {
            CalendarBean item = mItemList.get(i);
            boolean isInRange = isInRange(item);
            if (isMinEdge && isInRange) {
                return i;
            } else if (!isMinEdge && !isInRange) {
                return i - 1;
            }
        }
        return isMinEdge ? 6 : 0;
    }


    /**
     * 更新显示模式
     */
    final void handleMonthShowModeChanged() {
        invalidate();
    }

    /**
     * 更新周起始
     */
    final void updateWeekStart() {
        int position = (int) getTag();
        CalendarBean bean = CalendarUtil.getFirstCalendarStartWithMinCalendar(mDelegate.getMinYear(),
                mDelegate.getMinYearMonth(),
                mDelegate.getMinYearDay(),
                position + 1,
                mDelegate.getWeekStart());
        setSelectedCalendar(mDelegate.mSelectedCalendar);
        setup(bean);
    }

    /**
     * 更新当选模式
     */
    final void updateSingleSelect() {
        if (!mItemList.contains(mDelegate.mSelectedCalendar)) {
            mSelectedBean = null;
            invalidate();
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        heightMeasureSpec = MeasureSpec.makeMeasureSpec(mItemHeight
                + mDelegate.getMonthWeekPaddingTop() + mDelegate.getMonthWeekPaddingBottom(), MeasureSpec.EXACTLY);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

}
