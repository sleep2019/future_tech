package com.shopee.sc.ui.calendar;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

final class YearViewAdapter extends RecyclerView.Adapter<YearViewAdapter.YearViewHolder> {

    private final List<CalendarBean> mItems = new ArrayList<>();
    private OnItemClickListener mOnItemClickListener;
    private CalendarViewDelegateHorizontal mDelegate;
    private int mItemWidth, mItemHeight;

    YearViewAdapter() {
    }

    final void setDelegate(CalendarViewDelegateHorizontal delegate) {
        mDelegate = delegate;
    }

    final void setYearViewSize(int width, int height) {
        mItemWidth = width;
        mItemHeight = height;
    }

    @NonNull
    @Override
    public YearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        SimpleYearView yearView = new SimpleYearView(parent.getContext());
        RecyclerView.LayoutParams params = new RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT,
                RecyclerView.LayoutParams.MATCH_PARENT);
        yearView.setLayoutParams(params);
        final YearViewHolder holder = new YearViewHolder(yearView, mDelegate);
        holder.itemView.setTag(holder);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnItemClickListener != null) {
                    int pos = holder.getAdapterPosition();
                    mOnItemClickListener.onItemClick(pos, getItem(pos));
                }
            }
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull YearViewHolder holder, int position) {
        CalendarBean item = mItems.get(position);
        holder.mYearView.setYearViewDate(item.getYear(), item.getMonth());
        holder.mYearView.resetSize(mItemWidth, mItemHeight);
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    void replaceItems(List<CalendarBean> items) {
        if (items != null) {
            mItems.clear();
            mItems.addAll(items);
            notifyDataSetChanged();
        }
    }

    final List<CalendarBean> getItems() {
        return mItems;
    }

    final CalendarBean getItem(int position) {
        if (position < 0 || position >= mItems.size()) {
            return null;
        }
        return mItems.get(position);
    }


    interface OnItemClickListener {
        void onItemClick(int position, CalendarBean item);
    }

    static class YearViewHolder extends RecyclerView.ViewHolder {
        SimpleYearView mYearView;

        YearViewHolder(SimpleYearView yearView, CalendarViewDelegateHorizontal delegate) {
            super(yearView);
            mYearView = yearView;
            mYearView.setDelegate(delegate);
        }
    }

}
