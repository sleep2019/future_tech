package com.shopee.sc.ui.calendar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.NonNull;

/**
 * Created by honggang.xiong on 2020-03-25.
 */
public class DefaultYearViewPainter extends BaseYearViewPainter {

    private int mTextPadding;
    private String[] mMonthStr;
    private String[] mWeekStr;

    public DefaultYearViewPainter(Context context) {
        super(context);
        mTextPadding = CalendarUtil.dp2px(context, 3);
        mMonthStr = context.getResources().getStringArray(R.array.month_string_array);
        mWeekStr = context.getResources().getStringArray(R.array.year_view_week_string_array);
    }

    @Override
    protected void onDrawMonth(Canvas canvas, int year, int month, int x, int y, int width, int height) {
        canvas.drawText(mMonthStr[month - 1],
                x + mItemWidth / 2 - mTextPadding,
                y + mMonthTextBaseLine,
                mMonthTextPaint);
    }

    @Override
    protected void onDrawWeek(Canvas canvas, int week, int x, int y, int width, int height) {
        canvas.drawText(mWeekStr[week],
                x + width / 2,
                y + mWeekTextBaseLine,
                mWeekTextPaint);
    }


    @Override
    protected boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y,
                                       boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {
        return false;
    }

    @Override
    protected void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean isSelected) {
        // no op
    }

    @Override
    protected void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y,
                              boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected) {
        float top = mTextBaseLine + y;
        int cx = x + mItemWidth / 2;

        final boolean isCurrentDay = isCurrentDay(bean);
        Paint textPaint;
        if (isSelected) {
            textPaint = mSelectedTextPaint;
        } else if (isCurrentDay) {
            textPaint = mCurDayTextPaint;
        } else if (hasScheme) {
            textPaint = isInCurrentMonthCard ? mSchemeTextPaint : mOtherMonthTextPaint;
        } else {
            textPaint = isInCurrentMonthCard ? mCurMonthTextPaint : mOtherMonthTextPaint;
        }
        canvas.drawText(String.valueOf(bean.getDay()), cx, top, textPaint);
    }

}
