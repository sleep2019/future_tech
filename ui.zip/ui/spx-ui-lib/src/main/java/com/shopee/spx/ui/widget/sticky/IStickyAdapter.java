package com.shopee.spx.ui.widget.sticky;

/**
 * 不支持数据分组折叠 see {@link IStickyNormalAdapter}
 * 支持数据分组折叠 see {@link IStickyGroupAdapter}
 *
 * Created by honggang.xiong on 2020/9/10.
 */
public interface IStickyAdapter {

    /**
     * 根据任意子项的 layout position，向前查找离其最近的 sticky 数据的下标，未找到则返回 -1。
     * 如支持数据分组折叠，需返回目标 sticky 数据在所有 sticky 数据中的下标；
     * 如不支持数据分组折叠，可简单返回目标 sticky 数据在所有数据中的下标
     *
     * @param position pos of any item
     * @return sticky index
     */
    int getPreStickyIndexByPosition(int position);

    /**
     * 根据 sticky index，返回 sticky 数据在所有数据中的下标，未找到则返回 -1。
     *
     * @param stickyIndex sticky index
     * @return position pos in all data
     */
    int getStickyPositionFromIndex(int stickyIndex);

    /**
     * 根据当前 sticky index，返回下一条 sticky 数据的下标，未找到则返回 -1。
     *
     * @param currentStickyIndex current sticky index
     * @return next sticky index
     */
    int getNextStickyIndexFromCurrent(int currentStickyIndex);

}
