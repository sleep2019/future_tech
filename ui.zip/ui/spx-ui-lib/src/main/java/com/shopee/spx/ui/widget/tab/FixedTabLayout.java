package com.shopee.spx.ui.widget.tab;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Html;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.AttrRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.listener.OnPageSelectedListener;
import com.shopee.spx.ui.util.ContextUtils;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 自定义横向Tab栏
 * <p/>
 * 通过 {@link #setViewPager(ViewPager, String[])} 与ViewPager和Titles进行关联
 * <p/>
 * create_user: zeng.zheng@shopee.com
 * create_date: 2021/5/28
 **/

public class FixedTabLayout extends FrameLayout implements ViewPager.OnPageChangeListener {

    private ViewPager mViewPager;
    private TextView[] mTabList;
    private ArrayList<String> mTitles;
    private LinearLayout mTabsContainer;
    private View mIndicator;
    private View mIndicatorBottomDivider;
    private int mTabCount;
    private int mCurrentTab;
    private OnPageSelectedListener mListener;
    private float mTabWidth;

    /**
     * indicator
     */
    private float mIndicatorWidth;
    private int mIndicatorColor; //默认#EE4D2D
    private float mIndicatorHeight; //dp, 默认2dp

    /**
     * title
     */
    private float mTextSize; //sp, 默认14sp
    private int mTextSelectColor; //默认#303844
    private int mTextUnselectColor; //默认#96A5B4
    private boolean mTextMediumStyle; //默认true

    /**
     * divider
     */
    private boolean mShowBottomDivider; //默认true


    public FixedTabLayout(@NonNull Context context) {
        this(context, null);
    }

    public FixedTabLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FixedTabLayout(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        View rootView = LayoutInflater.from(context).inflate(R.layout.spx_ui_layout_fixed_tab, this, true);
        mTabsContainer = rootView.findViewById(R.id.tabs);
        obtainAttributes(context, attrs);

        mIndicator = rootView.findViewById(R.id.indicator);
        mIndicator.setBackgroundColor(mIndicatorColor);
        ViewGroup.LayoutParams lp = mIndicator.getLayoutParams();
        lp.height = (int) mIndicatorHeight;
        mIndicator.setLayoutParams(lp);
        mIndicatorBottomDivider = rootView.findViewById(R.id.bottom_divider);
        mIndicatorBottomDivider.setVisibility(mShowBottomDivider ? VISIBLE : GONE);
    }

    private void obtainAttributes(Context context, AttributeSet attrs) {
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.FixedTabLayout);

        mIndicatorColor = ta.getColor(R.styleable.FixedTabLayout_tl_indicator_color, Color.parseColor("#EE4D2D"));
        mIndicatorHeight = ta.getDimension(R.styleable.FixedTabLayout_tl_indicator_height, ContextUtils.dp2px(context, 2));

        mTextSize = ta.getDimension(R.styleable.FixedTabLayout_tl_text_size, ContextUtils.sp2px(context, 14));
        mTextSelectColor = ta.getColor(R.styleable.FixedTabLayout_tl_text_select_color, Color.parseColor("#303844"));
        mTextUnselectColor = ta.getColor(R.styleable.FixedTabLayout_tl_text_unselect_color, Color.parseColor("#96A5B4"));
        mTextMediumStyle = ta.getBoolean(R.styleable.FixedTabLayout_tl_textMedium, true);

        mShowBottomDivider = ta.getBoolean(R.styleable.FixedTabLayout_tl_divider_visible, true);
        ta.recycle();
    }

    /**
     * 关联ViewPager
     */
    public void setViewPager(ViewPager vp) {
        if (vp == null || vp.getAdapter() == null) {
            throw new IllegalStateException("ViewPager or ViewPager adapter can not be NULL !");
        }
        this.mViewPager = vp;
        this.mViewPager.removeOnPageChangeListener(this);
        this.mViewPager.addOnPageChangeListener(this);
        setTabs();
    }

    /**
     * 关联ViewPager,用于不想在ViewPager适配器中设置titles数据的情况
     */
    public void setViewPager(ViewPager vp, String[] titles) {
        if (vp == null || vp.getAdapter() == null) {
            throw new IllegalStateException("ViewPager or ViewPager adapter can not be NULL !");
        }

        if (titles == null || titles.length == 0) {
            throw new IllegalStateException("Titles can not be EMPTY !");
        }

        if (titles.length != vp.getAdapter().getCount()) {
            throw new IllegalStateException("Titles length must be the same as the page count !");
        }

        this.mViewPager = vp;
        mTitles = new ArrayList<>();
        Collections.addAll(mTitles, titles);

        this.mViewPager.removeOnPageChangeListener(this);
        this.mViewPager.addOnPageChangeListener(this);
        setTabs();
    }


    public void setBottomDividerVisible(boolean visible) {
        mShowBottomDivider = visible;
        mIndicatorBottomDivider.setVisibility(mShowBottomDivider ? VISIBLE : GONE);
    }

    private void setTabs() {
        mTabsContainer.removeAllViews();
        this.mTabCount = mTitles == null ? mViewPager.getAdapter().getCount() : mTitles.size();

        mTabList = new TextView[mTabCount];
        for (int i = 0; i < mTabCount; i++) {
            final int index = i;
            TextView textView = new TextView(getContext());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.weight = 1;
            textView.setLayoutParams(lp);
            textView.setPadding(ContextUtils.dp2px(textView.getContext(), 16.0F), 0, ContextUtils.dp2px(textView.getContext(), 16.0F), 0);
            textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, mTextSize);
            textView.setTextColor(mTextUnselectColor);
            if (mTextMediumStyle) {
                textView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            }
            CharSequence pageTitle = mTitles == null ? mViewPager.getAdapter().getPageTitle(i) : mTitles.get(i);
            textView.setText(pageTitle);
            textView.setGravity(Gravity.CENTER);
            textView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (null != mViewPager)
                        mViewPager.setCurrentItem(index, true);
                }
            });
            mTabsContainer.addView(textView);
            mTabList[i] = textView;
        }

        float initialX = mTabWidth / 2.0f - mIndicatorWidth / 2.0f;
        mIndicator.setX(initialX);
        setCurrentTab(0, false);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (isInEditMode()) {
            mTabWidth = getMeasuredWidth();
            return;
        }

        if (null == mTabList || mTabList.length == 0)
            mTabWidth = getMeasuredWidth();
        else
            mTabWidth = getMeasuredWidth() / mTabList.length;

        if (mIndicatorWidth <= 0 && mTabWidth > 0) {
            mIndicatorWidth = mTabWidth;
            ViewGroup.LayoutParams layoutParams = mIndicator.getLayoutParams();
            layoutParams.width = (int) mIndicatorWidth;
            mIndicator.setLayoutParams(layoutParams);
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        // indicator位置
        float newScrollX = mTabList[position].getLeft()
                + mTabWidth * positionOffset
                + mTabWidth / 2.0f - mIndicatorWidth / 2.0f;
        mIndicator.setX(newScrollX);
    }

    @Override
    public void onPageSelected(int position) {
        setCurrentTabInner(position);
        if (mListener != null) {
            mListener.onPageSelected(position);
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        // 最后纠正颜色
        if (state == ViewPager.SCROLL_STATE_IDLE) {
            for (int i = 0; i < mTabList.length; i++) {
                if (i != mCurrentTab)
                    mTabList[i].setTextColor(mTextUnselectColor);
                else
                    mTabList[i].setTextColor(mTextSelectColor);
            }
        }
    }

    /**
     * 单纯的改变tab上面的文字
     *
     * @param titles
     */
    public void updateTitles(String[] titles, ArrayList<String> numbers) {
        if (null != titles && null != numbers && titles.length > 0 && titles.length == numbers.size()) {
            for (int i = 0; i < mTabList.length; i++) {
                mTabList[i].setText(Html.fromHtml(titles[i] + "<font color='#9e9e9e'>" + " (" + numbers.get(i) + ")" + "</font>"));
            }
        }
    }

    public void updateTitlesWithSameColor(String[] titles, ArrayList<String> numbers) {
        if (null != titles && null != numbers && titles.length > 0 && titles.length == numbers.size()) {
            for (int i = 0; i < mTabList.length; i++) {
                String title = titles[i] + " (" + numbers.get(i) + ")";
                mTabList[i].setText(title);
            }
        }
    }

    public void updateNonNullTitlesWithSameColor(String[] titleList, ArrayList<String> numberList) {
        if (null != titleList && null != numberList && titleList.length > 0 && titleList.length == numberList.size()) {
            for (int i = 0; i < mTabList.length; i++) {
                if (!TextUtils.isEmpty(numberList.get(i))) {
                    String title = titleList[i] + " (" + numberList.get(i) + ")";
                    mTabList[i].setText(title);
                }
            }
        }
    }

    private void setCurrentTabInner(int index) {
        mCurrentTab = index;
    }

    public void setCurrentTab(int index, boolean smoothScroll) {
        setCurrentTabInner(index);
        mViewPager.setCurrentItem(index, smoothScroll);
        mTabList[index].setTextColor(mTextSelectColor);
    }

    public int getCurrentTab() {
        return mCurrentTab;
    }

    public void setOnPageSelectListener(OnPageSelectedListener listener) {
        mListener = listener;
    }


}
