package com.shopee.spx.ui.widget.bean;

import com.shopee.spx.ui.widget.view.TitleMenuView;

/**
 * @ClassName: BaseTitleItem
 * @Description: 标题栏item
 * @Author: jingwei.xie
 * @CreateDate: 2022/6/16 2:19 下午
 */
public class TitleMenuItem {

    private static final int DEFAULT_POS = -1;

    /**
     * item名字，用于标识item，在设置红点时可以直接设置
     */
    private String itemTag;
    private int resIcon;
    private boolean showRedDot;
    private int redDotNumber;
    /**
     * item的名称
     */
    private String itemName;
    /**
     * 绑定的view
     */
    private TitleMenuView menuView;

    public TitleMenuItem(String itemTag, int resIcon) {
        this.itemTag = itemTag;
        this.resIcon = resIcon;
    }

    public TitleMenuItem(String itemTag, int resIcon, String itemName) {
        this.itemTag = itemTag;
        this.resIcon = resIcon;
        this.itemName = itemName;
    }

    public String getItemTag() {
        return itemTag;
    }

    public void setItemTag(String itemTag) {
        this.itemTag = itemTag;
    }

    public int getResIcon() {
        return resIcon;
    }

    public boolean isShowRedDot() {
        return showRedDot;
    }

    public void setShowRedDot(boolean showRedDot) {
        this.showRedDot = showRedDot;
    }

    public TitleMenuView getMenuView() {
        return menuView;
    }

    public void setMenuView(TitleMenuView menuView) {
        this.menuView = menuView;
    }

    public static int getDefaultPos() {
        return DEFAULT_POS;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getRedDotNumber() {
        return redDotNumber;
    }

    public void setRedDotNumber(int redDotNumber) {
        this.redDotNumber = redDotNumber;
    }
}
