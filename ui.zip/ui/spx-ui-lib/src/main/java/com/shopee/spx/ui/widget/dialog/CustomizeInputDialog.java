package com.shopee.spx.ui.widget.dialog;

import android.content.Context;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

import androidx.annotation.LayoutRes;

import com.shopee.spx.ui.util.ContextUtils;

/**
 * 包含至少一个EditText的Dialog,功能：
 * 1、自动处理dialog的最大显示区域（默认最大高度340dp,可自定义修改）
 * 2、可以回调所有EditText的输入结果
 * Created by zheng.zeng on 2021-04-28.
 */
public class CustomizeInputDialog extends CustomizeDialog {

    private static final int SOFT_KEYBOARD_DELAY_MILLIS = 150; //ms
    private static final int DEFAULT_HEIGHT_VERTICAL = 340; //dp
    protected static final int DEFAULT_MARGIN_HORIZONTAL = 32; //dp
    private int[] editTextIds;
    private int confirmViewId;
    private OnInputResultListener mOnInputResultListener;
    private boolean dismissAfterConfirm;
    private int customizeMaxHeight;

    public CustomizeInputDialog(Context context, @LayoutRes int layoutId) {
        super(context, layoutId, POSITION_NORMAL);
    }

    /**
     * 自定义弹框最大高度
     *
     * @param customizeMaxHeightDp
     * @return
     */
    public CustomizeInputDialog setMaxHeight(int customizeMaxHeightDp) {
        customizeMaxHeight = customizeMaxHeightDp;
        return this;
    }


    /**
     * @param id 所有EditText的ResId, 用于输入结果的回调
     * @return
     */
    public CustomizeInputDialog setEditTextIds(int... id) {
        editTextIds = id;
        return this;
    }

    /**
     * 确认输入后, 获取结果回调，并dismiss
     *
     * @param confirmViewResId 确认输入按钮
     * @param listener         输入结果回调
     * @return
     */
    public CustomizeInputDialog setConfirmAndDismissListener(int confirmViewResId, OnInputResultListener listener) {
        confirmViewId = confirmViewResId;
        mOnInputResultListener = listener;
        dismissAfterConfirm = true;
        return this;
    }

    /**
     * 确认输入后, 获取结果回调，不会dismiss
     *
     * @param confirmViewResId 确认输入按钮
     * @param listener         输入结果回调
     * @return
     */
    public CustomizeInputDialog setConfirmListener(int confirmViewResId, OnInputResultListener listener) {
        confirmViewId = confirmViewResId;
        mOnInputResultListener = listener;
        dismissAfterConfirm = false;
        return this;
    }

    public void resetDimension() {
        if (mPosition == POSITION_NORMAL) {
            //居中弹框设置宽高限制
            int maxWidth = ContextUtils.getScreenWidth() - 2 * ContextUtils.dp2px(getContext(), DEFAULT_MARGIN_HORIZONTAL);
            int maxHeight = Math.min(ContextUtils.getScreenHeight(), ContextUtils.dp2px(getContext(),
                    customizeMaxHeight > 0 ? customizeMaxHeight : DEFAULT_HEIGHT_VERTICAL));
            mContentView.measure(
                    View.MeasureSpec.makeMeasureSpec(maxWidth, View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST));
            Window window = getWindow();
            if (window != null) {
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.width = mContentView.getMeasuredWidth();
                lp.height = mContentView.getMeasuredHeight();
                window.setAttributes(lp);
            }
        }
    }

    @Override
    public void show() {
        //设置回调监听
        if (confirmViewId > 0 && mOnInputResultListener != null && editTextIds.length > 0) {
            View confirmView = findViewById(confirmViewId);
            if (confirmView != null) {
                confirmView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String[] results = new String[editTextIds.length];
                        for (int i = 0; i < editTextIds.length; i++) {
                            results[i] = ((EditText) findViewById(editTextIds[i])).getText().toString().trim();
                        }
                        mOnInputResultListener.onInputResult(results);
                        if (dismissAfterConfirm) {
                            dismiss();
                        }
                    }
                });
            }

        }
        //调整大小
        resetDimension();
        super.show();
        if (editTextIds.length > 0) {
            EditText et = findViewById(editTextIds[0]);
            et.postDelayed(() -> {
                if (isShowing()) {
                    et.requestFocus();
                    et.setSelection(et.getText().length());
                    ContextUtils.showKeyboard(et);
                }
            }, SOFT_KEYBOARD_DELAY_MILLIS);
        }
    }

    public interface OnInputResultListener {
        void onInputResult(String... results);
    }
}
