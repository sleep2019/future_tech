package com.shopee.spx.ui.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.util.AttributeSet;

import androidx.annotation.Dimension;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.util.ContextUtils;

import java.util.Objects;

/**
 * 通过不断绘制两段圆弧来代表刷新状态的简单 Drawable.
 * <p>
 * Created by honggang.xiong on 2019-10-18.
 */
public class RoundRefreshDrawable extends Drawable {

    public static final int REFRESH_DEFAULT_DURATION_MILLIS = 900;
    public static final int REFRESH_DEFAULT_SWIPE_ANGEL = 50;

    private Paint mBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint mFgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RectF mRectF = new RectF();
    private int mRadius;
    private int mStrokeWidth;
    private ColorStateList mBgColor;
    private ColorStateList mFgColor;

    private boolean mRefreshing = false;
    private long mRefreshStartTime;
    private int mRefreshDuration = REFRESH_DEFAULT_DURATION_MILLIS;
    private int mSwipeAngel = REFRESH_DEFAULT_SWIPE_ANGEL;

    public static Params createParams(Context context, AttributeSet attrs) {
        Params params = new Params();
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.RoundRefresh);
        params.mBgColor = ta.getColorStateList(R.styleable.RoundRefresh_refreshBackgroundColor);
        if (params.mBgColor == null) {
            params.mBgColor = ColorStateList.valueOf(Color.BLACK);
        }
        params.mFgColor = ta.getColorStateList(R.styleable.RoundRefresh_refreshForegroundColor);
        if (params.mFgColor == null) {
            params.mFgColor = ColorStateList.valueOf(Color.WHITE);
        }
        params.mRefreshDuration = fixInRange(ta.getInt(R.styleable.RoundRefresh_refreshDuration,
                REFRESH_DEFAULT_DURATION_MILLIS), 100, 100_000);
        params.mStrokeWidth = fixInRange(ta.getDimensionPixelSize(R.styleable.RoundRefresh_refreshStrokeWidth,
                ContextUtils.dp2px(context, 2)), 1, 10_000);
        params.mRadius = fixInRange(ta.getDimensionPixelSize(R.styleable.RoundRefresh_refreshRadius,
                ContextUtils.dp2px(context, 10)), 1, 10_000);
        params.mDrawableSize = fixInRange(ta.getDimensionPixelSize(R.styleable.RoundRefresh_refreshDrawableSize,
                2 * params.mRadius), 2 * params.mRadius, 10_000);
        params.mSwipeAngel = fixInRange(ta.getInt(R.styleable.RoundRefresh_refreshSwipeAngel,
                REFRESH_DEFAULT_SWIPE_ANGEL), 1, 360);
        ta.recycle();
        return params;
    }

    public RoundRefreshDrawable(@Dimension int radius, @Dimension int strokeWidth, @NonNull ColorStateList bgColor, @NonNull ColorStateList fgColor) {
        mRadius = radius;
        mStrokeWidth = strokeWidth;
        updateDrawableColorInternal(bgColor, fgColor);
        mBgPaint.setStyle(Paint.Style.STROKE);
        mBgPaint.setStrokeWidth(mStrokeWidth);
        mFgPaint.setStyle(Paint.Style.STROKE);
        mFgPaint.setStrokeWidth(mStrokeWidth);
    }

    // return true if color changed for current state
    private boolean updateDrawableColorInternal(@NonNull ColorStateList bgColor, @NonNull ColorStateList fgColor) {
        mBgColor = Objects.requireNonNull(bgColor, "bgColor can't be null!");
        mFgColor = Objects.requireNonNull(fgColor, "fgColor can't be null!");
        boolean colorChanged = false;
        int newBgColor = mBgColor.getColorForState(getState(), mBgColor.getDefaultColor());
        if (newBgColor != mBgPaint.getColor()) {
            mBgPaint.setColor(newBgColor);
            colorChanged = true;
        }

        int newFgColor = mFgColor.getColorForState(getState(), mFgColor.getDefaultColor());
        if (newFgColor != mFgPaint.getColor()) {
            mFgPaint.setColor(newFgColor);
            colorChanged = true;
        }
        return colorChanged;
    }

    public void setRefreshDuration(int refreshDuration) {
        mRefreshDuration = refreshDuration;
    }

    public void setSwipeAngel(int swipeAngel) {
        mSwipeAngel = swipeAngel;
    }

    public boolean isRefreshing() {
        return mRefreshing;
    }

    public void startRefresh() {
        mRefreshing = true;
        mRefreshStartTime = SystemClock.elapsedRealtime();
        invalidateSelf();
    }

    public void stopRefresh() {
        mRefreshing = false;
    }

    public void updateDrawableColor(@NonNull ColorStateList bgColor, @NonNull ColorStateList fgColor) {
        updateDrawableColorInternal(bgColor, fgColor);
        if (mRefreshing) {
            invalidateSelf();
        }
    }

    @Override
    public void draw(@NonNull Canvas canvas) {
        long startAngle = -90;
        if (mRefreshing) {
            startAngle = (-90 + (SystemClock.elapsedRealtime() - mRefreshStartTime) * 360 / mRefreshDuration) % 360;
        }
        canvas.drawArc(mRectF, (startAngle + mSwipeAngel) % 360, 360 - mSwipeAngel, false, mBgPaint);
        canvas.drawArc(mRectF, startAngle, mSwipeAngel, false, mFgPaint);
        if (mRefreshing) {
            invalidateSelf();
        }
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        int w = bounds.width();
        int h = bounds.height();
        float r = mRadius - mStrokeWidth / 2.0F;
        float centerX = w / 2.0F;
        float centerY = h / 2.0F;
        mRectF.set(centerX - r, centerY - r, centerX + r, centerY + r);
    }

    @Override
    protected boolean onStateChange(int[] state) {
        if (updateDrawableColorInternal(mBgColor, mFgColor)) {
            invalidateSelf();
            return true;
        }
        return false;
    }

    @Override
    public boolean isStateful() {
        return super.isStateful() || mBgColor.isStateful() || mFgColor.isStateful();
    }

    @Override
    public void setAlpha(int alpha) {
        // ignore
    }

    @Override
    public void setColorFilter(@Nullable ColorFilter colorFilter) {
        // ignore
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    private static int fixInRange(int origin, int low, int high) {
        return Math.min(high, Math.max(origin, low));
    }


    public static class Params {
        // 圆环背景颜色
        ColorStateList mBgColor;
        // 圆环前景颜色
        ColorStateList mFgColor;
        // 循环一圈时间
        int mRefreshDuration;
        int mStrokeWidth;
        int mRadius;
        int mSwipeAngel;
        int mDrawableSize;

        public RoundRefreshDrawable newDrawable() {
            RoundRefreshDrawable drawable = new RoundRefreshDrawable(mRadius, mStrokeWidth, mBgColor, mFgColor);
            drawable.setRefreshDuration(mRefreshDuration);
            drawable.setSwipeAngel(mSwipeAngel);
            drawable.setBounds(0, 0, mDrawableSize, mDrawableSize);
            return drawable;
        }

        public ColorStateList getBgColor() {
            return mBgColor;
        }

        public void setBgColor(ColorStateList bgColor) {
            mBgColor = bgColor;
        }

        public ColorStateList getFgColor() {
            return mFgColor;
        }

        public void setFgColor(ColorStateList fgColor) {
            mFgColor = fgColor;
        }

        public int getRefreshDuration() {
            return mRefreshDuration;
        }

        public void setRefreshDuration(int refreshDuration) {
            mRefreshDuration = refreshDuration;
        }

        public int getStrokeWidth() {
            return mStrokeWidth;
        }

        public void setStrokeWidth(int strokeWidth) {
            mStrokeWidth = strokeWidth;
        }

        public int getRadius() {
            return mRadius;
        }

        public void setRadius(int radius) {
            mRadius = radius;
        }
    }

}
