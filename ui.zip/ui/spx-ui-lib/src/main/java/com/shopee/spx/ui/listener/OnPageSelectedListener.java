package com.shopee.spx.ui.listener;

public interface OnPageSelectedListener {
    void onPageSelected(int position);
}