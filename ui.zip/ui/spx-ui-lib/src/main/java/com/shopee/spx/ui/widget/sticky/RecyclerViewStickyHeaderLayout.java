package com.shopee.spx.ui.widget.sticky;

import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

/**
 * 包裹 {@link RecyclerView} 使其支持头部吸顶功能，RecyclerView 中的 Adapter 需实现 {@link IStickyAdapter}。
 *
 * Notice: 能且只能包裹一个 RecyclerView。
 *
 * Created by honggang.xiong on 2020/9/10.
 */
public class RecyclerViewStickyHeaderLayout extends FrameLayout {

    private static final int VIEW_TAG_TYPE = -101;
    private static final int VIEW_TAG_HOLDER = -102;

    private RecyclerView mRecyclerView;
    private FrameLayout mStickyLayout; // 吸顶容器，用于承载吸顶布局
    private int mCurrentStickyIndex = -1; // 记录当前吸顶的组
    private boolean isSticky = true; // 是否开启吸顶
    private boolean isRegisterDataObserver = false; // 是否已经注册了 adapter 刷新监听

    // 缓存吸顶布局。以吸顶 ViewHolder 的 viewType 为 key，ViewHolder 为 value
    private final SparseArray<RecyclerView.ViewHolder> mStickyViews = new SparseArray<>();

    public RecyclerViewStickyHeaderLayout(@NonNull Context context) {
        super(context);
    }

    public RecyclerViewStickyHeaderLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        if (getChildCount() > 0 || !(child instanceof RecyclerView)) {
            // 最多只能添加一个 RecyclerView，而且只能添加 RecyclerView
            throw new IllegalArgumentException("RecyclerViewStickyHeaderLayout can host only one RecyclerView");
        }
        super.addView(child, index, params);
        mRecyclerView = (RecyclerView) child;
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                // 在滚动的时候，需要不断的更新吸顶布局
                if (isSticky) {
                    updateStickyView(false);
                }
            }
        });
        addStickyLayout();
    }

    private void addStickyLayout() {
        mStickyLayout = new FrameLayout(getContext());
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT);
        mStickyLayout.setLayoutParams(lp);
        super.addView(mStickyLayout, 1, lp);
    }

    /**
     * 强制更新吸顶布局
     */
    public void forceUpdateStickyView() {
        updateStickyView(true);
    }

    /**
     * 更新吸顶布局
     *
     * @param forceUpdate 是否强制更新
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private void updateStickyView(boolean forceUpdate) {
        RecyclerView.Adapter adapter = mRecyclerView.getAdapter();
        if (!(adapter instanceof IStickyAdapter)) {
            return;
        }

        IStickyAdapter stickyAdapter = (IStickyAdapter) adapter;
        registerAdapterDataObserverIfNeeded(adapter);

        int firstVisibleItemPos = getFirstVisibleItemPos();
        // 通过显示的第一个项的 position 获取最近的 sticky index
        int stickyIndex = stickyAdapter.getPreStickyIndexByPosition(firstVisibleItemPos);
        if (forceUpdate || mCurrentStickyIndex != stickyIndex) {
            mCurrentStickyIndex = stickyIndex;

            // 通过 stickyIndex 获取 sticky position
            int stickyPosition = stickyAdapter.getStickyPositionFromIndex(stickyIndex);
            if (stickyPosition != -1) {
                int viewType = adapter.getItemViewType(stickyPosition);

                // 1、尝试复用当前的吸顶布局
                RecyclerView.ViewHolder holder = reuseStickyView(viewType);
                boolean reuseStickyView = holder != null;
                if (holder == null) {
                    // 2、尝试从缓存池中获取吸顶布局
                    holder = mStickyViews.get(viewType);
                }

                if (holder == null) {
                    // 3、通过 adapter 创建吸顶布局
                    holder = adapter.onCreateViewHolder(mRecyclerView, viewType);
                    holder.itemView.setTag(VIEW_TAG_TYPE, viewType);
                    holder.itemView.setTag(VIEW_TAG_HOLDER, holder);
                }

                // 更新吸顶布局的数据，以保证吸顶布局的显示效果和列表一致
                adapter.bindViewHolder(holder, stickyPosition);

                // 如果 holder 不是从当前吸顶布局复用的，需要把吸顶布局添加到容器里
                if (!reuseStickyView) {
                    mStickyLayout.addView(holder.itemView);
                }
            } else {
                // 如果当前没有 sticky，则不显示吸顶布局；并回收旧的吸顶布局
                recycle();
            }
        }

        if (mStickyLayout.getChildCount() > 0) {
            // 这里是处理第一次打开时，吸顶布局已经添加到StickyLayout，但 StickyLayout 的高依然为 0 的情况
            if (mStickyLayout.getHeight() == 0) {
                mStickyLayout.requestLayout();
            }

            // 设置 mStickyLayout 的 Y 偏移量
            int nextStickyPos = stickyAdapter.getStickyPositionFromIndex(stickyAdapter.getNextStickyIndexFromCurrent(stickyIndex));
            float offsetY = calculateOffset(firstVisibleItemPos, nextStickyPos);
            mStickyLayout.setTranslationY(offsetY);
        }
    }

    /**
     * 判断是否可复用吸顶布局，以避免频繁地添加和移除吸顶布局：
     * 如果可复用，则返回当前吸顶布局的 ViewHolder；
     * 如果不复用，则回收吸顶布局并返回 null。
     *
     * @param viewType viewType
     * @return ViewHolder
     */
    private RecyclerView.ViewHolder reuseStickyView(int viewType) {
        if (mStickyLayout.getChildCount() > 0) {
            View view = mStickyLayout.getChildAt(0);
            int type = (int) view.getTag(VIEW_TAG_TYPE);
            if (type == viewType) {
                return (RecyclerView.ViewHolder) view.getTag(VIEW_TAG_HOLDER);
            } else {
                recycle();
            }
        }
        return null;
    }

    /**
     * 回收并移除吸顶布局
     */
    private void recycle() {
        if (mStickyLayout.getChildCount() > 0) {
            View view = mStickyLayout.getChildAt(0);
            mStickyViews.put((int) (view.getTag(VIEW_TAG_TYPE)), (RecyclerView.ViewHolder) (view.getTag(VIEW_TAG_HOLDER)));
            mStickyLayout.removeAllViews();
        }
    }

    /**
     * 计算 StickyLayout 的偏移量，避免发生两个 sticky 布局重叠的情况
     *
     * @param firstVisibleItemPos 当前列表显示的第一项的位置
     * @param nextStickyPos       下一个 sticky 项的位置
     * @return offset
     */
    private float calculateOffset(int firstVisibleItemPos, int nextStickyPos) {
        if (nextStickyPos != -1) {
            int index = nextStickyPos - firstVisibleItemPos;
            if (mRecyclerView.getChildCount() > index) {
                // 获取下一个 sticky 的 itemView
                View view = mRecyclerView.getChildAt(index);
                float offset = view.getY() - mStickyLayout.getHeight();
                if (offset < 0) {
                    return offset;
                }
            }
        }
        return 0;
    }

    /**
     * 获取当前第一个显示的 item position
     */
    private int getFirstVisibleItemPos() {
        RecyclerView.LayoutManager layout = mRecyclerView.getLayoutManager();
        if (layout != null) {
            if (layout instanceof GridLayoutManager) {
                return ((GridLayoutManager) layout).findFirstVisibleItemPosition();
            } else if (layout instanceof LinearLayoutManager) {
                return ((LinearLayoutManager) layout).findFirstVisibleItemPosition();
            } else if (layout instanceof StaggeredGridLayoutManager) {
                int[] firstPositions = new int[((StaggeredGridLayoutManager) layout).getSpanCount()];
                ((StaggeredGridLayoutManager) layout).findFirstVisibleItemPositions(firstPositions);
                return getMin(firstPositions);
            }
        }
        return -1;
    }

    private int getMin(int[] arr) {
        int min = arr[0];
        for (int x = 1; x < arr.length; x++) {
            if (arr[x] < min) {
                min = arr[x];
            }
        }
        return min;
    }

    /**
     * 是否吸顶
     */
    public boolean isSticky() {
        return isSticky;
    }

    /**
     * 设置是否吸顶
     */
    public void setSticky(boolean sticky) {
        if (isSticky != sticky) {
            isSticky = sticky;
            if (mStickyLayout != null) {
                if (isSticky) {
                    mStickyLayout.setVisibility(VISIBLE);
                    updateStickyView(true);
                } else {
                    recycle();
                    mStickyLayout.setVisibility(GONE);
                }
            }
        }
    }

    private void registerAdapterDataObserverIfNeeded(RecyclerView.Adapter<?> adapter) {
        if (!isRegisterDataObserver) {
            isRegisterDataObserver = true;
            adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                @Override
                public void onChanged() {
                    updateStickyViewDelayed();
                }

                @Override
                public void onItemRangeChanged(int positionStart, int itemCount) {
                    updateStickyViewDelayed();
                }

                @Override
                public void onItemRangeInserted(int positionStart, int itemCount) {
                    updateStickyViewDelayed();
                }

                @Override
                public void onItemRangeRemoved(int positionStart, int itemCount) {
                    updateStickyViewDelayed();
                }
            });
        }
    }

    void updateStickyViewDelayed() {
        postDelayed(new Runnable() {
            @Override
            public void run() {
                updateStickyView(true);
            }
        }, 64);
    }

    @Override
    public boolean canScrollVertically(int direction) {
        if (mRecyclerView != null) {
            return mRecyclerView.canScrollVertically(direction);
        }
        return super.canScrollVertically(direction);
    }

    @Override
    public void scrollBy(int x, int y) {
        if (mRecyclerView != null) {
            mRecyclerView.scrollBy(x, y);
        } else {
            super.scrollBy(x, y);
        }
    }

    @Override
    public void scrollTo(int x, int y) {
        if (mRecyclerView != null) {
            mRecyclerView.scrollTo(x, y);
        } else {
            super.scrollTo(x, y);
        }
    }

}
