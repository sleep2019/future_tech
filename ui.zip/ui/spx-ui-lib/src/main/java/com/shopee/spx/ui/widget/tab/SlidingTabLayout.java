package com.shopee.spx.ui.widget.tab;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.listener.OnPageSelectedListener;
import com.shopee.spx.ui.util.ContextUtils;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 自定义滑动TabLayout
 * <p/>
 * 通过 {@link #setViewPager(ViewPager)} 与ViewPager进行关联
 * <p/>
 * create_user: zeng.zheng@shopee.com
 * create_date: 2021/5/28
 **/
public class SlidingTabLayout extends HorizontalScrollView implements ViewPager.OnPageChangeListener {
    private Context mContext;
    private ViewPager mViewPager;
    private ArrayList<String> mTitles;
    private String[] mTabNum;
    private LinearLayout mTabsContainer;
    private int mCurrentTab;
    private float mCurrentPositionOffset;
    private int mTabCount;
    private int mTabTotalWidth;

    private OnPageSelectedListener mListener;
    /**
     * 用于绘制Indicator
     */
    private Rect mIndicatorRect = new Rect();
    /**
     * 用于实现滚动居中
     */
    private Rect mTabRect = new Rect();
    private GradientDrawable mIndicatorDrawable = new GradientDrawable();
    private GradientDrawable mDividerDrawer = new GradientDrawable();

    /**
     * tab
     */
    private float mTabPadding; //dp, 默认24dp
    private float mPagePadding; //dp, 默认16dp
    private float mTabMinWidth; //dp, 默认44dp

    /**
     * indicator
     */
    private int mIndicatorColor; //默认#EE4D2D
    private float mIndicatorHeight; //dp, 默认2dp

    /**
     * title
     */
    private float mTextSize; //sp, 默认14sp
    private int mTextSelectColor; //默认#303844
    private int mTextUnselectColor; //默认#96A5B4
    private boolean mTextMediumStyle; //默认true

    /**
     * divider
     */
    private boolean mShowBottomDivider; //默认true

    private int mLastScrollX;
    private boolean mSnapOnTabClick;

    public SlidingTabLayout(Context context) {
        this(context, null, 0);
    }

    public SlidingTabLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SlidingTabLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setFillViewport(true);//设置滚动视图是否可以伸缩其内容以填充视口
        setWillNotDraw(false);//重写onDraw方法,需要调用这个方法来清除flag
        setClipChildren(false);
        setClipToPadding(false);

        this.mContext = context;
        mTabsContainer = new LinearLayout(context);
        addView(mTabsContainer);

        obtainAttributes(context, attrs);
    }

    private void obtainAttributes(Context context, AttributeSet attrs) {
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.SlidingTabLayout);

        mIndicatorColor = ta.getColor(R.styleable.SlidingTabLayout_tl_indicator_color, Color.parseColor("#EE4D2D"));
        mIndicatorHeight = ta.getDimension(R.styleable.SlidingTabLayout_tl_indicator_height, ContextUtils.dp2px(context, 2));

        mTextSize = ta.getDimension(R.styleable.SlidingTabLayout_tl_text_size, ContextUtils.sp2px(context, 14));
        mTextSelectColor = ta.getColor(R.styleable.SlidingTabLayout_tl_text_select_color, Color.parseColor("#303844"));
        mTextUnselectColor = ta.getColor(R.styleable.SlidingTabLayout_tl_text_unselect_color, Color.parseColor("#96A5B4"));
        mTextMediumStyle = ta.getBoolean(R.styleable.SlidingTabLayout_tl_textMedium, true);

        mTabPadding = ta.getDimension(R.styleable.SlidingTabLayout_tl_padding_between_tabs, ContextUtils.dp2px(context, 24));
        mPagePadding = ta.getDimension(R.styleable.SlidingTabLayout_tl_padding_between_tab_page, ContextUtils.dp2px(context, 16));
        mTabMinWidth = ta.getDimension(R.styleable.SlidingTabLayout_tl_tab_min_width, ContextUtils.dp2px(context, 44));

        mShowBottomDivider = ta.getBoolean(R.styleable.SlidingTabLayout_tl_divider_visible, true);

        ta.recycle();
    }

    /**
     * 关联ViewPager
     */
    public void setViewPager(ViewPager vp) {
        if (vp == null || vp.getAdapter() == null) {
            throw new IllegalStateException("ViewPager or ViewPager adapter can not be NULL !");
        }

        this.mViewPager = vp;

        this.mViewPager.removeOnPageChangeListener(this);
        this.mViewPager.addOnPageChangeListener(this);
        notifyDataSetChanged();
    }

    /**
     * 关联ViewPager,用于不想在ViewPager适配器中设置titles数据的情况
     */
    public void setViewPager(ViewPager vp, String[] titles) {
        if (vp == null || vp.getAdapter() == null) {
            throw new IllegalStateException("ViewPager or ViewPager adapter can not be NULL !");
        }

        if (titles == null || titles.length == 0) {
            throw new IllegalStateException("Titles can not be EMPTY !");
        }

        if (titles.length != vp.getAdapter().getCount()) {
            throw new IllegalStateException("Titles length must be the same as the page count !");
        }

        this.mViewPager = vp;
        mTitles = new ArrayList<>();
        Collections.addAll(mTitles, titles);

        mTabNum =new String[titles.length];
        this.mViewPager.removeOnPageChangeListener(this);
        this.mViewPager.addOnPageChangeListener(this);
        notifyDataSetChanged();
    }

    /**
     * 更新数据
     */
    public void notifyDataSetChanged() {
        mTabsContainer.removeAllViews();
        PagerAdapter adapter = mViewPager.getAdapter();
        if (adapter == null) {
            throw new IllegalStateException("ViewPager or ViewPager adapter can not be NULL !");
        }
        this.mTabCount = (mTitles == null ? adapter.getCount() : mTitles.size());
        View tabView;
        for (int i = 0; i < mTabCount; i++) {
            tabView = View.inflate(mContext, R.layout.spx_ui_layout_tab_item, null);
            CharSequence pageTitle = mTitles == null ? mViewPager.getAdapter().getPageTitle(i) : mTitles.get(i);
            if (pageTitle != null) {
                addTab(i, pageTitle.toString(), tabView);
            }
        }
        updateTabStyles();
    }

    public void addNewTab(String title) {
        View tabView = View.inflate(mContext, R.layout.spx_ui_layout_tab_item, null);
        PagerAdapter adapter = mViewPager.getAdapter();
        if (adapter == null) {
            throw new IllegalStateException("ViewPager or ViewPager adapter can not be NULL !");
        }
        if (mTitles != null) {
            mTitles.add(title);
        }

        CharSequence pageTitle = mTitles == null ? adapter.getPageTitle(mTabCount) : mTitles.get(mTabCount);
        if (pageTitle != null) {
            addTab(mTabCount, pageTitle.toString(), tabView);
        }
        this.mTabCount = mTitles == null ? adapter.getCount() : mTitles.size();

        updateTabStyles();
    }

    /**
     * 创建并添加tab
     */
    private void addTab(final int position, String title, View tabView) {
        TextView tvTabTitle = (TextView) tabView.findViewById(R.id.tv_tab_title);
        if (tvTabTitle != null) {
            if (title != null) tvTabTitle.setText(title);
        }

        tabView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = mTabsContainer.indexOfChild(v);
                if (position != -1) {
                    if (mViewPager.getCurrentItem() != position) {
                        if (mSnapOnTabClick) {
                            mViewPager.setCurrentItem(position, false);
                        } else {
                            mViewPager.setCurrentItem(position);
                        }
                    }
                }
            }
        });

        /** 每一个Tab的布局参数 */
        LinearLayout.LayoutParams lp_tab = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT);
        mTabsContainer.addView(tabView, position, lp_tab);
    }

    private void updateTabStyles() {
        for (int i = 0; i < mTabCount; i++) {
            View v = mTabsContainer.getChildAt(i);
            TextView tvTabTitle = v.findViewById(R.id.tv_tab_title);
            if (tvTabTitle != null) {
                String title = tvTabTitle.getText().toString();
                tvTabTitle.setTextColor(i == mCurrentTab ? mTextSelectColor : mTextUnselectColor);
                tvTabTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, mTextSize);
                if (i == 0) {
                    tvTabTitle.setPadding((int) mPagePadding, 0, (int) mTabPadding / 2, 0);
                } else if (i == mTabCount - 1) {
                    tvTabTitle.setPadding((int) mTabPadding / 2, 0, (int) mPagePadding, 0);
                } else {
                    tvTabTitle.setPadding((int) mTabPadding / 2, 0, (int) mTabPadding / 2, 0);
                }
                if (mTextMediumStyle) {
                    tvTabTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
                }
                if (tvTabTitle.getPaint().measureText(title) < mTabMinWidth) {
                    MarginLayoutParams lp = (MarginLayoutParams) tvTabTitle.getLayoutParams();
                    if (i == 0 || i == (mTabCount - 1)) {
                        lp.width = (int) mTabMinWidth + (int) mPagePadding + (int) mTabPadding / 2;
                    } else {
                        lp.width = (int) mTabMinWidth + (int) mTabPadding;
                    }
                    tvTabTitle.setLayoutParams(lp);
                }
            }
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        /**
         * position:当前View的位置
         * mCurrentPositionOffset:当前View的偏移量比例.[0,1)
         */
        this.mCurrentTab = position;
        this.mCurrentPositionOffset = positionOffset;
        scrollToCurrentTab();
        invalidate();
    }

    @Override
    public void onPageSelected(int position) {
        updateTabSelection(position);
        if (mListener != null) {
            mListener.onPageSelected(position);
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        // 最后纠正颜色
        if (state == ViewPager.SCROLL_STATE_IDLE) {
            for (int i = 0; i < mTabCount; i++) {
                View v = mTabsContainer.getChildAt(i);
                TextView tvTabTitle = v.findViewById(R.id.tv_tab_title);
                if (tvTabTitle != null) {
                    tvTabTitle.setTextColor(i == mCurrentTab ? mTextSelectColor : mTextUnselectColor);
                }
            }
        }
    }

    /**
     * HorizontalScrollView滚到当前tab,并且居中显示
     */
    private void scrollToCurrentTab() {
        if (mTabCount <= 0) {
            return;
        }

        int offset = (int) (mCurrentPositionOffset * mTabsContainer.getChildAt(mCurrentTab).getWidth());
        /**当前Tab的left+当前Tab的Width乘以positionOffset*/
        int newScrollX = mTabsContainer.getChildAt(mCurrentTab).getLeft() + offset;

        if (mCurrentTab > 0 || offset > 0) {
            /**HorizontalScrollView移动到当前tab,并居中*/
            newScrollX -= getWidth() / 2 - getPaddingLeft();
            calcIndicatorRect();
            newScrollX += ((mTabRect.right - mTabRect.left) / 2);
        }

        if (newScrollX != mLastScrollX) {
            mLastScrollX = newScrollX;
            /** scrollTo（int x,int y）:x,y代表的不是坐标点,而是偏移量
             *  x:表示离起始位置的x水平方向的偏移量
             *  y:表示离起始位置的y垂直方向的偏移量
             */
            scrollTo(newScrollX, 0);
        }
    }

    private void updateTabSelection(int position) {
        for (int i = 0; i < mTabCount; ++i) {
            View tabView = mTabsContainer.getChildAt(i);
            final boolean isSelect = (i == position);
            TextView tvTabTitle = tabView.findViewById(R.id.tv_tab_title);

            if (tvTabTitle != null) {
                tvTabTitle.setTextColor(isSelect ? mTextSelectColor : mTextUnselectColor);
            }
        }
    }

    private float leftMargin;
    private float rightMargin;

    private void calcIndicatorRect() {
        View currentTabView = mTabsContainer.getChildAt(this.mCurrentTab);
        float left = currentTabView.getLeft();
        float right = currentTabView.getRight();

        TextView tabTitle = currentTabView.findViewById(R.id.tv_tab_title);
        float textWidth = tabTitle.getPaint().measureText(tabTitle.getText().toString());
        textWidth = Math.max(textWidth, mTabMinWidth);

        if (mCurrentTab == 0) {
            leftMargin = mPagePadding;
            rightMargin = right - left - textWidth - mPagePadding;
        } else if (mCurrentTab == mTabCount - 1) {
            rightMargin = mPagePadding;
            leftMargin = right - left - textWidth - mPagePadding;
        } else {
            leftMargin = (right - left - textWidth) / 2;
            rightMargin = (right - left - textWidth) / 2;
        }

        if (this.mCurrentTab < mTabCount - 1) {
            View nextTabView = mTabsContainer.getChildAt(this.mCurrentTab + 1);
            float nextTabLeft = nextTabView.getLeft();
            float nextTabRight = nextTabView.getRight();

            left = left + mCurrentPositionOffset * (nextTabLeft - left);
            right = right + mCurrentPositionOffset * (nextTabRight - right);

            TextView nextTabTitle = nextTabView.findViewById(R.id.tv_tab_title);
            float nextTextWidth = nextTabTitle.getPaint().measureText(nextTabTitle.getText().toString());
            nextTextWidth = Math.max(nextTextWidth, mTabMinWidth);
            float nextLeftMargin = (nextTabRight - nextTabLeft - nextTextWidth) / 2;
            float nextRightMargin = (nextTabRight - nextTabLeft - nextTextWidth) / 2;
            if (mCurrentTab + 1 == mTabCount - 1) {
                nextRightMargin = mPagePadding;
                nextLeftMargin = right - left - nextTextWidth - mPagePadding;
            }

            leftMargin = leftMargin + mCurrentPositionOffset * (nextLeftMargin - leftMargin);
            rightMargin = rightMargin + mCurrentPositionOffset * (nextRightMargin - rightMargin);
        }
        mIndicatorRect.left = (int) (left + leftMargin - 1);
        mIndicatorRect.right = (int) (right - rightMargin - 1);

        mTabRect.left = (int) left;
        mTabRect.right = (int) right;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (isInEditMode() || mTabCount <= 0) {
            return;
        }

        int height = getHeight();
        int paddingLeft = getPaddingLeft();

        calcIndicatorRect();

        //draw divide
        if (mShowBottomDivider) {
            mDividerDrawer.setColor(Color.parseColor("#E7EDF2"));
            mDividerDrawer.setBounds(0, height - ContextUtils.dp2px(mContext, 0.5f), getWidth() * 5, height); //这里divider长度因为没有办法准确算出，取值5*getWidth
            mDividerDrawer.draw(canvas);
        }

        //draw indicator line
        if (mIndicatorHeight > 0) {
            mIndicatorDrawable.setColor(mIndicatorColor);
            mIndicatorDrawable.setBounds(paddingLeft + mIndicatorRect.left, height - (int) mIndicatorHeight,
                    paddingLeft + mIndicatorRect.right, height);
            mIndicatorDrawable.draw(canvas);
        }
    }

        /**
         * 单纯的改变tab上面的文字
         *
         * @param titles
         */
        public void updateTitles(String[] titles, ArrayList<String> numbers) {
            mTitles = new ArrayList<>();
            if (null != titles && null != numbers && titles.length > 0 && titles.length == numbers.size()) {
                for (int i = 0; i < titles.length; i++) {
                    if (!TextUtils.isEmpty(numbers.get(i))) {
                        mTabNum[i] = numbers.get(i);
                    }
                    if (!TextUtils.isEmpty(mTabNum[i])) {
                        mTitles.add(titles[i] + " (" + mTabNum[i] + ")");
                    } else {
                        mTitles.add(titles[i]);
                    }
                }
            }
            notifyDataSetChanged();
        }

    /**
     * 单纯的改变tab上面的文字
     * 与{@link #updateTitles(String[], ArrayList)}不同的是 重置了mTabNum数量
     *
     * @param titles
     */
    public void updateTitlesWithTabChanged(String[] titles, ArrayList<String> numbers) {
        mTitles = new ArrayList<>();
        if (titles == null) {
            return;
        }
        mTabNum = new String[titles.length];
        if (null != numbers && titles.length > 0 && titles.length == numbers.size()) {
            for (int i = 0; i < titles.length; i++) {
                if (!TextUtils.isEmpty(numbers.get(i))) {
                    mTabNum[i] = numbers.get(i);
                }
                if (!TextUtils.isEmpty(mTabNum[i])) {
                    mTitles.add(titles[i] + " (" + mTabNum[i] + ")");
                } else {
                    mTitles.add(titles[i]);
                }
            }
        }
        notifyDataSetChanged();
    }

    //setter and getter
    public void setCurrentTab(int currentTab) {
        this.mCurrentTab = currentTab;
        mViewPager.setCurrentItem(currentTab);
    }

    public void setBottomDividerVisible(boolean visible) {
        mShowBottomDivider = visible;
        invalidate();
    }

    public void setCurrentTab(int currentTab, boolean smoothScroll) {
        this.mCurrentTab = currentTab;
        mViewPager.setCurrentItem(currentTab, smoothScroll);
    }

    public void setTabPadding(float tabPadding) {
        this.mTabPadding = ContextUtils.dp2px(mContext, tabPadding);
        updateTabStyles();
    }

    public void setTabMinWidth(float tabMinWidth) {
        this.mTabMinWidth = ContextUtils.dp2px(mContext, tabMinWidth);
        updateTabStyles();
    }

    public void setIndicatorColor(int indicatorColor) {
        this.mIndicatorColor = indicatorColor;
        invalidate();
    }

    public void setIndicatorHeight(float indicatorHeight) {
        this.mIndicatorHeight = ContextUtils.dp2px(mContext, indicatorHeight);
        invalidate();
    }

    public void setTextSize(float textSize) {
        this.mTextSize = ContextUtils.sp2px(mContext, textSize);
        updateTabStyles();
    }

    public void setTextSelectColor(int textSelectColor) {
        this.mTextSelectColor = textSelectColor;
        updateTabStyles();
    }

    public void setTextUnselectColor(int textUnselectColor) {
        this.mTextUnselectColor = textUnselectColor;
        updateTabStyles();
    }

    public void setTextMediumStyle(boolean textMedium) {
        this.mTextMediumStyle = textMedium;
        updateTabStyles();
    }

    public void setSnapOnTabClick(boolean snapOnTabClick) {
        mSnapOnTabClick = snapOnTabClick;
    }

    public int getTabCount() {
        return mTabCount;
    }

    public int getCurrentTab() {
        return mCurrentTab;
    }

    public float getTabPadding() {
        return mTabPadding;
    }

    public float getTabMinWidth() {
        return mTabMinWidth;
    }

    public int getIndicatorColor() {
        return mIndicatorColor;
    }

    public float getIndicatorHeight() {
        return mIndicatorHeight;
    }

    public float getTextSize() {
        return mTextSize;
    }

    public int getTextSelectColor() {
        return mTextSelectColor;
    }

    public int getTextUnselectColor() {
        return mTextUnselectColor;
    }

    public boolean isTextMediumStyle() {
        return mTextMediumStyle;
    }

    public TextView getTitleView(int tab) {
        View tabView = mTabsContainer.getChildAt(tab);
        TextView tvTabTitle = (TextView) tabView.findViewById(R.id.tv_tab_title);
        return tvTabTitle;
    }

    public void setOnPageSelectListener(OnPageSelectedListener listener) {
        this.mListener = listener;
    }

    @Override
    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        bundle.putInt("mCurrentTab", mCurrentTab);
        return bundle;
    }

    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof Bundle) {
            Bundle bundle = (Bundle) state;
            mCurrentTab = bundle.getInt("mCurrentTab");
            state = bundle.getParcelable("instanceState");
            if (mCurrentTab != 0 && mTabsContainer.getChildCount() > 0) {
                updateTabSelection(mCurrentTab);
                scrollToCurrentTab();
            }
        }
        super.onRestoreInstanceState(state);
    }
}
