package com.shopee.spx.ui.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;

/**
 * Created by honggang.xiong on 2021/12/22.
 */
public abstract class TrackingDialog<D extends TrackingDialog<?>> extends Dialog {

    // 全局的上报 pv 时使用的 pageName 前缀以及上报点击事件时使用的 pageName 前缀，根据设计需要可能不一样。
    // eg: pvPageName = "dialog_home_page_exit"，clickEvent = "btn_home_page_exit_cancel"，则 pageName
    // 设置为 "home_page_exit"，sPvPageNamePrefix 设置为 "dialog"，sClickPageNamePrefix 设置为 "btn"
    private static String sGlobalPvPageNamePrefix;
    private static String sGlobalClickPageNamePrefix;
    private static EventTrackListener sTrackListener;

    private long mPvStartTime;
    private String mReportPageName;
    private String mReportUserType;
    private String mPvPageNamePrefix;
    private String mClickPageNamePrefix;

    public TrackingDialog(@NonNull Context context) {
        this(context, 0);
    }

    public TrackingDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
        mPvPageNamePrefix = sGlobalPvPageNamePrefix;
        mClickPageNamePrefix = sGlobalClickPageNamePrefix;
    }

    // 静态实例，全局设置一次即可
    public static void setEventTrackListener(EventTrackListener listener) {
        sTrackListener = listener;
    }

    public static void setGlobalPageNamePrefix(String pvPrefix, String clickPrefix) {
        sGlobalPvPageNamePrefix = pvPrefix;
        sGlobalClickPageNamePrefix = clickPrefix;
    }

    @NonNull
    protected abstract D getSelf();

    public D setOnClickListener(@IdRes int viewId, View.OnClickListener listener) {
        return setOnClickListener(viewId, listener, null, true);
    }

    public D setOnClickListener(@IdRes int viewId, View.OnClickListener listener, boolean autoDismiss) {
        return setOnClickListener(viewId, listener, null, autoDismiss);
    }

    public D setOnClickListener(@IdRes int viewId, View.OnClickListener listener, String trackClickSuffix) {
        return setOnClickListener(viewId, listener, trackClickSuffix, true);
    }

    public D setOnClickListener(@IdRes int viewId, View.OnClickListener listener, String trackClickSuffix,
                                boolean autoDismiss) {
        findViewById(viewId).setOnClickListener(v -> {
            reportClick(trackClickSuffix);
            if (listener != null) {
                listener.onClick(v);
            }
            if (autoDismiss) {
                dismiss();
            }
        });
        return getSelf();
    }

    public D setReportPageName(String reportPageName) {
        mReportPageName = reportPageName;
        return getSelf();
    }

    public D setReportUserType(String reportUserType) {
        mReportUserType = reportUserType;
        return getSelf();
    }

    public D setPageNamePrefix(String pvPrefix, String clickPrefix) {
        mPvPageNamePrefix = pvPrefix;
        mClickPageNamePrefix = clickPrefix;
        return getSelf();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mPvStartTime = SystemClock.elapsedRealtime();
        reportPv();
    }

    @Override
    protected void onStop() {
        super.onStop();
        reportDuration();
    }

    private void reportPv() {
        String pvPageName = getPvPageName();
        if (sTrackListener != null && !TextUtils.isEmpty(pvPageName)) {
            sTrackListener.onTrackPv(pvPageName, mReportUserType);
        }
    }

    private void reportDuration() {
        String pvPageName = getPvPageName();
        if (sTrackListener != null && !TextUtils.isEmpty(pvPageName)) {
            sTrackListener.onTrackDuration(pvPageName, SystemClock.elapsedRealtime() - mPvStartTime, mReportUserType);
        }
    }

    protected void reportClick(String clickSuffix) {
        String clickPageName = getClickPageName();
        if (sTrackListener != null && !TextUtils.isEmpty(clickPageName) && !TextUtils.isEmpty(clickSuffix)) {
            sTrackListener.onTrackClick(clickPageName + "_" + clickSuffix, mReportUserType);
        }
    }

    protected String getPvPageName() {
        if (TextUtils.isEmpty(mReportPageName)) {
            return null;
        }
        return TextUtils.isEmpty(mPvPageNamePrefix) ? mReportPageName : mPvPageNamePrefix + "_" + mReportPageName;
    }

    protected String getClickPageName() {
        if (TextUtils.isEmpty(mReportPageName)) {
            return null;
        }
        return TextUtils.isEmpty(mClickPageNamePrefix) ? mReportPageName : mClickPageNamePrefix + "_" + mReportPageName;
    }


    public interface EventTrackListener {
        void onTrackPv(String pageName, String userType);

        void onTrackDuration(String pageName, long stayMillis, String userType);

        void onTrackClick(String eventKey, String userType);
    }

}
