package com.shopee.spx.ui.widget.picker;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;

import androidx.annotation.IntRange;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.util.ContextUtils;

/**
 * 滚轮控件
 * <p>
 * Created by honggang.xiong on 2019/9/29.
 */
public class WheelView extends View {

    private TextPaint mTextPaintOut = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private TextPaint mTextPaintCenter = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private Paint mIndicatorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int mTextSizeOut;
    private int mTextSizeCenter;
    private boolean mTextAlignEnd;

    private int mTextColorOut;
    private int mTextColorCenter;
    private int mDividerColor = 0xFFDDDDDD;
    private int mDividerPaddingStart;
    private int mDividerPaddingEnd;

    // 每行高度
    @IntRange(from = 1)
    private int mItemHeight;
    // 当高度为 wrap_content 时，控件最大高度为 mItemHeight * mMaxItems，实际绘制的item数最多为n+1
    @IntRange(from = 0)
    private int mMaxItems;
    // 是否为循环模式
    private boolean mCyclic;

    // 第一条分隔线Y坐标
    private int mFirstDividerY;
    // 第二条分隔线Y坐标
    private int mSecondDividerY;

    // 滚动总高度Y值
    private int mTotalScrollY = 0;
    // 初始化默认选中的index
    private int mInitPosition = 0;
    // 当前选中 item 的index
    private int mSelectedPosition;
    // Scroller 运行时的临时变量，存储上一次的 scrollerY
    private int mPreScrollerY;

    // responsible for flinging the wheel.
    private final Scroller mFlingScroller;
    // responsible for adjusting the wheel.
    private final Scroller mAdjustScroller;

    private WheelAdapter<?> mWheelAdapter;
    private GestureDetector mGestureDetector;
    private OnItemSelectedListener mOnItemSelectedListener;

    public WheelView(Context context) {
        this(context, null);
    }

    public WheelView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.WheelView);
        mTextSizeOut = a.getDimensionPixelOffset(R.styleable.WheelView_wv_textSizeOut,
                context.getResources().getDimensionPixelSize(R.dimen.picker_text_size_out));
        mTextSizeCenter = a.getDimensionPixelOffset(R.styleable.WheelView_wv_textSizeCenter,
                context.getResources().getDimensionPixelSize(R.dimen.picker_text_size_center));
        mTextColorOut = a.getColor(R.styleable.WheelView_wv_textColorOut, Color.BLACK);
        mTextColorCenter = a.getColor(R.styleable.WheelView_wv_textColorCenter, Color.BLACK);
        mTextAlignEnd = a.getBoolean(R.styleable.WheelView_wv_textAlignEnd, false);
        mDividerColor = a.getColor(R.styleable.WheelView_wv_dividerColor, mDividerColor);
        mDividerPaddingStart = a.getDimensionPixelOffset(R.styleable.WheelView_wv_dividerPaddingStart, 0);
        mDividerPaddingEnd = a.getDimensionPixelOffset(R.styleable.WheelView_wv_dividerPaddingEnd, 0);
        int itemHeight = a.getDimensionPixelSize(R.styleable.WheelView_wv_itemHeight,
                context.getResources().getDimensionPixelSize(R.dimen.picker_item_height));
        int maxItems = a.getInt(R.styleable.WheelView_wv_maxItems, 7);
        mCyclic = a.getBoolean(R.styleable.WheelView_wv_isCyclic, true);
        a.recycle();

        setItemHeight(itemHeight);
        setMaxItems(maxItems);

        mFlingScroller = new Scroller(context, null, true);
        mAdjustScroller = new Scroller(context, new DecelerateInterpolator(2.5f));

        mGestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                scrollBy(0, (int) distanceY);
                invalidate();
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                adjustScroll((int) e.getY());
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                fling((int) -velocityY);
                return true;
            }
        });
        mGestureDetector.setIsLongpressEnabled(false);

        mTextPaintOut.setColor(mTextColorOut);
        mTextPaintOut.setTextSize(mTextSizeOut);
        mTextPaintOut.setTextAlign(mTextAlignEnd ? Paint.Align.RIGHT : Paint.Align.CENTER);

        mTextPaintCenter.setColor(mTextColorCenter);
        mTextPaintCenter.setTextSize(mTextSizeCenter);
        mTextPaintCenter.setTextAlign(mTextAlignEnd ? Paint.Align.RIGHT : Paint.Align.CENTER);

        mIndicatorPaint.setColor(mDividerColor);
        mIndicatorPaint.setStrokeWidth(ContextUtils.dp2px(context, 1));
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        int height = heightSize;
        int desiredHeight = mMaxItems * mItemHeight;
        switch (heightMode) {
            case MeasureSpec.UNSPECIFIED:
                height = desiredHeight;
                break;
            case MeasureSpec.AT_MOST:
                height = Math.min(heightSize, desiredHeight);
                break;
            case MeasureSpec.EXACTLY:
                height = heightSize;
                break;
        }
        setMeasuredDimension(getDefaultSize(getSuggestedMinimumWidth(), widthMeasureSpec), height);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        // 计算两条横线的Y坐标
        mFirstDividerY = (h - mItemHeight) / 2;
        mSecondDividerY = (h + mItemHeight) / 2;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean eventConsumed = mGestureDetector.onTouchEvent(event);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mFlingScroller.forceFinished(true);
                mAdjustScroller.forceFinished(true);
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
            default:
                if (!eventConsumed) {
                    // 拖拽事件 ACTION_UP 时，不会回调 onSingleTapUp，eventConsumed 为 false，进行一次调整操作
                    adjustScroll(-1);
                }
                break;
        }
        return true;
    }

    private boolean adjustScroll(int tapY) {
        if (!mFlingScroller.isFinished()) {
            mFlingScroller.forceFinished(true);
        }

        int offset = -(mTotalScrollY % mItemHeight);
        if (Math.abs(offset) > mItemHeight / 2) {
            offset += (offset > 0) ? -mItemHeight : mItemHeight;
        }

        if (tapY >= 0) { // adjustScroll 由单击触发时，计算当前点击位置和选中Rect之间隔了几个item
            int centerTopY = mFirstDividerY + offset;
            int centerBottomY = mSecondDividerY + offset;
            if (tapY < centerTopY) {
                // 单击在选中Rect上方时
                offset += ((tapY - centerBottomY) / mItemHeight) * mItemHeight;
            } else if (tapY > centerBottomY) {
                // 单击在选中Rect下方时
                offset += ((tapY - centerTopY) / mItemHeight) * mItemHeight;
            }
            // 单击在选中Rect中时，则不需要增加额外的offset
        }

        if (offset != 0) {
            mPreScrollerY = 0;
            mAdjustScroller.startScroll(0, 0, 0, offset, 800);
            postInvalidateOnAnimation();
            return true;
        }
        return false;
    }

    protected void fling(int velocityY) {
        mPreScrollerY = 0;
        mFlingScroller.fling(0, velocityY > 0 ? 0 : Integer.MAX_VALUE, 0, velocityY,
                0, 0, 0, Integer.MAX_VALUE);
        invalidate();
    }

    @Override
    public void computeScroll() {
        Scroller scroller = mFlingScroller;
        if (scroller.isFinished()) {
            scroller = mAdjustScroller;
            if (scroller.isFinished()) {
                return;
            }
        }
        scroller.computeScrollOffset();
        int currentScrollerY = scroller.getCurrY();
        if (mPreScrollerY == 0) {
            mPreScrollerY = scroller.getStartY();
        }
        scrollBy(0, currentScrollerY - mPreScrollerY);
        mPreScrollerY = currentScrollerY;
        if (scroller.isFinished()) {
            // fling 结束无需调整 或者 adjust 结束时，计算当前 position
            if (scroller != mFlingScroller || !adjustScroll(-1)) {
                calculateCurrentPosition(true);
            }
        } else {
            postInvalidateOnAnimation();
        }
    }

    @Override
    public void scrollBy(int x, int y) {
        mTotalScrollY += y;

        if (!mCyclic) { // 如果不是循环模式，则越界需回滚
            int top = -mInitPosition * mItemHeight;
            int bottom = (getItemCount() - 1 - mInitPosition) * mItemHeight;
            if (mTotalScrollY <= top || mTotalScrollY >= bottom) {
                mFlingScroller.forceFinished(true);
                mAdjustScroller.forceFinished(true);
                // pin to [top...bottom]
                mTotalScrollY = Math.min(mTotalScrollY, bottom);
                mTotalScrollY = Math.max(mTotalScrollY, top);
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        WheelAdapter<?> adapter = mWheelAdapter;
        if (adapter == null || getHeight() <= 0) {
            return;
        }

        // 中间两条横线
        canvas.drawLine(mDividerPaddingStart, mFirstDividerY, getWidth() - mDividerPaddingEnd, mFirstDividerY, mIndicatorPaint);
        canvas.drawLine(mDividerPaddingStart, mSecondDividerY, getWidth() - mDividerPaddingEnd, mSecondDividerY, mIndicatorPaint);

        final int itemCount = adapter.getItemCount();
        if (itemCount <= 0) {
            return;
        }

        int change = mTotalScrollY / mItemHeight;
        // 滚动中当前选中的index(即经过了中间位置item的index)
        int currentIndex = mInitPosition + change % itemCount;
        int baseIndex = currentIndex - mMaxItems / 2;
        int baseTopY = mFirstDividerY - mTotalScrollY % mItemHeight - (mMaxItems / 2) * mItemHeight;

        // 循环 n+2 次，实际符合绘制条件的item数小于等于 n+1
        for (int i = -1; i <= mMaxItems; i++) {
            // 索引值，即当前在控件中间的item看作数据源的中间，计算出相对源数据源的index值
            // 判断是否循环，如果是循环数据源也使用相对循环的position获取对应的item值
            int index = baseIndex + i;
            if (mCyclic) {
                index = (index % itemCount + itemCount) % itemCount;
            }
            if (index < 0 || index >= itemCount) {
                continue;
            }

            int topY = baseTopY + i * mItemHeight;
            if (topY < -mItemHeight || topY > getHeight()) {
                continue;
            }

            int diffY = Math.abs(mFirstDividerY - topY);
            TextPaint textPaint = mTextPaintOut;
            if (diffY < mItemHeight) {
                mTextPaintCenter.setTextSize(mTextSizeOut + (mTextSizeCenter - mTextSizeOut) * (1.0F - (float) diffY / mItemHeight));
                textPaint = mTextPaintCenter;
                if (diffY < mItemHeight / 2) {
                    mSelectedPosition = index;
                }
            }
            float baseY = topY + Math.round((mItemHeight - textPaint.ascent() - textPaint.descent()) / 2);
            float baseX = mTextAlignEnd ? (getWidth() * 3 / 4F) : (getWidth() / 2F);
            canvas.drawText(adapter.getDisplayText(index), baseX, baseY, textPaint);
        }
    }

    /**
     * @param size The scaled pixel size.
     */
    public void setTextSizeCenter(float size) {
        if (size > 0) {
            mTextSizeCenter = ContextUtils.sp2px(getContext(), size);
            mTextPaintCenter.setTextSize(mTextSizeCenter);
            invalidate();
        }
    }

    public void setTextSizeOut(float size) {
        if (size > 0) {
            mTextSizeOut = ContextUtils.sp2px(getContext(), size);
            mTextPaintOut.setTextSize(mTextSizeOut);
            invalidate();
        }
    }

    public void setTextColorOut(int outTextColor) {
        if (mTextColorOut != outTextColor && outTextColor != 0) {
            mTextColorOut = outTextColor;
            mTextPaintOut.setColor(mTextColorOut);
            invalidate();
        }
    }

    public void setTextColorCenter(int centerTextColor) {
        if (mTextColorCenter != centerTextColor && centerTextColor != 0) {
            mTextColorCenter = centerTextColor;
            mTextPaintCenter.setColor(mTextColorCenter);
            invalidate();
        }
    }

    public void setDividerColor(int dividerColor) {
        if (mDividerColor != dividerColor && dividerColor != 0) {
            mDividerColor = dividerColor;
            mIndicatorPaint.setColor(mDividerColor);
            invalidate();
        }
    }

    public int getItemHeight() {
        return mItemHeight;
    }

    public void setItemHeight(int itemHeight) {
        if (itemHeight <= 0) {
            throw new IllegalArgumentException("itemHeight should be bigger than 0, input=" + itemHeight);
        }
        mItemHeight = itemHeight;
        requestLayout();
    }

    public void setMaxItems(int maxItems) {
        if (maxItems < 0) {
            throw new IllegalArgumentException("maxItems should be bigger than -1, input=" + maxItems);
        }
        mMaxItems = maxItems;
        requestLayout();
    }

    public boolean isCyclic() {
        return mCyclic;
    }

    public final void setCyclic(boolean cyclic) {
        if (mCyclic != cyclic) {
            mCyclic = cyclic;
            if (!mCyclic) {
                // 设为非循环时，totalScrollY置为0
                mTotalScrollY = 0;
            }
            invalidate();
        }
    }

    public int getInitPosition() {
        return mInitPosition;
    }

    public void setInitPosition(int initPosition) {
        mInitPosition = mSelectedPosition = initPosition;
        mTotalScrollY = 0;
        invalidate();
    }

    public void setOnItemSelectedListener(OnItemSelectedListener OnItemSelectedListener) {
        mOnItemSelectedListener = OnItemSelectedListener;
    }

    public WheelAdapter<?> getWheelAdapter() {
        return mWheelAdapter;
    }

    public void setWheelAdapter(WheelAdapter<?> wheelAdapter) {
        if (mWheelAdapter != wheelAdapter) {
            if (!mFlingScroller.isFinished()) {
                mFlingScroller.forceFinished(true);
            }
            if (!mAdjustScroller.isFinished()) {
                mAdjustScroller.forceFinished(true);
            }
            calculateCurrentPosition(false);
            // 停止滑动，计算当前位置后，再切换 adapter
            mWheelAdapter = wheelAdapter;

            mTotalScrollY = 0;
            if (mWheelAdapter != null) {
                // 初始化显示的item的position，根据是否loop
                mInitPosition = Math.min(mSelectedPosition, mWheelAdapter.getItemCount() - 1);
                mInitPosition = Math.max(mInitPosition, 0);
            } else {
                mInitPosition = 0;
            }
            mSelectedPosition = mInitPosition;

            scrollBy(0, 0);
            invalidate();
        }
    }

    public int getItemCount() {
        return mWheelAdapter != null ? mWheelAdapter.getItemCount() : 0;
    }

    public int getCurrentPosition() {
        return mSelectedPosition;
    }

    public Object getCurrentItem() {
        if (mWheelAdapter != null) {
            return mWheelAdapter.getItem(mSelectedPosition);
        }
        return null;
    }

    public String getCurrentDisplayText() {
        return (mWheelAdapter != null) ? mWheelAdapter.getDisplayText(mSelectedPosition) : "";
    }

    protected final void calculateCurrentPosition(boolean notifyIfChanged) {
        if (mWheelAdapter != null && mWheelAdapter.getItemCount() > 0) {
            final int itemCount = mWheelAdapter.getItemCount();
            int change = Math.round(mTotalScrollY * 1.0F / mItemHeight);
            int currentIndex = mInitPosition + change % itemCount;
            if (mCyclic) {
                currentIndex = (currentIndex % itemCount + itemCount) % itemCount;
            }
            if (0 <= currentIndex && currentIndex < itemCount) {
                mSelectedPosition = currentIndex;
                if (notifyIfChanged && mOnItemSelectedListener != null) {
                    mOnItemSelectedListener.onItemSelected(getCurrentPosition());
                }
            }
        }
    }


    public interface OnItemSelectedListener {
        void onItemSelected(int index);
    }

}
