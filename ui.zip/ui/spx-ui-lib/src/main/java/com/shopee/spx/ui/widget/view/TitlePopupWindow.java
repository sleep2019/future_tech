package com.shopee.spx.ui.widget.view;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.PopupWindow;

import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.shopee.spx.ui.R;
import com.shopee.spx.ui.widget.adapter.TitleMenuAdapter;
import com.shopee.spx.ui.widget.bean.TitleMenuItem;
import com.shopee.spx.ui.widget.listener.MenuClickListener;

import java.util.List;

/**
 * @ClassName: TitlePopupWindow
 * @Description: 弹出弹窗供用户选择
 * @Author: jingwei.xie
 * @CreateDate: 2022/6/16 5:18 下午
 */
public class TitlePopupWindow extends PopupWindow implements PopupWindow.OnDismissListener {

    Window mWindow;
    private static final float DEFAULT_ALPHA = 0.7f;
    private static final float NORMAL_ALPHA = 1.0f;
    private PopupWindow.OnDismissListener mOnDismissListener;
    private MenuClickListener mMenuClickListener;

    public TitlePopupWindow(Context context, List<TitleMenuItem> menuItems, MenuClickListener menuClickListener) {
        super(context);
        View titleView = LayoutInflater.from(context).inflate(R.layout.spx_ui_popup_menu, null);
        setContentView(titleView);
        setWidth(WindowManager.LayoutParams.WRAP_CONTENT);
        setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        setTouchable(true);
        setOutsideTouchable(true);
        RecyclerView recyclerView = titleView.findViewById(R.id.recycler_view);
        TitleMenuAdapter titleMenuAdapter = new TitleMenuAdapter(menuItems);
        titleMenuAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                TitleMenuItem titleMenuItem = menuItems.get(position);
                if (menuClickListener != null) {
                    menuClickListener.onClick(view, titleMenuItem.getItemTag());
                }
                dismiss();
            }
        });
        recyclerView.setAdapter(titleMenuAdapter);
        setBackgroundDrawable(null);

        setPopupWindowAlpha(titleView);
        setOnDismissListener(this);
    }

    private void setPopupWindowAlpha(View titleView) {
        Activity activity = (Activity) titleView.getContext();
        if (activity != null) {
            //0 ~ 1
            mWindow = activity.getWindow();
            WindowManager.LayoutParams params = mWindow.getAttributes();
            params.alpha = DEFAULT_ALPHA;
            mWindow.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            mWindow.setAttributes(params);
        }
    }

    public void setDismissListener(OnDismissListener onDismissListener) {
        mOnDismissListener = onDismissListener;
    }

    @Override
    public void onDismiss() {
        if (mOnDismissListener != null) {
            mOnDismissListener.onDismiss();
        }

        if (mWindow != null) {
            WindowManager.LayoutParams params = mWindow.getAttributes();
            params.alpha = NORMAL_ALPHA;
            mWindow.setAttributes(params);
        }
    }
}
