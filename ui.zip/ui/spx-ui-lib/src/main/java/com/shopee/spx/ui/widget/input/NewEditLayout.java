package com.shopee.spx.ui.widget.input;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.shopee.sc.logger.api.Logger;
import com.shopee.spx.ui.R;
import com.shopee.spx.ui.util.ContextUtils;

import java.util.Objects;

/**
 * 新版输入框
 * <p>
 * Created by honggang.xiong on 2020/11/10.
 */
public class NewEditLayout extends ConstraintLayout {

    private final TextView mTvEditHint;
    private final TextView mTvEditPrefix;
    private final View mViewPrefixDivider;
    private final EditText mEtNewEdit;
    private final ImageView mIvClearText;
    private final CheckBox mCbShowPassword;
    private final View mEditLine;
    private final TextView mTvEditHelper;

    /**
     * 当前输入文字
     */
    @NonNull
    private String mCurrentText = "";

    /**
     * 输入框下划线默认颜色，焦点颜色，hint，error颜色
     */
    private int mInputDefaultColor;
    private int mInputFocusColor;
    private int mInputHintColor;
    private int mInputErrorColor;

    private OnInputListener mOnInputListener;
    private boolean mIsInputError = false;
    private boolean mIsPasswordInputType = false;
    private boolean mEnableClear = true;
    private String mOriginHint;
    private String mOriginHelper;
    private String mOriginError;

    public NewEditLayout(Context context) {
        this(context, null);
    }

    public NewEditLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public NewEditLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, R.layout.spx_ui_layout_new_edit, this);
        mTvEditHint = findViewById(R.id.tv_edit_hint);
        mTvEditPrefix = findViewById(R.id.tv_edit_prefix);
        mViewPrefixDivider = findViewById(R.id.view_prefix_divider);
        mEtNewEdit = findViewById(R.id.et_new_edit);
        mIvClearText = findViewById(R.id.iv_clear_text);
        mCbShowPassword = findViewById(R.id.cb_show_password);
        mEditLine = findViewById(R.id.edit_line);
        mTvEditHelper = findViewById(R.id.tv_edit_helper);
        initListener(context);
        initAttrs(context, attrs);
        mEtNewEdit.setTypeface(Typeface.DEFAULT); // reset to default typeface
    }

    private void initAttrs(Context context, AttributeSet attrs) {
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.NewEditLayout);
        int inputType = ta.getInt(R.styleable.NewEditLayout_android_inputType, InputType.TYPE_CLASS_NUMBER);
        setInputType(inputType);

        String hintText = ta.getString(R.styleable.NewEditLayout_android_hint);
        setHintText(hintText);

        String helperText = ta.getString(R.styleable.NewEditLayout_nelHelperText);
        setHelperText(helperText);

        setEditText(ta.getString(R.styleable.NewEditLayout_android_text));

        ColorStateList colors = ta.getColorStateList(R.styleable.NewEditLayout_android_textColor);
        if (colors == null) {
            colors = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.font_color_main));
        }
        setEditTextColor(colors);

        mEnableClear = ta.getBoolean(R.styleable.NewEditLayout_enableClear, mEnableClear);

        int defaultColor = ta.getColor(R.styleable.NewEditLayout_nelInputDefaultColor, ContextCompat.getColor(context, R.color.divider_color));
        int focusColor = ta.getColor(R.styleable.NewEditLayout_nelInputFocusColor, ContextCompat.getColor(context, R.color.font_color_second));
        int hintColor = ta.getColor(R.styleable.NewEditLayout_nelInputHintColor, ContextCompat.getColor(context, R.color.font_color_second));
        int errorColor = ta.getColor(R.styleable.NewEditLayout_nelInputErrorColor, 0xFFF32345);
        ta.recycle();
        setInputBackgroundColors(defaultColor, focusColor, hintColor, errorColor);

        hidePrefix();
        updateClearTextView();
    }

    private void initListener(Context context) {
        mEtNewEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                handleTextChanged(editable == null ? "" : editable.toString());
            }
        });
        mEtNewEdit.setOnFocusChangeListener((v, hasFocus) -> handleFocusChanged(hasFocus));
        mIvClearText.setOnClickListener(v -> clearCurrentText());
        mCbShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mEtNewEdit.setTransformationMethod(isChecked
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            mEtNewEdit.setSelection(mEtNewEdit.getText().length());
        });
        setOnClickListener(v -> requestEditTextFocus());
    }

    public void setInputType(int inputType) {
        mEtNewEdit.setInputType(inputType);
        mIsPasswordInputType = isPasswordInputType(inputType);
        updateShowPasswordView();
    }

    static boolean isPasswordInputType(int inputType) {
        final int variation =
                inputType & (EditorInfo.TYPE_MASK_CLASS | EditorInfo.TYPE_MASK_VARIATION);
        return variation == (EditorInfo.TYPE_CLASS_TEXT | EditorInfo.TYPE_TEXT_VARIATION_PASSWORD)
                || variation == (EditorInfo.TYPE_CLASS_TEXT | EditorInfo.TYPE_TEXT_VARIATION_WEB_PASSWORD)
                || variation == (EditorInfo.TYPE_CLASS_NUMBER | EditorInfo.TYPE_NUMBER_VARIATION_PASSWORD);
    }

    public void setInputBackgroundColors(@ColorInt int defaultColor, @ColorInt int focusColor,
                                         @ColorInt int hintColor, @ColorInt int errorColor) {
        if (mInputDefaultColor == defaultColor && mInputFocusColor == focusColor
                && mInputHintColor == hintColor && mInputErrorColor == errorColor) {
            return;
        }

        mInputDefaultColor = defaultColor;
        mInputFocusColor = focusColor;
        mInputHintColor = hintColor;
        mInputErrorColor = errorColor;

        mEtNewEdit.setHintTextColor(hintColor);
        mTvEditHint.setTextColor(hintColor);

        ColorDrawable editLineDrawable = new ColorDrawable(Color.WHITE);
        editLineDrawable.setTintMode(PorterDuff.Mode.SRC_IN);
        ColorStateList stateList = new ColorStateList(new int[][]{
                {android.R.attr.state_activated},
                {android.R.attr.state_selected},
                {}},
                new int[]{errorColor, focusColor, defaultColor});
        editLineDrawable.setTintList(stateList);
        mEditLine.setBackground(editLineDrawable);

        ColorStateList helperColor = new ColorStateList(new int[][]{
                {android.R.attr.state_activated},
                {}},
                new int[]{errorColor, focusColor});
        mTvEditHelper.setTextColor(helperColor);
    }

    public void setHintText(@StringRes int resId) {
        setHintText(getContext().getString(resId));
    }

    public void setHintText(String text) {
        if (!Objects.equals(mOriginHint, text)) {
            mOriginHint = text;
            updateHintView();
        }
    }

    public void setHelperText(@StringRes int resId) {
        setHelperText(getContext().getString(resId));
    }

    public void setHelperText(String text) {
        if (!Objects.equals(mOriginHelper, text)) {
            mOriginHelper = text;
            updateHelperView();
        }
    }

    public void showPrefix(String prefix, boolean showDivider) {
        mTvEditPrefix.setText(prefix);
        mTvEditPrefix.setVisibility(VISIBLE);
        mViewPrefixDivider.setVisibility(showDivider ? VISIBLE : GONE);
    }

    public void hidePrefix() {
        mTvEditPrefix.setVisibility(GONE);
        mViewPrefixDivider.setVisibility(GONE);
    }

    void handleTextChanged(@NonNull String text) {
        Logger.v("handleTextChanged:" + text);
        if (!Objects.equals(mCurrentText, text)) {
            mCurrentText = text;
            updateHintView();
            updateClearTextView();
            updateShowPasswordView();
            if (mOnInputListener != null) {
                mOnInputListener.onTextChanged(mCurrentText);
            }

            // 自动清除 error
            setInputError(false, null);
        }
    }

    void handleFocusChanged(boolean hasFocus) {
        updateHintView();
        updateShowPasswordView();
        updateHelperView();
        mEditLine.setSelected(mEtNewEdit.hasFocus());
        if (mOnInputListener != null) {
            mOnInputListener.onFocusChanged(hasFocus);
        }
    }

    private void updateHintView() {
        if (mEtNewEdit.hasFocus() || !TextUtils.isEmpty(mCurrentText)) {
            mTvEditHint.setText(mOriginHint);
            mEtNewEdit.setHint("");
        } else {
            mTvEditHint.setText("");
            mEtNewEdit.setHint(mOriginHint);
        }
    }

    private void updateClearTextView() {
        if (mEnableClear) {
            boolean showClear = !TextUtils.isEmpty(mCurrentText);
            mIvClearText.setVisibility(showClear ? VISIBLE : GONE);
        } else {
            mIvClearText.setVisibility(GONE);
        }
    }

    public boolean isEnableClear() {
        return mEnableClear;
    }

    public void setEnableClear(boolean enableClear) {
        if (mEnableClear != enableClear) {
            mEnableClear = enableClear;
            updateClearTextView();
        }
    }

    private void updateShowPasswordView() {
        boolean showCheckBox = mIsPasswordInputType && (mEtNewEdit.hasFocus() || !TextUtils.isEmpty(mCurrentText));
        mCbShowPassword.setVisibility(showCheckBox ? VISIBLE : GONE);
    }

    private void updateHelperView() {
        String text = null;
        if (mIsInputError) {
            text = mOriginError;
        } else {
            if (mEtNewEdit.hasFocus()) {
                text = mOriginHelper;
            }
        }
        if (TextUtils.isEmpty(text)) {
            mTvEditHelper.setVisibility(GONE);
        } else {
            mTvEditHelper.setVisibility(VISIBLE);
            mTvEditHelper.setText(text);
        }
    }

    @NonNull
    public String getCurrentText() {
        return mCurrentText;
    }

    /**
     * 会触发 {@link #handleTextChanged(String)}，所以这里无需修改 mCurrentText
     */
    public void clearCurrentText() {
        mEtNewEdit.setText("");
    }

    public void setInputError(boolean isError, @StringRes int resId) {
        setInputError(isError, resId == 0 ? null : getContext().getString(resId));
    }

    public void setInputError(boolean isError, @StringRes int resId, boolean includeUnderline) {
        setInputError(isError, resId == 0 ? null : getContext().getString(resId), includeUnderline);
    }

    /**
     * 设置为 error 状态，需调用方再次调用进行恢复
     *
     * @param isError   是否进入 error 状态
     * @param errorText null 代表使用 helperText 作为 errorText，其他代表自定义 errorText
     */
    public void setInputError(boolean isError, @Nullable String errorText) {
        setInputError(isError, errorText, true);
    }

    public void setInputError(boolean isError, @Nullable String errorText, boolean includeUnderline) {
        mIsInputError = isError;
        if (includeUnderline) {
            mEditLine.setActivated(isError);
        }
        mTvEditHelper.setActivated(isError);
        mOriginError = errorText != null ? errorText : mOriginHelper;
        updateHelperView();
    }

    public boolean isInputError() {
        return mIsInputError;
    }

    @NonNull
    public EditText getEditText() {
        return mEtNewEdit;
    }

    public void setMaxInputLength(int maxLength) {
        if (maxLength >= 0) {
            mEtNewEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        } else {
            mEtNewEdit.setFilters(new InputFilter[0]);
        }
    }

    public void setEditText(@Nullable CharSequence text) {
        mEtNewEdit.setText(text);
    }

    public void setEditTextColor(@ColorInt int textColor) {
        mEtNewEdit.setTextColor(textColor);
    }

    public void setEditTextColor(@NonNull ColorStateList colors) {
        mEtNewEdit.setTextColor(colors);
    }

    public void setEditTextEnabled(boolean enabled) {
        mEtNewEdit.setEnabled(enabled);
    }

    public boolean isEditTextEnabled() {
        return mEtNewEdit.isEnabled();
    }

    public void requestEditTextFocus() {
        setEditTextEnabled(true);
        mEtNewEdit.requestFocus();
        ContextUtils.showKeyboard(mEtNewEdit);
    }

    public void clearEditTextFocus() {
        mEtNewEdit.clearFocus();
        ContextUtils.hideKeyboard(mEtNewEdit);
    }

    public void togglePassword(boolean show) {
        if (mCbShowPassword.getVisibility() == VISIBLE) {
            mCbShowPassword.setChecked(show);
        }
    }

    public void setOnInputListener(@Nullable OnInputListener onInputListener) {
        mOnInputListener = onInputListener;
    }


    public interface OnInputListener {
        void onTextChanged(@NonNull String code);

        void onFocusChanged(boolean hasFocus);
    }

}
