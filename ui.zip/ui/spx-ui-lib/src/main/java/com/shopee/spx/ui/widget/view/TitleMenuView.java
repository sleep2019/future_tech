package com.shopee.spx.ui.widget.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.widget.bean.TitleMenuItem;

/**
 * @ClassName: TitleMenuView
 * @Description: 标题栏的menuItem显示
 * @Author: jingwei.xie
 * @CreateDate: 2022/6/16 2:58 下午
 */
public class TitleMenuView extends ConstraintLayout {

    private ImageView mIvIcon;
    private ImageView mIvRedDot;
    private TextView mTvRedDot;
    private String itemTag;
    private final int MAX_RED_COUNT = 99;

    public TitleMenuView(Context context) {
        this(context, null);
    }

    public TitleMenuView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TitleMenuView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context, attrs);
    }

    private void initView(Context context, AttributeSet attrs) {
        inflate(context, R.layout.spx_ui_item_menu, this);
        mIvIcon = findViewById(R.id.iv_right_icon);
        mIvRedDot = findViewById(R.id.iv_red_dot);
        mTvRedDot = findViewById(R.id.tv_red_dot);
    }

    public void setImageResource(Drawable drawable) {
        mIvIcon.setImageDrawable(drawable);
    }

    public void setImageResource(@DrawableRes int resId) {
        mIvIcon.setImageResource(resId);
    }

    public void setRedDotVisible(boolean visible) {
        mIvRedDot.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setTvReDotVisible(boolean visible) {
        mTvRedDot.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setTvRedDotNumber(int unreadCount) {
        if (unreadCount > MAX_RED_COUNT) {
            mTvRedDot.setVisibility(VISIBLE);
            mTvRedDot.setText(getContext().getString(R.string.ninety_nine_plus));
        } else if (unreadCount > 0) {
            mTvRedDot.setVisibility(VISIBLE);
            mTvRedDot.setText(String.valueOf(unreadCount));
        } else {
            mTvRedDot.setVisibility(GONE);
        }
    }

    public ImageView getIvIcon() {
        return mIvIcon;
    }

    public ImageView getIvRedDot() {
        return mIvRedDot;
    }

    public TextView getTvRedDot() {
        return mTvRedDot;
    }

    public void setIvIconSize(int width, int height) {
        mIvIcon.setLayoutParams(new ViewGroup.LayoutParams(width, height));
    }

    @Override
    public String getTag() {
        return itemTag;
    }

    public void setMenuItem(TitleMenuItem item) {
        setVisibility(VISIBLE);
        setImageResource(item.getResIcon());
        setRedDotVisible(item.isShowRedDot());
        setTvRedDotNumber(item.getRedDotNumber());
        itemTag = item.getItemTag();
        item.setMenuView(this);
    }
}
