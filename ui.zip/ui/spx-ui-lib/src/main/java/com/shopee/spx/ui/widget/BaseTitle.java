package com.shopee.spx.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.LayoutRes;
import androidx.constraintlayout.widget.ConstraintLayout;

/**
 * @ClassName: BaseTitle
 * @Description: java类作用描述
 * @Author: jingwei.xie
 * @CreateDate: 2021/5/28 6:45 下午
 */
public abstract class BaseTitle extends ConstraintLayout {

    protected ImageView mIvFirstRightIcon;
    protected ImageView mIvFirstRightIconRedDot;
    protected TextView mTvFirstRightIconRedDot;
    protected ImageView mIvSecondRightIcon;
    protected ImageView mIvThirdRightIcon;
    protected View mDividerView;

    protected int mFirstRightButton;
    protected int mSecondRightButton;
    protected int mThirdRightButton;

    public BaseTitle(Context context) {
        super(context);
    }

    public BaseTitle(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public BaseTitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, getLayoutId(), this);
        initView(attrs);
        setRightIcon(mFirstRightButton, mSecondRightButton, mThirdRightButton);
    }

    public void setRightIcon(int firstIcon, int secondIcon, int thirdIcon) {
        if (firstIcon > 0) {
            mIvFirstRightIcon.setImageResource(firstIcon);
            mIvFirstRightIcon.setVisibility(VISIBLE);
        } else {
            mIvFirstRightIcon.setVisibility(GONE);
        }

        if (secondIcon > 0) {
            mIvSecondRightIcon.setImageResource(secondIcon);
            mIvSecondRightIcon.setVisibility(VISIBLE);
        } else {
            mIvSecondRightIcon.setVisibility(GONE);
        }

        if (thirdIcon > 0) {
            mIvThirdRightIcon.setImageResource(thirdIcon);
            mIvThirdRightIcon.setVisibility(VISIBLE);
        } else {
            mIvThirdRightIcon.setVisibility(GONE);
        }
    }

    public void setShowBottomDivider(boolean showBottomDivider) {
        mDividerView.setVisibility(showBottomDivider ? View.VISIBLE : View.GONE);
    }

    public View getBottomDivider(){
        return mDividerView;
    }

    public void setFirstRightIconListener(View.OnClickListener clickListener) {
        mIvFirstRightIcon.setOnClickListener(clickListener);
    }

    public void setSecondRightIconListener(View.OnClickListener clickListener) {
        mIvSecondRightIcon.setOnClickListener(clickListener);
    }

    public void setThirdRightIconListener(View.OnClickListener clickListener) {
        mIvThirdRightIcon.setOnClickListener(clickListener);
    }

    public void setFirstRedDotTv(boolean visible) {
        mTvFirstRightIconRedDot.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setFirstRedDotTvText(String text) {
        mTvFirstRightIconRedDot.setText(text);
    }

    public void setFirstRedDotTvClickListener(View.OnClickListener clickListener) {
        mTvFirstRightIconRedDot.setOnClickListener(clickListener);
    }

    public void setFirstRedDot(boolean visible) {
        mIvFirstRightIconRedDot.setVisibility(visible ? VISIBLE : GONE);
    }

    public ImageView getFirstRightIcon() {
        return mIvFirstRightIcon;
    }

    public ImageView getSecondRightIcon() {
        return mIvSecondRightIcon;
    }

    public ImageView getThirdRightIcon() {
        return mIvThirdRightIcon;
    }

    public TextView getFirstRedDotTv(){
        return mTvFirstRightIconRedDot;
    }

    abstract @LayoutRes int getLayoutId();

    abstract void initView(AttributeSet attrs);
}
