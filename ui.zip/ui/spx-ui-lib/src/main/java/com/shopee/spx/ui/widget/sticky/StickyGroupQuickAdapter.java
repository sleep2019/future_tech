package com.shopee.spx.ui.widget.sticky;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.IExpandable;
import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

/**
 * 扩展 BaseMultiItemQuickAdapter 实现 {@link IStickyGroupAdapter}, 与 {@link RecyclerViewStickyHeaderLayout}
 * 配合使用即可实现 sticky header。
 *
 * 子类需遵循以下规范：
 * 1、最多只包含两级数据，实现 {@link IExpandable} 接口的数据为一级数据，其他为二级数据；
 * 2、只针对一级数据开启 sticky；
 *
 * FIXME: 当前通过 {@linkplain #collapse} 系列方法折叠 sticky header 时还有点显示问题，用到该功能时可优化之。
 *
 * Created by honggang.xiong on 2020/9/10.
 */
public abstract class StickyGroupQuickAdapter<T extends MultiItemEntity, K extends BaseViewHolder>
        extends BaseMultiItemQuickAdapter<T, K> implements IStickyGroupAdapter {

    public StickyGroupQuickAdapter(List<T> data) {
        super(data);
    }

    @Override
    public int getPreStickyIndexByPosition(int position) {
        List<T> dataList = getData();
        int size = getData().size();
        if (position < 0 || position >= size) {
            return -1;
        }

        int index = -1;
        for (int i = 0; i <= position; i++) {
            if (isStickyData(dataList.get(i), i)) {
                index++;
            }
        }
        return index;
    }

    @Override
    public int getStickyPositionFromIndex(int groupIndex) {
        List<T> dataList = getData();
        int size = getData().size();
        if (groupIndex < 0 || groupIndex >= size) {
            return -1;
        }

        int index = -1;
        for (int i = 0; i < size; i++) {
            if (isStickyData(dataList.get(i), i)) {
                index++;
            }
            if (index == groupIndex) {
                return i;
            }
        }
        return -1;
    }

    private boolean isStickyData(T data, int position) {
        return data instanceof IExpandable;
    }

}
