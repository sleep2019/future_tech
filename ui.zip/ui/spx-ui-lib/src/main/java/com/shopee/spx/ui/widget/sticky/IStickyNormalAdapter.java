package com.shopee.spx.ui.widget.sticky;

/**
 * Created by honggang.xiong on 2020/9/10.
 */
public interface IStickyNormalAdapter extends IStickyAdapter {

    @Override
    default int getStickyPositionFromIndex(int stickyIndex) {
        return stickyIndex;
    }

}
