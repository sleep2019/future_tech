package com.shopee.spx.ui.widget.sticky;

/**
 * Created by honggang.xiong on 2020/9/10.
 */
public interface IStickyGroupAdapter extends IStickyAdapter {

    /**
     * 返回分组下标 group index
     */
    int getPreStickyIndexByPosition(int position);

    int getStickyPositionFromIndex(int groupIndex);

    @Override
    default int getNextStickyIndexFromCurrent(int currentStickyIndex) {
        return currentStickyIndex + 1;
    }

}
