package com.shopee.spx.ui.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.drawable.RoundRefreshDrawable;

/**
 * 在 AppCompatTextView 的基础上，添加粘性 drawableStart、内置refresh loading Drawable
 * <p>
 * Created by honggang.xiong on 2019-10-18.
 */
public class PdaTextView extends AppCompatTextView {

    // TextView 在绘制 drawableStart 时，会调用 getHorizontalOffsetForDrawables() 进行 offset，
    // 重写该方法并在 onDraw() 时刷新该值，即可实现 drawableStart 和文字粘在一起。
    // 简单无侵入，即使后续 Android 更新移除该 api，也不影响正常流程。
    private int mOffsetForDrawableStart = 0;
    // 是否开启粘性 drawableStart，开启后，drawableStart 将紧靠文字，同时可响应 drawablePadding
    private boolean mDrawableStartSticky;
    private int mTargetDrawableSize = 0;
    private int mRefreshPosition;
    private boolean mRefreshing = false;
    // 代表刷新状态的简单 Drawable
    private RoundRefreshDrawable mCurrentRefreshDrawable;
    private RoundRefreshDrawable.Params mRefreshParams;

    public PdaTextView(Context context) {
        this(context, null);
    }

    public PdaTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.PdaTextView);
        mDrawableStartSticky = typedArray.getBoolean(R.styleable.PdaTextView_drawableStartSticky, true);
        mTargetDrawableSize = typedArray.getDimensionPixelSize(R.styleable.PdaTextView_targetDrawableSize, 0);
        mRefreshPosition = typedArray.getInt(R.styleable.PdaTextView_refreshPosition, Gravity.START);
        boolean refreshing = typedArray.getBoolean(R.styleable.PdaTextView_refreshing, false);
        typedArray.recycle();
        mRefreshParams = RoundRefreshDrawable.createParams(context, attrs);
        setRefreshing(refreshing);

        checkDrawablesAfterInit();
    }

    public boolean isRefreshing() {
        return mRefreshing;
    }

    public void toggleRefresh() {
        setRefreshing(!mRefreshing);
    }

    public void setRefreshing(boolean refreshing) {
        if (mRefreshing != refreshing) {
            if (refreshing) {
                showRefresh();
            } else {
                hideRefresh();
            }
        }
    }

    public void showRefresh() {
        if (mCurrentRefreshDrawable == null) {
            mCurrentRefreshDrawable = mRefreshParams.newDrawable();
            switch (mRefreshPosition) {
                case Gravity.TOP:
                    setCompoundDrawablesRelative(null, mCurrentRefreshDrawable, null, null);
                    break;
                case Gravity.BOTTOM:
                    setCompoundDrawablesRelative(null, null, null, mCurrentRefreshDrawable);
                    break;
                case Gravity.START:
                default:
                    setCompoundDrawablesRelative(mCurrentRefreshDrawable, null, null, null);
                    break;
            }
        }
        mCurrentRefreshDrawable.startRefresh();
        mRefreshing = true;
    }

    public void hideRefresh() {
        if (mCurrentRefreshDrawable != null) {
            mCurrentRefreshDrawable.stopRefresh();
            setCompoundDrawablesRelative(null, null, null, null);
            mCurrentRefreshDrawable = null;
        }
        mRefreshing = false;
    }

    @Deprecated
    public void updateRefreshDrawableColor(int bgColor, int fgColor) {
        updateRefreshDrawableColorStateList(ColorStateList.valueOf(bgColor), ColorStateList.valueOf(fgColor));
    }

    public void updateRefreshDrawableColorStateList(@NonNull ColorStateList bgColor, @NonNull ColorStateList fgColor) {
        mRefreshParams.setBgColor(bgColor);
        mRefreshParams.setFgColor(fgColor);
        if (mCurrentRefreshDrawable != null) {
            mCurrentRefreshDrawable.updateDrawableColor(bgColor, fgColor);
        }
    }

    private void checkDrawablesAfterInit() {
        if (mTargetDrawableSize > 0) {
            Drawable[] drawables = getCompoundDrawablesRelative();
            boolean hasRelative = drawables[0] != null || drawables[2] != null;
            if (hasRelative) {
                // have relative drawables
                setCompoundDrawablesRelative(drawables[0], drawables[1], drawables[2], drawables[3]);
            } else {
                drawables = getCompoundDrawables();
                if (drawables[0] != null || drawables[1] != null || drawables[2] != null || drawables[3] != null) {
                    // have absolute drawables
                    setCompoundDrawables(drawables[0], drawables[1], drawables[2], drawables[3]);
                }
            }
        }
    }

    private void resetDrawableBounds(@Nullable Drawable drawable, String desc) {
        if (drawable != null && !(drawable instanceof RoundRefreshDrawable)) {
            drawable.setBounds(0, 0, mTargetDrawableSize, mTargetDrawableSize);
        }
    }

    @Override
    public void setCompoundDrawables(@Nullable Drawable left, @Nullable Drawable top, @Nullable Drawable right, @Nullable Drawable bottom) {
        if (mTargetDrawableSize > 0) {
            resetDrawableBounds(left, "left");
            resetDrawableBounds(top, "top");
            resetDrawableBounds(right, "right");
            resetDrawableBounds(bottom, "bottom");
        }
        super.setCompoundDrawables(left, top, right, bottom);
    }

    @Override
    public void setCompoundDrawablesRelative(@Nullable Drawable start, @Nullable Drawable top, @Nullable Drawable end, @Nullable Drawable bottom) {
        if (mTargetDrawableSize > 0) {
            resetDrawableBounds(start, "start");
            resetDrawableBounds(top, "top");
            resetDrawableBounds(end, "end");
            resetDrawableBounds(bottom, "bottom");
        }
        super.setCompoundDrawablesRelative(start, top, end, bottom);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        refreshOffsetForDrawables();
        super.onDraw(canvas);
    }

    private void refreshOffsetForDrawables() {
        int result = 0;
        if (mDrawableStartSticky) {
            Drawable[] drawables = getCompoundDrawablesRelative();
            if (drawables[0] != null) { // drawableStart not null
                int hoGravity = getGravity() & Gravity.RELATIVE_HORIZONTAL_GRAVITY_MASK;
                float textWidth = getPaint().measureText(getText().toString());
                switch (hoGravity) {
                    case Gravity.START:
                        result = 0;
                        break;
                    case Gravity.END:
                        result = Math.round(getWidth() - getCompoundPaddingLeft() - getCompoundPaddingRight() - textWidth);
                        break;
                    case Gravity.CENTER_HORIZONTAL:
                    default:
                        result = Math.round((getWidth() - getCompoundPaddingLeft() - getCompoundPaddingRight() - textWidth) / 2.0F);
                        break;
                }
            }
            if (result < 0) {
                result = 0;
            }
        }
        mOffsetForDrawableStart = result;
    }

    // Do not delete this method
    public int getHorizontalOffsetForDrawables() {
        return mOffsetForDrawableStart;
    }

}
