package com.shopee.spx.ui.widget.sticky;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

/**
 * 扩展 BaseMultiItemQuickAdapter 实现 {@link IStickyNormalAdapter}, 与 {@link RecyclerViewStickyHeaderLayout}
 * 配合使用即可实现 sticky header。
 *
 * 子类只需通过 {@linkplain #isStickyData} 判断 sticky 数据即可
 *
 * Created by honggang.xiong on 2020/9/10.
 */
public abstract class StickyNormalQuickAdapter<T extends MultiItemEntity, K extends BaseViewHolder>
        extends BaseMultiItemQuickAdapter<T, K> implements IStickyNormalAdapter {

    public StickyNormalQuickAdapter(List<T> data) {
        super(data);
    }

    @Override
    public int getPreStickyIndexByPosition(int position) {
        List<T> dataList = getData();
        int size = getData().size();
        if (position < 0 || position >= size) {
            return -1;
        }

        for (int i = position; i >= 0; i--) {
            if (isStickyData(dataList.get(i), i)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int getNextStickyIndexFromCurrent(int currentStickyIndex) {
        List<T> dataList = getData();
        int size = getData().size();
        if (currentStickyIndex < 0 || currentStickyIndex >= size) {
            return -1;
        }

        for (int i = currentStickyIndex + 1; i < size; i++) {
            if (isStickyData(dataList.get(i), i)) {
                return i;
            }
        }
        return -1;
    }

    protected boolean isStickyData(T data, int position) {
        return false;
    }

    public T getLastOrNull() {
        List<T> dataList = getData();
        if (!dataList.isEmpty()) {
            return dataList.get(dataList.size() - 1);
        }
        return null;
    }

}
