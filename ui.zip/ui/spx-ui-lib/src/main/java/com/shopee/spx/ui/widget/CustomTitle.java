package com.shopee.spx.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.util.ContextUtils;

/**
 * @ClassName: CustomTitle
 * @Description: 常用于主页的显示
 * @Author: jingwei.xie
 * @CreateDate: 2021/5/28 10:40 上午
 */
public class CustomTitle extends BaseTitle {

    public static final int TITLE_ONLY = 0;
    public static final int TITLE_TAB = 1;
    public static final int TITLE_DRAWER = 2;

    private int mStyle = TITLE_ONLY;
    private View mClPortrait;
    private CircleImageView mIvPortrait;
    private ImageView mIvPortraitRedDot;
    private ImageView mIvPortraitDescRedDot;
    private TextView mTvPortraitDesc;
    private ImageView mIvPortraitStatus;
    private LinearLayout mTabContainer;
    private ConstraintLayout mDrawerContainer;
    private ImageView mIvPortraitDropDown;
    private ImageView mIvDrawerRedPoint;
    private ImageView mIvPortraitFunction;

    private int portraitIcon;
    private int portraitStatusIcon;
    private int style;
    private String portraitDesc;
    /**
     * 判断drop down按钮的显示
     */
    private boolean isDropDown = false;

    public CustomTitle(Context context) {
        this(context, null);
    }

    public CustomTitle(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomTitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    void initView(AttributeSet attrs) {
        mIvFirstRightIcon = findViewById(R.id.iv_first_right_icon);
        mIvFirstRightIconRedDot = findViewById(R.id.iv_first_red_dot);
        mTvFirstRightIconRedDot = findViewById(R.id.tv_first_red_dot);
        mIvSecondRightIcon = findViewById(R.id.iv_second_right_icon);
        mIvThirdRightIcon = findViewById(R.id.iv_third_right_icon);
        mDividerView = findViewById(R.id.view_title_divider);
        mClPortrait = findViewById(R.id.cl_portrait);
        mIvPortrait = findViewById(R.id.civ_portrait);
        mIvPortraitRedDot = findViewById(R.id.iv_portrait_red_dot);
        mIvPortraitDescRedDot = findViewById(R.id.tv_portrait_desc_red_dot);
        mIvPortraitStatus = findViewById(R.id.iv_portrait_status);
        mTvPortraitDesc = findViewById(R.id.tv_portrait_desc);
        mTabContainer = findViewById(R.id.ll_container_tab);
        mDrawerContainer = findViewById(R.id.cl_drawer);
        mIvPortraitDropDown = findViewById(R.id.iv_portrait_drop_down);
        mIvDrawerRedPoint = findViewById(R.id.iv_drawer_red_dot);
        mIvPortraitFunction = findViewById(R.id.iv_portrait_function);

        TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.CustomTitle);
        mFirstRightButton = ta.getResourceId(R.styleable.CustomTitle_custom_first_right_icon, 0);
        mSecondRightButton = ta.getResourceId(R.styleable.CustomTitle_custom_second_right_icon, 0);
        mThirdRightButton = ta.getResourceId(R.styleable.CustomTitle_custom_third_right_icon, 0);
        portraitIcon = ta.getResourceId(R.styleable.CustomTitle_portrait_icon, 0);
        portraitStatusIcon = ta.getResourceId(R.styleable.CustomTitle_portrait_status_icon, 0);
        portraitDesc = ta.getString(R.styleable.CustomTitle_portrait_desc);
        boolean showDivider = ta.getBoolean(R.styleable.CustomTitle_custom_show_bottom_divider, false);
        style = ta.getInt(R.styleable.CustomTitle_custom_title_style, TITLE_ONLY);
        ta.recycle();

        setShowBottomDivider(showDivider);
        setStyle(style, portraitIcon, portraitStatusIcon, portraitDesc);
    }

    @Override
    int getLayoutId() {
        return R.layout.spx_ui_layout_custom_title;
    }

    public void setStyle(int style, int portraitIcon, int portraitStatusIcon, String portraitDesc) {
        if (style < TITLE_ONLY || style > TITLE_DRAWER) {
            return;
        }
        mStyle = style;
        if (portraitIcon > 0) {
            mIvPortrait.setVisibility(VISIBLE);
            mIvPortrait.setImageResource(portraitIcon);
        }

        if (portraitStatusIcon > 0) {
            mIvPortraitStatus.setVisibility(VISIBLE);
            mIvPortraitStatus.setImageResource(portraitStatusIcon);
        } else {
            mIvPortraitStatus.setVisibility(GONE);
        }

        if (!TextUtils.isEmpty(portraitDesc)) {
            mTvPortraitDesc.setVisibility(VISIBLE);
            mTvPortraitDesc.setText(portraitDesc);
        } else {
            mTvPortraitDesc.setVisibility(GONE);

            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ContextUtils.dp2px(mIvPortrait.getContext(), 32),
                    ContextUtils.dp2px(mIvPortrait.getContext(), 32));
            params.setMargins(0, 0, 0, 0);
            mIvPortrait.setLayoutParams(params);
        }

        switch (mStyle) {
            case TITLE_ONLY:
                mClPortrait.setBackgroundResource(R.drawable.bg_grey_rect_background_radius_20);
                mDrawerContainer.setVisibility(GONE);
                break;

            case TITLE_TAB:
                mClPortrait.setBackground(null);
                mDrawerContainer.setVisibility(GONE);
                break;

            case TITLE_DRAWER:
                mIvPortrait.setVisibility(GONE);
                mIvPortraitStatus.setVisibility(GONE);
                mDrawerContainer.setVisibility(VISIBLE);
                break;

            default:
                break;
        }
    }

    public void setStyle(int style) {
        setStyle(style, portraitIcon, portraitStatusIcon, portraitDesc);
    }

    public void setClPortraitClickListener(View.OnClickListener clickListener) {
        mClPortrait.setOnClickListener(clickListener);
    }

    public View getClPortrait() {
        return mClPortrait;
    }

    public CircleImageView getIvPortrait() {
        return mIvPortrait;
    }

    public ImageView getIvPortraitRedDot() {
        return mIvPortraitRedDot;
    }

    public ImageView getIvPortraitDescRedDot() {
        return mIvPortraitDescRedDot;
    }

    public TextView getTvPortraitDesc() {
        return mTvPortraitDesc;
    }

    public ImageView getIvPortraitStatus() {
        return mIvPortraitStatus;
    }

    public void setPortraitRedDot(boolean visible) {
        // 兼容老模式下的红点显示
        if (mStyle == TITLE_DRAWER) {
            setDrawerRedPointVisible(visible);
        } else {
            mIvPortraitRedDot.setVisibility(visible ? VISIBLE : GONE);
        }
    }

    public void setPortraitFunctionDrawable(Drawable resId) {
        mIvPortraitFunction.setVisibility(VISIBLE);
        mIvPortraitFunction.setImageDrawable(resId);
    }

    public void setPortraitDescRedDot(boolean visible) {
        if (mStyle == TITLE_DRAWER) {
            setDrawerRedPointVisible(visible);
        } else {
            mIvPortraitDescRedDot.setVisibility(visible ? VISIBLE : GONE);
        }
    }

    public void setIvPortrait(View.OnClickListener clickListener) {
        mIvPortrait.setOnClickListener(clickListener);
    }

    public void setDrawerClickListener(View.OnClickListener clickListener) {
        mDrawerContainer.setOnClickListener(clickListener);
    }

    public void setPortraitDropDownListener(View.OnClickListener clickListener) {
        mIvPortraitDropDown.setOnClickListener(clickListener);
    }

    public void setPortraitDropDownVisible(boolean visible) {
        mIvPortraitDropDown.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setDrawerRedPointVisible(boolean visible) {
        mIvDrawerRedPoint.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setPortraitDropDownStatus(boolean isDropDown) {
        mIvPortraitDropDown.setImageResource(isDropDown ? R.drawable.ic_drop_down :
                R.drawable.ic_drop_up);
    }

    public boolean isPortraitDropDownVisible() {
        return mIvPortraitDropDown.getVisibility() == VISIBLE;
    }

    public int getStyle() {
        return mStyle;
    }


    public LinearLayout getTabContainer() {
        return mTabContainer;
    }

    public ConstraintLayout getDrawerContainer() {
        return mDrawerContainer;
    }

    public ImageView getIvPortraitDropDown() {
        return mIvPortraitDropDown;
    }

    public ImageView getIvDrawerRedPoint() {
        return mIvDrawerRedPoint;
    }

    public ImageView getIvPortraitFunction() {
        return mIvPortraitFunction;
    }

    public void addTabContainer(View view) {
        mTabContainer.setVisibility(View.VISIBLE);
        mTabContainer.addView(view);
    }
}


