package com.shopee.spx.ui.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;

import com.shopee.spx.ui.R;

/**
 * Created by honggang.xiong on 2019-10-20.
 */
public class SimpleToast {

    private static Context sAppContext;
    private static Toast sToast;

    public static void init(Context context) {
        sAppContext = context.getApplicationContext();
    }

    public static void showShort(CharSequence text) {
        show(text, Toast.LENGTH_SHORT);
    }

    public static void showShort(@StringRes int resId) {
        if (sAppContext != null) {
            show(sAppContext.getString(resId), Toast.LENGTH_SHORT);
        }
    }

    public static void showLong(CharSequence text) {
        show(text, Toast.LENGTH_LONG);
    }

    public static void showLong(@StringRes int resId) {
        if (sAppContext != null) {
            show(sAppContext.getString(resId), Toast.LENGTH_LONG);
        }
    }

    public synchronized static void show(CharSequence text, int duration) {
        if (sAppContext == null) {
            return;
        }
        if (sToast != null) {
            sToast.cancel();
        }

        sToast = makeToast(sAppContext);
        sToast.setDuration(duration);
        if (sToast.getView() instanceof TextView) {
            TextView textView = (TextView) sToast.getView();
            textView.setText(text);
        }
        sToast.show();
    }

    private static Toast makeToast(Context context) {
        Resources resources = context.getResources();

        int horizontalPadding = resources.getDimensionPixelSize(R.dimen.toast_horizontal_padding);
        int verticalPadding = resources.getDimensionPixelSize(R.dimen.toast_vertical_padding);
        int roundRadius = resources.getDimensionPixelSize(R.dimen.toast_radius);

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(ContextCompat.getColor(context, R.color.bg_toast));
        drawable.setCornerRadius(roundRadius);

        TextView textView = new TextView(context);
        textView.setTextColor(resources.getColor(R.color.white));
        textView.setMinHeight(resources.getDimensionPixelSize(R.dimen.toast_min_height));
        // 最大宽度，超过折行
        textView.setMaxWidth(resources.getDimensionPixelSize(R.dimen.toast_max_width));
        textView.setBackground(drawable);
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);

        Toast toast = new Toast(context);
        toast.setView(textView);
        toast.setGravity(Gravity.CENTER, 0, -resources.getDimensionPixelSize(R.dimen.toast_margin_bottom));
        return toast;
    }

}
