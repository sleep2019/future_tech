package com.shopee.spx.ui.widget.picker;

/**
 * Created by honggang.xiong on 2020/9/17.
 */
public class PickerMonthRange {

    private final int startYear;
    private final int startYearMonth; // 1 - 12
    private final int endYear;
    private final int endYearMonth;   // 1 - 12
    private final int startMonthInt;  // eg: 202009
    private final int endMonthInt;

    public PickerMonthRange() {
        this(1900, 1, 2099, 12);
    }

    public PickerMonthRange(int startYear, int startYearMonth, int endYear, int endYearMonth) {
        int startMonthInt = getMonthInt(startYear, startYearMonth);
        int endMonthInt = getMonthInt(endYear, endYearMonth);
        if (startMonthInt > endMonthInt) {
            throw new IllegalArgumentException("month range invalid: start=" + startMonthInt
                    + ", end=" + endMonthInt);
        }
        this.startYear = startYear;
        this.startYearMonth = startYearMonth;
        this.endYear = endYear;
        this.endYearMonth = endYearMonth;
        this.startMonthInt = startMonthInt;
        this.endMonthInt = endMonthInt;
    }

    public int getStartYear() {
        return startYear;
    }

    public int getStartYearMonth() {
        return startYearMonth;
    }

    public int getEndYear() {
        return endYear;
    }

    public int getEndYearMonth() {
        return endYearMonth;
    }

    public NumericWheelAdapter getYearAdapter() {
        return new NumericWheelAdapter(startYear, endYear);
    }

    public NumericWheelAdapter getMonthAdapter(int year) {
        NumericWheelAdapter adapter;
        if (year == startYear) {
            if (year == endYear) {
                adapter = new NumericWheelAdapter(startYearMonth, endYearMonth);
            } else {
                adapter = new NumericWheelAdapter(startYearMonth, 12);
            }
        } else if (year == endYear) {
            adapter = new NumericWheelAdapter(1, endYearMonth);
        } else {
            adapter = new NumericWheelAdapter(1, 12);
        }
        return adapter;
    }

    public int getStartMonthOfYear(int year) {
        if (year == startYear) {
            return startYearMonth;
        }
        return 1;
    }

    public boolean containsYear(int year) {
        return startYear <= year && year <= endYear;
    }

    public boolean containsMonth(int year, int month) {
        int monthInt = getMonthInt(year, month);
        return startMonthInt <= monthInt && monthInt <= endMonthInt;
    }

    public static int getMonthInt(int year, int month) {
        return year * 100 + month;
    }
}
