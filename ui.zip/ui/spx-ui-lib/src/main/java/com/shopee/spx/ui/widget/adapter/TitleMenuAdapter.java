package com.shopee.spx.ui.widget.adapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.shopee.spx.ui.R;
import com.shopee.spx.ui.widget.bean.TitleMenuItem;
import com.shopee.spx.ui.widget.view.TitleMenuView;

import java.util.List;

/**
 * @ClassName: TitleMenuAdapter
 * @Description: 标题menu的adapter
 * @Author: jingwei.xie
 * @CreateDate: 2022/6/16 6:17 下午
 */
public class TitleMenuAdapter extends BaseQuickAdapter<TitleMenuItem, BaseViewHolder> {

    public TitleMenuAdapter(@Nullable List<TitleMenuItem> data) {
        super(R.layout.spx_ui_item_menu_list, data);
    }

    @Override
    protected void convert(@NonNull BaseViewHolder helper, TitleMenuItem item) {
        TitleMenuView menuView = helper.getView(R.id.menu_item);
        menuView.setMenuItem(item);
        helper.setText(R.id.tvItemName, item.getItemName());
    }
}
