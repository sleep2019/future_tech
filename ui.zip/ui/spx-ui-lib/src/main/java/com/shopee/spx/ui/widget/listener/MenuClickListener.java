package com.shopee.spx.ui.widget.listener;

import android.view.View;

import androidx.annotation.Nullable;

/**
 * @ClassName: MenuClickListener
 * @Description: 按钮点击事件
 * @Author: jingwei.xie
 * @CreateDate: 2022/6/17 4:01 下午
 */
public interface MenuClickListener {
    void onClick(View view, @Nullable String tag);
}
