package com.shopee.spx.ui.widget.dialog;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.IdRes;
import androidx.annotation.IntDef;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.annotation.StyleRes;
import androidx.core.content.ContextCompat;

import com.shopee.spx.ui.R;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.SoftReference;

/**
 * Created by honggang.xiong on 2019-05-20.
 */
public class CustomizeDialog extends TrackingDialog<CustomizeDialog> {

    public static final int POSITION_NORMAL = 0;
    public static final int POSITION_BOTTOM = -1;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({POSITION_NORMAL, POSITION_BOTTOM})
    @interface Position {
    }

    protected View mContentView;
    protected int mPosition;
    private OnDismissListener mListener;

    public CustomizeDialog(Context context, @LayoutRes int layoutId) {
        this(context, layoutId, POSITION_NORMAL);
    }

    public CustomizeDialog(Context context, @LayoutRes int layoutId, @Position int position) {
        this(context, layoutId, position, position == POSITION_BOTTOM ? R.style.UiLibraryCustomDialog_BottomAnimation : R.style.UiLibraryCustomDialog);
    }

    public CustomizeDialog(Context context, @LayoutRes int layoutId, @Position int position, @StyleRes int themeResId) {
        super(context, themeResId);

        View contentView = LayoutInflater.from(context).inflate(layoutId, new FrameLayout(context), false);
        ViewGroup.MarginLayoutParams marginParams = (ViewGroup.MarginLayoutParams) contentView.getLayoutParams();
        mPosition = position;
        mContentView = contentView;
        setContentView(contentView, marginParams);

        Window window = getWindow();
        if (window != null) {
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = marginParams.width;
            lp.height = marginParams.height;
            lp.gravity = position == POSITION_BOTTOM ? (Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL) : Gravity.CENTER;
            window.setAttributes(lp);
        }
    }

    @NonNull
    @Override
    protected CustomizeDialog getSelf() {
        return this;
    }

    public View getContentView() {
        return mContentView;
    }

    @Override
    public void show() {
        if (!isDestroyedOrFinishing()) {
            super.show();
        }
    }

    protected boolean isDestroyedOrFinishing() {
        Activity activity = getActivityNoException();
        if (activity != null) {
            return activity.isDestroyed() || activity.isFinishing();
        }
        return false;
    }

    protected Activity getActivityNoException() {
        if (getContext() instanceof Activity) {
            return (Activity) getContext();
        } else if (getContext() instanceof ContextWrapper) {
            Context base = ((ContextWrapper) getContext()).getBaseContext();
            if (base instanceof Activity) {
                return (Activity) base;
            }
        }
        return null;
    }

    public CustomizeDialog setText(@IdRes int viewId, @StringRes int resId) {
        ((TextView) findViewById(viewId)).setText(resId);
        return this;
    }

    public CustomizeDialog setText(@IdRes int viewId, CharSequence text) {
        ((TextView) findViewById(viewId)).setText(text);
        return this;
    }

    public CustomizeDialog setTextColor(@IdRes int viewId, @ColorRes int resId) {
        ((TextView) findViewById(viewId)).setTextColor(ContextCompat.getColor(getContext(), resId));
        return this;
    }

    public CustomizeDialog setTextColorInt(@IdRes int viewId, @ColorInt int color) {
        ((TextView) findViewById(viewId)).setTextColor(color);
        return this;
    }

    public CustomizeDialog setTextSize(@IdRes int viewId, int sizeInSp) {
        ((TextView) findViewById(viewId)).setTextSize(sizeInSp);
        return this;
    }

    public CustomizeDialog setTextHint(@IdRes int viewId, @StringRes int resId) {
        ((TextView) findViewById(viewId)).setHint(resId);
        return this;
    }

    public CustomizeDialog setTextHint(@IdRes int viewId, CharSequence text) {
        ((TextView) findViewById(viewId)).setHint(text);
        return this;
    }

    public CustomizeDialog setTextHintColor(@IdRes int viewId, @ColorRes int resId) {
        ((TextView) findViewById(viewId)).setHintTextColor(ContextCompat.getColor(getContext(), resId));
        return this;
    }

    public CustomizeDialog setTextHintColorInt(@IdRes int viewId, @ColorInt int color) {
        ((TextView) findViewById(viewId)).setHintTextColor(color);
        return this;
    }

    public CustomizeDialog setTextGravity(@IdRes int viewId, int gravity) {
        ((TextView) findViewById(viewId)).setGravity(gravity);
        return this;
    }

    public CustomizeDialog addTextPaintFlags(@IdRes int viewId, int flags) {
        TextView textView = findViewById(viewId);
        textView.setPaintFlags(textView.getPaintFlags() | flags);
        return this;
    }

    public CustomizeDialog setImageResource(@IdRes int viewId, @DrawableRes int resId) {
        ((ImageView) findViewById(viewId)).setImageResource(resId);
        return this;
    }

    public CustomizeDialog setImageBitmap(@IdRes int viewId, Bitmap bm) {
        ((ImageView) findViewById(viewId)).setImageBitmap(bm);
        return this;
    }

    public CustomizeDialog setBackgroundColor(@IdRes int viewId, @ColorInt int color) {
        findViewById(viewId).setBackgroundColor(color);
        return this;
    }

    public CustomizeDialog setBackgroundRes(@IdRes int viewId, @DrawableRes int resId) {
        findViewById(viewId).setBackgroundResource(resId);
        return this;
    }

    public CustomizeDialog setVisibility(@IdRes int viewId, int visibility) {
        findViewById(viewId).setVisibility(visibility);
        return this;
    }

    public CustomizeDialog setOnCheckedChangeListener(@IdRes int viewId, CompoundButton.OnCheckedChangeListener listener) {
        CompoundButton view = findViewById(viewId);
        view.setOnCheckedChangeListener(listener);
        return this;
    }

    public CustomizeDialog setChecked(@IdRes int viewId, boolean checked) {
        View view = findViewById(viewId);
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(checked);
        }
        return this;
    }

    public CustomizeDialog setEnabled(@IdRes int viewId, boolean enabled) {
        findViewById(viewId).setEnabled(enabled);
        return this;
    }

    public CustomizeDialog setProgress(@IdRes int viewId, int progress) {
        ((ProgressBar) findViewById(viewId)).setProgress(progress);
        return this;
    }

    @Override
    public void setOnDismissListener(@Nullable OnDismissListener listener) {
        super.setOnDismissListener(listener == null ? null : new SafeOnDismissListener(listener));
        mListener = listener; //让listener被强引用，避免被回收导致Activity收不到回调
    }


    static class SafeOnDismissListener implements OnDismissListener {

        private SoftReference<OnDismissListener> mWeakReference;

        public SafeOnDismissListener(OnDismissListener outOnDismissListener) {
            mWeakReference = new SoftReference<>(outOnDismissListener);
        }

        @Override
        public void onDismiss(DialogInterface dialog) {
            if (mWeakReference.get() != null) {
                mWeakReference.get().onDismiss(dialog);
            }
        }
    }
}
