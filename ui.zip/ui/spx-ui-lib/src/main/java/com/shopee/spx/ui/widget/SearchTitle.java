package com.shopee.spx.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.shopee.spx.ui.R;

/**
 * Created by jingwei.xie on 2021-5-27.
 */
public class SearchTitle extends ConstraintLayout {

    private TextView mTvCancel;
    private EditText mEtSearch;
    private ImageView mIvRight;
    private ImageView mIvClear;
    protected View mDividerView;
    private View.OnClickListener mRightIconListener;
    private SearchListener mSearchListener;
    private boolean mRightIconVisible;

    public SearchTitle(Context context) {
        this(context, null);
    }

    public SearchTitle(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SearchTitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, R.layout.spx_ui_layout_search_title, this);
        mTvCancel = findViewById(R.id.tv_cancel);
        mEtSearch = findViewById(R.id.et_search_input);
        mIvClear = findViewById(R.id.iv_clear_input);
        mIvRight = findViewById(R.id.iv_right_icon);
        mDividerView = findViewById(R.id.view_title_divider);

        TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.SearchTitle);
        int rightIcon = ta.getResourceId(R.styleable.SearchTitle_right_icon, 0);
        int searchIcon = ta.getResourceId(R.styleable.SearchTitle_search_icon, 0);
        int clearIcon = ta.getResourceId(R.styleable.SearchTitle_clear_icon, 0);
        String cancelText = ta.getString(R.styleable.SearchTitle_cancel_text);
        String hint = ta.getString(R.styleable.SearchTitle_search_hint);
        boolean showDivider = ta.getBoolean(R.styleable.SearchTitle_search_show_bottom_divider, false);
        ta.recycle();

        setRightIcon(rightIcon);
        setClearIcon(clearIcon);
        setSearchText(searchIcon, cancelText, hint);
        setCancelIcon();
        setShowBottomDivider(showDivider);
    }

    public void setRightIcon(@DrawableRes int rightIcon, View.OnClickListener clickListener) {
        setRightIconClickListener(clickListener);
        setRightIcon(rightIcon);
    }

    public void setCancelIcon() {
        mTvCancel.setOnClickListener(v -> {
            mEtSearch.setText("");
        });
    }

    public void setRightIcon(int rightIcon) {
        if (rightIcon > 0) {
            mRightIconVisible = true;
            mIvRight.setVisibility(View.VISIBLE);
            mIvRight.setImageResource(rightIcon);
            mIvRight.setOnClickListener(v -> {
                if (mRightIconListener != null) {
                    mRightIconListener.onClick(mIvRight);
                }
            });
        }
    }

    public void setShowBottomDivider(boolean showBottomDivider) {
        mDividerView.setVisibility(showBottomDivider ? View.VISIBLE : View.GONE);
    }

    public View getBottomDivider(){
        return mDividerView;
    }

    public void setRightIconClickListener(View.OnClickListener clickListener) {
        mRightIconListener = clickListener;
    }

    private void setClearIcon(int clearIcon) {
        if (clearIcon > 0) {
            mIvClear.setImageResource(clearIcon);
        }
        mIvClear.setOnClickListener(v -> {
            mEtSearch.setText("");
        });
    }

    private void setSearchText(int searchIcon, String cancelText, String hint) {
        if (searchIcon > 0) {
            mEtSearch.setCompoundDrawablesRelativeWithIntrinsicBounds(searchIcon, 0, 0, 0);
        }

        if (!TextUtils.isEmpty(cancelText)) {
            mTvCancel.setText(cancelText);
        }

        if (!TextUtils.isEmpty(hint)) {
            mEtSearch.setHint(hint);
        }

        mEtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s == null) {
                    return;
                }

                if (mSearchListener != null) {
                    mSearchListener.onTextChange(s.toString());
                }

                if (s.toString().length() > 0) {
                    mIvClear.setVisibility(VISIBLE);
                    mIvRight.setVisibility(GONE);
                } else {
                    mIvClear.setVisibility(GONE);
                    mIvRight.setVisibility(mRightIconVisible ? VISIBLE : GONE);
                }
            }
        });
    }

    public TextView getCancelTextView() {
        return mTvCancel;
    }

    public EditText getSearchEdittext() {
        return mEtSearch;
    }

    public ImageView getRightImageView() {
        return mIvRight;
    }

    public ImageView getClearImageView() {
        return mIvClear;
    }

    public void setSearchListener(SearchListener searchListener) {
        this.mSearchListener = searchListener;
    }

    public interface SearchListener {
        void onTextChange(String text);
    }

}
