package com.shopee.spx.ui.widget.picker;

import android.view.View;

import com.shopee.spx.ui.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import static com.shopee.spx.ui.widget.picker.TimePickerView.PICKER_TYPE_DAY;
import static com.shopee.spx.ui.widget.picker.TimePickerView.PICKER_TYPE_HOUR;
import static com.shopee.spx.ui.widget.picker.TimePickerView.PICKER_TYPE_MINUTE;
import static com.shopee.spx.ui.widget.picker.TimePickerView.PICKER_TYPE_MONTH;
import static com.shopee.spx.ui.widget.picker.TimePickerView.PICKER_TYPE_SECOND;
import static com.shopee.spx.ui.widget.picker.TimePickerView.PICKER_TYPE_YEAR;

/**
 * 时间滚轮控件 controller
 * <p>
 * Created by honggang.xiong on 2019/9/29.
 */
public class WheelTime {

    public static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
    public static final int DEFAULT_START_YEAR = 1900;
    public static final int DEFAULT_END_YEAR = 2100;

    private static final int[] MONTH_DAYS = {31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    private WheelView mWvYear;
    private WheelView mWvMonth;
    private WheelView mWvDay;
    private WheelView mWvHour;
    private WheelView mWvMinute;
    private WheelView mWvSecond;
    private WheelView[] mWheelViews = new WheelView[6];

    @TimePickerView.PickerTypes
    private int mPickerType;

    private int mStartYear = DEFAULT_START_YEAR;
    private int mEndYear = DEFAULT_END_YEAR;

    public WheelTime(View view) {
        this(view, TimePickerView.PICKER_TYPE_ALL, 16);
    }

    public WheelTime(View view, int pickerType, int textSize) {
        setView(view);
        setPickerType(pickerType);
        setTextSizeCenter(textSize);
    }

    public void setPicker(int year, int month, int day) {
        this.setPicker(year, month, day, 0, 0, 0, null, null);
    }

    // month: [0, 11]
    public void setPicker(int year, int month, int day, int hour, int minute, int second,
                          String[] prefixArray, String[] suffixArray) {
        // 年
        mWvYear.setWheelAdapter(new NumericWheelAdapter(mStartYear, mEndYear,
                suffixArray != null ? suffixArray[0] : null,
                prefixArray != null ? prefixArray[0] : null));
        mWvYear.setInitPosition(year - mStartYear);

        // 月
        mWvMonth.setWheelAdapter(new NumericWheelAdapter(1, 12,
                suffixArray != null ? suffixArray[1] : null,
                prefixArray != null ? prefixArray[1] : null));
        mWvMonth.setInitPosition(month);

        // 日
        mWvDay.setWheelAdapter(new NumericWheelAdapter(1, getDaysOfMonth(year, month + 1),
                suffixArray != null ? suffixArray[2] : null,
                prefixArray != null ? prefixArray[2] : null));
        mWvDay.setInitPosition(day - 1);

        //时
        mWvHour.setWheelAdapter(new NumericWheelAdapter(0, 23,
                suffixArray != null ? suffixArray[3] : null,
                prefixArray != null ? prefixArray[3] : null));
        mWvHour.setInitPosition(hour);

        //分
        mWvMinute.setWheelAdapter(new NumericWheelAdapter(0, 59,
                suffixArray != null ? suffixArray[4] : null,
                prefixArray != null ? prefixArray[4] : null));
        mWvMinute.setInitPosition(minute);

        //秒
        mWvSecond.setWheelAdapter(new NumericWheelAdapter(0, 59,
                suffixArray != null ? suffixArray[4] : null,
                prefixArray != null ? prefixArray[4] : null));
        mWvSecond.setInitPosition(second);
    }

    private void setView(View contentView) {
        mWheelViews[0] = mWvYear = contentView.findViewById(R.id.wv_year);
        mWheelViews[1] = mWvMonth = contentView.findViewById(R.id.wv_month);
        mWheelViews[2] = mWvDay = contentView.findViewById(R.id.wv_day);
        mWheelViews[3] = mWvHour = contentView.findViewById(R.id.wv_hour);
        mWheelViews[4] = mWvMinute = contentView.findViewById(R.id.wv_min);
        mWheelViews[5] = mWvSecond = contentView.findViewById(R.id.wv_second);

        // 添加"年"监听
        mWvYear.setOnItemSelectedListener(index -> {
            int days = getDaysOfMonth(index + mStartYear, mWvMonth.getCurrentPosition() + 1);
            mWvDay.setWheelAdapter(new NumericWheelAdapter(1, days));
        });
        // 添加"月"监听
        mWvMonth.setOnItemSelectedListener(index -> {
            int days = getDaysOfMonth(mWvYear.getCurrentPosition() + mStartYear, index + 1);
            mWvDay.setWheelAdapter(new NumericWheelAdapter(1, days));
        });
    }

    @TimePickerView.PickerTypes
    public int getPickerType() {
        return mPickerType;
    }

    public void setPickerType(@TimePickerView.PickerTypes int pickerType) {
        if (mPickerType != pickerType) {
            mPickerType = pickerType;
            mWvYear.setVisibility((mPickerType & PICKER_TYPE_YEAR) != 0 ? View.VISIBLE : View.GONE);
            mWvMonth.setVisibility((mPickerType & PICKER_TYPE_MONTH) != 0 ? View.VISIBLE : View.GONE);
            mWvDay.setVisibility((mPickerType & PICKER_TYPE_DAY) != 0 ? View.VISIBLE : View.GONE);
            mWvHour.setVisibility((mPickerType & PICKER_TYPE_HOUR) != 0 ? View.VISIBLE : View.GONE);
            mWvMinute.setVisibility((mPickerType & PICKER_TYPE_MINUTE) != 0 ? View.VISIBLE : View.GONE);
            mWvSecond.setVisibility((mPickerType & PICKER_TYPE_SECOND) != 0 ? View.VISIBLE : View.GONE);
        }
    }

    /**
     * 返回时间，格式 yyyy-MM-dd HH:mm:ss
     */
    public String getTime() {
        return (mWvYear.getCurrentPosition() + mStartYear)
                + "-" + (mWvMonth.getCurrentPosition() + 1)
                + "-" + (mWvDay.getCurrentPosition() + 1)
                + " " + mWvHour.getCurrentPosition()
                + ":" + mWvMinute.getCurrentPosition()
                + ":" + mWvSecond.getCurrentPosition();
    }

    /**
     * 设置起始年份，call before {@linkplain #setPicker}
     */
    public void setStartYear(int startYear) {
        mStartYear = startYear;
    }

    /**
     * 设置截止年份，call before {@linkplain #setPicker}
     */
    public void setEndYear(int endYear) {
        mEndYear = endYear;
    }

    /**
     * 设置是否循环滚动
     */
    public void setCyclic(boolean cyclic) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setCyclic(cyclic);
            }
        }
    }

    public void setTextSizeCenter(int textSizeCenter) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setTextSizeCenter(textSizeCenter);
            }
        }
    }

    public void setTextSizeOut(int textSizeOut) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setTextSizeOut(textSizeOut);
            }
        }
    }

    /**
     * 设置分割线的颜色
     */
    public void setDividerColor(int dividerColor) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setDividerColor(dividerColor);
            }
        }
    }

    /**
     * 设置分割线之间的文字的颜色
     */
    public void setTextColorCenter(int textColorCenter) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setTextColorCenter(textColorCenter);
            }
        }
    }

    /**
     * 设置分割线以外文字的颜色
     */
    public void setTextColorOut(int textColorOut) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setTextColorOut(textColorOut);
            }
        }
    }

    public void setWheelMaxItems(int wheelMaxItems) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setMaxItems(wheelMaxItems);
            }
        }
    }

    public void setWheelItemHeight(int wheelItemHeight) {
        for (WheelView wheelView : mWheelViews) {
            if (wheelView != null) {
                wheelView.setItemHeight(wheelItemHeight);
            }
        }
    }

    /**
     * 获取某月的天数
     *
     * @param year  年
     * @param month 月
     * @return 某月的天数
     */
    public static int getDaysOfMonth(int year, /* 1-12 */ int month) {
        if (month == 2) {
            return isLeapYear(year) ? 29 : 28;
        }
        if (1 <= month && month <= 12) {
            return MONTH_DAYS[month - 1];
        }
        return 0;
    }

    /**
     * 是否是闰年
     *
     * @param year year
     * @return 是否是闰年
     */
    public static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

}

