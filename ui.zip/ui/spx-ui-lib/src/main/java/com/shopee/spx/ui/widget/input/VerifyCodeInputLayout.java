package com.shopee.spx.ui.widget.input;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.Dimension;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.Px;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.util.ContextUtils;

import java.util.Objects;

/**
 * 验证码输入框
 * <p>
 * Created by honggang.xiong on 2020/11/10.
 */
public class VerifyCodeInputLayout extends ConstraintLayout {

    public static final int MAX_VERIFY_CODE_BOX_COUNT = 6;

    private final TextView[] mTextViews = new TextView[MAX_VERIFY_CODE_BOX_COUNT];
    private final TextView[] mTvCursors = new TextView[MAX_VERIFY_CODE_BOX_COUNT];
    private final View[] mViewDividers = new View[MAX_VERIFY_CODE_BOX_COUNT - 1];
    private EditText mEditText;

    /**
     * 当前验证码
     */
    @NonNull
    private String mVerifyCode = "";

    /**
     * 输入框数量
     */
    private int mInputBoxCount = 0;

    /**
     * 输入框间距
     */
    private int mInputBoxSpace = 0;

    /**
     * 输入框背景/下划线默认颜色，焦点颜色，error颜色
     */
    private int mInputBgDefaultColor;
    private int mInputBgFocusColor;
    private int mInputBgErrorColor;

    private int mUnderlineMarginTop = 0;

    private Drawable mInputBackgroundDrawable;

    private int mInputTextColor;
    private int mInputCursorColor;

    private ValueAnimator mCursorAnimator;
    private OnInputListener mOnInputListener;
    private boolean mIsInputError = false;
    private boolean mIsPasswordInput = false;

    public VerifyCodeInputLayout(Context context) {
        this(context, null);
    }

    public VerifyCodeInputLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VerifyCodeInputLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, R.layout.spx_ui_layout_verify_code_input, this);
        mTextViews[0] = findViewById(R.id.tv_code1);
        mTextViews[1] = findViewById(R.id.tv_code2);
        mTextViews[2] = findViewById(R.id.tv_code3);
        mTextViews[3] = findViewById(R.id.tv_code4);
        mTextViews[4] = findViewById(R.id.tv_code5);
        mTextViews[5] = findViewById(R.id.tv_code6);
        mViewDividers[0] = findViewById(R.id.divider1);
        mViewDividers[1] = findViewById(R.id.divider2);
        mViewDividers[2] = findViewById(R.id.divider3);
        mViewDividers[3] = findViewById(R.id.divider4);
        mViewDividers[4] = findViewById(R.id.divider5);
        mTvCursors[0] = findViewById(R.id.tv_cursor1);
        mTvCursors[1] = findViewById(R.id.tv_cursor2);
        mTvCursors[2] = findViewById(R.id.tv_cursor3);
        mTvCursors[3] = findViewById(R.id.tv_cursor4);
        mTvCursors[4] = findViewById(R.id.tv_cursor5);
        mTvCursors[5] = findViewById(R.id.tv_cursor6);
        initEditText(context);
        initAttrs(context, attrs);
    }

    private void initAttrs(Context context, AttributeSet attrs) {
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.VerifyCodeInputLayout);
        int inputType = ta.getInt(R.styleable.VerifyCodeInputLayout_android_inputType, InputType.TYPE_CLASS_NUMBER);
        setInputType(inputType);

        int inputBoxCount = ta.getInteger(R.styleable.VerifyCodeInputLayout_vcInputBoxCount, MAX_VERIFY_CODE_BOX_COUNT);
        setInputBoxCount(inputBoxCount);

        int inputBoxSpace = ta.getDimensionPixelSize(R.styleable.VerifyCodeInputLayout_vcInputBoxSpace, 0);
        setInputBoxSpace(inputBoxSpace);

        int boxMinWidth = ta.getDimensionPixelSize(R.styleable.VerifyCodeInputLayout_vcInputBoxMinWidth, ContextUtils.dp2px(context, 20));
        int boxMinHeight = ta.getDimensionPixelSize(R.styleable.VerifyCodeInputLayout_vcInputBoxMinHeight, ContextUtils.dp2px(context, 20));
        setInputBoxMinSize(boxMinWidth, boxMinHeight);

        int inputTextColor = ta.getColor(R.styleable.VerifyCodeInputLayout_vcInputTextColor, Color.BLACK);
        setInputTextColor(inputTextColor);
        setInputTextSize(ta.getDimension(R.styleable.VerifyCodeInputLayout_vcInputTextSize, ContextUtils.sp2px(context, 14)));

        mInputCursorColor = ta.getColor(R.styleable.VerifyCodeInputLayout_vcInputCursorColor, inputTextColor);

        Drawable inputBackgroundDrawable = ta.getDrawable(R.styleable.VerifyCodeInputLayout_vcInputBackground);
        mUnderlineMarginTop = ta.getDimensionPixelOffset(R.styleable.VerifyCodeInputLayout_vcInputUnderlineMarginTop, ContextUtils.dp2px(context, 8));
        int underlineWidth = ta.getDimensionPixelOffset(R.styleable.VerifyCodeInputLayout_vcInputUnderlineWidth, ContextUtils.dp2px(context, 32));
        int underlineHeight = ta.getDimensionPixelOffset(R.styleable.VerifyCodeInputLayout_vcInputUnderlineHeight, 0);
        int defaultColor = ta.getColor(R.styleable.VerifyCodeInputLayout_vcInputBoxDefaultColor, Color.BLACK);
        int focusColor = ta.getColor(R.styleable.VerifyCodeInputLayout_vcInputBoxFocusColor, defaultColor);
        int errorColor = ta.getColor(R.styleable.VerifyCodeInputLayout_vcInputBoxErrorColor, Color.RED);
        int dividerWidth = ta.getDimensionPixelSize(R.styleable.VerifyCodeInputLayout_vcDividerWidth, 0);
        int dividerColor = ta.getColor(R.styleable.VerifyCodeInputLayout_vcDividerColor, Color.BLACK);
        ta.recycle();

        setDividerWidth(dividerWidth);
        setDividerColor(dividerColor);
        setInputBackgroundDrawable(inputBackgroundDrawable);
        setInputUnderLineDimension(underlineWidth, underlineHeight);
        setInputBackgroundColors(defaultColor, focusColor, errorColor);
    }

    private void initEditText(Context context) {
        mEditText = new VerifyCodeEditText(context);
        mEditText.setBackground(null);
        mEditText.setCursorVisible(false);
        mEditText.setFocusable(true);
        mEditText.setFocusableInTouchMode(true);
        mEditText.setLongClickable(false);
        mEditText.setTextColor(Color.TRANSPARENT);
        mEditText.setHintTextColor(Color.TRANSPARENT);
        LayoutParams lp = new LayoutParams(0, 0);
        lp.startToStart = ConstraintSet.PARENT_ID;
        lp.endToEnd = ConstraintSet.PARENT_ID;
        lp.topToTop = ConstraintSet.PARENT_ID;
        lp.bottomToBottom = ConstraintSet.PARENT_ID;
        addView(mEditText, lp);
        mEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                updateCodeInternal(editable == null ? "" : editable.toString());
            }
        });
        mEditText.setOnFocusChangeListener((v, hasFocus) -> updateFocusAndCursor());
    }

    private void setInputType(int inputType) {
        mEditText.setInputType(inputType);
        for (TextView textView : mTextViews) {
            textView.setInputType(inputType);
        }
        mIsPasswordInput = NewEditLayout.isPasswordInputType(inputType);
    }

    public void setInputBoxCount(int inputBoxCount) {
        if (inputBoxCount < 0 || inputBoxCount > MAX_VERIFY_CODE_BOX_COUNT) {
            throw new IllegalArgumentException("invalid inputBoxCount: " + inputBoxCount);
        }

        if (mInputBoxCount != inputBoxCount) {
            mInputBoxCount = inputBoxCount;
            mEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(mInputBoxCount)});
            for (int i = 0; i < inputBoxCount; i++) {
                mTextViews[i].setVisibility(VISIBLE);
            }
            for (int j = inputBoxCount; j < MAX_VERIFY_CODE_BOX_COUNT; j++) {
                mTextViews[j].setVisibility(GONE);
            }
        }
    }

    private void setInputBoxSpace(@Dimension int spaceInPx) {
        if (mInputBoxSpace == spaceInPx) {
            return;
        }

        mInputBoxSpace = spaceInPx;
        for (int i = 1; i < MAX_VERIFY_CODE_BOX_COUNT; i++) {
            TextView textView = mTextViews[i];
            MarginLayoutParams lp = (MarginLayoutParams) textView.getLayoutParams();
            lp.leftMargin = mInputBoxSpace;
        }
        requestLayout();
        invalidate();
    }

    private void setInputBoxMinSize(@Dimension int widthInPx, @Dimension int heightInPx) {
        for (TextView textView : mTextViews) {
            textView.setMinWidth(widthInPx);
            textView.setMinHeight(heightInPx);
        }
    }

    public void setInputTextColor(@ColorInt int textColor) {
        mInputTextColor = textColor;
        for (TextView textView : mTextViews) {
            textView.setTextColor(textColor);
        }
    }

    public void setInputTextSize(@Dimension float sizeInPX) {
        for (TextView textView : mTextViews) {
            textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeInPX);
        }
        for (TextView textView : mTvCursors) {
            textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeInPX);
        }
    }

    public void setDividerWidth(@Px int widthInPx) {
        for (View divider : mViewDividers) {
            if (widthInPx <= 0) {
                divider.setVisibility(GONE);
            } else {
                divider.setVisibility(VISIBLE);
                ViewGroup.LayoutParams lp = divider.getLayoutParams();
                if (lp != null) {
                    lp.width = widthInPx;
                }
            }
        }
        requestLayout();
        invalidate();
    }

    public void setDividerColor(@ColorInt int color) {
        for (View divider : mViewDividers) {
            divider.setBackgroundColor(color);
        }
        invalidate();
    }

    public void setInputBackgroundDrawable(@Nullable Drawable drawable) {
        if (drawable != null && drawable.getConstantState() == null) {
            drawable = null;
        }
        if (mInputBackgroundDrawable != drawable) {
            mInputBackgroundDrawable = drawable;
            for (TextView textView : mTextViews) {
                Drawable realDrawable = drawable == null ? null : drawable.getConstantState().newDrawable().mutate();
                textView.setBackground(realDrawable);
            }
        }
    }

    public void setInputUnderLineDimension(@Dimension int widthInPx, @Dimension int heightInPx) {
        if (widthInPx <= 0 || heightInPx <= 0) {
            for (TextView textView : mTextViews) {
                textView.setCompoundDrawablesRelative(null, null, null, null);
            }
            return;
        }

        for (TextView textView : mTextViews) {
            Drawable drawable = textView.getCompoundDrawablesRelative()[3];
            ColorDrawable colorDrawable;
            if (drawable instanceof ColorDrawable) {
                colorDrawable = (ColorDrawable) drawable;
            } else {
                colorDrawable = new ColorDrawable(Color.BLACK);
            }
            colorDrawable.setBounds(0, 0, widthInPx, heightInPx);
            textView.setCompoundDrawablePadding(mUnderlineMarginTop);
            textView.setCompoundDrawablesRelative(null, null, null, colorDrawable);
        }
    }

    public void setInputBackgroundColors(@ColorInt int defaultColor, @ColorInt int focusColor, @ColorInt int errorColor) {
        if (mInputBgDefaultColor == defaultColor && mInputBgFocusColor == focusColor && mInputBgErrorColor == errorColor) {
            return;
        }

        mInputBgDefaultColor = defaultColor;
        mInputBgFocusColor = focusColor;
        mInputBgErrorColor = errorColor;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            for (TextView textView : mTextViews) {
                Drawable drawableBottom = textView.getCompoundDrawablesRelative()[3];
                if (drawableBottom != null) {
                    drawableBottom.setTintMode(PorterDuff.Mode.SRC_IN);
                    ColorStateList stateList = new ColorStateList(new int[][]{
                            {android.R.attr.state_activated},
                            {android.R.attr.state_selected},
                            {}},
                            new int[]{errorColor, focusColor, defaultColor});
                    drawableBottom.setTintList(stateList);
                }

                Drawable backgroundDrawable = textView.getBackground();
                if (backgroundDrawable != null) {
                    backgroundDrawable.setTintMode(PorterDuff.Mode.SRC_IN);
                    ColorStateList stateList2 = new ColorStateList(new int[][]{
                            {android.R.attr.state_activated},
                            {android.R.attr.state_selected},
                            {}},
                            new int[]{errorColor, focusColor, defaultColor});
                    backgroundDrawable.setTintList(stateList2);
                }
            }
        }
    }

    @NonNull
    public String getVerifyCode() {
        return mVerifyCode;
    }

    /**
     * 会触发 {@link #updateCodeInternal(String)}，所以这里无需修改 mVerifyCode
     */
    public void clearVerifyCode() {
        mEditText.setText("");
    }

    public void setInputError(boolean isError) {
        if (mIsInputError != isError) {
            mIsInputError = isError;
            for (TextView textView : mTextViews) {
                textView.setActivated(isError);
            }
        }
    }

    public boolean isInputError() {
        return mIsInputError;
    }

    public void setEditTextEnabled(boolean enabled) {
        mEditText.setEnabled(enabled);
    }

    public boolean isEditTextEnabled() {
        return mEditText.isEnabled();
    }

    public void requestEditTextFocus() {
        setEditTextEnabled(true);
        mEditText.requestFocus();
        ContextUtils.showKeyboard(mEditText);
    }

    public void clearEditTextFocus() {
        mEditText.clearFocus();
        ContextUtils.hideKeyboard(mEditText);
    }

    public void setOnInputListener(@Nullable OnInputListener onInputListener) {
        mOnInputListener = onInputListener;
    }

    void updateCodeInternal(@NonNull String code) {
        if (Objects.equals(mVerifyCode, code)) {
            return;
        }

        mVerifyCode = code;
        int codeLength = mVerifyCode.length();
        cancelCursorAnimator();

        for (int i = 0; i < mInputBoxCount; i++) {
            mTextViews[i].setText(i < codeLength ? String.valueOf(mVerifyCode.charAt(i)) : "");
        }

        updateFocusAndCursor();

        notifyListener(); // 回调
    }

    private void cancelCursorAnimator() {
        if (mCursorAnimator != null) {
            mCursorAnimator.cancel();
            mCursorAnimator = null;
        }
    }

    /**
     * 更新焦点输入框及光标
     */
    private void updateFocusAndCursor() {
        int codeLength = mVerifyCode.length();
        boolean hadFocus = mEditText.hasFocus();
        for (int i = 0; i < mInputBoxCount; i++) {
            mTextViews[i].setSelected(hadFocus && i == codeLength);
        }

        cancelCursorAnimator();
        if (hadFocus && codeLength < mInputBoxCount) {
            startCursorAt(mTvCursors[codeLength]);
        }
    }

    private void startCursorAt(TextView view) {
        view.setText("|");
        mCursorAnimator = ObjectAnimator.ofInt(view, "textColor", mInputCursorColor, 0);
        mCursorAnimator.setDuration(1500);
        mCursorAnimator.setRepeatCount(-1);
        mCursorAnimator.setRepeatMode(ValueAnimator.RESTART);
        mCursorAnimator.setEvaluator((fraction, startValue, endValue) -> fraction <= 0.5f ? startValue : endValue);
        mCursorAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                view.setText("");
            }
        });
        mCursorAnimator.start();
    }

    private void notifyListener() {
        if (mOnInputListener != null) {
            if (mVerifyCode.length() != mInputBoxCount) {
                mOnInputListener.onCodeChanged(mVerifyCode);
            } else {
                mOnInputListener.onCodeCompleted(mVerifyCode);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        cancelCursorAnimator();
    }


    public interface OnInputListener {
        void onCodeChanged(@NonNull String code);

        void onCodeCompleted(@NonNull String code);
    }

    static class VerifyCodeEditText extends AppCompatEditText {
        public VerifyCodeEditText(Context context) {
            super(context);
        }

        public VerifyCodeEditText(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        @Override
        protected void onSelectionChanged(int selStart, int selEnd) {
            super.onSelectionChanged(selStart, selEnd);
            CharSequence text = getText();
            int length = text != null ? text.length() : 0;
            if (selStart != length || selEnd != length) {
                setSelection(length);
            }
        }
    }

}
