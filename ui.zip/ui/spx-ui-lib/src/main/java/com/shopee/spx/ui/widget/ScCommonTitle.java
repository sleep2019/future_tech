package com.shopee.spx.ui.widget;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.StringRes;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.util.ContextUtils;

/**
 * Created by honggang.xiong on 2019-11-15.
 */
public class ScCommonTitle extends BaseTitle {

    public static final int NO_OP = 0;
    public static final int COMMON_GO_BACK = 1;
    public static final int NO_BACK = 2;

    private int mStyle = COMMON_GO_BACK;
    private ImageView mIvBack;
    private TextView mTvCenterTitle;
    private ImageView mIvDropdown;

    public ScCommonTitle(Context context) {
        this(context, null);
    }

    public ScCommonTitle(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ScCommonTitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    void initView(AttributeSet attrs) {
        mIvBack = findViewById(R.id.iv_title_back);
        mTvCenterTitle = findViewById(R.id.tv_center_title);
        mIvFirstRightIcon = findViewById(R.id.iv_first_right_icon);
        mIvFirstRightIconRedDot = findViewById(R.id.iv_first_red_dot);
        mTvFirstRightIconRedDot = findViewById(R.id.tv_first_red_dot);
        mIvSecondRightIcon = findViewById(R.id.iv_second_right_icon);
        mIvThirdRightIcon = findViewById(R.id.iv_third_right_icon);
        mIvDropdown = findViewById(R.id.iv_drop_down);
        mDividerView = findViewById(R.id.view_title_divider);

        TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.ScCommonTitle);
        String centerTitle = ta.getString(R.styleable.ScCommonTitle_center_title);
        mFirstRightButton = ta.getResourceId(R.styleable.ScCommonTitle_common_first_right_icon, 0);
        mSecondRightButton = ta.getResourceId(R.styleable.ScCommonTitle_common_second_right_icon, 0);
        mThirdRightButton = ta.getResourceId(R.styleable.ScCommonTitle_common_third_right_icon, 0);
        boolean showDropDown = ta.getBoolean(R.styleable.ScCommonTitle_show_drop_down, false);
        boolean showDivider = ta.getBoolean(R.styleable.ScCommonTitle_common_show_bottom_divider, false);
        mStyle = ta.getInt(R.styleable.ScCommonTitle_common_title_style, COMMON_GO_BACK);
        ta.recycle();

        setCenterTitle(centerTitle);
        setDropDownIcon(showDropDown);
        setStyle(mStyle);
        setShowBottomDivider(showDivider);
    }

    @Override
    int getLayoutId() {
        return R.layout.spx_ui_layout_common_title;
    }

    private void setDropDownIcon(boolean showDropDown) {
        mIvDropdown.setVisibility(showDropDown ? VISIBLE : GONE);
    }

    public ImageView getBackImageView() {
        return mIvBack;
    }

    public TextView getCenterTextView() {
        return mTvCenterTitle;
    }

    public ImageView getDropdownImageView() {
        return mIvDropdown;
    }

    public void setDropDownListener(View.OnClickListener clickListener) {
        mIvDropdown.setOnClickListener(clickListener);
    }

    public void setCenterTitle(CharSequence text) {
        mTvCenterTitle.setText(text);
    }

    public void setCentTitleColor(@ColorInt int color) {
        mTvCenterTitle.setTextColor(color);
    }

    public void setBackIconColor(@ColorInt int color) {
        Drawable drawable = mIvBack.getDrawable();
        // must mutate
        drawable.mutate();
        drawable.setTint(color);
    }

    public void setCenterTitle(@StringRes int resId) {
        mTvCenterTitle.setText(resId);
    }

    public void setStyle(int style) {
        if (style < 0 || style > 2) {
            return;
        }
        mStyle = style;
        switch (mStyle) {
            case NO_OP:
                mIvBack.setVisibility(VISIBLE);
                mIvBack.setOnClickListener(null);
                break;
            case COMMON_GO_BACK:
                mIvBack.setVisibility(VISIBLE);
                mIvBack.setOnClickListener(v -> {
                    Activity activity = ContextUtils.getActivityFromView(v);
                    if (activity != null) {
                        activity.finish();
                    }
                });
                break;
            case NO_BACK:
                mIvBack.setVisibility(GONE);
                break;
        }
    }

    public void setOnBackClickListener(OnClickListener listener) {
        mIvBack.setOnClickListener(listener);
    }
}
