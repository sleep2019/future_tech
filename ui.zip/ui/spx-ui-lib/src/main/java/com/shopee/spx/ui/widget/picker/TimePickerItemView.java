package com.shopee.spx.ui.widget.picker;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

import androidx.annotation.ColorInt;
import androidx.annotation.Dimension;
import androidx.annotation.IntDef;
import androidx.annotation.IntRange;
import androidx.annotation.Nullable;

import com.shopee.spx.ui.R;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Calendar;
import java.util.Date;

/**
 * 时间选择器控件
 */
public class TimePickerItemView extends LinearLayout {

    public static final int PICKER_TYPE_YEAR = 1 << 5;
    public static final int PICKER_TYPE_MONTH = 1 << 4;
    public static final int PICKER_TYPE_DAY = 1 << 3;
    public static final int PICKER_TYPE_HOUR = 1 << 2;
    public static final int PICKER_TYPE_MINUTE = 1 << 1;
    public static final int PICKER_TYPE_SECOND = 1;

    // 年月
    public static final int PICKER_TYPE_YEAR_MONTH = PICKER_TYPE_YEAR | PICKER_TYPE_MONTH;
    // 年月日
    public static final int PICKER_TYPE_YEAR_MONTH_DAY = PICKER_TYPE_YEAR_MONTH | PICKER_TYPE_DAY;
    // 时分
    public static final int PICKER_TYPE_HOUR_MINUTE = PICKER_TYPE_HOUR | PICKER_TYPE_MINUTE;
    // 时分秒
    public static final int PICKER_TYPE_HOUR_MINUTE_SECOND = PICKER_TYPE_HOUR_MINUTE | PICKER_TYPE_SECOND;
    // 月日时分
    public static final int PICKER_TYPE_MONTH_DAY_HOUR_MIN = PICKER_TYPE_MONTH | PICKER_TYPE_DAY | PICKER_TYPE_HOUR_MINUTE;
    // 年月日时分秒
    public static final int PICKER_TYPE_ALL = PICKER_TYPE_YEAR_MONTH_DAY | PICKER_TYPE_HOUR_MINUTE_SECOND;

    @IntDef(flag = true, value = {
            PICKER_TYPE_YEAR,
            PICKER_TYPE_MONTH,
            PICKER_TYPE_DAY,
            PICKER_TYPE_HOUR,
            PICKER_TYPE_MINUTE,
            PICKER_TYPE_SECOND})
    @Retention(RetentionPolicy.SOURCE)
    public @interface PickerTypes {
    }

    private WheelTime mWheelTime;

    @PickerTypes
    private int mPickerType = PICKER_TYPE_ALL;

    private Date mDate;
    private int mStartYear;
    private int mEndYear;
    private boolean mCyclic;

    private int mColorBackgroundWheel;
    private int mDividerColor;
    private int mTextColorOut;
    private int mTextColorCenter;
    private int mTextSizeCenter = 16;
    private int mTextSizeOut = 14;

    private int mWheelMaxItems = 7;
    private int mWheelItemHeight;

    private String[] mTimePrefixArray;
    private String[] mTimeSuffixArray;

    public TimePickerItemView(Context context) {
        super(context);
        initView(context);
    }

    public TimePickerItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public TimePickerItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.spx_ui_layout_time_picker_item_view, this, true);
    }

    public void show() {
        getRootView().setBackgroundColor(mColorBackgroundWheel == 0 ? Color.WHITE : mColorBackgroundWheel);
        mWheelTime = new WheelTime(getRootView(), mPickerType, mTextSizeCenter);

        if (mStartYear != 0 && mEndYear != 0 && mStartYear <= mEndYear) {
            // 设置可以选择的时间范围, 要在setTime之前调用才有效果
            mWheelTime.setStartYear(mStartYear);
            mWheelTime.setEndYear(mEndYear);
        }
        setTime(mDate);
        mWheelTime.setCyclic(mCyclic);
        mWheelTime.setDividerColor(mDividerColor);
        mWheelTime.setTextSizeOut(mTextSizeOut);
        mWheelTime.setTextColorCenter(mTextColorCenter);
        mWheelTime.setTextColorOut(mTextColorOut);
        mWheelTime.setWheelMaxItems(mWheelMaxItems);
        if (mWheelItemHeight > 0) {
            mWheelTime.setWheelItemHeight(mWheelItemHeight);
        }
    }

    /**
     * 设置选中时间,默认选中当前时间
     */
    private void setTime(Date date) {
        Calendar calendar = Calendar.getInstance();
        if (date == null) {
            calendar.setTimeInMillis(System.currentTimeMillis());
        } else {
            calendar.setTime(date);
        }

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hours = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int seconds = calendar.get(Calendar.SECOND);
        mWheelTime.setPicker(year, month, day, hours, minute, seconds, mTimePrefixArray, mTimeSuffixArray);
    }

    /**
     * 获取选中时间，格式 yyyy-MM-dd HH:mm:ss
     */
    public String getTime() {
        return mWheelTime.getTime();
    }

    /**
     * 设置 PickerView 展示的时间类型，默认全部显示（年月日时分秒）
     */
    public TimePickerItemView setPickerType(int pickerType) {
        mPickerType = pickerType;
        return this;
    }

    /**
     * 设置初始选中时间
     */
    public TimePickerItemView setDate(Date date) {
        mDate = date;
        return this;
    }

    /**
     * 设置年份区间
     */
    public TimePickerItemView setRange(int startYear, int endYear) {
        mStartYear = startYear;
        mEndYear = endYear;
        return this;
    }

    /**
     * 设置是否循环，默认 false
     */
    public TimePickerItemView isCyclic(boolean cyclic) {
        mCyclic = cyclic;
        return this;
    }

    /**
     * 设置滚轮背景颜色，未设置或为 0 时默认白色
     */
    public TimePickerItemView setBgColor(@ColorInt int colorBackgroundWheel) {
        mColorBackgroundWheel = colorBackgroundWheel;
        return this;
    }

    /**
     * 设置滚轮内容字体大小，默认 16sp
     */
    public TimePickerItemView setTextSizeCenter(@Dimension(unit = Dimension.SP) int textSizeCenter) {
        mTextSizeCenter = textSizeCenter;
        return this;
    }

    /**
     * 设置滚轮外容字体大小，默认 14sp
     */
    public TimePickerItemView setTextSizeOut(@Dimension(unit = Dimension.SP) int textSizeOut) {
        mTextSizeOut = textSizeOut;
        return this;
    }

    /**
     * 设置滚轮分割线的颜色
     */
    public TimePickerItemView setDividerColor(@ColorInt int dividerColor) {
        mDividerColor = dividerColor;
        return this;
    }

    /**
     * 设置滚轮分割线之间的文字的颜色
     */
    public TimePickerItemView setTextColorCenter(@ColorInt int textColorCenter) {
        mTextColorCenter = textColorCenter;
        return this;
    }

    /**
     * 设置滚轮分割线以外文字的颜色
     */
    public TimePickerItemView setTextColorOut(@ColorInt int textColorOut) {
        mTextColorOut = textColorOut;
        return this;
    }

    /**
     * 设置滚轮 item 数量，奇数效果更好
     */
    public TimePickerItemView setWheelMaxItems(@IntRange(from = 0) int wheelMaxItems) {
        if (wheelMaxItems >= 0) {
            mWheelMaxItems = wheelMaxItems;
        }
        return this;
    }

    /**
     * 设置滚轮 item 高度
     */
    public TimePickerItemView setWheelItemHeight(@Dimension @IntRange(from = 1) int wheelItemHeight) {
        if (wheelItemHeight > 0) {
            mWheelItemHeight = wheelItemHeight;
        }
        return this;
    }

    /**
     * 设置年月日时分秒的前缀
     */
    public TimePickerItemView setTimePrefixArray(String[] timePrefixArray) {
        if (timePrefixArray == null || timePrefixArray.length == 6) {
            mTimePrefixArray = timePrefixArray;
        }
        return this;
    }

    /**
     * 设置年月日时分秒的后缀
     */
    public TimePickerItemView setTimeSuffixArray(String[] timeSuffixArray) {
        if (timeSuffixArray == null || timeSuffixArray.length == 6) {
            mTimeSuffixArray = timeSuffixArray;
        }
        return this;
    }
}

