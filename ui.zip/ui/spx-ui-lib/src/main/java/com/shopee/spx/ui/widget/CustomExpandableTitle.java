package com.shopee.spx.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.shopee.spx.ui.R;
import com.shopee.spx.ui.util.ContextUtils;
import com.shopee.spx.ui.widget.bean.TitleMenuItem;
import com.shopee.spx.ui.widget.listener.MenuClickListener;
import com.shopee.spx.ui.widget.view.TitleMenuView;
import com.shopee.spx.ui.widget.view.TitlePopupWindow;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * @ClassName: CustomExpandableTitle
 * @Description: 可展开的标题栏
 * @Author: jingwei.xie
 * @CreateDate: 2022/7/19 5:37 下午
 */
public class CustomExpandableTitle extends ConstraintLayout implements View.OnClickListener {

    protected TitleMenuView mMenuFirstRightIcon;
    protected ImageView mIvFirstRightIconRedDot;
    protected TextView mTvFirstRightIconRedDot;
    protected TitleMenuView mMenuSecondRightIcon;
    protected TitleMenuView mMenuThirdRightIcon;
    protected TitleMenuView mMoreView;
    protected View mDividerView;

    protected int mFirstRightButton;
    protected int mSecondRightButton;
    protected int mThirdRightButton;

    private static final String MENU_FIRST_ITEM = "menu_first_item";
    private static final String MENU_SECOND_ITEM = "menu_second_item";
    private static final String MENU_THIRD_ITEM = "menu_third_item";
    private static final String MENU_MORE_ITEM = "menu_more_item";

    protected List<TitleMenuItem> mMenuItems = new LinkedList<>();
    /**
     * 标题右icon的列表
     */
    protected LinkedList<TitleMenuView> mMenuViewList = new LinkedList<>();
    private MenuClickListener mMenuClickListener;

    /**
     * 标题栏的item数目，低于这个数目时，需要水平显示，高于这个item时，需要折叠显示
     */
    private static final int EXPAND_ITEM_COUNT = 4;
    private static final int MAX_HOR_ITEM_COUNT = 2;

    private TitlePopupWindow mTitlePopupWindow;

    public static final int TITLE_ONLY = 0;
    public static final int TITLE_TAB = 1;
    public static final int TITLE_DRAWER = 2;

    private int mStyle = TITLE_ONLY;
    private View mClPortrait;
    private CircleImageView mIvPortrait;
    private ImageView mIvPortraitRedDot;
    private ImageView mIvPortraitDescRedDot;
    private TextView mTvPortraitDesc;
    private ImageView mIvPortraitStatus;
    private LinearLayout mTabContainer;
    private ConstraintLayout mDrawerContainer;
    private ImageView mIvPortraitDropDown;
    private ImageView mIvDrawerRedPoint;
    private ImageView mIvPortraitFunction;

    private int portraitIcon;
    private int portraitStatusIcon;
    private int style;
    private String portraitDesc;
    /**
     * 判断drop down按钮的显示
     */
    private boolean isDropDown = false;

    public CustomExpandableTitle(Context context) {
        this(context, null);
    }

    public CustomExpandableTitle(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomExpandableTitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, getLayoutId(), this);
        initView(attrs);
        initMenuViewList();
        setRightIcon(mFirstRightButton, mSecondRightButton, mThirdRightButton);
    }

    private void initMenuViewList() {
        mMenuViewList.add(mMenuFirstRightIcon);
        mMenuViewList.add(mMenuSecondRightIcon);
        mMenuViewList.add(mMenuThirdRightIcon);
    }

    public void setRightIcon(int firstRightIcon, int secondRightIcon, int thirdRightIcon) {
        mMenuItems.clear();
        if (firstRightIcon > 0) {
            mMenuFirstRightIcon.setVisibility(VISIBLE);
            mMenuFirstRightIcon.setImageResource(firstRightIcon);
        } else {
            mMenuFirstRightIcon.setVisibility(GONE);
        }

        if (secondRightIcon > 0) {
            mMenuSecondRightIcon.setVisibility(VISIBLE);
            mMenuSecondRightIcon.setImageResource(secondRightIcon);
        } else {
            mMenuSecondRightIcon.setVisibility(GONE);
        }

        if (thirdRightIcon > 0) {
            mMenuThirdRightIcon.setVisibility(VISIBLE);
            mMenuThirdRightIcon.setImageResource(thirdRightIcon);
        } else {
            mMenuThirdRightIcon.setVisibility(GONE);
        }
    }

    public void setRightIcon(List<TitleMenuItem> titleMenuItems) {
        // 小于三个时直接显示
        if (titleMenuItems.size() < EXPAND_ITEM_COUNT) {
            for (int i = 0; i < mMenuViewList.size(); i++) {
                TitleMenuView menuView = mMenuViewList.get(i);
                if (i >= titleMenuItems.size() || titleMenuItems.get(i).getResIcon() <= 0) {
                    menuView.setVisibility(GONE);
                } else {
                    menuView.setMenuItem(titleMenuItems.get(i));
                    menuView.setOnClickListener(this);
                }
            }
        } else {
            // 多于三个时需要展开显示，第一个item显示更多
            TitleMenuView moreView = mMenuViewList.get(0);
            mMoreView = moreView;
            moreView.setMenuItem(new TitleMenuItem(MENU_MORE_ITEM, R.drawable.ic_more_24));
            // 将最左边的item设置显示的item
            for (int i = 1; i <= MAX_HOR_ITEM_COUNT; i++) {
                TitleMenuView menuView = mMenuViewList.get(i);
                menuView.setMenuItem(titleMenuItems.get(titleMenuItems.size() + i
                        - MAX_HOR_ITEM_COUNT - 1));
                menuView.setOnClickListener(this);
            }

            // 中间的通过popupwindow显示
            List<TitleMenuItem> subItem = titleMenuItems.subList(0, titleMenuItems.size() - MAX_HOR_ITEM_COUNT);
            Collections.reverse(subItem);

            int menuWidth = (int) this.getContext().getResources()
                    .getDimension(R.dimen.title_menu_min_width);
            moreView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mTitlePopupWindow != null && mTitlePopupWindow.isShowing()) {
                        mTitlePopupWindow.dismiss();
                    } else {
                        mTitlePopupWindow = new TitlePopupWindow(CustomExpandableTitle.this.getContext(),
                                subItem, mMenuClickListener);

                        mTitlePopupWindow.showAsDropDown(moreView, -menuWidth + moreView.getWidth() / 2, 0);
                    }
                }
            });
        }
    }

    public void setShowBottomDivider(boolean showBottomDivider) {
        mDividerView.setVisibility(showBottomDivider ? View.VISIBLE : View.GONE);
    }

    public View getBottomDivider() {
        return mDividerView;
    }

    public void setFirstRightIconListener(View.OnClickListener clickListener) {
        mMenuFirstRightIcon.setOnClickListener(clickListener);
    }

    public void setSecondRightIconListener(View.OnClickListener clickListener) {
        mMenuSecondRightIcon.setOnClickListener(clickListener);
    }

    public void setThirdRightIconListener(View.OnClickListener clickListener) {
        mMenuThirdRightIcon.setOnClickListener(clickListener);
    }

    public void setFirstRedDotTv(boolean visible) {
        mTvFirstRightIconRedDot.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setFirstRedDotTvText(String text) {
        mTvFirstRightIconRedDot.setText(text);
    }

    public void setFirstRedDotTvClickListener(View.OnClickListener clickListener) {
        mTvFirstRightIconRedDot.setOnClickListener(clickListener);
    }

    public void setFirstRedDot(boolean visible) {
        mIvFirstRightIconRedDot.setVisibility(visible ? VISIBLE : GONE);
    }

    public ImageView getFirstRightIcon() {
        return mMenuFirstRightIcon.getIvIcon();
    }

    public ImageView getSecondRightIcon() {
        return mMenuSecondRightIcon.getIvIcon();
    }

    public ImageView getThirdRightIcon() {
        return mMenuThirdRightIcon.getIvIcon();
    }

    public TextView getFirstRedDotTv() {
        return mTvFirstRightIconRedDot;
    }

    public void setBaseTitleItems(List<TitleMenuItem> items) {
        this.mMenuItems = items;
        setRightIcon(mMenuItems);
    }

    /***
     * 从右侧到左侧开始增加item
     */
    public void addBaseTitleItemRightToLeft(TitleMenuItem item) {
        mMenuItems.add(item);

    }

    /***
     * 从右侧开始增加item
     */
    public void addBaseTitleItemRightToLeft(int pos, TitleMenuItem item) {
        mMenuItems.add(pos, item);
    }

    /***
     * 从右侧开始增加item
     */
    public void addBaseTitleItemLeftToRight(int pos, TitleMenuItem item) {
        int size = mMenuItems.size();
        int menuPos = size - pos;
        if (menuPos >= 0) {
            mMenuItems.add(menuPos, item);
        }
    }

    public void notifyMenuChange() {
        setRightIcon(mMenuItems);
    }

    public void clearBaseTitleItem() {
        mMenuItems.clear();
    }

    public @Nullable
    TitleMenuItem getMenuItem(String menuName) {
        for (TitleMenuItem item : mMenuItems) {
            if (menuName.equals(item.getItemTag())) {
                return item;
            }
        }

        return null;
    }

    public @Nullable
    TitleMenuView getMenuItemView(String menuName) {
        for (TitleMenuItem item : mMenuItems) {
            if (menuName.equals(item.getItemTag())) {
                return item.getMenuView();
            }
        }

        return null;
    }

    public @Nullable
    TitleMenuView getMenuItemView(int index) {
        if (index > 0 && index < mMenuItems.size()) {
            return mMenuItems.get(index).getMenuView();
        }

        return null;
    }

    @Nullable
    public TitleMenuView getMoreView() {
        return mMoreView;
    }

    public void setMenuClickListener(MenuClickListener listener) {
        this.mMenuClickListener = listener;
    }

    @Override
    public void onClick(View v) {
        if (mMenuClickListener != null && v instanceof TitleMenuView) {
            mMenuClickListener.onClick(v, ((TitleMenuView) v).getTag());
        }
    }

    /**
     * 设置menu红点数目
     *
     * @param tag    item的tag
     * @param number 未读红点数
     */
    public void setMenuReDotNumber(String tag, int number) {
        TitleMenuItem item = getMenuItem(tag);
        if (item == null) {
            return;
        }
        item.setRedDotNumber(number);
        TitleMenuView menuItemView = item.getMenuView();

        // 判断item是否在moreview里面, 这里暂时只考虑到more列表中存在一个item存在未读数的情况
        if (mMenuItems.size() >= EXPAND_ITEM_COUNT && mMoreView != null) {
            mMoreView.setTvRedDotNumber(number);
        }

        if (menuItemView != null) {
            menuItemView.setTvRedDotNumber(number);
        }
    }

    int getLayoutId() {
        return R.layout.spx_ui_layout_custom_expand_title;
    }

    void initView(AttributeSet attrs) {
        mMenuFirstRightIcon = findViewById(R.id.iv_first_right_icon);
        mIvFirstRightIconRedDot = mMenuFirstRightIcon.getIvRedDot();
        mTvFirstRightIconRedDot = mMenuFirstRightIcon.getTvRedDot();
        mMenuSecondRightIcon = findViewById(R.id.iv_second_right_icon);
        mMenuThirdRightIcon = findViewById(R.id.iv_third_right_icon);
        mDividerView = findViewById(R.id.view_title_divider);
        mClPortrait = findViewById(R.id.cl_portrait);
        mIvPortrait = findViewById(R.id.civ_portrait);
        mIvPortraitRedDot = findViewById(R.id.iv_portrait_red_dot);
        mIvPortraitDescRedDot = findViewById(R.id.tv_portrait_desc_red_dot);
        mIvPortraitStatus = findViewById(R.id.iv_portrait_status);
        mTvPortraitDesc = findViewById(R.id.tv_portrait_desc);
        mTabContainer = findViewById(R.id.ll_container_tab);
        mDrawerContainer = findViewById(R.id.cl_drawer);
        mIvPortraitDropDown = findViewById(R.id.iv_portrait_drop_down);
        mIvDrawerRedPoint = findViewById(R.id.iv_drawer_red_dot);
        mIvPortraitFunction = findViewById(R.id.iv_portrait_function);

        TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.CustomTitle);
        mFirstRightButton = ta.getResourceId(R.styleable.CustomTitle_custom_first_right_icon, 0);
        mSecondRightButton = ta.getResourceId(R.styleable.CustomTitle_custom_second_right_icon, 0);
        mThirdRightButton = ta.getResourceId(R.styleable.CustomTitle_custom_third_right_icon, 0);
        portraitIcon = ta.getResourceId(R.styleable.CustomTitle_portrait_icon, 0);
        portraitStatusIcon = ta.getResourceId(R.styleable.CustomTitle_portrait_status_icon, 0);
        portraitDesc = ta.getString(R.styleable.CustomTitle_portrait_desc);
        boolean showDivider = ta.getBoolean(R.styleable.CustomTitle_custom_show_bottom_divider, false);
        style = ta.getInt(R.styleable.CustomTitle_custom_title_style, TITLE_ONLY);
        ta.recycle();

        setShowBottomDivider(showDivider);
        setStyle(style, portraitIcon, portraitStatusIcon, portraitDesc);
    }

    public void setStyle(int style, int portraitIcon, int portraitStatusIcon, String portraitDesc) {
        if (style < TITLE_ONLY || style > TITLE_DRAWER) {
            return;
        }
        mStyle = style;
        if (portraitIcon > 0) {
            mIvPortrait.setVisibility(VISIBLE);
            mIvPortrait.setImageResource(portraitIcon);
        }

        if (portraitStatusIcon > 0) {
            mIvPortraitStatus.setVisibility(VISIBLE);
            mIvPortraitStatus.setImageResource(portraitStatusIcon);
        } else {
            mIvPortraitStatus.setVisibility(GONE);
        }

        if (!TextUtils.isEmpty(portraitDesc)) {
            mTvPortraitDesc.setVisibility(VISIBLE);
            mTvPortraitDesc.setText(portraitDesc);
        } else {
            mTvPortraitDesc.setVisibility(GONE);

            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ContextUtils.dp2px(mIvPortrait.getContext(), 32),
                    ContextUtils.dp2px(mIvPortrait.getContext(), 32));
            params.setMargins(0, 0, 0, 0);
            mIvPortrait.setLayoutParams(params);
        }

        switch (mStyle) {
            case TITLE_ONLY:
                mClPortrait.setBackgroundResource(R.drawable.bg_grey_rect_background_radius_20);
                mDrawerContainer.setVisibility(GONE);
                break;

            case TITLE_TAB:
                mClPortrait.setBackground(null);
                mDrawerContainer.setVisibility(GONE);
                break;

            case TITLE_DRAWER:
                mIvPortrait.setVisibility(GONE);
                mIvPortraitStatus.setVisibility(GONE);
                mDrawerContainer.setVisibility(VISIBLE);
                break;

            default:
                break;
        }
    }

    public void setStyle(int style) {
        setStyle(style, portraitIcon, portraitStatusIcon, portraitDesc);
    }

    public void setClPortraitClickListener(View.OnClickListener clickListener) {
        mClPortrait.setOnClickListener(clickListener);
    }

    public View getClPortrait() {
        return mClPortrait;
    }

    public CircleImageView getIvPortrait() {
        return mIvPortrait;
    }

    public ImageView getIvPortraitRedDot() {
        return mIvPortraitRedDot;
    }

    public ImageView getIvPortraitDescRedDot() {
        return mIvPortraitDescRedDot;
    }

    public TextView getTvPortraitDesc() {
        return mTvPortraitDesc;
    }

    public ImageView getIvPortraitStatus() {
        return mIvPortraitStatus;
    }

    public void setPortraitRedDot(boolean visible) {
        // 兼容老模式下的红点显示
        if (mStyle == TITLE_DRAWER) {
            setDrawerRedPointVisible(visible);
        } else {
            mIvPortraitRedDot.setVisibility(visible ? VISIBLE : GONE);
        }
    }

    public void setPortraitFunctionDrawable(Drawable resId) {
        mIvPortraitFunction.setVisibility(VISIBLE);
        mIvPortraitFunction.setImageDrawable(resId);
    }

    public void setPortraitDescRedDot(boolean visible) {
        if (mStyle == TITLE_DRAWER) {
            setDrawerRedPointVisible(visible);
        } else {
            mIvPortraitDescRedDot.setVisibility(visible ? VISIBLE : GONE);
        }
    }

    public void setIvPortrait(View.OnClickListener clickListener) {
        mIvPortrait.setOnClickListener(clickListener);
    }

    public void setDrawerClickListener(View.OnClickListener clickListener) {
        mDrawerContainer.setOnClickListener(clickListener);
    }

    public void setPortraitDropDownListener(View.OnClickListener clickListener) {
        mIvPortraitDropDown.setOnClickListener(clickListener);
    }

    public void setPortraitDropDownVisible(boolean visible) {
        mIvPortraitDropDown.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setDrawerRedPointVisible(boolean visible) {
        mIvDrawerRedPoint.setVisibility(visible ? VISIBLE : GONE);
    }

    public void setPortraitDropDownStatus(boolean isDropDown) {
        mIvPortraitDropDown.setImageResource(isDropDown ? R.drawable.ic_drop_down :
                R.drawable.ic_drop_up);
    }

    public boolean isPortraitDropDownVisible() {
        return mIvPortraitDropDown.getVisibility() == VISIBLE;
    }

    public int getStyle() {
        return mStyle;
    }


    public LinearLayout getTabContainer() {
        return mTabContainer;
    }

    public ConstraintLayout getDrawerContainer() {
        return mDrawerContainer;
    }

    public ImageView getIvPortraitDropDown() {
        return mIvPortraitDropDown;
    }

    public ImageView getIvDrawerRedPoint() {
        return mIvDrawerRedPoint;
    }

    public ImageView getIvPortraitFunction() {
        return mIvPortraitFunction;
    }

    public void addTabContainer(View view) {
        mTabContainer.setVisibility(View.VISIBLE);
        mTabContainer.addView(view);
    }
}
