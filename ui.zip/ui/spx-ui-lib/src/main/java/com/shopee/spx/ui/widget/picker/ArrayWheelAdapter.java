package com.shopee.spx.ui.widget.picker;

/**
 * Numeric Wheel adapter.
 */
public class ArrayWheelAdapter implements WheelAdapter<String> {

    private String[] mValues;

    /**
     * Constructor
     *
     * @param array the values display in wheel
     */
    public ArrayWheelAdapter(String[] array) {
        mValues = array;
    }


    @Override
    public String getItem(int index) {
        if (index >= 0 && index < mValues.length) {
            return mValues[index];
        }
        return "";
    }

    @Override
    public String getDisplayText(int index) {
        if (index >= 0 && index < mValues.length) {
            return mValues[index];
        }
        return "";
    }

    @Override
    public int indexOf(String o) {
        for (int i = 0; i < mValues.length; i++) {
            if (mValues[i].equals(o)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int getItemCount() {
        return mValues.length;
    }

}
