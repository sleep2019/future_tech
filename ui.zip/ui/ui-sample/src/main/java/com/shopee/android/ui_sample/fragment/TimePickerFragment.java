package com.shopee.android.ui_sample.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.shopee.android.ui.widget.picker.TimePickerItemView;
import com.shopee.android.ui.widget.picker.TimePickerView;
import com.shopee.android.ui_library.widget.button.CustomOneButton;
import com.shopee.android.ui_sample.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class TimePickerFragment extends Fragment {
    public static final int ONE_DAY_SECOND = 24 * 60 * 60;
    public static final String TIME_ZONE_UTC = "UTC";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_time_picker, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final TimePickerItemView timePickerItemView = view.findViewById(R.id.time_picker);
        CustomOneButton btnConfirm = view.findViewById(R.id.btn_confirm);

        timePickerItemView
                .setPickerType(TimePickerView.PICKER_TYPE_YEAR_MONTH_DAY)
                .setRange(2019, 2020)
                .setWheelMaxItems(5)
                .setTextSizeCenter(18)
                .setTextSizeOut(16)
                .setTextColorOut(getResources().getColor(R.color.txt_gray_8C9AAB))
                .setDate(new Date(System.currentTimeMillis()))
                .show();


        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String time = timePickerItemView.getTime();
                Log.d("TimePickerFragment", "time=" + time);
                Log.d("TimePickerFragment", "UTCDaySecond=" + getUTCDaySecond(time));
            }
        });
    }

    public static long getUTCDaySecond(String dateStr) {
        if (TextUtils.isEmpty(dateStr)) {
            return 0;
        }
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD, Locale.getDefault());
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_UTC));
            Date date = simpleDateFormat.parse(dateStr);
            long time = (date.getTime() / 1000);//转成秒
            return time;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

}
