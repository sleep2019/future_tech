package com.shopee.android.ui_sample;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-10-10.
 */
public class TestUiSecondActivity extends FragmentActivity {

    private static final String KEY_SECOND_TYPE = "key_second_type";
    public static final int TYPE_BASIC = 100;      // 基础
    public static final int TYPE_FORM = 200;       // 表单
    public static final int TYPE_FEEDBACK = 300;   // 操作反馈
    public static final int TYPE_NAVIGATION = 400; // 导航
    public static final int TYPE_BUSINESS = 500;   // 业务控件
    public static final int TYPE_TIME_PICKER = 600;   // 时间选择控件

    public static boolean navigate(Context context, int type) {
        switch (type) {
//            case TYPE_BASIC:
//            case TYPE_FORM:
//            case TYPE_FEEDBACK:
//            case TYPE_NAVIGATION:
            case TYPE_BUSINESS:
            case TYPE_TIME_PICKER:
                Intent intent = new Intent(context, TestUiSecondActivity.class);
                intent.putExtra(KEY_SECOND_TYPE, type);
                context.startActivity(intent);
                return true;
            default:
                return false;
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_ui_sub);
        int type = getIntent().getIntExtra(KEY_SECOND_TYPE, TYPE_BASIC);
        ((TextView) findViewById(R.id.tv_header)).setText(getTitleByType(type));
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setAdapter(new PdaUiSecondAdapter(getUiListByType(type)));
    }

    private String getTitleByType(int type) {
        switch (type) {
            case TYPE_FORM:
                return "表单";
            case TYPE_FEEDBACK:
                return "操作反馈 / Feedback";
            case TYPE_NAVIGATION:
                return "导航 / Navigation";
            case TYPE_BUSINESS:
                return "业务控件";
            case TYPE_TIME_PICKER:
                return "时间选择";
            case TYPE_BASIC:
            default:
                return "基础";
        }
    }

    private List<Pair<String, Integer>> getUiListByType(int type) {
        List<Pair<String, Integer>> result = new ArrayList<>();
        switch (type) {
            case TYPE_BASIC:
                result.add(Pair.create("颜色 color", TestUiThirdActivity.TYPE_BASIC_COLOR));
                result.add(Pair.create("图标 icon", TestUiThirdActivity.TYPE_BASIC_ICON));
                result.add(Pair.create("字体 font", TestUiThirdActivity.TYPE_BASIC_FONT));
                result.add(Pair.create("按钮 button", TestUiThirdActivity.TYPE_BASIC_BUTTON));
                result.add(Pair.create("插图 illustration", TestUiThirdActivity.TYPE_BASIC_ILLUSTRATION));
                break;
            case TYPE_FORM:
                result.add(Pair.create("输入框 input", TestUiThirdActivity.TYPE_FORM_INPUT));
                result.add(Pair.create("单选框 radio", TestUiThirdActivity.TYPE_FORM_RADIO));
                result.add(Pair.create("复选框 checkbox", TestUiThirdActivity.TYPE_FORM_CHECKBOX));
                result.add(Pair.create("开关 switch", TestUiThirdActivity.TYPE_FORM_SWITCH));
                result.add(Pair.create("多行文本框 textarea", TestUiThirdActivity.TYPE_FORM_TEXT_AREA));
                result.add(Pair.create("选择器 picker", TestUiThirdActivity.TYPE_FORM_PICKER));
                result.add(Pair.create("列表 list", TestUiThirdActivity.TYPE_FORM_LIST));
                break;
            case TYPE_FEEDBACK:
                result.add(Pair.create("加载 Loading", TestUiThirdActivity.TYPE_FEEDBACK_LOADING));
                result.add(Pair.create("动作面板 ActionSheet", TestUiThirdActivity.TYPE_FEEDBACK_ACTION_SHEET));
                result.add(Pair.create("轻提示 Toast", TestUiThirdActivity.TYPE_FEEDBACK_TOAST));
                result.add(Pair.create("对话框 Modal", TestUiThirdActivity.TYPE_FEEDBACK_MODAL));
                break;
            case TYPE_NAVIGATION:
                result.add(Pair.create("导航栏 NavBar", TestUiThirdActivity.TYPE_NAVIGATION_TITLE_BAR));
                result.add(Pair.create("宫格 Grid", TestUiThirdActivity.TYPE_NAVIGATION_GRID));
                result.add(Pair.create("标签页 Tab", TestUiThirdActivity.TYPE_NAVIGATION_TAB));
                break;
            case TYPE_BUSINESS:
                result.add(Pair.create("文本显示Item", TestUiThirdActivity.TYPE_BUSINESS_ITEM_COMPONENT));
                result.add(Pair.create("按钮", TestUiThirdActivity.TYPE_BUSINESS_CUSTOM_ONE_BUTTON));
                result.add(Pair.create("空视图", TestUiThirdActivity.TYPE_BUSINESS_EMPTY_VIEW));
                result.add(Pair.create("自定义Tablayout", TestUiThirdActivity.TYPE_BUSINESS_CUSTOM_TABLAYOUT));
                break;
            case TYPE_TIME_PICKER:
                result.add(Pair.create("时间选择", TestUiThirdActivity.TYPE_TIME_PICKER));
                break;
            default:
                break;
        }
        return result;
    }


    static class PdaUiSecondAdapter extends BaseQuickAdapter<Pair<String, Integer>, BaseViewHolder> {

        public PdaUiSecondAdapter(@Nullable List<Pair<String, Integer>> data) {
            super(R.layout.item_debug_list, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, final Pair<String, Integer> item) {
            helper.setText(R.id.tv_title, item.first);
            helper.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TestUiThirdActivity.navigate(v.getContext(), item.second);
                }
            });
        }
    }
}
