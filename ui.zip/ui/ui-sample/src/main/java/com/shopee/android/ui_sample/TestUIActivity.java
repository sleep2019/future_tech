package com.shopee.android.ui_sample;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by honggang.xiong on 2019-09-18.
 */
public class TestUIActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_ui);
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setAdapter(new PdaUiAdapter(getUiList()));
    }

    private List<PdaUiItem> getUiList() {
        List<PdaUiItem> result = new ArrayList<>();
//        result.add(new PdaUiItem("基础", "包含颜色、文本、图标等", TestUiSecondActivity.TYPE_BASIC));
//        result.add(new PdaUiItem("表单", "包含输入框、单选框、复选框、列表等", TestUiSecondActivity.TYPE_FORM));
//        result.add(new PdaUiItem("操作反馈", "包含对话框、轻提示、动作面板等", TestUiSecondActivity.TYPE_FEEDBACK));
//        result.add(new PdaUiItem("导航", "包含导航栏、分页器、抽屉等", TestUiSecondActivity.TYPE_NAVIGATION));
        result.add(new PdaUiItem("业务控件", "包含SKU商品卡、扫码计数、条码数据等", TestUiSecondActivity.TYPE_BUSINESS));
        result.add(new PdaUiItem("时间选择控件", "时间选择", TestUiSecondActivity.TYPE_TIME_PICKER));
        return result;
    }


    static class PdaUiItem {
        String title;
        String content;
        int type;

        public PdaUiItem(String title, String content, int type) {
            this.title = title;
            this.content = content;
            this.type = type;
        }
    }

    static class PdaUiAdapter extends BaseQuickAdapter<PdaUiItem, BaseViewHolder> {

        public PdaUiAdapter(@Nullable List<PdaUiItem> data) {
            super(R.layout.item_pda_ui, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, final PdaUiItem item) {
            helper.setText(R.id.tv_title, item.title);
            helper.setText(R.id.tv_content, item.content);
            helper.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!TestUiSecondActivity.navigate(v.getContext(), item.type)) {
                        Toast.makeText(mContext, "To Be Continued", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

}
