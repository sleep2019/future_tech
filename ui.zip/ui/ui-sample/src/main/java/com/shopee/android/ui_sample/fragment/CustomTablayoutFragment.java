package com.shopee.android.ui_sample.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.shopee.android.ui_library.widget.tablayout.CustomTabLayout;
import com.shopee.android.ui_sample.R;

import java.util.ArrayList;
import java.util.List;

public class CustomTablayoutFragment extends Fragment {

    private CustomTabLayout mCustomTablayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_custom_tablayout, container, false);
        mCustomTablayout = (CustomTabLayout) view.findViewById(R.id.custom_tablayout);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        initView();
        super.onActivityCreated(savedInstanceState);
    }

    private void initView() {
        List<Fragment> fragmentList = new ArrayList<Fragment>();
        List<String> titleList = new ArrayList<String>();
        fragmentList.add(new EmptyLayoutFragment());
        fragmentList.add(new EmptyLayoutFragment());
        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());
//        fragmentList.add(new EmptyLayoutFragment());

        titleList.add("first");
        titleList.add("1133334555554444");
        titleList.add("third");
//        titleList.add("fourth");
//        titleList.add("fifth");
//        titleList.add("sixth");
//        titleList.add("seventh");
//        titleList.add("eighth");
//        titleList.add("ninth");
//        titleList.add("tenth");
//        titleList.add("eleventh");
//        titleList.add("twelfth");

        mCustomTablayout.initData(getChildFragmentManager(), fragmentList, titleList, 0);
        mCustomTablayout.setTabTitle(0, "newTitle");
    }
}
