package com.shopee.android.ui_sample;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.shopee.android.ui_sample.fragment.CustomOneButtonFragment;
import com.shopee.android.ui_sample.fragment.CustomTablayoutFragment;
import com.shopee.android.ui_sample.fragment.EmptyLayoutFragment;
import com.shopee.android.ui_sample.fragment.ItemComponentFragment;
import com.shopee.android.ui_sample.fragment.TimePickerFragment;

/**
 * Created by honggang.xiong on 2019-10-10.
 */
public class TestUiThirdActivity extends FragmentActivity {

    private static final String KEY_THIRD_TYPE = "key_third_type";
    public static final int TYPE_BASIC_COLOR = 101;         // 基础 - 颜色
    public static final int TYPE_BASIC_ICON = 102;          // 基础 - 图标
    public static final int TYPE_BASIC_FONT = 103;          // 基础 - 字体
    public static final int TYPE_BASIC_BUTTON = 104;        // 基础 - 按钮
    public static final int TYPE_BASIC_ILLUSTRATION = 105;  // 基础 - 插图

    public static final int TYPE_FORM_INPUT = 201;          // 表单 - 输入框
    public static final int TYPE_FORM_RADIO = 202;          // 表单 - 单选框
    public static final int TYPE_FORM_CHECKBOX = 203;       // 表单 - 复选框
    public static final int TYPE_FORM_SWITCH = 204;         // 表单 - 开关
    public static final int TYPE_FORM_TEXT_AREA = 205;      // 表单 - 多行文本框
    public static final int TYPE_FORM_PICKER = 206;         // 表单 - 选择器
    public static final int TYPE_FORM_LIST = 207;           // 表单 - 列表

    public static final int TYPE_FEEDBACK_LOADING = 301;           // 操作反馈 - 加载
    public static final int TYPE_FEEDBACK_ACTION_SHEET = 302;      // 操作反馈 - 动作面板
    public static final int TYPE_FEEDBACK_TOAST = 303;             // 操作反馈 - 轻提示
    public static final int TYPE_FEEDBACK_MODAL = 304;             // 操作反馈 - 对话框

    public static final int TYPE_NAVIGATION_TITLE_BAR = 401;       // 导航 - 导航栏
    public static final int TYPE_NAVIGATION_GRID = 402;            // 导航 - 宫格
    public static final int TYPE_NAVIGATION_TAB = 403;             // 导航 - 标签页

    public static final int TYPE_BUSINESS_ITEM_COMPONENT = 501;         // 业务控件--文本显示item
    public static final int TYPE_BUSINESS_CUSTOM_ONE_BUTTON = 502;         //业务控件--按钮
    public static final int TYPE_BUSINESS_EMPTY_VIEW = 503;         //业务控件--空的view
    public static final int TYPE_BUSINESS_CUSTOM_TABLAYOUT = 504;         //业务控件--自定义的tablayout

    public static final int TYPE_TIME_PICKER = 601;         //时间选择


    public static void navigate(Context context, int thirdType) {
        Intent intent = new Intent(context, TestUiThirdActivity.class);
        intent.putExtra(KEY_THIRD_TYPE, thirdType);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_ui_third);
        Fragment baseFragment = (Fragment) getSupportFragmentManager().findFragmentById(R.id.content_container);
        if (baseFragment == null) {
            int thirdType = getIntent().getIntExtra(KEY_THIRD_TYPE, TYPE_BASIC_COLOR);
            baseFragment = generateFragment(thirdType);
            if (baseFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.content_container, baseFragment)
                        .commit();
            }
        }
    }

    private Fragment generateFragment(int thirdType) {
        switch (thirdType) {
            case TYPE_BUSINESS_ITEM_COMPONENT:
                return new ItemComponentFragment();
            case TYPE_BUSINESS_CUSTOM_ONE_BUTTON:
                return new CustomOneButtonFragment();
            case TYPE_BUSINESS_EMPTY_VIEW:
                return new EmptyLayoutFragment();
            case TYPE_BUSINESS_CUSTOM_TABLAYOUT:
                return new CustomTablayoutFragment();
            case TYPE_TIME_PICKER:
                return new TimePickerFragment();

        }
        return null;
    }

}
