package com.shopee.sc.calendarview.sample.pager;

import androidx.recyclerview.widget.LinearLayoutManager;

import com.shopee.sc.calendarview.sample.Article;
import com.shopee.sc.calendarview.sample.ArticleAdapter;
import com.shopee.sc.calendarview.sample.R;
import com.shopee.sc.calendarview.sample.base.fragment.BaseFragment;
import com.shopee.sc.calendarview.sample.group.GroupItemDecoration;
import com.shopee.sc.calendarview.sample.group.GroupRecyclerView;

public class PagerFragment extends BaseFragment {

    private GroupRecyclerView mRecyclerView;


    static PagerFragment newInstance() {
        return new PagerFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_pager;
    }

    @Override
    protected void initView() {
        mRecyclerView = mRootView.findViewById(R.id.recyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.addItemDecoration(new GroupItemDecoration<String, Article>());
        mRecyclerView.setAdapter(new ArticleAdapter(mContext));
        mRecyclerView.notifyDataSetChanged();
    }

    @Override
    protected void initData() {

    }

    boolean isScrollTop() {
        return mRecyclerView != null && mRecyclerView.computeVerticalScrollOffset() == 0;
    }
}
