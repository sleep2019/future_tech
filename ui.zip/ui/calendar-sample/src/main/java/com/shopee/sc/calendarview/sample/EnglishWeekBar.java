package com.shopee.sc.calendarview.sample;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.widget.TextView;

import com.shopee.sc.ui.calendar.CalendarBean;
import com.shopee.sc.ui.calendar.WeekBar;

/**
 * 自定义英文栏
 */
public class EnglishWeekBar extends WeekBar {

    private int mPreSelectedIndex;

    public EnglishWeekBar(Context context) {
        super(context);
    }

    @Override
    protected void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.cv_week_bar, this, true);
        mTvWeeks = new TextView[7];
        for (int i = 0; i < 7; i++) {
            mTvWeeks[i] = (TextView) getChildAt(i);
        }
        setBackgroundColor(Color.WHITE);
        int padding = dipToPx(context, 10);
        setPadding(padding, 0, padding, 0);
    }

    @Override
    protected void onDateSelected(CalendarBean calendar, int weekStart, boolean isClick) {
        getChildAt(mPreSelectedIndex).setSelected(false);
        int viewIndex = getViewIndexByCalendar(calendar, weekStart);
        getChildAt(viewIndex).setSelected(true);
        mPreSelectedIndex = viewIndex;
    }

    @Override
    protected void updateWeekLabels(int weekStart) {
        String[] weeks = getContext().getResources().getStringArray(R.array.english_week_string_array);
        for (int i = 0; i < 7; i++) {
            mWeekLabels[i] = weeks[(weekStart + i - 1) % 7];
        }
    }

    /**
     * dp转px
     *
     * @param context context
     * @param dpValue dp
     * @return px
     */
    private static int dipToPx(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
