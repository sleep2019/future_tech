package com.shopee.sc.calendarview.sample.solay;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.TextView;

import com.shopee.sc.ui.calendar.WeekBar;
import com.shopee.sc.calendarview.sample.R;

/**
 * 自定义英文栏
 */

public class SolarWeekBar extends WeekBar {

    public SolarWeekBar(Context context) {
        super(context);
    }

    @Override
    protected void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.solar_week_bar, this, true);
        setBackgroundColor(context.getResources().getColor(R.color.solar_background));
        mTvWeeks = new TextView[7];
        for (int i = 0; i < 7; i++) {
            mTvWeeks[i] = (TextView) getChildAt(i);
        }
    }


    @Override
    protected void updateWeekLabels(int weekStart) {
        String[] weeks = getContext().getResources().getStringArray(R.array.english_week_string_array);
        for (int i = 0; i < 7; i++) {
            mWeekLabels[i] = weeks[(weekStart + i - 1) % 7];
        }
    }

}
