package com.shopee.sc.calendarview.sample.index;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.NonNull;

import com.shopee.sc.ui.calendar.BaseMonthWeekPainter;
import com.shopee.sc.ui.calendar.CalendarBean;

/**
 * 下标标记的日历控件
 */

public class IndexMonthView extends BaseMonthWeekPainter {
    private Paint mSchemeBasicPaint = new Paint();
    private int mPadding;
    private int mH, mW;

    public IndexMonthView(Context context) {
        super(context);

        mSchemeBasicPaint.setAntiAlias(true);
        mSchemeBasicPaint.setStyle(Paint.Style.FILL);
        mSchemeBasicPaint.setTextAlign(Paint.Align.CENTER);
        mSchemeBasicPaint.setColor(0xff333333);
        mSchemeBasicPaint.setFakeBoldText(true);
        mPadding = dipToPx(context, 4);
        mH = dipToPx(context, 2);
        mW = dipToPx(context, 8);
    }

    @Override
    protected boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {
        mSelectedBgPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(x + mPadding, y + mPadding, x + mItemWidth - mPadding, y + mItemHeight - mPadding, mSelectedBgPaint);
        return true;
    }

    @Override
    protected void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean calendar, int x, int y, boolean isSelected) {
        mSchemeBasicPaint.setColor(calendar.getSchemeColor());
        canvas.drawRect(x + mItemWidth / 2 - mW / 2,
                y + mItemHeight - mH * 2 - mPadding,
                x + mItemWidth / 2 + mW / 2,
                y + mItemHeight - mH - mPadding, mSchemeBasicPaint);
    }

    @SuppressWarnings("IntegerDivisionInFloatingPointContext")
    @Override
    protected void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean calendar, int x, int y, boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected) {
        int cx = x + mItemWidth / 2;
        int top = y - mItemHeight / 6;
        boolean isCurrentDay = isCurrentDay(calendar);
        if (hasScheme) {
            canvas.drawText(String.valueOf(calendar.getDay()), cx, mTextBaseLine + top,
                    isCurrentDay ? mCurDayTextPaint :
                            isInCurrentMonthCard ? mSchemeTextPaint : mOtherMonthTextPaint);

            canvas.drawText(calendar.getFestival(), cx, mTextBaseLine + y + mItemHeight / 10,
                    isCurrentDay ? mCurDayFestivalPaint :
                            mCurMonthFestivalPaint);

        } else {
            canvas.drawText(String.valueOf(calendar.getDay()), cx, mTextBaseLine + top,
                    isCurrentDay ? mCurDayTextPaint :
                            isInCurrentMonthCard ? mCurMonthTextPaint : mOtherMonthTextPaint);
            canvas.drawText(calendar.getFestival(), cx, mTextBaseLine + y + mItemHeight / 10, mCurMonthFestivalPaint);
        }
    }

    /**
     * dp转px
     *
     * @param context context
     * @param dpValue dp
     * @return px
     */
    private static int dipToPx(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
