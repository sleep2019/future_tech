package com.shopee.sc.calendarview.sample.simple;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.NonNull;

import com.shopee.sc.ui.calendar.BaseMonthWeekPainter;
import com.shopee.sc.ui.calendar.CalendarBean;

/**
 * 高仿魅族日历布局
 */

public class SimpleMonthView extends BaseMonthWeekPainter {

    private int mRadius;

    public SimpleMonthView(Context context) {
        super(context);
        //兼容硬件加速无效的代码
//        setLayerType(View.LAYER_TYPE_SOFTWARE,mSelectedPaint);
        //4.0以上硬件加速会导致无效
        mSelectedBgPaint.setMaskFilter(new BlurMaskFilter(25, BlurMaskFilter.Blur.SOLID));
    }

    @Override
    protected void onPreviewHook(int itemHeight, int itemWidth, float textBaseLine) {
        super.onPreviewHook(itemHeight, itemWidth, textBaseLine);
        mRadius = Math.min(mItemWidth, mItemHeight) / 5 * 2;
        mSchemeBgPaint.setStyle(Paint.Style.STROKE);
    }

    @Override
    protected void onLoopStart(int x, int y) {

    }

    @Override
    protected boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {
        int cx = x + mItemWidth / 2;
        int cy = y + mItemHeight / 2;
        canvas.drawCircle(cx, cy, mRadius, mSelectedBgPaint);
        return false;
    }

    @Override
    protected void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean isSelected) {
        int cx = x + mItemWidth / 2;
        int cy = y + mItemHeight / 2;
        canvas.drawCircle(cx, cy, mRadius, mSchemeBgPaint);
    }

    @Override
    protected void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean calendar, int x, int y, boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected) {
        float baselineY = mTextBaseLine + y;
        int cx = x + mItemWidth / 2;

        boolean isCurrentDay = isCurrentDay(calendar);
        if (isSelected) {
            canvas.drawText(String.valueOf(calendar.getDay()),
                    cx,
                    baselineY,
                    mSelectedTextPaint);
        } else if (hasScheme) {
            canvas.drawText(String.valueOf(calendar.getDay()),
                    cx,
                    baselineY,
                    isCurrentDay ? mCurDayTextPaint :
                            isInCurrentMonthCard ? mSchemeTextPaint : mOtherMonthTextPaint);

        } else {
            canvas.drawText(String.valueOf(calendar.getDay()), cx, baselineY,
                    isCurrentDay ? mCurDayTextPaint :
                            isInCurrentMonthCard ? mCurMonthTextPaint : mOtherMonthTextPaint);
        }
    }
}
