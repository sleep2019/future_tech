package com.shopee.sc.calendarview.sample.custom;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.TextView;

import com.shopee.sc.ui.calendar.CalendarBean;
import com.shopee.sc.ui.calendar.WeekBar;
import com.shopee.sc.calendarview.sample.R;

/**
 * 自定义英文栏
 */
public class CustomWeekBar extends WeekBar {

    private int mPreSelectedIndex;

    public CustomWeekBar(Context context) {
        super(context);
    }

    @Override
    protected void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.custom_week_bar, this, true);
        mTvWeeks = new TextView[7];
        for (int i = 0; i < 7; i++) {
            mTvWeeks[i] = (TextView) getChildAt(i);
        }
    }

    @Override
    protected void onDateSelected(CalendarBean bean, int weekStart, boolean isClick) {
        getChildAt(mPreSelectedIndex).setSelected(false);
        int viewIndex = getViewIndexByCalendar(bean, weekStart);
        getChildAt(viewIndex).setSelected(true);
        mPreSelectedIndex = viewIndex;
    }

    @Override
    protected void updateWeekLabels(int weekStart) {
        String[] weeks = getContext().getResources().getStringArray(R.array.chinese_week_string_array);
        for (int i = 0; i < 7; i++) {
            mWeekLabels[i] = weeks[(weekStart + i - 1) % 7];
        }
    }

}
