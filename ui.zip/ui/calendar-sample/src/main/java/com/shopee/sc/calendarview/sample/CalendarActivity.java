package com.shopee.sc.calendarview.sample;

import android.content.Context;
import android.content.Intent;

import com.shopee.sc.calendarview.sample.base.activity.BaseActivity;

/**
 * Only calendar
 */
public class CalendarActivity extends BaseActivity {

    public static void show(Context context) {
        context.startActivity(new Intent(context, CalendarActivity.class));
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_calendar;
    }

    @Override
    protected void initView() {
        setStatusBarDarkMode();
    }

    @Override
    protected void initData() {

    }
}
