package com.shopee.sc.calendarview.sample;

import android.app.Application;

import com.shopee.spx.ui.helper.UIMatchingHelper;

/**
 * Created by honggang.xiong on 2021/6/8.
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        UIMatchingHelper.setup(this);
        UIMatchingHelper.register(this, 360, UIMatchingHelper.MATCH_BASE_WIDTH);
    }
}
