package com.shopee.sc.calendarview.sample.single;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.NonNull;

import com.shopee.sc.ui.calendar.BaseMonthWeekPainter;
import com.shopee.sc.ui.calendar.CalendarBean;

/**
 * 高仿魅族日历布局
 */

public class SingleMonthView extends BaseMonthWeekPainter {

    private int mRadius;
    private Paint mRingPaint = new Paint();
    private int mRingRadius;

    /**
     * 不可用画笔
     */
    private Paint mDisablePaint = new Paint();

    private int mH;
    private Context mContext;

    public Context getContext() {
        return mContext;
    }

    public SingleMonthView(Context context) {
        super(context);

        mContext = context;
        //兼容硬件加速无效的代码
//        setLayerType(View.LAYER_TYPE_SOFTWARE, mSelectedPaint);
        //4.0以上硬件加速会导致无效
        mSelectedBgPaint.setMaskFilter(new BlurMaskFilter(30, BlurMaskFilter.Blur.SOLID));

//        setLayerType(View.LAYER_TYPE_SOFTWARE, mSchemePaint);
        mSchemeBgPaint.setMaskFilter(new BlurMaskFilter(30, BlurMaskFilter.Blur.SOLID));

        mRingPaint.setAntiAlias(true);
        mRingPaint.setColor(mSchemeBgPaint.getColor());
        mRingPaint.setStyle(Paint.Style.STROKE);
        mRingPaint.setStrokeWidth(dipToPx(context, 1));
//        setLayerType(View.LAYER_TYPE_SOFTWARE, mRingPaint);
        mRingPaint.setMaskFilter(new BlurMaskFilter(30, BlurMaskFilter.Blur.SOLID));

        mDisablePaint.setColor(0xFF9f9f9f);
        mDisablePaint.setAntiAlias(true);
        mDisablePaint.setStrokeWidth(dipToPx(context, 2));
        mDisablePaint.setFakeBoldText(true);

        mH = dipToPx(context, 18);

    }

    @Override
    protected void onPreviewHook(int itemHeight, int itemWidth, float textBaseLine) {
        super.onPreviewHook(itemHeight, itemWidth, textBaseLine);
        mRadius = Math.min(mItemWidth, mItemHeight) / 6 * 2;
        mRingRadius = Math.min(mItemWidth, mItemHeight) / 5 * 2;
        mSelectedTextPaint.setTextSize(dipToPx(getContext(), 17));
    }


    @Override
    protected boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {

        int cx = x + mItemWidth / 2;
        int cy = y + mItemHeight / 2;

        canvas.drawCircle(cx, cy, mRadius, mSelectedBgPaint);
        canvas.drawCircle(cx, cy, mRingRadius, mRingPaint);

        return true;
    }

    @Override
    protected void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean isSelected) {

//        int cx = x + mItemWidth / 2;
//        int cy = y + mItemHeight / 2;
        //canvas.drawCircle(cx, cy, mRadius, mSchemePaint);
    }

    @Override
    protected void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean calendar, int x, int y, boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected) {
        float baselineY = mTextBaseLine + y - dipToPx(getContext(), 1);
        int cx = x + mItemWidth / 2;
        boolean isCurrentDay = isCurrentDay(calendar);
        if (isSelected) {
            canvas.drawText(isCurrentDay ? "今" : "选",
                    cx,
                    baselineY,
                    mSelectedTextPaint);
        } else if (hasScheme) {
            canvas.drawText(isCurrentDay ? "今" : String.valueOf(calendar.getDay()),
                    cx,
                    baselineY,
                    isCurrentDay ? mCurDayTextPaint :
                            isInCurrentMonthCard ? mSchemeTextPaint : mOtherMonthTextPaint);

        } else {
            canvas.drawText(isCurrentDay ? "今" : String.valueOf(calendar.getDay()),
                    cx,
                    baselineY,
                    isCurrentDay ? mCurDayTextPaint :
                            isInCurrentMonthCard ? mCurMonthTextPaint : mOtherMonthTextPaint);
        }

        //日期是否可用？拦截
        if (isCalendarIntercepted(calendar)) {
            canvas.drawLine(x + mH, y + mH, x + mItemWidth - mH, y + mItemHeight - mH, mDisablePaint);
        }

    }


    /**
     * dp转px
     *
     * @param context context
     * @param dpValue dp
     * @return px
     */
    private static int dipToPx(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
