package com.shopee.sc.calendarview.sample.lunar;

import android.text.TextUtils;

import com.shopee.sc.ui.calendar.BaseSubCalendarBean;

/**
 * Created by honggang.xiong on 2020-03-06.
 */
public class LunarCalendarBean extends BaseSubCalendarBean {
    /**
     * 如果是闰月，则返回闰月
     */
    private int leapMonth;

    private int lunarYear;  // 农历年
    private int lunarMonth; // 农历月
    private int lunarDay;   // 农历日

    /**
     * 24节气
     */
    private String solarTerm;

    /**
     * 传统农历节日
     */
    private String traditionFestival;

    /**
     * 农历字符串，初一、初二等
     */
    private String lunar;

    public LunarCalendarBean(int gregorianYear, int gregorianMonth, int gregorianDay) {
        super(gregorianYear, gregorianMonth, gregorianDay);
    }

    @Override
    public void setupCalendar() {
        int year = solarYear;
        int month = solarMonth;
        int day = solarDay;

        int[] lunar = LunarUtil.solarToLunar(year, month, day);
        subYear = lunarYear = lunar[0];
        subMonth = lunarMonth = lunar[1];
        subDay = lunarDay = lunar[2];
        if (lunar[3] == 1) { // 如果是闰月
            leapMonth = lunarMonth;
        }
        String solarTerm = LunarCalendarUtil.getSolarTerm(year, month, day);
        String traditionFestival = LunarCalendarUtil.getTraditionFestival(lunar[0], lunar[1], lunar[2]);
        String lunarText = LunarCalendarUtil.numToChinese(lunar[1], lunar[2], lunar[3]);

        setSolarTerm(solarTerm);
        setTraditionFestival(traditionFestival);
        setLunar(lunarText);
    }

    public int getLeapMonth() {
        return leapMonth;
    }

    @Override
    public String getYearText() {
        return String.valueOf(lunarYear);
    }

    @Override
    public String getMonthText() {
        return String.valueOf(lunarMonth);
    }

    @Override
    public String getDayText() {
        return lunar;
    }

    public String getSolarTerm() {
        return solarTerm;
    }

    public void setSolarTerm(String solarTerm) {
        this.solarTerm = solarTerm;
    }

    public String getTraditionFestival() {
        return traditionFestival;
    }

    public void setTraditionFestival(String traditionFestival) {
        this.traditionFestival = traditionFestival;
    }

    public String getLunar() {
        return lunar;
    }

    public void setLunar(String lunar) {
        this.lunar = lunar;
    }

    @Override
    public String getFestival() {
        if (!TextUtils.isEmpty(solarTerm)) {
            return solarTerm;
        } else {
            return traditionFestival;
        }
    }

}
