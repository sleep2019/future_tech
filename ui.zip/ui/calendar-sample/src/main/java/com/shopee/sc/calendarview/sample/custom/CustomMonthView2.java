package com.shopee.sc.calendarview.sample.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.NonNull;

import com.shopee.sc.ui.calendar.BaseMonthWeekPainter;
import com.shopee.sc.ui.calendar.CalendarBean;

/**
 * CheckInHistory Calendar custom style.
 */
public class CustomMonthView2 extends BaseMonthWeekPainter {

    // 今天的背景色
    private Paint mCurrentDayPaint = new Paint();
    // 今天的背景半径
    private float mCurrentDayRadius;
    // 选中日背景半径
    private float mSelectedRadius;
    // 底部圆点半径
    private float mPointRadius;
    private int mPadding;

    public CustomMonthView2(Context context) {
        super(context);

        mCurrentDayPaint.setAntiAlias(true);
        mCurrentDayPaint.setStyle(Paint.Style.FILL);
        mCurrentDayPaint.setColor(0xFFFDE5E0);

        mPadding = dipToPx(context, 2);
        mPointRadius = dipToPx(context, 3);
    }

    @Override
    protected void onPreviewHook(int itemHeight, int itemWidth, float textBaseLine) {
        super.onPreviewHook(itemHeight, itemWidth, textBaseLine);
        mSelectedRadius = Math.min(mItemWidth, mItemHeight) / 11.0F * 5;
        mCurrentDayRadius = mSelectedRadius * 3 / 5;
    }

    @Override
    protected boolean onDrawSelectedBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {
        int cx = x + mItemWidth / 2;
        int cy = y + mItemHeight / 2;
        canvas.drawCircle(cx, cy, mSelectedRadius, mSelectedBgPaint);
        // 返回 false 时，选中状态不执行 onDrawScheme
        return true;
    }

    @Override
    protected void onDrawSchemeBg(@NonNull Canvas canvas, @NonNull CalendarBean bean, int x, int y, boolean isSelected) {
        // 未选中时，在底部绘制 scheme 指定颜色的圆点
        if (!isSelected) {
            canvas.drawCircle(x + mItemWidth / 2.0F, y + mItemHeight - 3 * mPadding, mPointRadius, mSchemeBgPaint);
        }
    }


    @Override
    protected void onDrawText(@NonNull Canvas canvas, @NonNull CalendarBean calendar, int x, int y,
                              boolean isInCurrentMonthCard, boolean hasScheme, boolean isSelected) {
        int cx = x + mItemWidth / 2;
        int cy = y + mItemHeight / 2;
        float baselineY = mTextBaseLine + y;

        boolean isCurrentDay = isCurrentDay(calendar);
        if (isCurrentDay && !isSelected) {
            canvas.drawCircle(cx, cy, mCurrentDayRadius, mCurrentDayPaint);
        }

        if (isSelected) {
            canvas.drawText(String.valueOf(calendar.getDay()), cx, baselineY, mSelectedTextPaint);
        } else if (hasScheme) {
            canvas.drawText(String.valueOf(calendar.getDay()), cx, baselineY,
                    isCurrentDay ? mCurDayTextPaint
                            : isInCurrentMonthCard ? mSchemeTextPaint : mOtherMonthTextPaint);
        } else {
            canvas.drawText(String.valueOf(calendar.getDay()), cx, baselineY,
                    isCurrentDay ? mCurDayTextPaint
                            : isInCurrentMonthCard ? mCurMonthTextPaint : mOtherMonthTextPaint);
        }
    }

    /**
     * dp转px
     *
     * @param context context
     * @param dpValue dp
     * @return px
     */
    private static int dipToPx(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
